--
-- PostgreSQL database dump
--

\restrict tfN9bsXahzmbh9PeiS3x1UsBY8l0BPNtvHEaJm3zusccEgFZhPYve2Y1v8pEbJX

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS '';


--
-- Name: enum__dietary_options_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__dietary_options_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__dietary_options_v_version_status OWNER TO postgres;

--
-- Name: enum__faqs_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__faqs_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__faqs_v_version_status OWNER TO postgres;

--
-- Name: enum__faqs_v_version_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__faqs_v_version_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum__faqs_v_version_workflow_status OWNER TO postgres;

--
-- Name: enum__food_items_v_version_allergens_allergen; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_allergens_allergen AS ENUM (
    'shellfish',
    'fish',
    'peanuts',
    'tree_nuts',
    'soy',
    'wheat',
    'eggs',
    'dairy',
    'sesame',
    'msg'
);


ALTER TYPE public.enum__food_items_v_version_allergens_allergen OWNER TO postgres;

--
-- Name: enum__food_items_v_version_availability; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_availability AS ENUM (
    'year_round',
    'seasonal',
    'festival',
    'weekend',
    'morning',
    'night'
);


ALTER TYPE public.enum__food_items_v_version_availability OWNER TO postgres;

--
-- Name: enum__food_items_v_version_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_category AS ENUM (
    'main',
    'snack',
    'dessert',
    'beverage',
    'coffee_tea',
    'juice',
    'traditional_drink',
    'condiment',
    'breakfast',
    'soup',
    'noodles',
    'rice',
    'grilled'
);


ALTER TYPE public.enum__food_items_v_version_category OWNER TO postgres;

--
-- Name: enum__food_items_v_version_flavor_profile_flavor; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_flavor_profile_flavor AS ENUM (
    'sweet',
    'sour',
    'salty',
    'umami',
    'bitter',
    'savory',
    'creamy',
    'tangy'
);


ALTER TYPE public.enum__food_items_v_version_flavor_profile_flavor OWNER TO postgres;

--
-- Name: enum__food_items_v_version_local_names_language; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_local_names_language AS ENUM (
    'ms',
    'zh',
    'hokkien',
    'cantonese',
    'ta',
    'en'
);


ALTER TYPE public.enum__food_items_v_version_local_names_language OWNER TO postgres;

--
-- Name: enum__food_items_v_version_origin; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_origin AS ENUM (
    'malay',
    'chinese',
    'indian',
    'peranakan',
    'thai',
    'indonesian',
    'fusion',
    'international'
);


ALTER TYPE public.enum__food_items_v_version_origin OWNER TO postgres;

--
-- Name: enum__food_items_v_version_preparation_method; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_preparation_method AS ENUM (
    'stir_fried',
    'steamed',
    'grilled',
    'deep_fried',
    'braised',
    'boiled',
    'raw',
    'fermented',
    'cured',
    'mixed'
);


ALTER TYPE public.enum__food_items_v_version_preparation_method OWNER TO postgres;

--
-- Name: enum__food_items_v_version_spice_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_spice_level AS ENUM (
    '0',
    '1',
    '2',
    '3',
    '4',
    '5'
);


ALTER TYPE public.enum__food_items_v_version_spice_level OWNER TO postgres;

--
-- Name: enum__food_items_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__food_items_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__food_items_v_version_status OWNER TO postgres;

--
-- Name: enum__stories_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__stories_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__stories_v_version_status OWNER TO postgres;

--
-- Name: enum__stories_v_version_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__stories_v_version_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum__stories_v_version_workflow_status OWNER TO postgres;

--
-- Name: enum__testimonials_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__testimonials_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__testimonials_v_version_status OWNER TO postgres;

--
-- Name: enum__testimonials_v_version_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__testimonials_v_version_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum__testimonials_v_version_workflow_status OWNER TO postgres;

--
-- Name: enum__tours_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__tours_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__tours_v_version_status OWNER TO postgres;

--
-- Name: enum__tours_v_version_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__tours_v_version_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum__tours_v_version_workflow_status OWNER TO postgres;

--
-- Name: enum__vendors_v_version_closed_on_day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_closed_on_day AS ENUM (
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday',
    'holiday'
);


ALTER TYPE public.enum__vendors_v_version_closed_on_day OWNER TO postgres;

--
-- Name: enum__vendors_v_version_cuisine_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_cuisine_type AS ENUM (
    'malay',
    'chinese',
    'indian',
    'peranakan',
    'thai',
    'indonesian',
    'western',
    'fusion',
    'mixed'
);


ALTER TYPE public.enum__vendors_v_version_cuisine_type OWNER TO postgres;

--
-- Name: enum__vendors_v_version_facilities_facility; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_facilities_facility AS ENUM (
    'aircon',
    'wifi',
    'parking',
    'wheelchair',
    'halal_cert',
    'prayer_room',
    'outdoor',
    'takeaway',
    'delivery',
    'reservations',
    'family'
);


ALTER TYPE public.enum__vendors_v_version_facilities_facility OWNER TO postgres;

--
-- Name: enum__vendors_v_version_location_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_location_state AS ENUM (
    'kl',
    'penang',
    'selangor',
    'melaka',
    'johor',
    'perak',
    'kelantan',
    'terengganu',
    'kedah',
    'pahang',
    'ns',
    'perlis',
    'sabah',
    'sarawak'
);


ALTER TYPE public.enum__vendors_v_version_location_state OWNER TO postgres;

--
-- Name: enum__vendors_v_version_operating_hours_day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_operating_hours_day AS ENUM (
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday',
    'holiday'
);


ALTER TYPE public.enum__vendors_v_version_operating_hours_day OWNER TO postgres;

--
-- Name: enum__vendors_v_version_payment_methods_method; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_payment_methods_method AS ENUM (
    'cash',
    'credit_card',
    'debit_card',
    'tng',
    'grabpay',
    'boost',
    'qr_pay',
    'online_banking'
);


ALTER TYPE public.enum__vendors_v_version_payment_methods_method OWNER TO postgres;

--
-- Name: enum__vendors_v_version_price_range; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_price_range AS ENUM (
    'budget',
    'moderate',
    'upscale',
    'fine_dining'
);


ALTER TYPE public.enum__vendors_v_version_price_range OWNER TO postgres;

--
-- Name: enum__vendors_v_version_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum__vendors_v_version_status OWNER TO postgres;

--
-- Name: enum__vendors_v_version_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum__vendors_v_version_type AS ENUM (
    'street_stall',
    'hawker_stall',
    'food_court',
    'kopitiam',
    'restaurant',
    'pasar_malam',
    'pasar_pagi',
    'home_kitchen',
    'food_truck',
    'heritage_shop'
);


ALTER TYPE public.enum__vendors_v_version_type OWNER TO postgres;

--
-- Name: enum_dietary_landing_pages_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_dietary_landing_pages_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_dietary_landing_pages_status OWNER TO postgres;

--
-- Name: enum_dietary_options_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_dietary_options_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_dietary_options_status OWNER TO postgres;

--
-- Name: enum_faqs_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_faqs_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_faqs_status OWNER TO postgres;

--
-- Name: enum_faqs_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_faqs_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum_faqs_workflow_status OWNER TO postgres;

--
-- Name: enum_food_items_allergens_allergen; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_allergens_allergen AS ENUM (
    'shellfish',
    'fish',
    'peanuts',
    'tree_nuts',
    'soy',
    'wheat',
    'eggs',
    'dairy',
    'sesame',
    'msg'
);


ALTER TYPE public.enum_food_items_allergens_allergen OWNER TO postgres;

--
-- Name: enum_food_items_availability; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_availability AS ENUM (
    'year_round',
    'seasonal',
    'festival',
    'weekend',
    'morning',
    'night'
);


ALTER TYPE public.enum_food_items_availability OWNER TO postgres;

--
-- Name: enum_food_items_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_category AS ENUM (
    'main',
    'snack',
    'dessert',
    'beverage',
    'coffee_tea',
    'juice',
    'traditional_drink',
    'condiment',
    'breakfast',
    'soup',
    'noodles',
    'rice',
    'grilled'
);


ALTER TYPE public.enum_food_items_category OWNER TO postgres;

--
-- Name: enum_food_items_flavor_profile_flavor; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_flavor_profile_flavor AS ENUM (
    'sweet',
    'sour',
    'salty',
    'umami',
    'bitter',
    'savory',
    'creamy',
    'tangy'
);


ALTER TYPE public.enum_food_items_flavor_profile_flavor OWNER TO postgres;

--
-- Name: enum_food_items_local_names_language; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_local_names_language AS ENUM (
    'ms',
    'zh',
    'hokkien',
    'cantonese',
    'ta',
    'en'
);


ALTER TYPE public.enum_food_items_local_names_language OWNER TO postgres;

--
-- Name: enum_food_items_origin; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_origin AS ENUM (
    'malay',
    'chinese',
    'indian',
    'peranakan',
    'thai',
    'indonesian',
    'fusion',
    'international'
);


ALTER TYPE public.enum_food_items_origin OWNER TO postgres;

--
-- Name: enum_food_items_preparation_method; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_preparation_method AS ENUM (
    'stir_fried',
    'steamed',
    'grilled',
    'deep_fried',
    'braised',
    'boiled',
    'raw',
    'fermented',
    'cured',
    'mixed'
);


ALTER TYPE public.enum_food_items_preparation_method OWNER TO postgres;

--
-- Name: enum_food_items_spice_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_spice_level AS ENUM (
    '0',
    '1',
    '2',
    '3',
    '4',
    '5'
);


ALTER TYPE public.enum_food_items_spice_level OWNER TO postgres;

--
-- Name: enum_food_items_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_food_items_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_food_items_status OWNER TO postgres;

--
-- Name: enum_location_landing_pages_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_location_landing_pages_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_location_landing_pages_status OWNER TO postgres;

--
-- Name: enum_media_coverage_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_media_coverage_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_media_coverage_status OWNER TO postgres;

--
-- Name: enum_redirects_to_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_redirects_to_type AS ENUM (
    'reference',
    'custom'
);


ALTER TYPE public.enum_redirects_to_type OWNER TO postgres;

--
-- Name: enum_specialty_landing_pages_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_specialty_landing_pages_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_specialty_landing_pages_status OWNER TO postgres;

--
-- Name: enum_stories_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_stories_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_stories_status OWNER TO postgres;

--
-- Name: enum_stories_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_stories_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum_stories_workflow_status OWNER TO postgres;

--
-- Name: enum_testimonials_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_testimonials_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_testimonials_status OWNER TO postgres;

--
-- Name: enum_testimonials_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_testimonials_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum_testimonials_workflow_status OWNER TO postgres;

--
-- Name: enum_thank_you_pages_cta_section_cta_buttons_variant; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_thank_you_pages_cta_section_cta_buttons_variant AS ENUM (
    'primary',
    'secondary'
);


ALTER TYPE public.enum_thank_you_pages_cta_section_cta_buttons_variant OWNER TO postgres;

--
-- Name: enum_thank_you_pages_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_thank_you_pages_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_thank_you_pages_status OWNER TO postgres;

--
-- Name: enum_thank_you_pages_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_thank_you_pages_type AS ENUM (
    'contact',
    'tour_inquiry',
    'feedback',
    'newsletter',
    'booking',
    'custom',
    'inquiry'
);


ALTER TYPE public.enum_thank_you_pages_type OWNER TO postgres;

--
-- Name: enum_tours_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_tours_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_tours_status OWNER TO postgres;

--
-- Name: enum_tours_workflow_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_tours_workflow_status AS ENUM (
    'draft',
    'in_review',
    'approved',
    'published'
);


ALTER TYPE public.enum_tours_workflow_status OWNER TO postgres;

--
-- Name: enum_translations_collection; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_translations_collection AS ENUM (
    'tours',
    'stories',
    'testimonials',
    'faqs',
    'media_coverage',
    'dietary_landing_pages',
    'specialty_landing_pages',
    'travel_type_landing_pages',
    'location_landing_pages',
    'home_page',
    'legal_pages'
);


ALTER TYPE public.enum_translations_collection OWNER TO postgres;

--
-- Name: enum_translations_locale; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_translations_locale AS ENUM (
    'en',
    'ms',
    'zh',
    'de',
    'es',
    'fr',
    'nl',
    'ja',
    'pt',
    'ru'
);


ALTER TYPE public.enum_translations_locale OWNER TO postgres;

--
-- Name: enum_translations_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_translations_status AS ENUM (
    'draft',
    'in_translation',
    'ready_for_review',
    'published'
);


ALTER TYPE public.enum_translations_status OWNER TO postgres;

--
-- Name: enum_travel_type_landing_pages_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_travel_type_landing_pages_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_travel_type_landing_pages_status OWNER TO postgres;

--
-- Name: enum_users_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_users_role AS ENUM (
    'admin',
    'editor',
    'translator',
    'reviewer'
);


ALTER TYPE public.enum_users_role OWNER TO postgres;

--
-- Name: enum_vendors_closed_on_day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_closed_on_day AS ENUM (
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday',
    'holiday'
);


ALTER TYPE public.enum_vendors_closed_on_day OWNER TO postgres;

--
-- Name: enum_vendors_cuisine_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_cuisine_type AS ENUM (
    'malay',
    'chinese',
    'indian',
    'peranakan',
    'thai',
    'indonesian',
    'western',
    'fusion',
    'mixed'
);


ALTER TYPE public.enum_vendors_cuisine_type OWNER TO postgres;

--
-- Name: enum_vendors_facilities_facility; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_facilities_facility AS ENUM (
    'aircon',
    'wifi',
    'parking',
    'wheelchair',
    'halal_cert',
    'prayer_room',
    'outdoor',
    'takeaway',
    'delivery',
    'reservations',
    'family'
);


ALTER TYPE public.enum_vendors_facilities_facility OWNER TO postgres;

--
-- Name: enum_vendors_location_state; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_location_state AS ENUM (
    'kl',
    'penang',
    'selangor',
    'melaka',
    'johor',
    'perak',
    'kelantan',
    'terengganu',
    'kedah',
    'pahang',
    'ns',
    'perlis',
    'sabah',
    'sarawak'
);


ALTER TYPE public.enum_vendors_location_state OWNER TO postgres;

--
-- Name: enum_vendors_operating_hours_day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_operating_hours_day AS ENUM (
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday',
    'holiday'
);


ALTER TYPE public.enum_vendors_operating_hours_day OWNER TO postgres;

--
-- Name: enum_vendors_payment_methods_method; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_payment_methods_method AS ENUM (
    'cash',
    'credit_card',
    'debit_card',
    'tng',
    'grabpay',
    'boost',
    'qr_pay',
    'online_banking'
);


ALTER TYPE public.enum_vendors_payment_methods_method OWNER TO postgres;

--
-- Name: enum_vendors_price_range; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_price_range AS ENUM (
    'budget',
    'moderate',
    'upscale',
    'fine_dining'
);


ALTER TYPE public.enum_vendors_price_range OWNER TO postgres;

--
-- Name: enum_vendors_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_vendors_status OWNER TO postgres;

--
-- Name: enum_vendors_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_vendors_type AS ENUM (
    'street_stall',
    'hawker_stall',
    'food_court',
    'kopitiam',
    'restaurant',
    'pasar_malam',
    'pasar_pagi',
    'home_kitchen',
    'food_truck',
    'heritage_shop'
);


ALTER TYPE public.enum_vendors_type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _contact_page_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._contact_page_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb,
    version_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false
);


ALTER TABLE public._contact_page_v OWNER TO postgres;

--
-- Name: _contact_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public._contact_page_v ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public._contact_page_v_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: _corporate_groups_page_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._corporate_groups_page_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb,
    version_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false
);


ALTER TABLE public._corporate_groups_page_v OWNER TO postgres;

--
-- Name: _corporate_groups_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public._corporate_groups_page_v ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public._corporate_groups_page_v_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: _dietary_options_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._dietary_options_v (
    id integer NOT NULL,
    parent_id integer,
    version_name character varying,
    version_slug character varying,
    version_icon character varying,
    version_color character varying,
    version_description character varying,
    version_status public.enum__dietary_options_v_version_status DEFAULT 'published'::public.enum__dietary_options_v_version_status,
    version_scheduled_publish timestamp(3) with time zone,
    version_published_at timestamp(3) with time zone,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__dietary_options_v_version_status DEFAULT 'draft'::public.enum__dietary_options_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._dietary_options_v OWNER TO postgres;

--
-- Name: _dietary_options_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._dietary_options_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._dietary_options_v_id_seq OWNER TO postgres;

--
-- Name: _dietary_options_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._dietary_options_v_id_seq OWNED BY public._dietary_options_v.id;


--
-- Name: _directions_page_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._directions_page_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb,
    version_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false
);


ALTER TABLE public._directions_page_v OWNER TO postgres;

--
-- Name: _directions_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public._directions_page_v ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public._directions_page_v_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: _faqs_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._faqs_v (
    id integer NOT NULL,
    parent_id integer,
    version_question character varying,
    version_answer character varying,
    version_category character varying,
    version_sort_order numeric,
    version_tags character varying,
    version_page_visibility character varying,
    version_tour_id numeric,
    version_workflow_status public.enum__faqs_v_version_workflow_status DEFAULT 'draft'::public.enum__faqs_v_version_workflow_status,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__faqs_v_version_status DEFAULT 'draft'::public.enum__faqs_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._faqs_v OWNER TO postgres;

--
-- Name: _faqs_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._faqs_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._faqs_v_id_seq OWNER TO postgres;

--
-- Name: _faqs_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._faqs_v_id_seq OWNED BY public._faqs_v.id;


--
-- Name: _food_items_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._food_items_v (
    id integer NOT NULL,
    parent_id integer,
    version_name character varying,
    version_slug character varying,
    version_description character varying,
    version_category public.enum__food_items_v_version_category,
    version_origin public.enum__food_items_v_version_origin,
    version_region character varying,
    version_spice_level public.enum__food_items_v_version_spice_level DEFAULT '0'::public.enum__food_items_v_version_spice_level,
    version_preparation_method public.enum__food_items_v_version_preparation_method,
    version_typical_price numeric,
    version_availability public.enum__food_items_v_version_availability DEFAULT 'year_round'::public.enum__food_items_v_version_availability,
    version_image_id integer,
    version_cultural_significance character varying,
    version_serving_suggestions character varying,
    version_popular_variations character varying,
    version_pairings character varying,
    version_vendor_notes character varying,
    version_status public.enum__food_items_v_version_status DEFAULT 'draft'::public.enum__food_items_v_version_status,
    version_featured boolean DEFAULT false,
    version_scheduled_publish timestamp(3) with time zone,
    version_published_at timestamp(3) with time zone,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__food_items_v_version_status DEFAULT 'draft'::public.enum__food_items_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._food_items_v OWNER TO postgres;

--
-- Name: _food_items_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._food_items_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._food_items_v_id_seq OWNER TO postgres;

--
-- Name: _food_items_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._food_items_v_id_seq OWNED BY public._food_items_v.id;


--
-- Name: _food_items_v_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._food_items_v_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    dietary_options_id integer,
    media_id integer
);


ALTER TABLE public._food_items_v_rels OWNER TO postgres;

--
-- Name: _food_items_v_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._food_items_v_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._food_items_v_rels_id_seq OWNER TO postgres;

--
-- Name: _food_items_v_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._food_items_v_rels_id_seq OWNED BY public._food_items_v_rels.id;


--
-- Name: _food_items_v_version_allergens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._food_items_v_version_allergens (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    allergen public.enum__food_items_v_version_allergens_allergen,
    _uuid character varying
);


ALTER TABLE public._food_items_v_version_allergens OWNER TO postgres;

--
-- Name: _food_items_v_version_allergens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._food_items_v_version_allergens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._food_items_v_version_allergens_id_seq OWNER TO postgres;

--
-- Name: _food_items_v_version_allergens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._food_items_v_version_allergens_id_seq OWNED BY public._food_items_v_version_allergens.id;


--
-- Name: _food_items_v_version_flavor_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._food_items_v_version_flavor_profile (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    flavor public.enum__food_items_v_version_flavor_profile_flavor,
    _uuid character varying
);


ALTER TABLE public._food_items_v_version_flavor_profile OWNER TO postgres;

--
-- Name: _food_items_v_version_flavor_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._food_items_v_version_flavor_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._food_items_v_version_flavor_profile_id_seq OWNER TO postgres;

--
-- Name: _food_items_v_version_flavor_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._food_items_v_version_flavor_profile_id_seq OWNED BY public._food_items_v_version_flavor_profile.id;


--
-- Name: _food_items_v_version_ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._food_items_v_version_ingredients (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    ingredient character varying,
    is_main boolean,
    _uuid character varying
);


ALTER TABLE public._food_items_v_version_ingredients OWNER TO postgres;

--
-- Name: _food_items_v_version_ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._food_items_v_version_ingredients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._food_items_v_version_ingredients_id_seq OWNER TO postgres;

--
-- Name: _food_items_v_version_ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._food_items_v_version_ingredients_id_seq OWNED BY public._food_items_v_version_ingredients.id;


--
-- Name: _food_items_v_version_local_names; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._food_items_v_version_local_names (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    language public.enum__food_items_v_version_local_names_language,
    name character varying,
    script character varying,
    _uuid character varying
);


ALTER TABLE public._food_items_v_version_local_names OWNER TO postgres;

--
-- Name: _food_items_v_version_local_names_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._food_items_v_version_local_names_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._food_items_v_version_local_names_id_seq OWNER TO postgres;

--
-- Name: _food_items_v_version_local_names_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._food_items_v_version_local_names_id_seq OWNED BY public._food_items_v_version_local_names.id;


--
-- Name: _home_page_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._home_page_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false,
    _status character varying(50) DEFAULT 'draft'::character varying
);


ALTER TABLE public._home_page_v OWNER TO postgres;

--
-- Name: _home_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._home_page_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._home_page_v_id_seq OWNER TO postgres;

--
-- Name: _home_page_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._home_page_v_id_seq OWNED BY public._home_page_v.id;


--
-- Name: _how_it_works_page_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._how_it_works_page_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb,
    version_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false
);


ALTER TABLE public._how_it_works_page_v OWNER TO postgres;

--
-- Name: _how_it_works_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public._how_it_works_page_v ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public._how_it_works_page_v_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: _how_to_prepare_page_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._how_to_prepare_page_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb,
    version_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false
);


ALTER TABLE public._how_to_prepare_page_v OWNER TO postgres;

--
-- Name: _how_to_prepare_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public._how_to_prepare_page_v ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public._how_to_prepare_page_v_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: _landing_pages_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._landing_pages_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb,
    version_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false
);


ALTER TABLE public._landing_pages_v OWNER TO postgres;

--
-- Name: _landing_pages_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public._landing_pages_v ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public._landing_pages_v_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: _legal_pages_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._legal_pages_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false,
    _status character varying(50) DEFAULT 'draft'::character varying
);


ALTER TABLE public._legal_pages_v OWNER TO postgres;

--
-- Name: _legal_pages_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._legal_pages_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._legal_pages_v_id_seq OWNER TO postgres;

--
-- Name: _legal_pages_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._legal_pages_v_id_seq OWNED BY public._legal_pages_v.id;


--
-- Name: menus_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menus_items (
    id integer CONSTRAINT _menus_items_v_id_not_null NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    label character varying,
    url character varying,
    open_in_new_tab boolean DEFAULT false,
    "order" integer
);


ALTER TABLE public.menus_items OWNER TO postgres;

--
-- Name: _menus_items_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._menus_items_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._menus_items_v_id_seq OWNER TO postgres;

--
-- Name: _menus_items_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._menus_items_v_id_seq OWNED BY public.menus_items.id;


--
-- Name: _stories_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._stories_v (
    id integer NOT NULL,
    parent_id integer,
    version_title character varying,
    version_slug character varying,
    version_author_id integer,
    version_excerpt character varying,
    version_content character varying,
    version_published_date timestamp(3) with time zone,
    version_status public.enum__stories_v_version_status DEFAULT 'draft'::public.enum__stories_v_version_status,
    version_workflow_status public.enum__stories_v_version_workflow_status DEFAULT 'draft'::public.enum__stories_v_version_workflow_status,
    version_scheduled_publish timestamp(3) with time zone,
    version_meta_title character varying,
    version_meta_description character varying,
    version_meta_image_id integer,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__stories_v_version_status DEFAULT 'draft'::public.enum__stories_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean,
    version_featured_image_id integer
);


ALTER TABLE public._stories_v OWNER TO postgres;

--
-- Name: _stories_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._stories_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._stories_v_id_seq OWNER TO postgres;

--
-- Name: _stories_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._stories_v_id_seq OWNED BY public._stories_v.id;


--
-- Name: _testimonials_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._testimonials_v (
    id integer NOT NULL,
    parent_id integer,
    version_author_name character varying,
    version_author_location character varying,
    version_rating numeric,
    version_review_text character varying,
    version_review_title character varying,
    version_author_photo character varying,
    version_date timestamp(3) with time zone,
    version_visibility_verified boolean DEFAULT true,
    version_visibility_featured boolean DEFAULT false,
    version_platform character varying,
    version_workflow_status public.enum__testimonials_v_version_workflow_status DEFAULT 'draft'::public.enum__testimonials_v_version_workflow_status,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__testimonials_v_version_status DEFAULT 'draft'::public.enum__testimonials_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._testimonials_v OWNER TO postgres;

--
-- Name: _testimonials_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._testimonials_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._testimonials_v_id_seq OWNER TO postgres;

--
-- Name: _testimonials_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._testimonials_v_id_seq OWNED BY public._testimonials_v.id;


--
-- Name: _tours_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._tours_v (
    id integer NOT NULL,
    parent_id integer,
    version_name character varying,
    version_slug character varying,
    version_tagline character varying,
    version_short_description character varying,
    version_full_description character varying,
    version_price numeric,
    version_currency character varying DEFAULT 'MYR'::character varying,
    version_duration character varying,
    version_duration_minutes numeric,
    version_location character varying,
    version_meeting_point character varying,
    version_max_participants numeric,
    version_min_participants numeric DEFAULT 2,
    version_tailored_available boolean DEFAULT false,
    version_tailored_notes character varying,
    version_booking_url character varying,
    version_instant_confirmation boolean DEFAULT true,
    version_scheduled_publish timestamp(3) with time zone,
    version_featured boolean DEFAULT false,
    version_popular boolean DEFAULT false,
    version_new boolean DEFAULT false,
    version_published_at timestamp(3) with time zone,
    version_status public.enum__tours_v_version_status DEFAULT 'draft'::public.enum__tours_v_version_status,
    version_workflow_status public.enum__tours_v_version_workflow_status DEFAULT 'draft'::public.enum__tours_v_version_workflow_status,
    version_meta_title character varying,
    version_meta_description character varying,
    version_meta_image_id integer,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__tours_v_version_status DEFAULT 'draft'::public.enum__tours_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean,
    version_hero_image_id integer
);


ALTER TABLE public._tours_v OWNER TO postgres;

--
-- Name: _tours_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._tours_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._tours_v_id_seq OWNER TO postgres;

--
-- Name: _tours_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._tours_v_id_seq OWNED BY public._tours_v.id;


--
-- Name: _tours_v_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._tours_v_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    dietary_options_id integer,
    travel_type_landing_pages_id integer,
    specialty_landing_pages_id integer,
    food_items_id integer
);


ALTER TABLE public._tours_v_rels OWNER TO postgres;

--
-- Name: _tours_v_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._tours_v_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._tours_v_rels_id_seq OWNER TO postgres;

--
-- Name: _tours_v_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._tours_v_rels_id_seq OWNED BY public._tours_v_rels.id;


--
-- Name: _tours_v_version_gallery_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._tours_v_version_gallery_images (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    _uuid character varying,
    image_id integer
);


ALTER TABLE public._tours_v_version_gallery_images OWNER TO postgres;

--
-- Name: _tours_v_version_gallery_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._tours_v_version_gallery_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._tours_v_version_gallery_images_id_seq OWNER TO postgres;

--
-- Name: _tours_v_version_gallery_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._tours_v_version_gallery_images_id_seq OWNED BY public._tours_v_version_gallery_images.id;


--
-- Name: _tours_v_version_highlights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._tours_v_version_highlights (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    highlight character varying,
    _uuid character varying
);


ALTER TABLE public._tours_v_version_highlights OWNER TO postgres;

--
-- Name: _tours_v_version_highlights_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._tours_v_version_highlights_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._tours_v_version_highlights_id_seq OWNER TO postgres;

--
-- Name: _tours_v_version_highlights_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._tours_v_version_highlights_id_seq OWNED BY public._tours_v_version_highlights.id;


--
-- Name: _tours_v_version_whats_excluded; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._tours_v_version_whats_excluded (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    item character varying,
    _uuid character varying
);


ALTER TABLE public._tours_v_version_whats_excluded OWNER TO postgres;

--
-- Name: _tours_v_version_whats_excluded_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._tours_v_version_whats_excluded_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._tours_v_version_whats_excluded_id_seq OWNER TO postgres;

--
-- Name: _tours_v_version_whats_excluded_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._tours_v_version_whats_excluded_id_seq OWNED BY public._tours_v_version_whats_excluded.id;


--
-- Name: _tours_v_version_whats_included; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._tours_v_version_whats_included (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    item character varying,
    _uuid character varying
);


ALTER TABLE public._tours_v_version_whats_included OWNER TO postgres;

--
-- Name: _tours_v_version_whats_included_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._tours_v_version_whats_included_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._tours_v_version_whats_included_id_seq OWNER TO postgres;

--
-- Name: _tours_v_version_whats_included_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._tours_v_version_whats_included_id_seq OWNED BY public._tours_v_version_whats_included.id;


--
-- Name: _track_record_page_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._track_record_page_v (
    id integer NOT NULL,
    parent_id integer,
    version jsonb,
    version_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    latest boolean DEFAULT false,
    autosave boolean DEFAULT false
);


ALTER TABLE public._track_record_page_v OWNER TO postgres;

--
-- Name: _track_record_page_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public._track_record_page_v ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public._track_record_page_v_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: _vendors_v; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v (
    id integer NOT NULL,
    parent_id integer,
    version_name character varying,
    version_slug character varying,
    version_type public.enum__vendors_v_version_type,
    version_description character varying,
    version_history character varying,
    version_year_established numeric,
    version_generation character varying,
    version_owner_name character varying,
    version_cuisine_type public.enum__vendors_v_version_cuisine_type,
    version_location_address character varying,
    version_location_city character varying,
    version_location_state public.enum__vendors_v_version_location_state,
    version_location_postcode character varying,
    version_location_country character varying DEFAULT 'Malaysia'::character varying,
    version_location_latitude numeric,
    version_location_longitude numeric,
    version_location_landmark character varying,
    version_contact_phone character varying,
    version_contact_whatsapp character varying,
    version_contact_email character varying,
    version_contact_website character varying,
    version_contact_facebook character varying,
    version_contact_instagram character varying,
    version_price_range public.enum__vendors_v_version_price_range,
    version_images_main_id integer,
    version_story character varying,
    version_media_features character varying,
    version_tips character varying,
    version_status public.enum__vendors_v_version_status DEFAULT 'draft'::public.enum__vendors_v_version_status,
    version_featured boolean DEFAULT false,
    version_scheduled_publish timestamp(3) with time zone,
    version_published_at timestamp(3) with time zone,
    version_updated_at timestamp(3) with time zone,
    version_created_at timestamp(3) with time zone,
    version__status public.enum__vendors_v_version_status DEFAULT 'draft'::public.enum__vendors_v_version_status,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    latest boolean,
    autosave boolean
);


ALTER TABLE public._vendors_v OWNER TO postgres;

--
-- Name: _vendors_v_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_id_seq OWNED BY public._vendors_v.id;


--
-- Name: _vendors_v_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    food_items_id integer,
    dietary_options_id integer
);


ALTER TABLE public._vendors_v_rels OWNER TO postgres;

--
-- Name: _vendors_v_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_rels_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_rels_id_seq OWNED BY public._vendors_v_rels.id;


--
-- Name: _vendors_v_version_awards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v_version_awards (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    award character varying,
    year numeric,
    organization character varying,
    _uuid character varying
);


ALTER TABLE public._vendors_v_version_awards OWNER TO postgres;

--
-- Name: _vendors_v_version_awards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_version_awards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_version_awards_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_version_awards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_version_awards_id_seq OWNED BY public._vendors_v_version_awards.id;


--
-- Name: _vendors_v_version_closed_on; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v_version_closed_on (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    day public.enum__vendors_v_version_closed_on_day,
    _uuid character varying
);


ALTER TABLE public._vendors_v_version_closed_on OWNER TO postgres;

--
-- Name: _vendors_v_version_closed_on_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_version_closed_on_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_version_closed_on_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_version_closed_on_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_version_closed_on_id_seq OWNED BY public._vendors_v_version_closed_on.id;


--
-- Name: _vendors_v_version_facilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v_version_facilities (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    facility public.enum__vendors_v_version_facilities_facility,
    _uuid character varying
);


ALTER TABLE public._vendors_v_version_facilities OWNER TO postgres;

--
-- Name: _vendors_v_version_facilities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_version_facilities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_version_facilities_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_version_facilities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_version_facilities_id_seq OWNED BY public._vendors_v_version_facilities.id;


--
-- Name: _vendors_v_version_images_gallery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v_version_images_gallery (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    image_id integer,
    _uuid character varying
);


ALTER TABLE public._vendors_v_version_images_gallery OWNER TO postgres;

--
-- Name: _vendors_v_version_images_gallery_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_version_images_gallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_version_images_gallery_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_version_images_gallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_version_images_gallery_id_seq OWNED BY public._vendors_v_version_images_gallery.id;


--
-- Name: _vendors_v_version_operating_hours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v_version_operating_hours (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    day public.enum__vendors_v_version_operating_hours_day,
    open_time character varying,
    close_time character varying,
    is_closed boolean,
    notes character varying,
    _uuid character varying
);


ALTER TABLE public._vendors_v_version_operating_hours OWNER TO postgres;

--
-- Name: _vendors_v_version_operating_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_version_operating_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_version_operating_hours_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_version_operating_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_version_operating_hours_id_seq OWNED BY public._vendors_v_version_operating_hours.id;


--
-- Name: _vendors_v_version_payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._vendors_v_version_payment_methods (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id integer NOT NULL,
    method public.enum__vendors_v_version_payment_methods_method,
    _uuid character varying
);


ALTER TABLE public._vendors_v_version_payment_methods OWNER TO postgres;

--
-- Name: _vendors_v_version_payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public._vendors_v_version_payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._vendors_v_version_payment_methods_id_seq OWNER TO postgres;

--
-- Name: _vendors_v_version_payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public._vendors_v_version_payment_methods_id_seq OWNED BY public._vendors_v_version_payment_methods.id;


--
-- Name: about_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page (
    id integer NOT NULL,
    seo_title character varying,
    seo_description character varying,
    parent_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _locales jsonb
);


ALTER TABLE public.about_page OWNER TO postgres;

--
-- Name: about_page_blocks_founder_story_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_founder_story_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    title character varying,
    content text
);


ALTER TABLE public.about_page_blocks_founder_story_block OWNER TO postgres;

--
-- Name: about_page_blocks_founder_story_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_founder_story_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_founder_story_block_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_founder_story_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_founder_story_block_id_seq OWNED BY public.about_page_blocks_founder_story_block.id;


--
-- Name: about_page_blocks_hero_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_hero_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    title character varying,
    subtitle character varying
);


ALTER TABLE public.about_page_blocks_hero_block OWNER TO postgres;

--
-- Name: about_page_blocks_hero_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_hero_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_hero_block_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_hero_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_hero_block_id_seq OWNED BY public.about_page_blocks_hero_block.id;


--
-- Name: about_page_blocks_philosophy_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_philosophy_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    content text
);


ALTER TABLE public.about_page_blocks_philosophy_block OWNER TO postgres;

--
-- Name: about_page_blocks_philosophy_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_philosophy_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_philosophy_block_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_philosophy_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_philosophy_block_id_seq OWNED BY public.about_page_blocks_philosophy_block.id;


--
-- Name: about_page_blocks_stats_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_stats_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying
);


ALTER TABLE public.about_page_blocks_stats_block OWNER TO postgres;

--
-- Name: about_page_blocks_stats_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_stats_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_stats_block_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_stats_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_stats_block_id_seq OWNED BY public.about_page_blocks_stats_block.id;


--
-- Name: about_page_blocks_stats_block_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_stats_block_stats (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    number character varying,
    label character varying
);


ALTER TABLE public.about_page_blocks_stats_block_stats OWNER TO postgres;

--
-- Name: about_page_blocks_stats_block_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_stats_block_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_stats_block_stats_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_stats_block_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_stats_block_stats_id_seq OWNED BY public.about_page_blocks_stats_block_stats.id;


--
-- Name: about_page_blocks_team_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_team_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying
);


ALTER TABLE public.about_page_blocks_team_block OWNER TO postgres;

--
-- Name: about_page_blocks_team_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_team_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_team_block_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_team_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_team_block_id_seq OWNED BY public.about_page_blocks_team_block.id;


--
-- Name: about_page_blocks_team_block_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_team_block_members (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    name character varying,
    role character varying,
    specialty character varying,
    description text,
    photo character varying
);


ALTER TABLE public.about_page_blocks_team_block_members OWNER TO postgres;

--
-- Name: about_page_blocks_team_block_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_team_block_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_team_block_members_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_team_block_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_team_block_members_id_seq OWNED BY public.about_page_blocks_team_block_members.id;


--
-- Name: about_page_blocks_timeline_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_timeline_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying
);


ALTER TABLE public.about_page_blocks_timeline_block OWNER TO postgres;

--
-- Name: about_page_blocks_timeline_block_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_blocks_timeline_block_events (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    year character varying,
    title character varying,
    description text
);


ALTER TABLE public.about_page_blocks_timeline_block_events OWNER TO postgres;

--
-- Name: about_page_blocks_timeline_block_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_timeline_block_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_timeline_block_events_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_timeline_block_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_timeline_block_events_id_seq OWNED BY public.about_page_blocks_timeline_block_events.id;


--
-- Name: about_page_blocks_timeline_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_blocks_timeline_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_blocks_timeline_block_id_seq OWNER TO postgres;

--
-- Name: about_page_blocks_timeline_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_blocks_timeline_block_id_seq OWNED BY public.about_page_blocks_timeline_block.id;


--
-- Name: about_page_breadcrumbs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.about_page_breadcrumbs (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    doc_id integer,
    url character varying,
    label character varying
);


ALTER TABLE public.about_page_breadcrumbs OWNER TO postgres;

--
-- Name: about_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.about_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_page_id_seq OWNER TO postgres;

--
-- Name: about_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.about_page_id_seq OWNED BY public.about_page.id;


--
-- Name: contact_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_page (
    id integer NOT NULL,
    seo_title text,
    seo_description text,
    hero_title text NOT NULL,
    hero_subtitle text,
    intro_title text,
    intro_subtitle text,
    contact_email text,
    contact_phone text,
    whatsapp_number text,
    contact_hours text,
    social_facebook text,
    social_instagram text,
    faq_content text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.contact_page OWNER TO postgres;

--
-- Name: contact_page_breadcrumbs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_page_breadcrumbs (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    doc_id integer,
    url character varying,
    label character varying
);


ALTER TABLE public.contact_page_breadcrumbs OWNER TO postgres;

--
-- Name: contact_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.contact_page ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.contact_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stories (
    id integer NOT NULL,
    title character varying,
    slug character varying NOT NULL,
    author_id integer,
    excerpt character varying,
    content character varying,
    published_date timestamp(3) with time zone,
    status public.enum_stories_status DEFAULT 'draft'::public.enum_stories_status,
    workflow_status public.enum_stories_workflow_status DEFAULT 'draft'::public.enum_stories_workflow_status,
    scheduled_publish timestamp(3) with time zone,
    meta_title character varying,
    meta_description character varying,
    meta_image_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_stories_status DEFAULT 'draft'::public.enum_stories_status,
    featured_image_id integer,
    _locales jsonb
);


ALTER TABLE public.stories OWNER TO postgres;

--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.testimonials (
    id integer NOT NULL,
    author_name character varying,
    author_location character varying,
    rating numeric,
    review_text character varying,
    review_title character varying,
    author_photo character varying,
    date timestamp(3) with time zone,
    visibility_verified boolean DEFAULT true,
    visibility_featured boolean DEFAULT false,
    platform character varying,
    workflow_status public.enum_testimonials_workflow_status DEFAULT 'draft'::public.enum_testimonials_workflow_status,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_testimonials_status DEFAULT 'draft'::public.enum_testimonials_status,
    _locales jsonb,
    CONSTRAINT testimonials_rating_range CHECK (((rating >= (1)::numeric) AND (rating <= (5)::numeric)))
);


ALTER TABLE public.testimonials OWNER TO postgres;

--
-- Name: tours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tours (
    id integer NOT NULL,
    name character varying,
    slug character varying NOT NULL,
    tagline character varying,
    short_description character varying,
    full_description character varying,
    price numeric,
    currency character varying DEFAULT 'MYR'::character varying,
    duration character varying,
    duration_minutes numeric,
    location character varying,
    meeting_point character varying,
    max_participants numeric,
    min_participants numeric DEFAULT 2,
    tailored_available boolean DEFAULT false,
    tailored_notes character varying,
    booking_url character varying,
    instant_confirmation boolean DEFAULT true,
    scheduled_publish timestamp(3) with time zone,
    featured boolean DEFAULT false,
    popular boolean DEFAULT false,
    new boolean DEFAULT false,
    published_at timestamp(3) with time zone,
    status public.enum_tours_status DEFAULT 'draft'::public.enum_tours_status,
    workflow_status public.enum_tours_workflow_status DEFAULT 'draft'::public.enum_tours_workflow_status,
    meta_title character varying,
    meta_description character varying,
    meta_image_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_tours_status DEFAULT 'draft'::public.enum_tours_status,
    hero_image_id integer,
    _locales jsonb,
    CONSTRAINT tours_duration_positive CHECK ((duration_minutes > (0)::numeric)),
    CONSTRAINT tours_max_participants_positive CHECK ((max_participants > (0)::numeric)),
    CONSTRAINT tours_min_lte_max CHECK ((min_participants <= max_participants)),
    CONSTRAINT tours_min_participants_positive CHECK ((min_participants > (0)::numeric)),
    CONSTRAINT tours_price_positive CHECK ((price > (0)::numeric))
);


ALTER TABLE public.tours OWNER TO postgres;

--
-- Name: vendors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors (
    id integer NOT NULL,
    name character varying,
    slug character varying NOT NULL,
    type public.enum_vendors_type,
    description character varying,
    history character varying,
    year_established numeric,
    generation character varying,
    owner_name character varying,
    cuisine_type public.enum_vendors_cuisine_type,
    location_address character varying,
    location_city character varying,
    location_state public.enum_vendors_location_state,
    location_postcode character varying,
    location_country character varying DEFAULT 'Malaysia'::character varying,
    location_latitude numeric,
    location_longitude numeric,
    location_landmark character varying,
    contact_phone character varying,
    contact_whatsapp character varying,
    contact_email character varying,
    contact_website character varying,
    contact_facebook character varying,
    contact_instagram character varying,
    price_range public.enum_vendors_price_range,
    images_main_id integer,
    story character varying,
    media_features character varying,
    tips character varying,
    status public.enum_vendors_status DEFAULT 'draft'::public.enum_vendors_status,
    featured boolean DEFAULT false,
    scheduled_publish timestamp(3) with time zone,
    published_at timestamp(3) with time zone,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_vendors_status DEFAULT 'draft'::public.enum_vendors_status
);


ALTER TABLE public.vendors OWNER TO postgres;

--
-- Name: content_overview; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.content_overview AS
 SELECT ( SELECT count(*) AS count
           FROM public.tours
          WHERE (tours.status = 'published'::public.enum_tours_status)) AS published_tours,
    ( SELECT count(*) AS count
           FROM public.tours
          WHERE (tours.status = 'draft'::public.enum_tours_status)) AS draft_tours,
    ( SELECT count(*) AS count
           FROM public.stories
          WHERE (stories.status = 'published'::public.enum_stories_status)) AS published_stories,
    ( SELECT count(*) AS count
           FROM public.testimonials) AS total_testimonials,
    ( SELECT count(*) AS count
           FROM public.vendors
          WHERE (vendors.status = 'published'::public.enum_vendors_status)) AS published_vendors,
    ( SELECT count(*) AS count
           FROM public.vendors
          WHERE (vendors.status = 'draft'::public.enum_vendors_status)) AS draft_vendors;


ALTER VIEW public.content_overview OWNER TO postgres;

--
-- Name: corporate_groups_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.corporate_groups_page (
    id integer NOT NULL,
    seo_title text NOT NULL,
    seo_description text NOT NULL,
    hero_eyebrow text,
    hero_title text NOT NULL,
    hero_subtitle text,
    offer_eyebrow text,
    offer_heading text,
    offer_body_1 text,
    offer_body_2 text,
    benefits_eyebrow text,
    benefits_title text,
    kl_section_eyebrow text,
    kl_section_heading text,
    kl_section_subtext text,
    penang_section_eyebrow text,
    penang_section_heading text,
    penang_section_subtext text,
    how_eyebrow text,
    how_heading text,
    cta_heading text,
    cta_body text,
    cta_email_label text,
    cta_whatsapp_label text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.corporate_groups_page OWNER TO postgres;

--
-- Name: corporate_groups_page_benefit_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.corporate_groups_page_benefit_cards (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    icon text,
    title text NOT NULL,
    description text
);


ALTER TABLE public.corporate_groups_page_benefit_cards OWNER TO postgres;

--
-- Name: corporate_groups_page_benefit_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.corporate_groups_page_benefit_cards ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.corporate_groups_page_benefit_cards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: corporate_groups_page_how_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.corporate_groups_page_how_steps (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    number integer,
    title text NOT NULL,
    description text
);


ALTER TABLE public.corporate_groups_page_how_steps OWNER TO postgres;

--
-- Name: corporate_groups_page_how_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.corporate_groups_page_how_steps ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.corporate_groups_page_how_steps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: corporate_groups_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.corporate_groups_page ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.corporate_groups_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: corporate_groups_page_offer_perfect_for; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.corporate_groups_page_offer_perfect_for (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    item text NOT NULL
);


ALTER TABLE public.corporate_groups_page_offer_perfect_for OWNER TO postgres;

--
-- Name: corporate_groups_page_offer_perfect_for_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.corporate_groups_page_offer_perfect_for ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.corporate_groups_page_offer_perfect_for_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dietary_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dietary_options (
    id integer NOT NULL,
    name character varying,
    slug character varying,
    icon character varying,
    color character varying,
    description character varying,
    status public.enum_dietary_options_status DEFAULT 'published'::public.enum_dietary_options_status,
    scheduled_publish timestamp(3) with time zone,
    published_at timestamp(3) with time zone,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_dietary_options_status DEFAULT 'draft'::public.enum_dietary_options_status
);


ALTER TABLE public.dietary_options OWNER TO postgres;

--
-- Name: dietary_options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dietary_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dietary_options_id_seq OWNER TO postgres;

--
-- Name: dietary_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dietary_options_id_seq OWNED BY public.dietary_options.id;


--
-- Name: directions_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.directions_page (
    id integer NOT NULL,
    seo_title text NOT NULL,
    seo_description text NOT NULL,
    hero_title text NOT NULL,
    hero_description text,
    hero_image text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.directions_page OWNER TO postgres;

--
-- Name: directions_page_general_tips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.directions_page_general_tips (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    tip text NOT NULL
);


ALTER TABLE public.directions_page_general_tips OWNER TO postgres;

--
-- Name: directions_page_general_tips_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.directions_page_general_tips ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.directions_page_general_tips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: directions_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.directions_page ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.directions_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: directions_page_meeting_points; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.directions_page_meeting_points (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    tour text NOT NULL,
    location_name text NOT NULL,
    address text,
    directions text,
    landmark text,
    map_url text,
    parking_info text,
    public_transport text
);


ALTER TABLE public.directions_page_meeting_points OWNER TO postgres;

--
-- Name: directions_page_meeting_points_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.directions_page_meeting_points ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.directions_page_meeting_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faqs (
    id integer NOT NULL,
    question character varying,
    answer character varying,
    category character varying,
    sort_order numeric,
    tags character varying,
    page_visibility character varying,
    tour_id numeric,
    workflow_status public.enum_faqs_workflow_status DEFAULT 'draft'::public.enum_faqs_workflow_status,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_faqs_status DEFAULT 'draft'::public.enum_faqs_status,
    _locales jsonb
);


ALTER TABLE public.faqs OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faqs_id_seq OWNER TO postgres;

--
-- Name: faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faqs_id_seq OWNED BY public.faqs.id;


--
-- Name: featured_testimonials; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.featured_testimonials AS
 SELECT id,
    author_name,
    author_location,
    rating,
    review_text,
    platform,
    date
   FROM public.testimonials
  WHERE (visibility_featured = true)
  ORDER BY rating DESC, date DESC;


ALTER VIEW public.featured_testimonials OWNER TO postgres;

--
-- Name: food_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_items (
    id integer NOT NULL,
    name character varying,
    slug character varying,
    description character varying,
    category public.enum_food_items_category,
    origin public.enum_food_items_origin,
    region character varying,
    spice_level public.enum_food_items_spice_level DEFAULT '0'::public.enum_food_items_spice_level,
    preparation_method public.enum_food_items_preparation_method,
    typical_price numeric,
    availability public.enum_food_items_availability DEFAULT 'year_round'::public.enum_food_items_availability,
    image_id integer,
    cultural_significance character varying,
    serving_suggestions character varying,
    popular_variations character varying,
    pairings character varying,
    vendor_notes character varying,
    status public.enum_food_items_status DEFAULT 'draft'::public.enum_food_items_status,
    featured boolean DEFAULT false,
    scheduled_publish timestamp(3) with time zone,
    published_at timestamp(3) with time zone,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _status public.enum_food_items_status DEFAULT 'draft'::public.enum_food_items_status
);


ALTER TABLE public.food_items OWNER TO postgres;

--
-- Name: food_items_allergens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_items_allergens (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    allergen public.enum_food_items_allergens_allergen
);


ALTER TABLE public.food_items_allergens OWNER TO postgres;

--
-- Name: food_items_flavor_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_items_flavor_profile (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    flavor public.enum_food_items_flavor_profile_flavor
);


ALTER TABLE public.food_items_flavor_profile OWNER TO postgres;

--
-- Name: food_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.food_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.food_items_id_seq OWNER TO postgres;

--
-- Name: food_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.food_items_id_seq OWNED BY public.food_items.id;


--
-- Name: food_items_ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_items_ingredients (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    ingredient character varying,
    is_main boolean
);


ALTER TABLE public.food_items_ingredients OWNER TO postgres;

--
-- Name: food_items_local_names; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_items_local_names (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    language public.enum_food_items_local_names_language,
    name character varying,
    script character varying
);


ALTER TABLE public.food_items_local_names OWNER TO postgres;

--
-- Name: food_items_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_items_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    dietary_options_id integer,
    media_id integer
);


ALTER TABLE public.food_items_rels OWNER TO postgres;

--
-- Name: food_items_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.food_items_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.food_items_rels_id_seq OWNER TO postgres;

--
-- Name: food_items_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.food_items_rels_id_seq OWNED BY public.food_items_rels.id;


--
-- Name: home_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page (
    id integer NOT NULL,
    faqs jsonb,
    meta_title text,
    meta_description text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.home_page OWNER TO postgres;

--
-- Name: home_page_blocks_about_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_about_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    eyebrow character varying,
    title character varying,
    subtitle character varying,
    description text,
    heritage character varying,
    image character varying
);


ALTER TABLE public.home_page_blocks_about_block OWNER TO postgres;

--
-- Name: home_page_blocks_about_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_about_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_about_block_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_about_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_about_block_id_seq OWNED BY public.home_page_blocks_about_block.id;


--
-- Name: home_page_blocks_cta_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_cta_block (
    id integer CONSTRAINT home_page_cta_section_id_not_null NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    eyebrow character varying,
    title character varying,
    subtitle character varying
);


ALTER TABLE public.home_page_blocks_cta_block OWNER TO postgres;

--
-- Name: home_page_blocks_cta_block_buttons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_cta_block_buttons (
    id integer CONSTRAINT home_page_cta_section_buttons_id_not_null NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    label character varying,
    url character varying,
    variant character varying(50) DEFAULT 'primary'::character varying
);


ALTER TABLE public.home_page_blocks_cta_block_buttons OWNER TO postgres;

--
-- Name: home_page_blocks_cta_block_features; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_cta_block_features (
    id integer CONSTRAINT home_page_cta_section_features_id_not_null NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    text character varying
);


ALTER TABLE public.home_page_blocks_cta_block_features OWNER TO postgres;

--
-- Name: home_page_blocks_hero_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_hero_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    title character varying,
    highlight character varying,
    title_end character varying,
    subtitle character varying,
    description text,
    price_info character varying,
    bg_image character varying
);


ALTER TABLE public.home_page_blocks_hero_block OWNER TO postgres;

--
-- Name: home_page_blocks_hero_block_badges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_hero_block_badges (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    text character varying
);


ALTER TABLE public.home_page_blocks_hero_block_badges OWNER TO postgres;

--
-- Name: home_page_blocks_hero_block_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_hero_block_badges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_hero_block_badges_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_hero_block_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_hero_block_badges_id_seq OWNED BY public.home_page_blocks_hero_block_badges.id;


--
-- Name: home_page_blocks_hero_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_hero_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_hero_block_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_hero_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_hero_block_id_seq OWNED BY public.home_page_blocks_hero_block.id;


--
-- Name: home_page_blocks_manifesto_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_manifesto_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    eyebrow character varying,
    headline text,
    tagline character varying,
    body text,
    attribution_role character varying
);


ALTER TABLE public.home_page_blocks_manifesto_block OWNER TO postgres;

--
-- Name: home_page_blocks_manifesto_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_manifesto_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_manifesto_block_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_manifesto_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_manifesto_block_id_seq OWNED BY public.home_page_blocks_manifesto_block.id;


--
-- Name: home_page_blocks_pillars_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_pillars_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    intro character varying
);


ALTER TABLE public.home_page_blocks_pillars_block OWNER TO postgres;

--
-- Name: home_page_blocks_pillars_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_pillars_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_pillars_block_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_pillars_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_pillars_block_id_seq OWNED BY public.home_page_blocks_pillars_block.id;


--
-- Name: home_page_blocks_pillars_block_pillars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_pillars_block_pillars (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    label character varying,
    heading character varying,
    body text
);


ALTER TABLE public.home_page_blocks_pillars_block_pillars OWNER TO postgres;

--
-- Name: home_page_blocks_pillars_block_pillars_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_pillars_block_pillars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_pillars_block_pillars_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_pillars_block_pillars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_pillars_block_pillars_id_seq OWNED BY public.home_page_blocks_pillars_block_pillars.id;


--
-- Name: home_page_blocks_segments_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_segments_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    heading character varying,
    subheading character varying,
    view_all_label character varying
);


ALTER TABLE public.home_page_blocks_segments_block OWNER TO postgres;

--
-- Name: home_page_blocks_segments_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_segments_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_segments_block_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_segments_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_segments_block_id_seq OWNED BY public.home_page_blocks_segments_block.id;


--
-- Name: home_page_blocks_stats_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_stats_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    title character varying,
    subtitle character varying
);


ALTER TABLE public.home_page_blocks_stats_block OWNER TO postgres;

--
-- Name: home_page_blocks_stats_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_stats_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_stats_block_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_stats_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_stats_block_id_seq OWNED BY public.home_page_blocks_stats_block.id;


--
-- Name: home_page_blocks_stats_block_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_stats_block_stats (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    number character varying,
    heading character varying,
    body text
);


ALTER TABLE public.home_page_blocks_stats_block_stats OWNER TO postgres;

--
-- Name: home_page_blocks_stats_block_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_stats_block_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_stats_block_stats_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_stats_block_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_stats_block_stats_id_seq OWNED BY public.home_page_blocks_stats_block_stats.id;


--
-- Name: home_page_blocks_vendors_block; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_vendors_block (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    block_name character varying,
    eyebrow character varying,
    title character varying,
    subtitle character varying
);


ALTER TABLE public.home_page_blocks_vendors_block OWNER TO postgres;

--
-- Name: home_page_blocks_vendors_block_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_vendors_block_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_vendors_block_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_vendors_block_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_vendors_block_id_seq OWNED BY public.home_page_blocks_vendors_block.id;


--
-- Name: home_page_blocks_vendors_block_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_page_blocks_vendors_block_links (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path character varying,
    label character varying,
    url character varying
);


ALTER TABLE public.home_page_blocks_vendors_block_links OWNER TO postgres;

--
-- Name: home_page_blocks_vendors_block_links_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_blocks_vendors_block_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_blocks_vendors_block_links_id_seq OWNER TO postgres;

--
-- Name: home_page_blocks_vendors_block_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_blocks_vendors_block_links_id_seq OWNED BY public.home_page_blocks_vendors_block_links.id;


--
-- Name: home_page_cta_section_buttons_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_cta_section_buttons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_cta_section_buttons_id_seq OWNER TO postgres;

--
-- Name: home_page_cta_section_buttons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_cta_section_buttons_id_seq OWNED BY public.home_page_blocks_cta_block_buttons.id;


--
-- Name: home_page_cta_section_features_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_cta_section_features_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_cta_section_features_id_seq OWNER TO postgres;

--
-- Name: home_page_cta_section_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_cta_section_features_id_seq OWNED BY public.home_page_blocks_cta_block_features.id;


--
-- Name: home_page_cta_section_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_cta_section_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_cta_section_id_seq OWNER TO postgres;

--
-- Name: home_page_cta_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_cta_section_id_seq OWNED BY public.home_page_blocks_cta_block.id;


--
-- Name: home_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.home_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.home_page_id_seq OWNER TO postgres;

--
-- Name: home_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.home_page_id_seq OWNED BY public.home_page.id;


--
-- Name: how_it_works_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_it_works_page (
    id integer NOT NULL,
    hero_title text NOT NULL,
    hero_subtitle text,
    steps_title text,
    inclusions_title text,
    formats_title text,
    formats_subtitle text,
    seo_title text,
    seo_description text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.how_it_works_page OWNER TO postgres;

--
-- Name: how_it_works_page_formats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_it_works_page_formats (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    name text NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.how_it_works_page_formats OWNER TO postgres;

--
-- Name: how_it_works_page_formats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_it_works_page_formats ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_it_works_page_formats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_it_works_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_it_works_page ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_it_works_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_it_works_page_inclusions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_it_works_page_inclusions (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    item text NOT NULL
);


ALTER TABLE public.how_it_works_page_inclusions OWNER TO postgres;

--
-- Name: how_it_works_page_inclusions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_it_works_page_inclusions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_it_works_page_inclusions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_it_works_page_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_it_works_page_steps (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    number integer NOT NULL,
    title text NOT NULL,
    detail text NOT NULL
);


ALTER TABLE public.how_it_works_page_steps OWNER TO postgres;

--
-- Name: how_it_works_page_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_it_works_page_steps ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_it_works_page_steps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_to_prepare_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_to_prepare_page (
    id integer NOT NULL,
    seo_title text NOT NULL,
    seo_description text NOT NULL,
    hero_title text NOT NULL,
    hero_description text NOT NULL,
    hero_image text,
    what_to_wear_heading text,
    what_to_bring_heading text,
    what_to_expect_heading text,
    dietary_heading text,
    dietary_intro text,
    directions_cta_text text,
    directions_cta_button text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.how_to_prepare_page OWNER TO postgres;

--
-- Name: how_to_prepare_page_dietary_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_to_prepare_page_dietary_notes (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    description text
);


ALTER TABLE public.how_to_prepare_page_dietary_notes OWNER TO postgres;

--
-- Name: how_to_prepare_page_dietary_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_to_prepare_page_dietary_notes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_to_prepare_page_dietary_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_to_prepare_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_to_prepare_page ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_to_prepare_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_to_prepare_page_what_to_bring; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_to_prepare_page_what_to_bring (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    description text
);


ALTER TABLE public.how_to_prepare_page_what_to_bring OWNER TO postgres;

--
-- Name: how_to_prepare_page_what_to_bring_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_to_prepare_page_what_to_bring ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_to_prepare_page_what_to_bring_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_to_prepare_page_what_to_expect; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_to_prepare_page_what_to_expect (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    description text
);


ALTER TABLE public.how_to_prepare_page_what_to_expect OWNER TO postgres;

--
-- Name: how_to_prepare_page_what_to_expect_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_to_prepare_page_what_to_expect ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_to_prepare_page_what_to_expect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: how_to_prepare_page_what_to_wear; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.how_to_prepare_page_what_to_wear (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    description text
);


ALTER TABLE public.how_to_prepare_page_what_to_wear OWNER TO postgres;

--
-- Name: how_to_prepare_page_what_to_wear_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.how_to_prepare_page_what_to_wear ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.how_to_prepare_page_what_to_wear_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages (
    id integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    type character varying(20) NOT NULL,
    status character varying(50) DEFAULT 'draft'::character varying,
    icon text,
    color text,
    hero_title text,
    hero_subtitle text,
    hero_description text,
    hero_image text,
    intro_heading text,
    intro_content text,
    challenges_heading text,
    options_heading text,
    options_content text,
    features_heading text,
    tips_heading text,
    tips_content text,
    safe_dishes_heading text,
    avoid_dishes_heading text,
    tours_heading text,
    meta_title text,
    meta_description text,
    published_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.landing_pages OWNER TO postgres;

--
-- Name: landing_pages_avoid_dishes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages_avoid_dishes (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    name text NOT NULL,
    description text
);


ALTER TABLE public.landing_pages_avoid_dishes OWNER TO postgres;

--
-- Name: landing_pages_avoid_dishes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages_avoid_dishes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_avoid_dishes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages_challenges (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    description text
);


ALTER TABLE public.landing_pages_challenges OWNER TO postgres;

--
-- Name: landing_pages_challenges_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages_challenges ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_challenges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages_highlights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages_highlights (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    description text
);


ALTER TABLE public.landing_pages_highlights OWNER TO postgres;

--
-- Name: landing_pages_highlights_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages_highlights ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_highlights_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages_safe_dishes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages_safe_dishes (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    name text NOT NULL,
    description text
);


ALTER TABLE public.landing_pages_safe_dishes OWNER TO postgres;

--
-- Name: landing_pages_safe_dishes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages_safe_dishes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_safe_dishes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages_suitable_tours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages_suitable_tours (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    tour_slug text NOT NULL
);


ALTER TABLE public.landing_pages_suitable_tours OWNER TO postgres;

--
-- Name: landing_pages_suitable_tours_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages_suitable_tours ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_suitable_tours_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages_tips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages_tips (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    content text
);


ALTER TABLE public.landing_pages_tips OWNER TO postgres;

--
-- Name: landing_pages_tips_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages_tips ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_tips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: landing_pages_travel_tips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.landing_pages_travel_tips (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    title text NOT NULL,
    content text
);


ALTER TABLE public.landing_pages_travel_tips OWNER TO postgres;

--
-- Name: landing_pages_travel_tips_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.landing_pages_travel_tips ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.landing_pages_travel_tips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: legal_pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_pages (
    id integer NOT NULL,
    slug text NOT NULL,
    status character varying(50) DEFAULT 'draft'::character varying,
    headline text NOT NULL,
    content jsonb,
    meta_title text,
    meta_description text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.legal_pages OWNER TO postgres;

--
-- Name: legal_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.legal_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_pages_id_seq OWNER TO postgres;

--
-- Name: legal_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.legal_pages_id_seq OWNED BY public.legal_pages.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    icon character varying,
    color character varying,
    description text,
    status character varying(50) DEFAULT 'published'::character varying,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'published'::character varying
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.locations_id_seq OWNER TO postgres;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    id integer NOT NULL,
    alt character varying,
    caption character varying,
    usage character varying,
    prefix character varying DEFAULT 'payload-media'::character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    url character varying,
    thumbnail_u_r_l character varying,
    filename character varying,
    mime_type character varying,
    filesize numeric,
    width numeric,
    height numeric,
    focal_x numeric,
    focal_y numeric,
    sizes_thumbnail_url character varying,
    sizes_thumbnail_width numeric,
    sizes_thumbnail_height numeric,
    sizes_thumbnail_mime_type character varying,
    sizes_thumbnail_filesize numeric,
    sizes_thumbnail_filename character varying,
    sizes_medium_url character varying,
    sizes_medium_width numeric,
    sizes_medium_height numeric,
    sizes_medium_mime_type character varying,
    sizes_medium_filesize numeric,
    sizes_medium_filename character varying,
    sizes_large_url character varying,
    sizes_large_width numeric,
    sizes_large_height numeric,
    sizes_large_mime_type character varying,
    sizes_large_filesize numeric,
    sizes_large_filename character varying
);


ALTER TABLE public.media OWNER TO postgres;

--
-- Name: media_coverage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_coverage (
    id integer NOT NULL,
    category character varying,
    outlet character varying NOT NULL,
    year character varying,
    detail character varying,
    url character varying,
    label character varying,
    logo_domain character varying,
    highlight character varying,
    status public.enum_media_coverage_status DEFAULT 'draft'::public.enum_media_coverage_status,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _locales jsonb
);


ALTER TABLE public.media_coverage OWNER TO postgres;

--
-- Name: media_coverage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_coverage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_coverage_id_seq OWNER TO postgres;

--
-- Name: media_coverage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_coverage_id_seq OWNED BY public.media_coverage.id;


--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_id_seq OWNER TO postgres;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: menus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menus (
    id integer NOT NULL,
    name character varying NOT NULL,
    location character varying(50) NOT NULL,
    items jsonb NOT NULL,
    item_count integer,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'published'::character varying
);


ALTER TABLE public.menus OWNER TO postgres;

--
-- Name: menus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menus_id_seq OWNER TO postgres;

--
-- Name: menus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menus_id_seq OWNED BY public.menus.id;


--
-- Name: payload_kv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_kv (
    id integer NOT NULL,
    key character varying NOT NULL,
    data jsonb NOT NULL
);


ALTER TABLE public.payload_kv OWNER TO postgres;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_kv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_kv_id_seq OWNER TO postgres;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_kv_id_seq OWNED BY public.payload_kv.id;


--
-- Name: payload_locked_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_locked_documents (
    id integer NOT NULL,
    global_slug character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_locked_documents OWNER TO postgres;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_locked_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_id_seq OWNER TO postgres;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_locked_documents_id_seq OWNED BY public.payload_locked_documents.id;


--
-- Name: payload_locked_documents_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_locked_documents_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer,
    media_id integer,
    tours_id integer,
    stories_id integer,
    testimonials_id integer,
    faqs_id integer,
    media_coverage_id integer,
    dietary_options_id integer,
    food_items_id integer,
    vendors_id integer,
    dietary_landing_pages_id integer,
    specialty_landing_pages_id integer,
    travel_type_landing_pages_id integer,
    location_landing_pages_id integer,
    about_page_id integer,
    contact_page_id integer,
    thank_you_pages_id integer,
    translations_id integer,
    site_settings_id integer,
    redirects_id integer,
    search_id integer,
    home_page_id integer,
    legal_pages_id integer,
    menus_id integer,
    travel_types_id integer,
    specialty_experiences_id integer,
    locations_id integer,
    forms_id integer,
    form_submissions_id integer,
    how_it_works_page_id integer,
    how_to_prepare_page_id integer,
    corporate_groups_page_id integer,
    track_record_page_id integer,
    directions_page_id integer,
    landing_pages_id integer
);


ALTER TABLE public.payload_locked_documents_rels OWNER TO postgres;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_locked_documents_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNER TO postgres;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNED BY public.payload_locked_documents_rels.id;


--
-- Name: payload_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_migrations (
    id integer NOT NULL,
    name character varying,
    batch numeric,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_migrations OWNER TO postgres;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_migrations_id_seq OWNER TO postgres;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_migrations_id_seq OWNED BY public.payload_migrations.id;


--
-- Name: payload_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_preferences (
    id integer NOT NULL,
    key character varying,
    value jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_preferences OWNER TO postgres;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_id_seq OWNER TO postgres;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_preferences_id_seq OWNED BY public.payload_preferences.id;


--
-- Name: payload_preferences_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_preferences_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer
);


ALTER TABLE public.payload_preferences_rels OWNER TO postgres;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_preferences_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNER TO postgres;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNED BY public.payload_preferences_rels.id;


--
-- Name: published_stories; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.published_stories AS
 SELECT id,
    title,
    slug,
    author_id,
    excerpt,
    published_date,
    status
   FROM public.stories
  WHERE (status = 'published'::public.enum_stories_status)
  ORDER BY published_date DESC;


ALTER VIEW public.published_stories OWNER TO postgres;

--
-- Name: published_tours; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.published_tours AS
 SELECT id,
    name,
    slug,
    price,
    currency,
    duration,
    location,
    featured,
    popular
   FROM public.tours
  WHERE (status = 'published'::public.enum_tours_status)
  ORDER BY featured DESC, name;


ALTER VIEW public.published_tours OWNER TO postgres;

--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_settings (
    id integer NOT NULL,
    site_name character varying,
    tagline character varying,
    description character varying,
    hero_title character varying,
    hero_subtitle character varying,
    hero_description character varying,
    hero_image character varying,
    booking_url character varying,
    social_media jsonb,
    contact_email character varying,
    contact_phone character varying,
    whatsapp_number character varying,
    address character varying,
    meta_title character varying,
    meta_description character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    main_navigation jsonb,
    mobile_navigation jsonb,
    footer_navigation jsonb,
    footer_copyright_text text,
    sub_page_menus jsonb
);


ALTER TABLE public.site_settings OWNER TO postgres;

--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.site_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.site_settings_id_seq OWNER TO postgres;

--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: specialty_experiences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specialty_experiences (
    id integer NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    icon character varying,
    color character varying,
    description text,
    status character varying(50) DEFAULT 'published'::character varying,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'published'::character varying
);


ALTER TABLE public.specialty_experiences OWNER TO postgres;

--
-- Name: specialty_experiences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.specialty_experiences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.specialty_experiences_id_seq OWNER TO postgres;

--
-- Name: specialty_experiences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.specialty_experiences_id_seq OWNED BY public.specialty_experiences.id;


--
-- Name: stories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stories_id_seq OWNER TO postgres;

--
-- Name: stories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stories_id_seq OWNED BY public.stories.id;


--
-- Name: testimonials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.testimonials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.testimonials_id_seq OWNER TO postgres;

--
-- Name: testimonials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.testimonials_id_seq OWNED BY public.testimonials.id;


--
-- Name: thank_you_pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.thank_you_pages (
    id integer NOT NULL,
    title character varying NOT NULL,
    type public.enum_thank_you_pages_type NOT NULL,
    slug character varying NOT NULL,
    status public.enum_thank_you_pages_status DEFAULT 'draft'::public.enum_thank_you_pages_status,
    hero_section_heading character varying DEFAULT 'Thank You!'::character varying,
    hero_section_subheading character varying DEFAULT 'We''ve received your message'::character varying,
    hero_section_icon character varying DEFAULT '✅'::character varying,
    message jsonb,
    contact_info_show_contact boolean DEFAULT true,
    contact_info_email character varying,
    contact_info_phone character varying,
    contact_info_response_time character varying DEFAULT 'We''ll respond within 24 hours'::character varying,
    cta_section_show_cta boolean DEFAULT true,
    seo_meta_title character varying,
    seo_meta_description character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    _locales jsonb
);


ALTER TABLE public.thank_you_pages OWNER TO postgres;

--
-- Name: thank_you_pages_cta_section_cta_buttons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.thank_you_pages_cta_section_cta_buttons (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    text character varying NOT NULL,
    url character varying NOT NULL,
    variant public.enum_thank_you_pages_cta_section_cta_buttons_variant DEFAULT 'primary'::public.enum_thank_you_pages_cta_section_cta_buttons_variant
);


ALTER TABLE public.thank_you_pages_cta_section_cta_buttons OWNER TO postgres;

--
-- Name: thank_you_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.thank_you_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.thank_you_pages_id_seq OWNER TO postgres;

--
-- Name: thank_you_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.thank_you_pages_id_seq OWNED BY public.thank_you_pages.id;


--
-- Name: thank_you_pages_next_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.thank_you_pages_next_steps (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    step character varying NOT NULL
);


ALTER TABLE public.thank_you_pages_next_steps OWNER TO postgres;

--
-- Name: tours_gallery_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tours_gallery_images (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    image_id integer
);


ALTER TABLE public.tours_gallery_images OWNER TO postgres;

--
-- Name: tours_highlights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tours_highlights (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    highlight character varying
);


ALTER TABLE public.tours_highlights OWNER TO postgres;

--
-- Name: tours_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tours_id_seq OWNER TO postgres;

--
-- Name: tours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tours_id_seq OWNED BY public.tours.id;


--
-- Name: tours_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tours_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    dietary_options_id integer,
    travel_type_landing_pages_id integer,
    specialty_landing_pages_id integer,
    food_items_id integer,
    travel_types_id integer,
    specialty_experiences_id integer
);


ALTER TABLE public.tours_rels OWNER TO postgres;

--
-- Name: tours_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tours_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tours_rels_id_seq OWNER TO postgres;

--
-- Name: tours_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tours_rels_id_seq OWNED BY public.tours_rels.id;


--
-- Name: tours_whats_excluded; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tours_whats_excluded (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    item character varying
);


ALTER TABLE public.tours_whats_excluded OWNER TO postgres;

--
-- Name: tours_whats_included; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tours_whats_included (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    item character varying
);


ALTER TABLE public.tours_whats_included OWNER TO postgres;

--
-- Name: track_record_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.track_record_page (
    id integer NOT NULL,
    seo_title text NOT NULL,
    seo_description text NOT NULL,
    hero_title text NOT NULL,
    hero_subtitle text,
    philosophy_quote text,
    how_we_work_eyebrow text,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'draft'::character varying,
    _locales jsonb,
    _latestversion integer,
    _autosave boolean DEFAULT false
);


ALTER TABLE public.track_record_page OWNER TO postgres;

--
-- Name: track_record_page_awards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.track_record_page_awards (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    award text NOT NULL,
    year integer,
    organization text
);


ALTER TABLE public.track_record_page_awards OWNER TO postgres;

--
-- Name: track_record_page_awards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.track_record_page_awards ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.track_record_page_awards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: track_record_page_case_studies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.track_record_page_case_studies (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    client text NOT NULL,
    type text,
    description text
);


ALTER TABLE public.track_record_page_case_studies OWNER TO postgres;

--
-- Name: track_record_page_case_studies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.track_record_page_case_studies ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.track_record_page_case_studies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: track_record_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.track_record_page ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.track_record_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: track_record_page_press; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.track_record_page_press (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    outlet text NOT NULL,
    url text
);


ALTER TABLE public.track_record_page_press OWNER TO postgres;

--
-- Name: track_record_page_press_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.track_record_page_press ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.track_record_page_press_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: track_record_page_segments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.track_record_page_segments (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    num text,
    emoji text,
    name text NOT NULL,
    description text
);


ALTER TABLE public.track_record_page_segments OWNER TO postgres;

--
-- Name: track_record_page_segments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.track_record_page_segments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.track_record_page_segments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: track_record_page_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.track_record_page_stats (
    id integer NOT NULL,
    _parent_id integer,
    _order integer,
    _path text,
    number text NOT NULL,
    label text NOT NULL
);


ALTER TABLE public.track_record_page_stats OWNER TO postgres;

--
-- Name: track_record_page_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.track_record_page_stats ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.track_record_page_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: travel_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.travel_types (
    id integer NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    icon character varying,
    color character varying,
    description text,
    status character varying(50) DEFAULT 'published'::character varying,
    created_at timestamp(3) with time zone DEFAULT now(),
    updated_at timestamp(3) with time zone DEFAULT now(),
    _status character varying(50) DEFAULT 'published'::character varying
);


ALTER TABLE public.travel_types OWNER TO postgres;

--
-- Name: travel_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.travel_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.travel_types_id_seq OWNER TO postgres;

--
-- Name: travel_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.travel_types_id_seq OWNED BY public.travel_types.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    role public.enum_users_role DEFAULT 'editor'::public.enum_users_role NOT NULL,
    full_name character varying,
    department character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    reset_password_token character varying,
    reset_password_expiration timestamp(3) with time zone,
    salt character varying,
    hash character varying,
    login_attempts numeric DEFAULT 0,
    lock_until timestamp(3) with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vendors_awards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors_awards (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    award character varying,
    year numeric,
    organization character varying
);


ALTER TABLE public.vendors_awards OWNER TO postgres;

--
-- Name: vendors_closed_on; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors_closed_on (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    day public.enum_vendors_closed_on_day
);


ALTER TABLE public.vendors_closed_on OWNER TO postgres;

--
-- Name: vendors_facilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors_facilities (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    facility public.enum_vendors_facilities_facility
);


ALTER TABLE public.vendors_facilities OWNER TO postgres;

--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vendors_id_seq OWNER TO postgres;

--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: vendors_images_gallery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors_images_gallery (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    image_id integer
);


ALTER TABLE public.vendors_images_gallery OWNER TO postgres;

--
-- Name: vendors_operating_hours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors_operating_hours (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    day public.enum_vendors_operating_hours_day,
    open_time character varying,
    close_time character varying,
    is_closed boolean,
    notes character varying
);


ALTER TABLE public.vendors_operating_hours OWNER TO postgres;

--
-- Name: vendors_payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors_payment_methods (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    method public.enum_vendors_payment_methods_method
);


ALTER TABLE public.vendors_payment_methods OWNER TO postgres;

--
-- Name: vendors_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    food_items_id integer,
    dietary_options_id integer
);


ALTER TABLE public.vendors_rels OWNER TO postgres;

--
-- Name: vendors_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vendors_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vendors_rels_id_seq OWNER TO postgres;

--
-- Name: vendors_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vendors_rels_id_seq OWNED BY public.vendors_rels.id;


--
-- Name: _dietary_options_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._dietary_options_v ALTER COLUMN id SET DEFAULT nextval('public._dietary_options_v_id_seq'::regclass);


--
-- Name: _faqs_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._faqs_v ALTER COLUMN id SET DEFAULT nextval('public._faqs_v_id_seq'::regclass);


--
-- Name: _food_items_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v ALTER COLUMN id SET DEFAULT nextval('public._food_items_v_id_seq'::regclass);


--
-- Name: _food_items_v_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_rels ALTER COLUMN id SET DEFAULT nextval('public._food_items_v_rels_id_seq'::regclass);


--
-- Name: _food_items_v_version_allergens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_allergens ALTER COLUMN id SET DEFAULT nextval('public._food_items_v_version_allergens_id_seq'::regclass);


--
-- Name: _food_items_v_version_flavor_profile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_flavor_profile ALTER COLUMN id SET DEFAULT nextval('public._food_items_v_version_flavor_profile_id_seq'::regclass);


--
-- Name: _food_items_v_version_ingredients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_ingredients ALTER COLUMN id SET DEFAULT nextval('public._food_items_v_version_ingredients_id_seq'::regclass);


--
-- Name: _food_items_v_version_local_names id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_local_names ALTER COLUMN id SET DEFAULT nextval('public._food_items_v_version_local_names_id_seq'::regclass);


--
-- Name: _home_page_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._home_page_v ALTER COLUMN id SET DEFAULT nextval('public._home_page_v_id_seq'::regclass);


--
-- Name: _legal_pages_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._legal_pages_v ALTER COLUMN id SET DEFAULT nextval('public._legal_pages_v_id_seq'::regclass);


--
-- Name: _stories_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._stories_v ALTER COLUMN id SET DEFAULT nextval('public._stories_v_id_seq'::regclass);


--
-- Name: _testimonials_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._testimonials_v ALTER COLUMN id SET DEFAULT nextval('public._testimonials_v_id_seq'::regclass);


--
-- Name: _tours_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v ALTER COLUMN id SET DEFAULT nextval('public._tours_v_id_seq'::regclass);


--
-- Name: _tours_v_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_rels ALTER COLUMN id SET DEFAULT nextval('public._tours_v_rels_id_seq'::regclass);


--
-- Name: _tours_v_version_gallery_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_gallery_images ALTER COLUMN id SET DEFAULT nextval('public._tours_v_version_gallery_images_id_seq'::regclass);


--
-- Name: _tours_v_version_highlights id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_highlights ALTER COLUMN id SET DEFAULT nextval('public._tours_v_version_highlights_id_seq'::regclass);


--
-- Name: _tours_v_version_whats_excluded id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_whats_excluded ALTER COLUMN id SET DEFAULT nextval('public._tours_v_version_whats_excluded_id_seq'::regclass);


--
-- Name: _tours_v_version_whats_included id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_whats_included ALTER COLUMN id SET DEFAULT nextval('public._tours_v_version_whats_included_id_seq'::regclass);


--
-- Name: _vendors_v id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_id_seq'::regclass);


--
-- Name: _vendors_v_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_rels ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_rels_id_seq'::regclass);


--
-- Name: _vendors_v_version_awards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_awards ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_version_awards_id_seq'::regclass);


--
-- Name: _vendors_v_version_closed_on id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_closed_on ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_version_closed_on_id_seq'::regclass);


--
-- Name: _vendors_v_version_facilities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_facilities ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_version_facilities_id_seq'::regclass);


--
-- Name: _vendors_v_version_images_gallery id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_images_gallery ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_version_images_gallery_id_seq'::regclass);


--
-- Name: _vendors_v_version_operating_hours id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_operating_hours ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_version_operating_hours_id_seq'::regclass);


--
-- Name: _vendors_v_version_payment_methods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_payment_methods ALTER COLUMN id SET DEFAULT nextval('public._vendors_v_version_payment_methods_id_seq'::regclass);


--
-- Name: about_page id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page ALTER COLUMN id SET DEFAULT nextval('public.about_page_id_seq'::regclass);


--
-- Name: about_page_blocks_founder_story_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_founder_story_block ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_founder_story_block_id_seq'::regclass);


--
-- Name: about_page_blocks_hero_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_hero_block ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_hero_block_id_seq'::regclass);


--
-- Name: about_page_blocks_philosophy_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_philosophy_block ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_philosophy_block_id_seq'::regclass);


--
-- Name: about_page_blocks_stats_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_stats_block ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_stats_block_id_seq'::regclass);


--
-- Name: about_page_blocks_stats_block_stats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_stats_block_stats ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_stats_block_stats_id_seq'::regclass);


--
-- Name: about_page_blocks_team_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_team_block ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_team_block_id_seq'::regclass);


--
-- Name: about_page_blocks_team_block_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_team_block_members ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_team_block_members_id_seq'::regclass);


--
-- Name: about_page_blocks_timeline_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_timeline_block ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_timeline_block_id_seq'::regclass);


--
-- Name: about_page_blocks_timeline_block_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_timeline_block_events ALTER COLUMN id SET DEFAULT nextval('public.about_page_blocks_timeline_block_events_id_seq'::regclass);


--
-- Name: dietary_options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dietary_options ALTER COLUMN id SET DEFAULT nextval('public.dietary_options_id_seq'::regclass);


--
-- Name: faqs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs ALTER COLUMN id SET DEFAULT nextval('public.faqs_id_seq'::regclass);


--
-- Name: food_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items ALTER COLUMN id SET DEFAULT nextval('public.food_items_id_seq'::regclass);


--
-- Name: food_items_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_rels ALTER COLUMN id SET DEFAULT nextval('public.food_items_rels_id_seq'::regclass);


--
-- Name: home_page id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page ALTER COLUMN id SET DEFAULT nextval('public.home_page_id_seq'::regclass);


--
-- Name: home_page_blocks_about_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_about_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_about_block_id_seq'::regclass);


--
-- Name: home_page_blocks_cta_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_cta_section_id_seq'::regclass);


--
-- Name: home_page_blocks_cta_block_buttons id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block_buttons ALTER COLUMN id SET DEFAULT nextval('public.home_page_cta_section_buttons_id_seq'::regclass);


--
-- Name: home_page_blocks_cta_block_features id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block_features ALTER COLUMN id SET DEFAULT nextval('public.home_page_cta_section_features_id_seq'::regclass);


--
-- Name: home_page_blocks_hero_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_hero_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_hero_block_id_seq'::regclass);


--
-- Name: home_page_blocks_hero_block_badges id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_hero_block_badges ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_hero_block_badges_id_seq'::regclass);


--
-- Name: home_page_blocks_manifesto_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_manifesto_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_manifesto_block_id_seq'::regclass);


--
-- Name: home_page_blocks_pillars_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_pillars_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_pillars_block_id_seq'::regclass);


--
-- Name: home_page_blocks_pillars_block_pillars id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_pillars_block_pillars ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_pillars_block_pillars_id_seq'::regclass);


--
-- Name: home_page_blocks_segments_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_segments_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_segments_block_id_seq'::regclass);


--
-- Name: home_page_blocks_stats_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_stats_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_stats_block_id_seq'::regclass);


--
-- Name: home_page_blocks_stats_block_stats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_stats_block_stats ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_stats_block_stats_id_seq'::regclass);


--
-- Name: home_page_blocks_vendors_block id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_vendors_block ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_vendors_block_id_seq'::regclass);


--
-- Name: home_page_blocks_vendors_block_links id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_vendors_block_links ALTER COLUMN id SET DEFAULT nextval('public.home_page_blocks_vendors_block_links_id_seq'::regclass);


--
-- Name: legal_pages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_pages ALTER COLUMN id SET DEFAULT nextval('public.legal_pages_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: media_coverage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_coverage ALTER COLUMN id SET DEFAULT nextval('public.media_coverage_id_seq'::regclass);


--
-- Name: menus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus ALTER COLUMN id SET DEFAULT nextval('public.menus_id_seq'::regclass);


--
-- Name: menus_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus_items ALTER COLUMN id SET DEFAULT nextval('public._menus_items_v_id_seq'::regclass);


--
-- Name: payload_kv id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_kv ALTER COLUMN id SET DEFAULT nextval('public.payload_kv_id_seq'::regclass);


--
-- Name: payload_locked_documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_id_seq'::regclass);


--
-- Name: payload_locked_documents_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_rels_id_seq'::regclass);


--
-- Name: payload_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_migrations ALTER COLUMN id SET DEFAULT nextval('public.payload_migrations_id_seq'::regclass);


--
-- Name: payload_preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_id_seq'::regclass);


--
-- Name: payload_preferences_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_rels_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: specialty_experiences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialty_experiences ALTER COLUMN id SET DEFAULT nextval('public.specialty_experiences_id_seq'::regclass);


--
-- Name: stories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories ALTER COLUMN id SET DEFAULT nextval('public.stories_id_seq'::regclass);


--
-- Name: testimonials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.testimonials ALTER COLUMN id SET DEFAULT nextval('public.testimonials_id_seq'::regclass);


--
-- Name: thank_you_pages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thank_you_pages ALTER COLUMN id SET DEFAULT nextval('public.thank_you_pages_id_seq'::regclass);


--
-- Name: tours id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours ALTER COLUMN id SET DEFAULT nextval('public.tours_id_seq'::regclass);


--
-- Name: tours_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_rels ALTER COLUMN id SET DEFAULT nextval('public.tours_rels_id_seq'::regclass);


--
-- Name: travel_types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.travel_types ALTER COLUMN id SET DEFAULT nextval('public.travel_types_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Name: vendors_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_rels ALTER COLUMN id SET DEFAULT nextval('public.vendors_rels_id_seq'::regclass);


--
-- Data for Name: _contact_page_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._contact_page_v (id, parent_id, version, version_label, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _corporate_groups_page_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._corporate_groups_page_v (id, parent_id, version, version_label, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _dietary_options_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._dietary_options_v (id, parent_id, version_name, version_slug, version_icon, version_color, version_description, version_status, version_scheduled_publish, version_published_at, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave) FROM stdin;
1	1	Vegetarian	vegetarian	🥬	#22c55e	No meat, poultry, or fish. May include dairy and eggs depending on the type.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
2	2	Vegan	vegan	🌱	#16a34a	No animal products whatsoever — no meat, dairy, eggs, honey, or gelatin.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
3	3	Halal	halal	☪️	#0ea5e9	Prepared according to Islamic dietary law. No pork, no alcohol, meat from certified sources.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
4	4	Gluten-Free	gluten-free	🌾	#f59e0b	No wheat, barley, rye, or other gluten-containing ingredients.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
5	5	Dairy-Free	dairy-free	🥛	#8b5cf6	No milk, cheese, butter, cream, or other dairy products.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
6	6	Nut-Free	nut-free	🥜	#ef4444	No peanuts, tree nuts, or nut-derived ingredients. Important for allergy safety.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
7	7	Pescatarian	pescatarian	🐟	#06b6d4	No meat or poultry, but fish and seafood are allowed.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
9	9	Egg-Free	egg-free	🥚	#f97316	No eggs or egg-derived ingredients.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
10	10	Low-Sodium	low-sodium	🧂	#64748b	Reduced salt content. Suitable for those monitoring sodium intake.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
11	11	Spicy	spicy	🌶️	#dc2626	Contains chili or hot spices. Can be adjusted for heat tolerance.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	t	f
\.


--
-- Data for Name: _directions_page_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._directions_page_v (id, parent_id, version, version_label, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _faqs_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._faqs_v (id, parent_id, version_question, version_answer, version_category, version_sort_order, version_tags, version_page_visibility, version_tour_id, version_workflow_status, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave) FROM stdin;
1	1	How much does a food tour in KL cost?	Join-in tours are RM 285 to RM 359 per person, depending on which tour you choose. Private tours are quoted on request, usually for groups of four or more. Send us a message on WhatsApp and we'll put together something that works for your group.	booking	1	\N	\N	\N	draft	2026-04-03 11:20:22.334+08	2026-04-03 11:20:22.333+08	published	2026-04-03 11:20:22.34+08	2026-04-03 11:20:22.34+08	t	f
2	2	How do I book?	Book directly on the tour page at simplyenak.com or message us on WhatsApp at +60 12-345-6789. We confirm within 3 hours during business hours, often sooner. No third-party platforms, no booking fees, no hidden costs — we keep it direct so you get the best price.	booking	2	\N	\N	\N	draft	2026-04-03 11:20:22.362+08	2026-04-03 11:20:22.362+08	published	2026-04-03 11:20:22.364+08	2026-04-03 11:20:22.364+08	t	f
3	3	What if I need to cancel?	Free cancellation up to 48 hours before most tours, and 24 hours for some specialty experiences. We'll confirm the specific policy when you book. Life happens — flights get delayed, kids get sick. We're flexible and understanding, because we've been travelers too.	booking	3	\N	\N	\N	draft	2026-04-03 11:20:22.373+08	2026-04-03 11:20:22.373+08	published	2026-04-03 11:20:22.375+08	2026-04-03 11:20:22.375+08	t	f
4	4	How long are the tours?	Most tours run 4 to 5 hours at a leisurely pace. We pace based on your group's energy and curiosity — we're not watching a clock. If a vendor has a story worth hearing about their 40 years of cooking, we stop and hear it. That's the Simply Enak difference.	day	4	\N	\N	\N	draft	2026-04-03 11:20:22.385+08	2026-04-03 11:20:22.385+08	published	2026-04-03 11:20:22.387+08	2026-04-03 11:20:22.387+08	t	f
5	5	What can I expect on a food tour?	You'll visit 8-10 food stalls over 4-5 hours, tasting 15+ different dishes. Your guide shares stories about the food, culture, and history — like why Aunty Lim's laksa recipe hasn't changed since 1982. Small groups (max 9 people), local prices, no tourist traps. Just real food, real stories.	tour	10	\N	\N	\N	draft	2026-04-03 11:20:22.397+08	2026-04-03 11:20:22.396+08	published	2026-04-03 11:20:22.398+08	2026-04-03 11:20:22.398+08	t	f
6	6	Can I take photos during the tour?	Absolutely! We encourage photos — most guests want to remember Aunty Lim's smile or Uncle Tan's wok skills. Vendors are proud of their food and happy to be photographed. We'll also take group photos and can help you capture the perfect shot for Instagram or TripAdvisor.	tour	10	\N	\N	\N	draft	2026-04-03 11:20:22.409+08	2026-04-03 11:20:22.409+08	published	2026-04-03 11:20:22.411+08	2026-04-03 11:20:22.411+08	t	f
7	7	How much walking is involved?	Approximately 3km walking distance over 4-5 hours, at a leisurely pace with plenty of stops. We pause at each stall for 20-30 minutes, giving you time to digest, take photos, and listen to vendor stories. Not a power walk — more like a stroll through the neighborhood with friends.	accessibility	10	\N	\N	\N	draft	2026-04-03 11:20:22.419+08	2026-04-03 11:20:22.419+08	published	2026-04-03 11:20:22.421+08	2026-04-03 11:20:22.421+08	t	f
8	8	What happens if it rains?	Tours run rain or shine! Malaysia's rain is intense but brief — usually 20-30 minutes then sunshine returns. We have covered alternatives at most stalls and adjust the route if needed. Some guests say eating char kway teow while watching tropical rain is the best part of the tour.	accessibility	10	\N	\N	\N	draft	2026-04-03 11:20:22.429+08	2026-04-03 11:20:22.429+08	published	2026-04-03 11:20:22.43+08	2026-04-03 11:20:22.43+08	t	f
9	9	When will I receive confirmation?	We typically confirm within 3 hours during business hours (9am-6pm MYT), often within 30 minutes. For last-minute bookings same-day, message us on WhatsApp and we'll check vendor availability. Weekend tours fill up faster, so book 2-3 days ahead when possible.	booking	10	\N	\N	\N	draft	2026-04-03 11:20:22.438+08	2026-04-03 11:20:22.438+08	published	2026-04-03 11:20:22.44+08	2026-04-03 11:20:22.44+08	t	f
10	10	What's the minimum group size for private tours?	Private tours are available for groups of 4 or more people. We customize the route, pace, and food stops based on your group's preferences and dietary needs. Popular for corporate team building, family celebrations, or friends who want an exclusive experience. Message us on WhatsApp for a custom quote.	booking	10	\N	\N	\N	draft	2026-04-03 11:20:22.45+08	2026-04-03 11:20:22.45+08	published	2026-04-03 11:20:22.451+08	2026-04-03 11:20:22.451+08	t	f
11	11	I have food allergies. Is it safe?	We take allergies seriously. Let us know when booking about any allergies — peanuts, shellfish, gluten, etc. We'll adjust the route and inform each vendor. Some vendors have dedicated allergen-free prep areas. For severe allergies, we carry epinephrine and know the nearest clinic. Your safety comes first.	food	10	\N	\N	\N	draft	2026-04-03 11:20:22.459+08	2026-04-03 11:20:22.459+08	published	2026-04-03 11:20:22.461+08	2026-04-03 11:20:22.461+08	t	f
12	12	Is the food spicy?	Malaysian food can be spicy, but we adjust for your tolerance. Many Chinese dishes serve chili separately — you add your own heat. Malay dishes tend to be spicier by default. We'll warn you before each stop and can request mild versions. Our goal is flavor enjoyment, not fire-breathing.	food	10	\N	\N	\N	draft	2026-04-03 11:20:22.468+08	2026-04-03 11:20:22.468+08	published	2026-04-03 11:20:22.47+08	2026-04-03 11:20:22.47+08	t	f
13	13	Are there toilet breaks during the tour?	Yes! We start near a toilet facility and have bathroom breaks planned at 2-3 points during the tour. Most stalls have basic facilities, and we know which shopping centers have clean restrooms along the route. We pace the tour so you're never rushing or uncomfortable.	practical	10	\N	\N	\N	draft	2026-04-03 11:20:22.478+08	2026-04-03 11:20:22.478+08	published	2026-04-03 11:20:22.48+08	2026-04-03 11:20:22.48+08	t	f
14	14	Is there parking near the meeting point?	Yes, there's parking near all our meeting points. For Chinatown tours, there's paid parking at Petaling Street market or nearby shopping centers. For Chow Kit, street parking is available. We'll send detailed parking instructions with your booking confirmation. Some areas have limited weekend parking, so arrive 10 minutes early.	practical	10	\N	\N	\N	draft	2026-04-03 11:20:22.487+08	2026-04-03 11:20:22.487+08	published	2026-04-03 11:20:22.489+08	2026-04-03 11:20:22.489+08	t	f
\.


--
-- Data for Name: _food_items_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._food_items_v (id, parent_id, version_name, version_slug, version_description, version_category, version_origin, version_region, version_spice_level, version_preparation_method, version_typical_price, version_availability, version_image_id, version_cultural_significance, version_serving_suggestions, version_popular_variations, version_pairings, version_vendor_notes, version_status, version_featured, version_scheduled_publish, version_published_at, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _food_items_v_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._food_items_v_rels (id, "order", parent_id, path, dietary_options_id, media_id) FROM stdin;
\.


--
-- Data for Name: _food_items_v_version_allergens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._food_items_v_version_allergens (_order, _parent_id, id, allergen, _uuid) FROM stdin;
\.


--
-- Data for Name: _food_items_v_version_flavor_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._food_items_v_version_flavor_profile (_order, _parent_id, id, flavor, _uuid) FROM stdin;
\.


--
-- Data for Name: _food_items_v_version_ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._food_items_v_version_ingredients (_order, _parent_id, id, ingredient, is_main, _uuid) FROM stdin;
\.


--
-- Data for Name: _food_items_v_version_local_names; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._food_items_v_version_local_names (_order, _parent_id, id, language, name, script, _uuid) FROM stdin;
\.


--
-- Data for Name: _home_page_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._home_page_v (id, parent_id, version, created_at, updated_at, latest, autosave, _status) FROM stdin;
\.


--
-- Data for Name: _how_it_works_page_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._how_it_works_page_v (id, parent_id, version, version_label, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _how_to_prepare_page_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._how_to_prepare_page_v (id, parent_id, version, version_label, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _landing_pages_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._landing_pages_v (id, parent_id, version, version_label, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _legal_pages_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._legal_pages_v (id, parent_id, version, created_at, updated_at, latest, autosave, _status) FROM stdin;
\.


--
-- Data for Name: _stories_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._stories_v (id, parent_id, version_title, version_slug, version_author_id, version_excerpt, version_content, version_published_date, version_status, version_workflow_status, version_scheduled_publish, version_meta_title, version_meta_description, version_meta_image_id, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave, version_featured_image_id) FROM stdin;
1	1	The Satay Master of Kampung Baru	satay-master-kampung-baru	1	Pak Din has been fanning charcoal fires for 40 years. His secret isn't just the marinade—it's the patience.	Pak Din has been fanning charcoal fires for 40 years. His secret isn't just the marinade—it's the patience.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.571+08	2026-04-03 11:28:35.569+08	published	2026-04-03 11:28:35.577+08	2026-04-03 11:28:35.577+08	t	f	\N
2	2	The Heritage Behind Malaysian Food	heritage-behind-malaysian-food	1	Discover how Malaysian cuisine became a melting pot of Malay, Chinese, Indian, and indigenous influences over centuries of trade and cultural exchange.	Discover how Malaysian cuisine became a melting pot of Malay, Chinese, Indian, and indigenous influences over centuries of trade and cultural exchange.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.627+08	2026-04-03 11:28:35.627+08	published	2026-04-03 11:28:35.629+08	2026-04-03 11:28:35.629+08	t	f	\N
3	3	Understanding Mamak Culture	understanding-mamak-culture	1	The 24-hour open-air restaurants that serve as Malaysia's living room. Why teh tarik and roti canai unite the nation.	The 24-hour open-air restaurants that serve as Malaysia's living room. Why teh tarik and roti canai unite the nation.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.645+08	2026-04-03 11:28:35.645+08	published	2026-04-03 11:28:35.648+08	2026-04-03 11:28:35.648+08	t	f	\N
4	4	Family Recipes Passed Down Through Generations	family-recipes-generations	1	Family recipes passed down through generations	Family recipes passed down through generations	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.661+08	2026-04-03 11:28:35.661+08	published	2026-04-03 11:28:35.663+08	2026-04-03 11:28:35.663+08	t	f	\N
5	5	Why We Don't Do 'Tourist' Food	why-we-dont-do-tourist-food	1	There's a difference between the food served to tourists and the food locals eat. Here is how to spot the difference and why it matters.	There's a difference between the food served to tourists and the food locals eat. Here is how to spot the difference and why it matters.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.674+08	2026-04-03 11:28:35.674+08	published	2026-04-03 11:28:35.675+08	2026-04-03 11:28:35.675+08	t	f	\N
6	6	Why Street Food Is The Soul Of Malaysia	street-food-soul-malaysia	1	From hawker centers to roadside stalls, street food isn't just about eating—it's where communities gather, stories are shared, and traditions are preserved.	From hawker centers to roadside stalls, street food isn't just about eating—it's where communities gather, stories are shared, and traditions are preserved.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.686+08	2026-04-03 11:28:35.686+08	published	2026-04-03 11:28:35.688+08	2026-04-03 11:28:35.688+08	t	f	\N
7	7	11 Foods To Try During Hari Raya	11-foods-hari-raya	1	Hari Raya marks the end of Ramadan with a month of celebrations and amazing dishes, many of which can only be found this time of the year.	Hari Raya marks the end of Ramadan with a month of celebrations and amazing dishes, many of which can only be found this time of the year.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.698+08	2026-04-03 11:28:35.698+08	published	2026-04-03 11:28:35.7+08	2026-04-03 11:28:35.7+08	t	f	\N
8	8	What "Vegetarian" Actually Means in Kuala Lumpur	what-vegetarian-actually-means-kuala-lumpur	1	In KL, vegetarian food is rooted in Buddhist and Hindu spiritual practice, not wellness trends. The rules are completely different depending on who cooked your food. Here's what you need to know before you order.	**TL;DR:** Vegetarian food in KL is nothing like vegetarian food back home. Here, it's rooted in Buddhist and Hindu spiritual practice, not health trends — and that changes everything about what ends up on your plate. Some dishes include eggs. Some exclude onion and garlic entirely. Some Buddhists only eat vegetarian twice a month. Read this before you order, and you'll eat far better.\n\n---\n\nThe first time someone in KL tells you they're vegetarian, don't assume you know what that means.\n\nBack home — whether that's London, Sydney, or New York — vegetarian usually means one thing: no meat. It's a dietary choice. Maybe ethical, maybe health-related. The rules are pretty clear.\n\nIn Kuala Lumpur, the same word covers something completely different. Vegetarian food here grew out of Buddhist merit-making, Hindu devotion, and Taoist spiritual discipline. These are practices that go back centuries. The food that came from them is some of the most interesting you'll eat in this city — but only if you understand what you're looking at.\n\nWe've been taking people through KL's [vegetarian food spots](http://localhost:4321/tours/dietary/vegetarian) for 14 years. The question we hear most isn't "where do I eat?" It's "why does vegetarian food here work so differently?" This post answers that.\n\n---\n\n## Why Vegetarian Food in KL Isn't What You Expect\n\nKL sits at a cultural crossroads. Three distinct communities have shaped how vegetarian food looks and tastes here: Chinese Buddhist, Tamil Hindu, and increasingly, health-conscious Malaysians following a newer plant-based wave.\n\n[35% of Malaysians now regularly eat plant-based meals](https://www.statista.com/statistics/1075705/malaysia-plant-based-food-consumers/), according to Statista's 2025 data. But that number includes people eating vegetarian for very different reasons. Some are doing it for health. Many are doing it for faith. And the food on their plates reflects that difference completely.\n\nThe wellness trend is real. But it's layered on top of something much older. The Buddhist and Hindu vegetarian traditions in Malaysia weren't imported last decade. They arrived with the communities themselves, generations ago, and took root in neighbourhoods, temples, and family kitchens across the city.\n\nWhen you understand that, the food starts to make sense.\n\n---\n\n## So What Does "Vegetarian" Actually Mean Here?\n\nIn Malaysia, "vegetarian" means something different depending on who cooked your food. Chinese Buddhist vegetarian food typically excludes all meat, eggs, dairy, and the five pungent roots: onion, garlic, chives, spring onion, and leeks. South Indian vegetarian food often includes eggs and dairy, but no beef. The word is the same. The plate can look completely different.\n\nThis trips up visitors constantly. You order something labelled vegetarian at a Chinese Buddhist stall and wonder why there's no garlic flavour. You order at a Tamil restaurant and find egg in your thosai. Neither is wrong. They're just different traditions with different rules.\n\nThe [Chinese Buddhist tradition](https://en.wikipedia.org/wiki/Malaysian_Chinese_cuisine) is particularly fascinating. What you'll find at Buddhist temple canteens and 素食 (sù shí) stalls is often entirely plant-based, long before "vegan" became a marketing word. The five pungent roots are avoided because they're believed to stimulate the mind and disturb meditation. So the flavour base is completely different from what you'd expect — no allium sharpness, more subtle, often sweeter.\n\nSouth Indian vegetarian food follows the Hindu tradition. Eggs and dairy are frequently included. The flavour profiles are bolder: tamarind, mustard seeds, curry leaves, coconut. Banana leaf rice with vegetable curries, thosai with sambar, idli with coconut chutney. Rich, complex, and filling.\n\nSame word. Very different kitchens.\n\n---\n\n## The Buddhist Calendar and the Days Everything Changes\n\nHere's something most visitors never know, and we love watching people's faces when we explain it.\n\nMany Chinese Buddhists in Malaysia eat vegetarian on the 1st and 15th of each lunar month. It's a merit-making practice. A way of honouring the occasion with discipline and restraint.\n\nOn those days, [something shifts in the city's food scene](https://teahouse.buddhistdoor.net/eye-on-southeast-asia-lunch-at-a-malaysian-temples-vegetarian-canteen/). Stalls that normally sell mixed food put out vegetarian menus. Temple canteens run buffets that start at dawn and sell out before lunch. Regular hawker centres fill up early with regulars who only eat vegetarian twice a month but take it seriously when they do.\n\nUncle Chen, one of the vendors we visit on our [Chinatown food walks](http://localhost:4321/tours/kl-street-food), makes his handmade steamed buns every morning. On the 1st and 15th, his vegetarian varieties go first. Always. He's been watching this pattern for decades.\n\nIf you happen to be in KL on one of those days, go early. The food is worth it, and the atmosphere in the stalls and temple canteens is something you won't see on a regular Tuesday.\n\n---\n\n## Does That Mean Vegetarian Food Here Is Always Egg-Free?\n\nNo, and this is probably the most important thing to know before you order. Chinese Buddhist vegetarian food is usually fully plant-based: no eggs, no dairy, no five pungent roots. South Indian vegetarian food regularly includes eggs and dairy. A "vegetarian" label means different things at different stalls, so always ask.\n\nThe simplest way to tell the difference before you order: look for the characters 素食 (sù shí). That's the Chinese term for Buddhist vegetarian food. If you see that sign, you're in a place following the stricter definition. No meat, no eggs, no dairy, no onion, no garlic.\n\nAt Indian stalls, the word "vegetarian" is usually displayed in English or Tamil. The rules are different there: eggs may be in, dairy is common, and the flavour base will reflect it. Neither approach is more "correct." They're just rooted in different spiritual traditions.\n\nThe practical takeaway: when in doubt, ask. Point to the dish and say "ada telur?" (any eggs?). Most stall owners are happy to explain. In our experience, they appreciate the curiosity.\n\n---\n\n## Where This Food Actually Comes From\n\nThe Chinese Buddhist vegetarian tradition in Malaysia came with the Hokkien, Cantonese, and Hakka immigrants who built KL's Chinatown and surrounding neighbourhoods. They brought their temple practices with them. The vegetarian food culture that exists in those streets today traces directly back to those communities, and the family kitchens and temple canteens that kept the tradition alive across generations.\n\nThe Tamil Hindu tradition arrived with South Indian labourers and traders. The banana leaf rice stalls in Brickfields and Little India serve food that connects directly to South Indian temple cuisine: rice, lentils, coconut-based curries, pickles, and pappadum, all made without beef or pork.\n\nWalk through [Kuala Lumpur's food neighbourhoods](http://localhost:4321/tours/locations/kuala-lumpur) and you're walking through that layered history. It's there in the signage, in the ingredients, in the way certain stalls smell different from the ones next to them.\n\nOur Chow Kit Market tour puts you right in the middle of it. The [Chow Kit wet market](http://localhost:4321/tours/chow-kit-market) is where you see the raw ingredients of both traditions side by side: the tofu blocks and mock meat products from the Buddhist suppliers, the fresh curry leaves and dried lentils from the Indian grocers. It's the best single place in KL to understand how these food cultures coexist.\n\nThe [plant-based food industry in Malaysia is growing at 18% annually](https://malaysiaexpatguide.com/plant-based-eating-in-malaysia/) right now, driven partly by a new generation of health-conscious Malaysians. But what makes KL's vegetarian scene genuinely interesting isn't the new wave. It's the century-old foundation underneath it.\n\n---\n\n## How Do I Navigate Vegetarian Food in KL as a Visitor?\n\nThe single most useful thing you can learn: look for 素食 signs in Chinese script. That tells you the place follows Buddhist vegetarian standards — no meat, no eggs, no dairy, no five pungent roots. These spots are everywhere once you know what to look for.\n\nAt Indian restaurants and stalls, ask about eggs and dairy directly. Most places are happy to tell you exactly what's in a dish.\n\nAt Malay hawker stalls, be careful. Many dishes that look vegetarian contain belacan (shrimp paste) or were cooked in lard. This isn't carelessness — it's just that "vegetarian" in the Western sense isn't always the default assumption. We'll cover this in detail in our next guide on the [hidden meat problem in KL hawker food](http://localhost:4321/tours). For now: always ask, and enjoy the conversation that usually follows.\n\nThe spots that locals know are vegetarian — temple canteens, Buddhist stalls, long-running family operations — [often don't advertise themselves](https://www.veganfoodquest.com/vegan-guide-to-kuala-lumpur/). They don't need to. The community already knows. That's exactly where we take guests.\n\n---\n\n## KL Is One of the Great Vegetarian Cities in Asia\n\nHere's the short version of everything above.\n\nVegetarian food in KL is a spiritual category before it's a dietary one. The rules genuinely differ by tradition: Chinese Buddhist food is often stricter than Western veganism, while South Indian vegetarian food follows a completely different logic. And on the 1st and 15th of the lunar month, the whole scene shifts.\n\nOnce you understand the cultural logic, the food makes beautiful sense. It's not confusing — it's rich. And it opens up parts of the city that most visitors never reach.\n\nWe've been navigating this for 14 years. Come eat with us, and we'll show you the spots, the stalls, and the stories that don't make it onto any map. [Have a look at what we do together.](http://localhost:4321/tours/dietary/vegetarian)\n\n---\n\n## Frequently Asked Questions\n\n**Is KL good for vegetarians?**\nYes, genuinely. KL has one of the most developed vegetarian food scenes in Southeast Asia, rooted in Chinese Buddhist and South Indian Hindu traditions that go back generations. The variety is enormous, from temple canteens to hawker stalls to full restaurants. Once you know how to read the signs, you'll eat very well.\n\n**What does 素食 mean and how do I spot it?**\n素食 (pronounced sù shí) is the Chinese term for Buddhist vegetarian food. It means the food excludes all meat, eggs, dairy, and the five pungent roots (onion, garlic, chives, spring onion, leeks). Look for this on signage outside stalls and restaurants — it's your clearest guide to strictly plant-based food in KL's Chinese areas.\n\n**Why do some vegetarian dishes in Malaysia have no onion or garlic?**\nThis comes from the Chinese Buddhist tradition, which avoids the five pungent roots: onion, garlic, chives, spring onion, and leeks. They're believed to stimulate the mind and disturb spiritual practice. If your vegetarian dish tastes unusually mild or subtly sweet, that's likely why. It's a feature, not an oversight.\n\n**What is the Buddhist vegetarian tradition in Malaysia, and why do some people only eat vegetarian twice a month?**\nMany Malaysian Chinese Buddhists observe vegetarian days on the 1st and 15th of the lunar calendar as a merit-making practice. It's a form of spiritual discipline rather than a permanent dietary choice. On those days, vegetarian stalls get busy early and temple canteens run special menus.\n\n**Can Simply Enak accommodate vegetarian guests on their tours?**\nYes, completely. We've been accommodating vegetarian guests for 14 years, and we know exactly where to take you. Our tours include stops that work beautifully for vegetarians — from the Chow Kit Market to Chinatown's Buddhist stalls. Just let us know when you book and we'll make sure every stop works for you.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.708+08	2026-04-03 11:28:35.708+08	published	2026-04-03 11:28:35.711+08	2026-04-03 11:28:35.711+08	t	f	\N
9	9	The Hidden Meat Problem: Why Vegetables in KL Aren't Always What They Seem	hidden-meat-problem-vegetarian-kl	1	Ordering vegetables at a mixed hawker stall in KL doesn't make your meal vegetarian. Belacan, lard, oyster sauce and meat-based broths hide in plain sight. Here's where they are and how to navigate them.	**TL;DR:** Ordering vegetables at a mixed hawker stall in KL doesn't make your meal vegetarian. Belacan (shrimp paste) is in almost every Malay vegetable dish. Lard is the default cooking fat at many Chinese stalls. Broths are usually pork-based. Oyster sauce is on almost every plate of Chinese greens. This post shows you where the animal products hide and how to navigate them.\n\n---\n\nHere's something that surprises almost every vegetarian visitor to KL.\n\nYou sit down at a hawker stall. You point to the vegetable dish. It looks perfectly innocent: kangkung, stir-fried with chilli and garlic. No meat in sight.\n\nWhat you can't see is the belacan.\n\nBelacan is fermented shrimp paste. It goes into the wok before the vegetables do, and it's in a huge proportion of Malay vegetable dishes. [Sambal belacan is to Malaysians what ketchup is to the West](https://www.linsfood.com/sambal-belacan-malay-chilli-paste/): ubiquitous, invisible if you don't know to ask, and packed with umami from fermented seafood.\n\nIf you're vegetarian and eating at mixed hawker stalls in KL, this is the guide you need. We've been navigating this for 14 years, and we want to save you the discovery.\n\n---\n\n## What Is Belacan, and Why Is It Everywhere?\n\nBelacan is a fermented shrimp paste made from tiny dried shrimp, compressed into blocks and aged until pungent and deeply savoury. It is one of the foundational flavours in Malay cooking, used the way a French cook uses butter or an Italian cook uses olive oil: as the base that everything else is built on.\n\nThe most famous example is [kangkung belacan](https://www.singaporeanmalaysianrecipes.com/kangkung-belacan-recipe/): stir-fried water spinach with shrimp paste. The name literally tells you what's in it. But most visitors don't read the name. They see a plate of greens and assume it's safe.\n\nBelacan also goes into sambal, which is served alongside almost every Malay dish. It's in nasi goreng. It flavours the broth in some laksa varieties. It seasons the chilli sauces at mixed stalls. You often can't taste it as seafood — the fermentation transforms it into something deeper, smokier, more complex.\n\nAt a dedicated 素食 Buddhist stall, none of this is an issue. At a mixed Malay hawker stall, it's worth asking every time.\n\n---\n\n## The Lard Question at Chinese Stalls\n\nChinese hawker cooking has its own hidden ingredient: pork lard.\n\nLard gives Chinese stir-fries a rich, aromatic quality that vegetable oil can't replicate. Many Chinese hawkers use it by default, even for vegetable dishes. The most famous example is char kway teow: flat rice noodles stir-fried in a blazing hot wok. The smoky, charred flavour comes partly from the lard that coats the pan.\n\nA plate of stir-fried kailan or tofu at a mixed Chinese stall may have been cooked in lard, even if no meat appears on the plate.\n\nThen there's oyster sauce. [Oyster sauce is made from oyster extract](https://en.wikipedia.org/wiki/Oyster_sauce) and is the default sauce for Chinese-style greens across Malaysia. It's in the glossy sauce on your gai lan. It's in the dipping sauce beside your tofu. It's often added without anyone thinking to mention it, because for most diners it's not a concern.\n\nVegetarian oyster sauce does exist and is common at Buddhist 素食 stalls. At mixed Chinese stalls, the default is the real thing.\n\n---\n\n## Which Dishes Are Most Likely to Catch You Out?\n\n**Kangkung belacan** — stir-fried water spinach. Almost always contains shrimp paste, even at non-Malay stalls.\n\n**Nasi goreng** — fried rice. Usually seasoned with belacan, oyster sauce, or anchovies. Vegetarian versions exist only at 素食 stalls.\n\n**Char kway teow** — flat noodles, very often cooked in lard with prawns and lard croutons mixed through.\n\n**Vegetable soups** — the broth at a mixed hawker stall is almost always pork-based or chicken-based, even if vegetables are the only solid ingredient.\n\n**Chinese greens (gai lan, kailan, bayam)** — default sauce is oyster sauce, default cooking fat is often lard.\n\n**Laksa** — the broth contains dried shrimp, prawn paste, or seafood stock in most versions. Vegetarian laksa is available but specific to certain stalls.\n\n**Sambal** — virtually any sambal at a Malay stall contains belacan. Even served on the side, it came from the same wok.\n\n---\n\n## How Do You Actually Navigate This?\n\nThe safest approach: eat at stalls built for vegetarians, not mixed stalls that try to accommodate you.\n\nLook for [素食 (sù shí) signs](http://localhost:4321/tours/dietary/vegetarian) in Chinese script. These stalls use vegetable oil, mushroom-based sauces, and no belacan. The whole kitchen is set up for vegetarian cooking.\n\nAt Indian vegetarian restaurants, the kitchen is built around a completely different tradition. No lard. No belacan. Ask about eggs and dairy, but you don't have to worry about shrimp paste or pork.\n\nAt Malay hawker stalls, the phrase to know is: "Tak mahu belacan, tak mahu ikan" — no belacan, no fish. Some vendors can accommodate this; many cannot, because the belacan goes into the base sambal before individual orders are cooked. It's worth asking, and most stall owners will tell you honestly if they can help.\n\nAt mixed Chinese stalls, ask "Tak guna lard?" (No lard?) and "Ada sos tiram?" (Is there oyster sauce?). Some vendors have vegetable oil and vegetarian oyster sauce available. Many don't.\n\nThe stalls where you can eat freely without asking every question are the Buddhist 素食 stalls and Indian vegetarian places. [Our Chow Kit Market tour](http://localhost:4321/tours/chow-kit-market) takes you through both, so you can see, smell, and taste the difference in a single morning.\n\n---\n\n## Why This Isn't Anyone's Fault\n\nIt's worth saying clearly: vendors using belacan and lard aren't trying to catch you out.\n\nThese ingredients are part of how Malaysian cooking has worked for generations. The concept of "vegetarian" as a dietary default, where you'd expect any restaurant to accommodate you, is a relatively recent idea. In the hawker context, "vegetables" means no meat on the plate. The cooking medium and the flavour base aren't part of that definition.\n\nKnowing this changes how you navigate it. You're not looking for vendors who forgot to mention something. You're looking for the kitchens that were built around a different tradition from the start: the Buddhist 素食 stalls, the Indian vegetarian places, the temple canteens that have been feeding vegetarians properly for decades.\n\nThat's exactly what [we show people on our tours in Kuala Lumpur](http://localhost:4321/tours/locations/kuala-lumpur). Not how to negotiate with mixed stalls, but how to find the stalls that already work beautifully for you.\n\n---\n\n## Frequently Asked Questions\n\n**Is belacan in all Malay vegetable dishes?**\nNot every single one, but most. Belacan goes into sambal, which is the base sauce for a huge number of Malay vegetable dishes. Kangkung belacan, nasi goreng, and most stir-fried Malay vegetables contain it. At 素食 stalls, belacan is never used.\n\n**How do I ask a vendor if there's belacan in a dish?**\nSay "ada belacan?" — is there belacan? Most vendors will answer honestly. If they're not sure, they'll say so. At dedicated 素食 stalls, you don't need to ask at all.\n\n**Is char kway teow vegetarian?**\nAlmost never at a mixed stall. The classic version is made with lard, pork lard croutons, prawns, and sometimes cockles. Vegetarian char kway teow exists at Buddhist 素食 stalls, made with vegetable oil and no seafood.\n\n**Can I ask Chinese hawker stalls to cook without lard?**\nSome can and will. Others use lard as part of the base preparation and can't separate it from individual orders. It's always worth asking, but the most reliable option is a 素食 stall where the whole kitchen runs on vegetable oil.\n\n**Do Indian vegetarian restaurants in KL use belacan or lard?**\nNo. South Indian and Tamil vegetarian cooking has its own tradition that does not include belacan, lard, or pork-based ingredients. These restaurants are a safe option for vegetarians, though it's worth asking about eggs and dairy depending on your needs.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.724+08	2026-04-03 11:28:35.724+08	published	2026-04-03 11:28:35.728+08	2026-04-03 11:28:35.728+08	t	f	\N
10	10	How to Find Vegetarian Restaurants in KL, Penang and Ipoh	how-to-find-vegetarian-restaurants-kl-penang-ipoh	1	Vegetarian restaurants in Malaysia don't always advertise themselves. Many are temple canteens and Buddhist community stalls known only by word of mouth. Here's how to find them in KL, Penang and Ipoh.	**TL;DR:** Vegetarian restaurants in Malaysia don't always advertise themselves. Many are attached to temples, run by Buddhist communities, and found through local knowledge. Once you know the signs to look for — the 素食 characters, the timing, the right neighbourhoods — they're everywhere. This guide shows you how to find them in KL, Penang and Ipoh.\n\n---\n\nHere's the thing about the best vegetarian spots in Malaysia.\n\nThey're not trying to attract you.\n\nThe Buddhist temple canteen off Jalan Ampang in KL doesn't need a website. The lunch-only 素食 stall tucked behind the wet market in Ipoh doesn't need Instagram. The decades-old vegetarian shop beside a George Town temple in Penang doesn't need a TripAdvisor listing. The communities that eat there already know exactly where they are.\n\nThis is what makes finding vegetarian food in Malaysia different from finding it anywhere else. You're not looking for restaurants competing for your attention. You're looking for places that exist to serve a community — and have been doing so for generations.\n\nHere's how to find them.\n\n---\n\n## The 素食 Sign: Your Single Most Reliable Guide\n\nThe single most useful thing you can learn: look for the characters 素食 (pronounced sù shí).\n\n素食 is the Chinese term for Buddhist vegetarian food. Any stall or restaurant displaying these characters follows strict vegetarian kitchen standards: no meat, no seafood, no eggs, no dairy, and no five pungent roots (onion, garlic, chives, spring onion, leeks). The whole kitchen is built around these rules. You don't have to ask.\n\nYou'll find 素食 signs in Chinatown, in older neighbourhood shophouses, on hawker stall banners in predominantly Chinese areas. Once you start looking, they're everywhere.\n\nIn KL, walk the older streets around Petaling Street and Chinatown. In [Penang](http://localhost:4321/tours/locations/penang), George Town's pre-war shophouse rows have 素食 stalls tucked between hardware shops and coffee houses. In Ipoh, the Old Town area has a strong Buddhist community and several long-running 素食 spots.\n\nThese are the places locals go. They often have no English signage. They open early and close by midday. And the food is some of the most carefully made vegetarian cooking you'll find in this country.\n\n---\n\n## Temple Canteens: The Spots Nobody Advertises\n\nThe most reliable vegetarian food in KL is often inside or beside a Buddhist temple.\n\n[The Dharma Realm Guan Yin Sagely Monastery](https://teahouse.buddhistdoor.net/eye-on-southeast-asia-lunch-at-a-malaysian-temples-vegetarian-canteen/) on Jalan Ampang is one of KL's most striking religious landmarks. Behind the main monastery building is a large canteen that serves over twenty freshly cooked vegetarian dishes every morning. The food is strictly Buddhist vegetarian: no eggs, no dairy, no pungent roots. A full plate costs around RM 5-8. There's no tourist signage pointing you there.\n\nKun Yam Thong Temple, also on Jalan Ampang, runs a vegetarian canteen during lunch hours. Locals have been coming here for years. There's nothing online to send you there.\n\nThese canteens are welcoming to everyone, not only Buddhists. They're community spaces. But you have to know they exist to walk through the door.\n\nIn Penang, Annalakshmi at the Temple of Fine Arts in Pulau Tikus operates on a donation basis. The cooks and servers are all volunteers. The food is Indian vegetarian, cooked fresh and served buffet-style. Penangites know it well. Most visitors walk straight past it.\n\n[We take guests to spots like these](http://localhost:4321/tours/dietary/vegetarian) precisely because they won't find them on their own — not because they're secret, but because they don't announce themselves.\n\n---\n\n## How the 1st and 15th Changes Your Options\n\nIf you're in KL, Penang or Ipoh on the 1st or 15th of the lunar calendar, your vegetarian options multiply.\n\nOn those days, many Chinese Buddhists observe vegetarian eating as a merit-making practice. Stalls that normally serve mixed food put out vegetarian menus. Vendors who only cook vegetarian twice a month still do it properly, because it's a discipline they've kept for decades.\n\nTemple canteens get busier. 素食 stalls appear at regular hawker centres that aren't there on other days. The vegetarian section of the wet market sees more traffic.\n\nIf you have flexibility on travel dates, this is worth factoring in. [Our Chinatown food walks](http://localhost:4321/tours/kl-street-food) pass through some of these stalls on their active days.\n\n---\n\n## The Apps and Tools That Help\n\n**[HappyCow](https://www.happycow.net/asia/malaysia/kuala-lumpur/)** is the most comprehensive tool for finding vegetarian and vegan restaurants across Malaysia. [Penang alone has 23 fully vegan and 151 vegetarian-friendly restaurants listed](https://www.happycow.net/best-vegan-restaurants/penang-malaysia). [Ipoh has 65](https://www.happycow.net/asia/malaysia/ipoh/). KL has hundreds.\n\nThe caveat: many of the best vegetarian spots in Malaysia, especially temple canteens and older 素食 stalls, are not listed anywhere. HappyCow is a starting point, not the full picture.\n\nGoogle Maps is also useful. Search for "素食" directly in Chinese characters and you'll get results that an English search for "vegetarian" would miss entirely — because these places don't use English to describe themselves.\n\n---\n\n## KL: Where to Start Looking\n\nThe clearest concentrations of vegetarian food in KL:\n\n**Chinatown (Petaling Street and nearby streets):** 素食 stalls, Buddhist vegetarian shops, and temple canteens within walking distance of each other. Go in the morning for the most options.\n\n**Brickfields (Little India):** South Indian vegetarian restaurants, banana leaf rice stalls, and dosa shops. A completely different vegetarian tradition from the Chinese Buddhist spots, and equally good.\n\n**Jalan Ampang (near KLCC):** Two of KL's most well-known temple canteens within a short walk. Budget RM 5-10 for a full, filling plate.\n\nOur [Chow Kit Market tour](http://localhost:4321/tours/chow-kit-market) passes through areas where you'll see both traditions side by side. It's the single clearest way to understand how the two vegetarian food cultures of KL coexist.\n\n---\n\n## Penang: The Richest Vegetarian Scene in the North\n\nPenang has one of the most developed vegetarian food scenes in Malaysia, driven by its large, long-established Chinese Buddhist community and its South Indian Tamil heritage.\n\nThe pre-war shophouses of George Town contain 素食 shops that have been there for decades. Most open for breakfast and lunch only. The food is simple, affordable, and very good.\n\nPenang's Indian vegetarian scene, concentrated around Little India near Penang Road, runs alongside the Chinese Buddhist scene entirely separately. Two different traditions, both thriving, within a few streets of each other.\n\nMak Cik Salmah, one of the vendors we work with in Penang, knows these neighbourhoods as well as anyone. When we're there, she guides us to the spots that don't appear on any app.\n\n---\n\n## Ipoh: Quieter, But Worth the Search\n\nIpoh has a smaller vegetarian scene than KL or Penang, but a strong Buddhist community means 素食 stalls are well-established in the Old Town area.\n\nThe coffee shops of Old Town Ipoh are famous across Malaysia. The vegetarian stalls that share those spaces are talked about less. Arrive before noon: most close by 12:30pm. What you find is genuinely good, and very affordable.\n\n---\n\n## The Honest Answer\n\nThe most reliable way to find good vegetarian food in KL, Penang or Ipoh is to know the community — or go with someone who does.\n\nApps get you started. The 素食 sign gets you most of the way. But the temple canteen with no sign, the 素食 stall that only appears on certain days, the Penang shop that's been vegetarian since before it was a category: those you find through people.\n\nThat's what we've been building for 14 years. [Come eat with us](http://localhost:4321/tours), and we'll show you the ones worth finding.\n\n---\n\n## Frequently Asked Questions\n\n**What does 素食 mean, and how do I use it to find vegetarian restaurants?**\n素食 (sù shí) is the Chinese term for Buddhist vegetarian food. Search for it directly in Google Maps or look for the characters on shop signage. It's far more reliable than searching "vegetarian" in English, as many 素食 stalls have no English signage at all.\n\n**Are there vegetarian restaurants in KL that aren't listed on HappyCow?**\nYes, many. Temple canteens, older 素食 stalls, and community-run lunch spots often have no online presence. They're known within the community but invisible to apps and search engines. Going with a local guide is the most reliable way to find them.\n\n**What time do vegetarian restaurants in KL and Penang open and close?**\nMost Buddhist 素食 stalls and temple canteens open early, around 7am, and close by midday or early afternoon. If you arrive after 1pm, many will be sold out. Indian vegetarian restaurants typically have longer hours. Plan to eat vegetarian in the morning or at lunch and you'll have far more choice.\n\n**Is Penang better for vegetarians than KL?**\nDifferent rather than better. Penang has a more concentrated vegetarian scene within walking distance in George Town, mixing Chinese Buddhist and South Indian traditions. KL has more overall variety but is more spread out. Both cities have excellent options once you know where to look.\n\n**Can Simply Enak help me find vegetarian food in KL, Penang and Ipoh?**\nYes. We've been navigating these cities and their food cultures for 14 years. Whether you join a tour or just want advice, we're happy to point you toward the spots we eat at ourselves.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.749+08	2026-04-03 11:28:35.748+08	published	2026-04-03 11:28:35.751+08	2026-04-03 11:28:35.751+08	t	f	\N
11	11	11 Foods To Try During Hari Raya	11-foods-to-try-during-hari-raya	1	There’s nothing in this world like the food you will find in Malaysia during Hari Raya. Don’t get me wrong, we have amazing food all year round and for special occasions, but the delicacies served during Hari Raya are at the top of most of our tourists’ “must-have” lists.	<p>There’s nothing in this world like the food you will find in Malaysia during Hari Raya. Don’t get me wrong, we have amazing food all year round and for special occasions, but the delicacies served during Hari Raya are at the top of most of our tourists’ “must-have” lists.</p>\n<p>Hari Raya marks the end of Ramadan, or the fasting month, for Muslims worldwide, and especially here in Malaysia. So what follows a month of fasting? A whole month of celebrations and eating amazing dishes, many of which can only be found this time of the year. But you don’t have to be Muslim to enjoy them and experience everything that Hari Raya has to offer. But we can talk about other aspects of Hari Raya later. Let’s dive right in and talk about my personal favorite subject, food.</p>\n<h3>11 Traditional Hari Raya Dishes</h3>\n<h4>Lemang</h4>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_66_4cc0e593c3.jpeg" alt="asset-66.jpeg">\n<p>Lemang can take four to five hours just to cook, but I’m here to tell you it is well worth it. The cooking process alone is unique and has gone unchanged since its beginning. Lemang is essentially coconut milk, sticky rice, and a little salt wrapped in fragrant banana leaves, then stuffed into hollow bamboo sticks and roasted over a fire.</p>\n<p>The banana leaves stop the rice from sticking to the bamboo tube.</p>\n<p>You’ll know Lemang when you see them all lined up in a row being cooked in stalls. They are set against the fire, slightly slanted then turned every so often so everything gets cooked evenly. The Lemang is then served with shredded beef, chicken or even curries of your liking.</p>\n<h4>Ketupat</h4>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_67_7dc1c18a70.jpeg" alt="asset-67.jpeg">\n<p>Another great way to enjoy rice that tourists and locals line up for is Ketupat, the symbol of Hari Raya Like Lemang, Ketupat is unique and can be served in place of traditional steamed rice.</p>\n<p>Ketupat is like a dumpling where rice is packed into a diamond-shaped pocket made from woven palm. It’s then boiled. Once fully cooked, the woven palm wrapper is cut and peeled away so the rice inside can be sliced and served with whatever meal you would normally have with regular rice. I like to encourage our tourists to like to try a combination of Ketupat and Lemang on the same plate with their meat and vegetables since that’s the way I like it as well.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/Rendang_6869ee0f79.jpg" alt="Rendang.jpg">\n<p>It’s impossible for me to write about or even talk about Rendang without craving it. And once you try this traditional festival dish on your next trip to Malaysia, you will have the same experience. It’s the most famous beef recipe in Malaysia, Indonesia, and Singapore. It’s so delicious in fact, that in 2011, rendeng was number one in CNN’s “World’s 50 Most Delicious Foods.”</p>\n<p>An all-time favourite for the festive table, rendang is often prepared with either beef or chicken infused with aromatic spices and coconut milk for hours. Many culinary experts around the world like to refer to rendang as a curry because of the way it’s slowly stewed on low heat and the array of spices, but it’s richer than a curry and has less sauce, so many Malaysians don’t consider it a curry</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Bubur Lambuk</h4>\n<p>Bubur Lambuk is a type of porridge that has many variations, however Kuma, or date powder, is often the main ingredient. It really depends where in Malaysia you go, ut all of the tourists who have tried the many variations say they are all delicious. The recipe traditionally calls for a flavourful combination of anise, cardamom, cinnamon and black pepper, among other spices. Vegetables and meat are added as well.</p>\n<p>This is a dish that can actually be found being served for free at many Mosques and food banks during the month of Ramadan. It is a symbol of the tradition of feeding the poor during the Holy month, which is one of the pillars of the faith.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_64_63a54c56d4.jpeg" alt="asset-64.jpeg">\n<p>While the base ingredients to make this sweet Hari Raya dessert – coconut milk, cane sugar and rice flour – appear unassuming enough, in truth this is one of the most challenging recipes on this list. The cooking process involves continuously stirring the sticky mixture in a hot wok for nine hours. Then it is rolled, portioned out and individually wrapped.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.762+08	2026-04-03 11:28:35.762+08	published	2026-04-03 11:28:35.765+08	2026-04-03 11:28:35.765+08	t	f	\N
12	12	Bak Chang – The traditional food of the Chinese Dumpling Festival	chinese-dumpling-festival	1	The Chinese Dumpling Festival is the perfect time to plan your Malaysian getaway and indulge in one of the most delicious delicacies that can be found at any festival time. The Bak Chang or Zhong in Cantonese and Zhang in Hokkien. These are glutinous rice dumplings stuffed with various fillings, and	<p>The Chinese Dumpling Festival is the perfect time to plan your Malaysian getaway and indulge in one of the most delicious delicacies that can be found at any festival time. The Bak Chang or Zhong in Cantonese and Zhang in Hokkien. These are glutinous rice dumplings stuffed with various fillings, and wrapped in bamboo or lotus leaves. They can be triangle shaped, square or round. But the shape doesn’t matter, they are all delicious. Just ask anyone who had been here during festival time and tried them. And they can be sweet, spicy, savory or all of the above. It all depends on who you buy them from and what part of Malaysia they have been influenced by.</p>\n<h4>About The Festival</h4>\n<p>The Chinese Dumpling festival falls on the fifth day of the fifth lunar month, so every year it’s calculated on a different date. For 2019, it will fall on June 7th. Alternately it’s called the Double Fifth festival or the Dragon Boat Festival in Penang.</p>\n<p>It’s believed the festival originated during the Warring States period in China, when Qu Yuan, a well-loved poet, jumped into the Miluo river and drowned himself when his country fell to the enemy. The villagers jumped into their boats and raced out to find and salvage his body, hence the boat races. When they couldn’t find his body, they threw dumplings into the river for the fish to eat, so they wouldn’t eat his body.</p>\n<p>An alternate version tells the story that the admirers of Qu Yuan dropped sticky rice bamboo wrappers into the river to feed him in the afterlife.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/Bakchang_Zhong_Festival_Malaysia2_4b50ed1e83.jpeg" alt="Bakchang_Zhong_Festival_Malaysia2.jpeg">\n<h4>THE ZHONG</h4>\n<p>Though the origins of Zhong, points to Southern China, this heritage food is also well acclaimed across the Malaysian Chinese communities. The Kuala Lumpur (Cantonese speaking KL-ites) refer it as Zong, the Northern Penang name it Bak Chang in the local Hokkien dialect and the Baba-Nyonya Peranakan call this dish Chang. For the purposes of this post from here on out I’ll refer to the dumpling as the Zhong.</p>\n<p>Some of the traditional and modern types of Zhong available are:</p>\n<h4>THE HOKKIEN HAM YUK ZHONG (肉粽) / BAK CHANG IN HOKKIEN DIALECT (肉粽)</h4>\n<p>Salty Meat Dumplings are typically filled with fatty pork belly marinated with five spice herb powders, salted egg yolks, dried shrimp, mushrooms and my favorite chestnuts. The glutinous rice is pre-fried with dark soya sauce to give it a dark brown colour.</p>\n<h4>THE CANTONESE ZHONG / LOK TAU ZHONG (绿豆粽)</h4>\n<p>Another savory Meat Dumplings, favoured by the Cantonese descendants are typically filled with leaner pork meat, yellow mung beans, salted egg yolks, mushrooms and chestnuts. This version is white or paler in colour, the difference with no dark soya sauce added. Occasionally it comes in the form of a pillow longitude shape.</p>\n<h4>NYONYA ZHONG (娘惹粽)</h4>\n<p>A specialty of Peranakan cuisine, the fillings are minced pork with candied winter melon, ground roasted peanuts and taucheo (Chinese soybean paste made from yellow soybeans). Traditionally the dumpling has a bit of blue rice coloured from the butterfly pea flower.</p>\n<h4>KAN SUI ZHONG (碱水粽)</h4>\n<p>Literally translated as “alkaline water Zong”, this is a dessert item or a snack for tea time. The glutinous rice is treated with lye water hence the distinctive yellow color. It’s usually plain, with no filling and if there are It’s a sweet stuffing, for example, red bean paste. It’s often complimented with sugar, gula melaka (Malay for palm sugar) or a delicious local coconut spread named kaya.</p>\n<h4>THE ULTIMATE GIANT ZHONG (WHICH CAN WEIGH UP TO 2 KG)</h4>\n<p>Savoury Meat Dumplings typically filled with fatty pork belly, duck meat marinated with five spice herb powder, roasted pork, salted egg yolks, dried shrimp, mushrooms and chestnuts. Someone once shared that it was a portion to feed and be shared amongst the family.</p>\n<h4>THE VEGETARIAN</h4>\n<p>There are few vegetarian choices from glutinous rice, to healthy grains (of brown rice, red rice or sticky millet) with soy cubes, mushroom, chestnut and black eye peas.</p>\n<h4>THE GRAND FINALE</h4>\n<p>This is a more modern version of the Giant Zong sold by the 5-6 stars hotels and the luxurious ingredients are its greatest prize. From Abalone, to Japanese dried scallops, to expensive quality mushrooms, various healthy and exotic rice grains, to truffles and anything that will lure the consumer to buy.</p>\n<h4>ZHONG IS FAMILY TIME</h4>\n<p>The process of making it is truly an art and takes many cumbersome steps, from purchasing the ingredients to preparation to frying, folding and steaming/boiling. For Malaysian families, everyone gets involved in making Zhong for the festival, and each one of us has our own role and individual strength or skill, for instance folding the bamboo leaves with stuffing and tying them up. We appreciate and respect each others’ roles, even those of the children. When I was a kid I was delighted to eat Zhong after witnessing and taking part in the hours and hours of work it took to make them.</p>\n<p>The most delicious Zhong sold around KL would be freshly homemade from generation-old family recipes, which have been passed on from moms or grandmas. In my heart the best Zhong recipe by far comes from my late grandma, no one has and probably will be able to surpass that level of standard on the ‘delicious-Zhong meter.’ There are no shortcuts to traditional recipes and there are some things in life that are irreplaceable.</p>\n<p>I attempted to make Zhong according to my grandma’s recipe a few months ago. I pulled some family members together and we got everything we needed and went to work. The outcome was a disaster. The taste, texture, and everything fell short of what I was used to.</p>\n<p>There are a few stalls that sell them throughout the year, and they’re pretty good, but I am a little biased toward my family’s recipe, although that shouldn’t stop you from trying them at all. For the best Zhong however, visit us at festival time. That’s when you’ll get the classic recipes. Happy Tuen Ng Jit!</p>\n<p>You might be able to sample a Zhong yourself when you are joining our Kuala Lumpur Street Food Tour or our Penang Street Food Tour, just ask your guide if it’s available and we’ll try our best to get you to taste one.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_64_63a54c56d4.jpeg" alt="asset-64.jpeg">\n<p>While the base ingredients to make this sweet Hari Raya dessert – coconut milk, cane sugar and rice flour – appear unassuming enough, in truth this is one of the most challenging recipes on this list. The cooking process involves continuously stirring the sticky mixture in a hot wok for nine hours. Then it is rolled, portioned out and individually wrapped.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.777+08	2026-04-03 11:28:35.777+08	published	2026-04-03 11:28:35.779+08	2026-04-03 11:28:35.779+08	t	f	\N
13	13	Do Malaysians Eat Dog Meat? (and other strange dishes Malaysians eat)	dog-meat	1	Every once in a while on a tour I get the odd question, based on what I call global rumors. One such question and rumor is: Do Malaysians eat dog meat?	<p>Every once in a while on a tour I get the odd question, based on what I call global rumors. One such question and rumor is: <strong>Do Malaysians eat dog meat?</strong></p>\n<p>Although not illegal in Malaysia, the short answer is — no. Malaysians do not eat dog (or cats). This is a major misconception since dogs and cats can at times be found on the menu in other Asian countries like China, South Korea, and Viet Nam.</p>\n<p>However, there are a few what many would call exotic and other call just plain strange, foods in Malaysian cuisine.</p>\n<p><strong>Here are some examples:</strong></p>\n<h4>Frog on a Stick</h4>\n<p>Frog legs aren’t that strange to Westerners and are even quite common in Chinese cuisine, such as frog leg porridge, but the whole frog?</p>\n<p>In a well-known night market called Jalan Alor in Kuala Lumpur, there’s a stall there that serves the whole frog battered and deep fried on a stick. Add a little chili powder on top to kick it up a notch. It’s not easy being green.</p>\n<h4>Bull Penis Soup</h4>\n<p>I have to be honest. Some of the dishes on this list I have eaten and enjoyed and some I have not. I suppose it’s mostly psychological. But this is one I had to try.</p>\n<p>And it’s delicious. The dish is called <strong>Sup Torpedo</strong> and the bull penis is the star. The broth is like a curry and it’s served with Indian spices. Sup Torpedo is said to work wonders for male virility. In some places, you can request the testicles as well, if you are hungry enough.</p>\n<h4>Porcupine Rendang</h4>\n<p>Rendang is a spicy meat dish that originates in the Malay archipelago. It’s prepared by stir-frying meat in a spice paste with coconut milk, lemongrass and tamarind.</p>\n<p>Mainly made with beef, there is one place in Selangor that has taken Rendang to a new level. They are using porcupine meat.</p>\n<p>I’ve never made it out there to try it, but reports tell me it’s a little on the chewy side, however, the spices and preparation take away any of the gamey flavors it may have.</p>\n<h4>Sago Grubs</h4>\n<p>Yup, grubs. Mainly a delicacy in Sabah and Sarawak, many Malaysians don’t even have the courage to twist the heads off these live, squirming worms and pop them in their mouths. But don’t worry, if eating them live is not your thing you can find them cooked in various ways. Stir fry is the most common.</p>\n<p>Truth be told, these little guys are packed with vitamins and minerals and are actually a healthier choice than chicken or beef.</p>\n<p>No one ever said eating healthier was easy, right?</p>\n<h4>Chicken feet</h4>\n<p>As far as weird may go, this one is actually pretty tame and I snack on these all the time. They can be prepared many ways and eaten the same as you would chicken wings.</p>\n<p>Next time you sit down for a Chinese Dim Sum lunch, try a plate of hot and tasty braised chicken feet.</p>\n<h4>Fried Pigs Brains</h4>\n<p>The smooth, custard flavor of these normal-looking meatballs is definitely an acquired taste. This is a specialty item that I have only seen in a select few places.</p>\n<h4>Cow’s Lung</h4>\n<p>Internal organs seem to be a hit in South East Asian countries, and Malaysia fits right in there. It’s not particularly a bad thing when you consider that it’s better than letting it go to waste.</p>\n<p>Cow’s lung is a popular dish commonly called paru or paru Goreng. It is cow lung, brushed with seasoning then fried and goes great with nasi (rice).</p>\n<h4>Crispy Honey Bees</h4>\n<p>This is one that shocked me more than the Sago grubs. But when you stop and think about the nutritional value and can get past the psychological barriers, it makes sense to give these a try.</p>\n<p>Honey bees and larvae are either fried or sautéed and then served up as a snack. They taste a lot like chicken, or so I am told.</p>\n<p>So Malaysians may not eat dogs, but they do have some dishes that make their way onto the “strange” list. At least by Western opinions. There are a lot more dishes, like sup gearbox, satay parut and liver satay that are weird and phenomenal that I’ll discuss in a later article.</p>\n<p>Did I miss any dish you enjoyed on your visit to Malaysia? Or anything that shocked you even more than the above? Let me know in the comments below.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.791+08	2026-04-03 11:28:35.791+08	published	2026-04-03 11:28:35.794+08	2026-04-03 11:28:35.794+08	t	f	\N
14	14	Do Malaysians Speak English	do-malaysians-speak-english	1	As a tour guide, it’s always fun to watch the amazed and delighted expressions on tourists’ faces when they have their first real experience interacting with the locals.	<p>As a tour guide, it’s always fun to watch the amazed and delighted expressions on tourists’ faces when they have their first real experience interacting with the locals.</p>\n<p>When it comes to the airport staff and guides, they expect them to speak English, it’s their job, but when they approach a vendor or any random person on the street they prepare to spill out broken sentences backed with exaggerated hand gestures. The Malaysian local smiles and speaks to them in perfect English.</p>\n<p>Well, nearly perfect. It’s called Malaysian English.</p>\n<p>And the response from the tourist is almost always the same.</p>\n<p>“Oh, I didn’t know Malaysians can speak such good English!</p>\n<p>” Yes, Malaysians do speak English, so don’t be shy to go ahead and speak as you normally would and they will reply to you in Malaysian English. Of course, there will be some differences in the usage of words, perhaps phonetics and a little Malaysian flare will be added in. But these types of differences exist even among English-speaking countries such as the US, UK and Australia. So if you’re a first-timer in Malaysia, you’re bound to hear (and even pick up) some local lingo throughout your stay.</p>\n<p>Interesting fact: When it comes to language — or languages, I should say, Malaysia hosts an impressive 137 languages, dialects and indigenous sub-dialects throughout the nation. Let’s’ take a look at languages in Malaysia, so you’ll have a better understanding of what to expect and to feel a little more at ease.</p>\n<h4>Maylay: The Official</h4>\n<p>So this is where it might get a little confusing. Malay is the official national language of Malaysia, which is broken up into ten dialects. Of those, Bahasa Melayu is the official, standardized dialect which is also spoken in Indonesia, Singapore, Brunei and Thailand for a total of about 18 million speakers worldwide. So when we use the word, Malay, to describe the official language, we are referring to the Bahasa Melayu dialect. Coincidentally, Indonesian, spoken by 170 million people, is also a form of Malay.</p>\n<p>The earliest known record of Malay is found on inscriptions in southern Sumatra and on the island of Bangka, and dates back to 683-6 CE. At that time it was written in Indian script and heavily influenced by Sanskrit. It was transformed in the 14th century to Arabic, then again in the 17th century to the modern Latin alphabet.</p>\n<h4>British English</h4>\n<p>By the mid-18th century, the British had set up trading posts on the Malay peninsula. With them, they brought politics, goods for trade and English. Since 1819, the British already had control of Singapore and English began to have an influence on the Malaysian language, and vice versa. Words like paddy, lorry, amok, rattan, bamboo, and sarong are just a few examples of Malay infiltration into the English language.</p>\n<p>The English used in Malaysia today is based on British English and is called Malaysian English. They follow British spellings, however, American slang is strong, especially among Malaysian youth.</p>\n<p>Like Malay, English plays an important role to bridge the gap between dialects and languages, such as among Chinese or Tamil speakers, so they can communicate comfortably. When talking to people who don’t understand their language, they will instead use Malay, English or a mixture mentioned before, Manglish.</p>\n<h4>Manglish or Malaysian Standard English (MySE)</h4>\n<p>This is where the fun begins. This is such a fun language to listen to and even more fun to speak, And it’s almost impossible not to pick up a little bit, even on a short tour.</p>\n<p>About a month ago I overheard a tourist talking to her daughter back home in the US. Her and her husband were on their second trip to Malaysia and she was having a little trouble with the connection, so she was talking a bit loud. What caught my attention was when she said “See HOW la,” which is Manglish for something like “I’ll see and let you know.”</p>\n<p>The entire group stopped and stared at her, myself included then we all erupted with laughter when she had realized what she said. And with an almost perfect accent! This isn’t the first time I have heard tourists speaking Manglish and I always get a kick out of it.</p>\n<p>Let me give some examples of Manglish and how certain words are used, so you’ll have an idea of how the blend of the two languages fit together.</p>\n<p>Warning: Manglish can be addicting — please use Manglish responsibly.</p>\n<h4>Digging into Manglish</h4>\n<p>Manglish shouldn’t be confused with Malaysian English. Even though they may have similar names, unlike Malaysian English which follows the rules with some local flare added, Manglish doesn’t always follow the grammatical structure of British English.</p>\n<p>Manglish also has influences from other languages as, Hokkien, Mandarin, Cantonese, and Tamil.</p>\n<p>Take note: As with any country and language, Manglish can vary from region to region in its usage and slang according to certain influences.</p>\n<h4>La</h4>\n<p>Understanding “la” is fundamental. It can be used in a variety of ways in daily communication and describes different kinds of emotions, but it really has no specific meaning.</p>\n<p>• Frustration – what la</p>\n<p>• To emphasize – ya la</p>\n<p>• Feeling so so – OK la</p>\n<p>• Trying to chill – come on la</p>\n<p>• To ask – serious la?</p>\n<p>• Denying – no la</p>\n<p>Example:</p>\n<p>You to the vendor: Can you give me a discount?</p>\n<p>In Manglish: Ei, cheaper la!</p>\n<p>There’s no definite answer to where the usage of “la” came from, however, the Chinese do make use of “lah” and lay claim to its influence.</p>\n<p>Here are a few interesting words used by locals that have a different twist on their original meaning.</p>\n<h4>Boss</h4>\n<p>Only used with males, it literally means what it’s supposed to mean, but here in Malaysia, it’s widely used as a sign of respect or to make someone feel important. It’s not an official calling, but more of a respectful way to address someone. Even, if we are in the Mamak restaurant, it’s normal to call the waiter boss.</p>\n<p>Example:</p>\n<p>Loan officer: Your application is denied because you don’t meet the qualifications.</p>\n<p>You : Please la, boss. Can’t you help me this time? Can la, boss?</p>\n<h4>One</h4>\n<p>This one can be confusing. No pun intended. When a local uses the word “one” they aren’t referring to the number. It’s used more for emphasis.</p>\n<p>Example:</p>\n<p>Local: So handsome one. Going out with leng loi is it?</p>\n<p>Meaning: So handsome! Going out with a girl?</p>\n<h6>Spender</h6>\n<p>This isn’t what you would think it is. This is not referring to a person who likes to spend lavishly on things they don’t need. No, in our local lingo spender means a male’s brief. Yes, you read correctly. Spender is underwear. I don’t think an example is really needed here.</p>\n<h4>Tackle</h4>\n<p>For football fans, this word has a pretty common meaning, kill the guy with the ball. In other places in English, it can be used to describe taking on a huge problem or challenge. It can also mean fishing gear. In Manglish, it means none of these. Here is an example of a bit of a gap between English and Manglish.</p>\n<p>If you hear a local saying he wants to tackle a girl, please don’t call the police. In Manglish, “tackle” means to get a girl’s attention.</p>\n<p>The Mix Doesn’t Stop There</p>\n<p>Manglish has a converse side to the above. Besides English words being used in different variations, Malay words make their way into English sentences.</p>\n<p>Here are some examples of how Malay words are used in conjunction with English.</p>\n<h4>Tapau</h4>\n<p>Tapau means to take away or pack up the food.</p>\n<p>Example:</p>\n<p>(To the waiter) Boss, can you tapau this chicken and rice for me?</p>\n<p>Bos, tapau chicken rice, can?</p>\n<h4>Kautim</h4>\n<p>This word comes from Cantonese and means “to settle” as in to finish some work or to settle a problem.</p>\n<p>Example:</p>\n<p>Boss: Lee, don’t forget to update me on that deal tomorrow.</p>\n<p>Lee: Don’t worry boss. I will kautim it for you. Other interesting words you may hear:</p>\n<h4>Mat Salleh</h4>\n<p>This word is referring to westerners, but not in a derogatory way.</p>\n<p>Example:</p>\n<p>Local (to the taxi driver): Tolong jap tunjuk Mat Salleh tu macam mana nak gi Kuantan.</p>\n<p>Meaning: Please help to assist the westerner, he wanted to go to Kuantan.</p>\n<h4>Jambu</h4>\n<p>Jambu’s original meaning was supposed to be a guava fruit but has been transformed to refer to a cute boy like the author of this article and Korean boy bands.</p>\n<p>Other Dialects and Influences The British were not the only outside culture to make its mark on Malaysia. For instance, In southern Malaysia, Mandarin is widely spoken and taught in schools due to the high Chinese-Malaysian population. They also speak other Chinese dialects such as Hokkien, Cantonese, Hakka, Hainanese, Hok-chew, Yue, and Min. However, a lot of the smaller dialects are facing extinction as Mandarin becomes more dominant.</p>\n<p>Tamil is another popular language used by the Indian-Malaysians. Sinhalese is a language mainly by the Sri Lankan population and Thai is spoken in some parts but is considered a minority language.</p>\n<h4>Indigenous Languages Of Malaysia</h4>\n<p>There are over 30 native tribes in Malaysia each with its own unique ancestral language including sub-dialects. Kazadandusuns and Iban are the most recognizable among the native languages.</p>\n<p>Don’t feel pressured to learn a whole new language before your vacation. Although the locals do appreciate the respect for their mother tongue, they are always more than happy to practice their English with a real westerner.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.807+08	2026-04-03 11:28:35.807+08	published	2026-04-03 11:28:35.81+08	2026-04-03 11:28:35.81+08	t	f	\N
15	15	A Tourist’ Guide To Eating Durians in Malaysia	eating-durians	1	When you come to Malaysia you will hear about a flavour that is as common as vanilla in the West. It’s called durian. And in my opinion — it’s delicious.	<p>When you come to Malaysia you will hear about a flavour that is as common as vanilla in the West. It’s called durian. And in my opinion — it’s delicious.</p>\n<p>I actually consider myself a bit of a durian connoisseur. You’ll hear me or other tour guides talking about durian puffs, durian ice cream, durian milkshakes, durian fritters, durian shaved ice and durian candy….</p>\n<p>But when you first see the actual durian fruit you would never think it to be anything edible, with its tough, thorny exterior. And when you smell a durian, you definitely won’t think it’s anything edible.</p>\n<p>Yes, durians stink.</p>\n<p>I often wonder how the vendors can stand it. The durian’s ungodly smell is so powerful and lingering that it’s literally banned in many hotels, aeroplanes, hospitals, malls and other public areas. The pungent odour has been described by tourists as smelling like sewage, gasoline, or even rotten vegetables wrapped in an old sock.</p>\n<p>Now I don’t want to suede you or set your prejudices against taking the plunge into your next exotic fruit adventure. Durian is, as they say, the King of Tropical Fruit. It “stinks like hell, but tastes like heaven”.</p>\n<p>If this is your first time hearing about Durians or you are keen to expand your knowledge, here’s a great introduction to eating Durians Malaysia.</p>\n<h4>What Exactly Is Durian?</h4>\n<p>Interesting fact, the word “<strong>durian</strong>” actually comes from the Malay word duri, meaning “thorn”. Durian is a large fruit from one of the nine fruit-bearing species of durian tree, and not all of them taste the same. It can look similar to jackfruit, but the durian has a thick, thorny rind ranging in colour from a husk green to brown, whereas the jackfruit has more of a green, pebbly rind.</p>\n<p>It can come in a variety of shapes and sizes, depending on the species, from oblong to round and it typically weighs about one to three kilos (2 to 7 lb). It can grow as long as 30 centimetres (12 in) and get up to 15 centimetres (6 in) in diameter.</p>\n<h4>Why Is The Durian Considered The King Of Tropical Fruit?</h4>\n<p>I’ll say it again. It’s out of this world delicious. Once you get through that thorny exterior and past the smell, you’ll find a sweet, rich and creamy pulp that Malaysians put in many of their food items.</p>\n<p>For example, you can find it in cakes if you hop inside our local cake shop called <strong>Secret Recipe</strong>. If Ice cream is your thing, <strong>Inside Scoop</strong> is the place to go for durian ice cream. And if you are a chocoholic like me, check out <strong>Beryl’s Chocolate Shop</strong> where they use real durian flesh in their chocolate.</p>\n<p>I recently spoke with a tourist couple who just got back from Temerloh, Pahang which is about 130 kilometres from Kuala Lumpur. They were raving about the Ikan <strong>Patin Masak Tempoyak (Tempoyak</strong> cooked with fresh Silver Catfish) which is a dish Temerloh is famous for.</p>\n<p>Tempoyak is a Malaysian condiment made by mixing some salt with the flesh of the durian and letting it ferment at room temperature for three to five days. Its normally made with the lower class durian during peak season when they are in excess. Another great dish to try is Tempoyak with Petai beans.</p>\n<h4>I’m seriously getting hungry.</h4>\n<p>Durian are like apples — in a way</p>\n<p>Like apples, durians come in different varieties, so don’t expect them all to taste the same or to taste like any other fruit you have ever tried in the West. They have a unique explosion of multi-dimensional flavours that’s a combination of sweet, savoury and creamy all at once.</p>\n<p>Some have compared it to whipped cream with a hint of chives, whereas others have said it’s like garlic and caramelized sugar. Everyone’s palate is different and will detect different things. I sat with some tourists a while ago as they tasted durian for the first time. One said it was like butterscotch pudding with almonds, but another guy said it was like red wine simmered in onions.</p>\n<p>So which variety of durian is best? Again it’s like apples. Some prefer the pulpy Washington red whereas others like the crispness of a granny smith. You will have to decide which you like best.</p>\n<h4>Let’s go through some of the varieties and how they look and taste:</h4>\n<p><strong>Durian kampung</strong> — Probably the least expensive to find is the durian kampung. It tends to be sweeter, but the taste can be a bit unpredictable. It may not necessarily have the most flesh and some may contain big seeds so it may not be as filling as expected, which is a good thing so you have room to try more.</p>\n<p><strong>D21 and D24</strong> — These are the best entry-level durian known mainly for their consistency in a bittersweet taste and creamy texture. What makes this durian good for first-timers is that it has a mild aroma, so it won’t be too overwhelming.</p>\n<p><strong>Musang King or Mao Shan Wang</strong> — This is the most expensive and probably the best-tasting durian. It has a distinctive star shape on the bottom, so make sure you check for that before forking over the big cash. Mao Shan Wang is a rich and creamy durian with several layers of flavour from bitter to sweet.</p>\n<p><strong>Black Thorn</strong> — This one originated in Penang and has a dark, rich yellow pulp that’s sweet and custardy. You can tell the blackthorn because the thorns are darker on the ends.</p>\n<p><strong>Red Prawn or Udang Merah</strong> — The taste of this one really depends on the age of the tree it came from, which you would have no way of telling so it’s best to ask the vendor. The younger the tree, the sweeter the fruit. Older trees produce more bitter fruit. Another unique characteristic is its reddish-orange colour compared to the creamy yellow and whites of most other durians.</p>\n<p><strong>D88</strong> — I had one of these last weekends and it filled me up so much that I skipped lunch. It had a great flesh-to-seed ratio and a bittersweet fibrous texture with a bit of an alcoholic aftertaste.</p>\n<p><strong>Golden Phoenix </strong>— This durian is grown from older trees that are only available in Johor. It has a pungent odour and a thin skin that is easily opened. These durians lean to the bitter side and tend to be watery, but a lot of people are drawn to this texture and taste.</p>\n<p><strong>XO Durian</strong> — This pale yellow durian can almost taste like an alcoholic drink because of its fermented, watery flesh.</p>\n<p><strong>Raja Kunyit </strong>— This one is my favourite. It has a firm, smooth, custard-type texture and is sweeter with just a hint of a bitter aftertaste. What’s great about this one is it’s almost seedless. It has just tiny, underdeveloped seeds that can be easily removed (or spit out) from the flesh.</p>\n<p><strong>Tawa or D162 Durians</strong> — This is another fleshy durian with small seeds. It’s almost pure white and has a light, creamy texture that is less sweet than other varieties.</p>\n<p><strong>Hor Lor Durians</strong> — Another one that originated in Penang, it’s a favourite of some because of its drier consistency and sweeter taste.</p>\n<p>The above is just a brief introduction to the exciting world of durian. There are many other varieties to taste and savour and even more are being developed by durian farmers all over the country. Are you now ready to be a durian connoisseur?</p>\n<h4>How Do You Choose A Quality Durian?</h4>\n<p>It’s important for the budding durian expert to be able to know how to choose a good, quality durian. I’ve found sometimes vendors may try to pass off the old stocks to the tourists and less experienced ones, so it’s best to ask around for the more reputable ones. Even better to take a guide with you.</p>\n<p>So to understand a little more about what to look for when picking a durian, you have to keep in mind that durians are not “picked” from the trees. Instead, the harvesters in Malaysia wait for the durian to fall and this usually happens at night. They’ll sleep by the tree (but not under it! That’s way too dangerous!) waiting for the durian to hit the ground.</p>\n<p>Once the durian falls from the tree, it’s ripe and should be eaten within about four to five days. That’s not a very big window to hit.</p>\n<p>But trust me, you’ll want to pick durian that is in this range. Unripe durian is tasteless and has thick, leathery flesh that’s difficult to pull away from the seed, and the overripe will be too bitter and have a stronger fermented taste. The best time to find and indulge in durian is June – July.</p>\n<p>When you pick up the fruit, give them a shake. If you hear the fruits knocking against the shell, chances are the fruit is dry and has a good consistency. When the knocking sound isn’t there, the fruit is likely more wet and soggy. Another thing to look for is thick thorns and avoid any that are cracked on the bottom. This is a sign the fruit has over-ripened.</p>\n<p>When you pick up the durian, it should feel light and not heavy and waterlogged. Next, give it a good whiff down the seams. If you are struggling to get any scent or get a slight raw fruit smell, then it’s under-ripe. If the smell knocks you over, then it is probably overripe. Even though the durian has a strong odour by nature, you want to find a nice, sweet medium between little smell and overpowering. In Malaysia, you will find that most durian sellers cut a triangular shape into the durian to give the buyer a better idea of the quality they are buying.</p>\n<p>Durian prices and grades vary depending on the species and their weight.</p>\n<p><strong>Expert Tip:</strong></p>\n<p>Look out for wormholes in the durian skin, when you find them you know that someone had a taster before you did. The older generation takes these worms as a sign of a good quality durian, some even go as far as eating the worms.</p>\n<h4>How To Open Your Durian</h4>\n<p>Now that you got your durian, how are you going to open the darn thing? Depending on which variety you chose, this can be a daunting task. It takes some skill, but with practice, anyone can do it.</p>\n<p>First, flip the durian stem side down. You’ll want to use some gloves or a kitchen towel to handle the durian. Then insert a knife in the bottom centre as far as you can get it and wiggle it back and forth. Doing this should rupture the seams.</p>\n<p>Pull the knife out and grab the durian with your fingers inside the opening from the knife. By using sheer, brute force, pull open your durian into two halves.</p>\n<h4>Eating Durian</h4>\n<p>Durian is naturally rich in potassium, dietary fibre, iron, vitamin C, and vitamin B complex which makes it excellent for improving skin health, and building muscle, and is good for healthy bowel movements. Further, it also contains minerals like manganese, copper, iron and magnesium and is a great source of potassium and the essential amino acid, tryptophan.</p>\n<p>In conventional Chinese wisdom, durian fruit is eaten along with purple mangosteen fruit, a fragrant and slightly acidic fruit that tastes kind of like a mix between orange and peach. The belief is that the “heaty” nature (ying) of durian will be balanced by the cooling properties (yang) of mangosteen.</p>\n<p>Also, being that durian is “heaty”, the rule is they should not be eaten with other “heaty” foods or beverages such as alcohol, coffee, curry or tom yum. And it can be a powerful aphrodisiac.</p>\n<p>There is no scientific evidence to back these claims, however, I say why to risk it and just go with what they say.</p>\n<p><strong>Pro Tip:</strong> To get rid of the aftertaste that may linger after eating durian, try drinking some coconut water and pop a breath mint. The coconut water will also help reduce the odour of the “durian burp”.</p>\n<h4>Durian Farms</h4>\n<p>Durians are planted on a large scale in Penang state and also in Pahang and are one of the most valuable crops for Malaysia. Starting in June to July and lasting until September, truckloads of durian can be seen all over Malaysia, originating from places like Johor and Pahang.</p>\n<p>An interesting recent study has proven that the flying fox bat, once considered a pest, is mainly responsible for the pollination of the durian flowers. So without the bats — no durian!</p>\n<p>I love taking the drive out to the farms, getting my hands on the best Durians when they are in season and enjoying the beautiful scenery. Interested in joining? Or do you have a favourite Durian? Let me know in the comments below.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.821+08	2026-04-03 11:28:35.821+08	published	2026-04-03 11:28:35.824+08	2026-04-03 11:28:35.824+08	t	f	\N
16	16	Is It Safe To Eat Roadside Food In Malaysia?	food-safety	1	Last week I was out with guests on a tour from the West and, after my typical lengthy descriptions of the best street foods to eat, one of my friends pulls me aside and whispered:	<p>Last week I was out with guests on a tour from the West and, after my typical lengthy descriptions of the best street foods to eat, one of my friends pulls me aside and whispered:</p>\n<p>“Looks great, but — is it safe to eat?”</p>\n<p>I actually get that question quite a bit. We’ve all heard horror stories about the dangers of eating when traveling abroad. Especially to underdeveloped nations that may not have the strict food safety laws and guidelines that most Western countries do. Many people are concerned they might die from food poisoning or end up spending their entire trip clinging to a bottle of Pepto.</p>\n<p>It’s not an uncommon fear and there’s always a risk. However, if you follow just a few rules of thumb listed below and pay closer attention to things you most likely do already, like washing your hands before you eat, then you should have no trouble enjoying all the great street foods Malaysia has to offer.</p>\n<p>Here are some things to consider before heading out to the hawker:</p>\n<h4>Let Your Stomach Adjust</h4>\n<p>When I first had Malaysian food, it was the spices that had me popping tums more than anything else. Take it slow and be careful for the first few days not to overindulge in spicy foods if your gut isn’t used to it. Give your stomach a little time to get localized.</p>\n<p>Remember, there are other risks as well like the heat and dehydration (especially if alcohol is part of your nightlife) that can also have an affect on how you digest your food. I always like to carry a good bottle of water with me whenever I hit the streets.</p>\n<p>Speaking Of Water…</p>\n<p>Although tap water in the larger cities is deemed safe to drink, it’s best when coming from the West to stick to bottled water while on the streets. Extra filtration has been added for water in restaurants and most likely your hotel and the water used for teas and soups have been boiled.</p>\n<p>But what about the ice? Ice is normally safe as most vendors buy their ice from a licensed distributor who used only filtered water. If you find a vendor making their own ice from tap water, best to move on.</p>\n<h4>Look For Running Water</h4>\n<p>Keep an eye out for stalls that have access to running tap water and are using soap to wash their utensils, chopstix, cups and plates. Generally speaking, Malaysians are in the habit of washing everything before serving, however, you may see some that are merely wiping down the plate or utensil with a tissue or cloth. Avoid these stalls.</p>\n<p>You may see a stall with a pot or bucket of water that you may think they are using for washing utensils, plates and cups. This is actually for washing your hands.</p>\n<h4>Best Times To Visit The Stalls</h4>\n<p>Stalls like to prepare for the coming rush at certain times of the day, so some items may be prepared in advance to accommodate for the high volume. Strategically plan your street food snacking to coincide with mealtimes like breakfast, lunch, and dinner. Doing this will ensure you are getting the freshest and hottest food.</p>\n<p>I always go for items that are within just a few minutes of being cooked and bypass anything that looks like it may have been sitting for a while. One thing to remember is the food “danger zone” is roughly 5 to 60 °C (41 to 140 °F). This is the ideal temperature range for bacteria and food pathogens to thrive.</p>\n<p>Deep-fried foods have been put through temperatures well above this and eggs and other foods that are cooked to order are also normally safe to eat. Rice that has been around for a while should be avoided.</p>\n<h4>Read Food Blogs</h4>\n<p>Food bloggers are constantly on the Malaysian streets searching for the best street food stalls to write about, so credibility goes a long way. If a blogger has featured a vendor, chances are the quality and standards of hygiene and taste are pretty high.</p>\n<p>Join the Simply Enak Food Guide. I’ll visit a vendor several times and at various times throughout the day to see how they operate and taste the quality, then report back and let you know if I recommend it.</p>\n<p>And lastly…</p>\n<h4>Find The Busier Stalls</h4>\n<p>Look for the busier stalls that have the most locals in line. This means they will be putting up the freshest cooked food as the turnover will be high, and probably either the best prices or the most delicious. Or both!</p>\n<h4>Bubur Lambuk</h4>\n<p>Bubur Lambuk is a type of porridge that has many variations, however Kuma, or date powder, is often the main ingredient. It really depends where in Malaysia you go, ut all of the tourists who have tried the many variations say they are all delicious. The recipe traditionally calls for a flavourful combination of anise, cardamom, cinnamon and black pepper, among other spices. Vegetables and meat are added as well.</p>\n<p>This is a dish that can actually be found being served for free at many Mosques and food banks during the month of Ramadan. It is a symbol of the tradition of feeding the poor during the Holy month, which is one of the pillars of the faith.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_64_63a54c56d4.jpeg" alt="asset-64.jpeg">\n<p>While the base ingredients to make this sweet Hari Raya dessert – coconut milk, cane sugar and rice flour – appear unassuming enough, in truth this is one of the most challenging recipes on this list. The cooking process involves continuously stirring the sticky mixture in a hot wok for nine hours. Then it is rolled, portioned out and individually wrapped.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.834+08	2026-04-03 11:28:35.834+08	published	2026-04-03 11:28:35.836+08	2026-04-03 11:28:35.836+08	t	f	\N
17	17	9 Hidden Gems To Visit In Kuala Lumpur	hidden-gems-in-kuala-lumpur	1	If you’ve been to Kuala Lumpur before, you may have already seen many of the larger attractions from KLCC to the Botanical Gardens. A lot of tourists we get are return visitors and are looking for something a little more or off the beaten path. So we have decided to put together a list of attraction	<p>If you’ve been to Kuala Lumpur before, you may have already seen many of the larger attractions from KLCC to the Botanical Gardens. A lot of tourists we get are return visitors and are looking for something a little more or off the beaten path. So we have decided to put together a list of attractions for those who are keen to explore an alternative side of Kuala Lumpur.</p>\n<p>All of the below suggestions are within walking distance of the Chinatown area.</p>\n<h4>1. Zhongshan Building – Jalan Rotan – Kampung Attap</h4>\n<p>I am hearing a lot of feedback from tourists lately about this one. Back in the 1950s the Zhongshan Building housed a row of interconnected shophouses. Since then over the years it has been the home to Selangor Zhongshan Association, a frozen foods distributor and various local merchants. So it’s a unique building with a lot of history.</p>\n<p>Today it is back in operation as a three-building independent arts and research hub. Indie you will find the art gallery of OUR art projects, a contemporary art gallery founded by Snow Ng and Liza Ho. After being funded by ThinkCity, a not-for-profit subsidiary of Khazanah Nasional. They opened their art gallery on the first floor. However since there was so much extra space, they decided to lease some of it to other artists.</p>\n<p>Also inside you will find Tandang Records music store, Tommy le Baker’s Kampung Attap outpost and a lot more.</p>\n<h4>2. Peter Hoe Evolution – Boutique shop</h4>\n<p>This is the place to find the perfect souvenir. Peter Hoe Evolution is a unique and amazing shop in Jalan Doraisamy (also known as The Row KL) with a wide selection of homeware, clothes and souvenirs. It’s broken up into three sections: a retail store, boutique and café where you can lounge on silk pillows and enjoy goodies baked by Malaysia’s own Peter Hoe himself.</p>\n<p>The retail store fuses Asian and modern styles with its handmade crafts and merchandise designed by Peter Hoe and made by many local artisans and craftsmen. Here you can find beautiful woven mats, rattan baskets and other treasures. Recently a tourist couple came back with some beautiful handmade candles and brightly colored flowery shirts and I knew right away they had been to Peter Hoe Evolution.</p>\n<p>Also inside is a boutique with clothes designed by local fashion designer Justin Yap.</p>\n<h3>3. Malaysian Cartoon and Comic house</h3>\n<p>If you don’t already associate Malaysia with classic cartoons and comic art, after you visit this place you will. If you are a fan of comic books, comic strips and cartoons then this is the place to go.</p>\n<p>The Malaysian Cartoon and Comic house and sits right in Taman Botani Perdana (KL Lake Gardens) The walls are lined with hundreds of comic dating back to the 1930’s. These comics predate modern methods and were hand drawn and words delicately added. Don’t worry, many have English subtitles or explanations so you can enjoy them too.</p>\n<p>A Lot of the earlier comics feature Malaysian heroes and local legends like Mah Suri, Puteri Langkawi. You’ll also find some political satire comics and magazine and newspaper drawings.</p>\n<p>What a lot of history buff tourists find interesting are the Japanese and British comics that were used as wartime propaganda to try and get the Malaysian people on their side.</p>\n<h4>4. PS150 bar</h4>\n<p>So we are talking about hidden gems and hidden is the word to describe the PS150 bar. PS150 is a classy brothel-styled cocktail bar on Petaling Street in Chinatown. And it’s not that easy to find. Tucked away under the popular cafe, Merchant’s Lane next to a stationary store, it’s fashioned like a pre-war speakeasy from a time when alcohol was illegal.</p>\n<p>You enter through a toy shop where you’ll find the PS 150 dressed in a very Chinese style with Far East accents, a reminder of the earlier days of Kuala Lumpur. There are three parts: The main bar with some of the best cocktails in town, the outside courtyard and they have private “opium den” booths available as well if you are looking to get dressed up and spend some quality alone time with your significant other.</p>\n<h4>5. BarZehn</h4>\n<p>Speaking of the speakeasy, hidden behind two faded blue doors with peeling paint on graffiti ladend street, you’ll find one of Kuala Lumpur’s best-kept secrets. And I’m letting the cat out of the bag.</p>\n<p>Once through the blue doors, you’ll follow a hallway to a flight of stairs. Take those stairs down and push through a couple more doors to find a dimly lit, opulent and plush lounge with vintage posters lining the walls.</p>\n<p>Literally meaning the “Eight Treasures”, BarZhen is a reference to a famous alcoholic concoction in Chinese herbology that has been used as a remedy for a variety of illnesses. Many of the bar’s signature cocktails follow a traditional Chinese style including using potent herbs to give you an eye-opening jolt.</p>\n<p>In the mood to try a cup of spiked tea? Try BarZhen’s best-selling drink, Lycium Maca Osmanthus Tea. You can also find great drinks infused with Ginseng, Tongkat Ali, and Wolfberry.</p>\n<h4>6. Tian Jing Hotel</h4>\n<p>The phrase Tianjin literally translates from Chinese meaning “Air Well”. Located right in the heart of Chinatown, the Tian Jing Hotel has only 15 rooms, but they are amazing and live up to their name. They are constructed with the wisdom of ancient Chinese architecture to make use of and maximize natural light, expand air circulation, and keep a cool balance at room temperature. The antique furniture in the hotel has been collected from all over Malaysia and each piece has a unique story.</p>\n<p>If you are unable to get a room for the night, don’t worry. You can still stop in and indulge yourself at Tian Jing Hotel’s Lim Kee Cafe famous for their desserts. I was just there last Sunday and had their raspberry tiramisu which I highly recommend. You can also get a generous scoop of ice cream. They have flavors like pandan, teh tarik, mascarpone and soursop.</p>\n<h4>7. Bank Negara Museum and Art Gallery</h4>\n<p>Another hidden gem that many will find interesting is the Bank Negara Museum and Art Gallery located at Jalan Dato’ Onn. It’s a museum dedicated not only to Malaysian works of art, but to providing an educational avenue for anyone who is interested in better understanding of the Malaysian economy and its economic history. It also shows how the bank played an important role in the nation’s economic development and financial regulation from 1959 to the present day.</p>\n<p>This is a great one for those who love to experience impressive works of art and learn some economic history at the same time. The museum itself comprises six galleries: the Art Gallery, Economic Gallery, Islamic Finance Gallery, Numismatics Gallery, Children’s Gallery and the Bank Negara Malaysia Gallery. It underlines the bank as a major patron of the art housing over 1,500 contemporary Malaysian and ASEAN artworks acquired since 1962.</p>\n<p>The museum is open daily and free to get in. In my opinion, it’s a worthwhile stop.</p>\n<h4>8. Yat Hang Trading</h4>\n<p>For those who read my post on souvenirs, this is one of the places you’ll be able to find the mooncake moulders and a few of the other items that you foodies will love. Yat Hang Trading has been in business for over 100 years and has everything from typical Chinese utensils, to decades-old hand-painted ceramics. Anything that could be used in a traditional Chinese home or eatery.</p>\n<p>Many of the other local Chinese restaurants and bars get their utensils from Yat Hang Trading. In fact, if you stop at the PS150 bar, the snack bowls on the bar came from there. There’s plenty of authentic Malaysian- Chinese merchandise to choose from so if you’re looking around for that one perfect Malaysian souvenir that can also be useful in the home, this is the place to check out. You’ll also get to experience some of Kuala Lumpur history.</p>\n<h4>9. A Decent Nasi Lemak Inside Kl City Gallery Arch Cafe</h4>\n<p>When you visit Malaysia you are bound to try the national dish. In fact, with all the tourists on our tours I insist that they do. So why not try it at the place that has the finest, traditional recipes in all of Kuala Lumpur? I just talked to a tourist couple yesterday who have been here once a year for the last 4 years and they told me they go to the Arch Cafe inside Kl City Gallery on their first day here and their last day. And they always get the Nasi Lemak.</p>\n<p>The food isn’t the only thing that attracts visitors to the Arch Cafe. The tables and chairs are over a century old and were collected from the oldest coffee shop in old Market square and pudu. They have been used not only by prominent politicians, judges and other figures in Malaysian history, but also by the notorious Chinese gangsters from that era.</p>\n<p>So these are our picks for the hidden gems of Kuala Lumpur. What gems have you found around Kuala Lumpur? Let us know and we’ll update this post.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.847+08	2026-04-03 11:28:35.847+08	published	2026-04-03 11:28:35.849+08	2026-04-03 11:28:35.849+08	t	f	\N
18	18	Plan your trip around these festivities in Malaysia	malaysian-festivities	1	An adventure to Malaysia is exciting. There are so many new things to see, taste, smell and do. There’s the beach, exotic foods, great people to meet, hundreds of different ethnic groups to learn about, and amazing nightlife. But there is more to experience in Malaysia than just everyday life. For i	<p>An adventure to Malaysia is exciting. There are so many new things to see, taste, smell and do. There’s the beach, exotic foods, great people to meet, hundreds of different ethnic groups to learn about, and amazing nightlife. But there is more to experience in Malaysia than just everyday life. For instance, New Orleans is a great town to visit year-round, but the best time to visit is of course on Mardi Gras.</p>\n<p>I’m talking about my favorite times of the year. Festival time.</p>\n<p>There are about two festivals a month throughout the year in different parts of Malaysia. Most festivals revolve around culture or religion and since Malaysia is a great blend of religions including Hindus, Muslims, Christians, Sikhs, and Buddhists and hundreds of different ethnic groups there is always something going on.</p>\n<p>East and West Malaysia may have separate cultural events and some may have open houses with dancing and lots of food spread out for everyone to enjoy, yet others are a time of fasting and prayer and visiting the temple or mosque.</p>\n<p>Here are ten must-see festivals in Malaysia to plan your adventure around.</p>\n<h4>Chinese New Year</h4>\n<p><strong>When</strong>: Can fall anywhere between lat January to Mid February.</p>\n<p><strong>Where</strong>: All throughout Malaysia in the Chinese communities.</p>\n<p>The Chinese communities transform the entire country into a vibrant, colorful festival of dancing dragons and paper lanterns. Chinese New year is the biggest event of the year for the Chinese communities and everyone gets involved.</p>\n<p>Lions and Dragons (not real ones of course) dance in a colorful yearly ritual to bring good fortune and prosperity in the New Year and to chase away any evil spirits or bad omens. The Chinese Malaysians will have people in costume doing these dances in businesses, their homes and some cities have events of traditional music and ceremonies.</p>\n<p>Shopping malls and many public places hang red lantern decorations (red is a lucky color) and children are given “ang pow” or a small red envelope filled with money. Another common tradition is giving away oranges to people that visit your home during this time.</p>\n<p>Chinese New year is also a time to find good-fortune foods like pineapple tarts, love letters (thin folded wafers) and peanut cookies just to name a few.</p>\n<h4>Eid (Hari Raya Aidilfitri)</h4>\n<p><strong>When</strong>: Late May to Mid June</p>\n<p><strong>Where</strong>: All throughout Malaysia, mostly in Muslim communities.</p>\n<p>Also called Hari Raya Puasa, this celebration marks the end of Ramadan’s month-long fasting for Muslims and celebrates the triumph of self-discipline and symbolizes rebirth or refinement. The phrase Hari Raya literally translates to “celebration day” and this is one huge celebration day, probably the biggest in Malaysia.</p>\n<p>It has no fixed date each year, instead, the religious experts calculate the date according to the lunar Hijri month. For one month, Muslims observe strict fasting from sunrise to sunset. They abstain from eating, drinking and smoking, and strive to resist any bad thoughts or desires.</p>\n<p>At sunrise on the last day, they attend the mosque for prayer then return home for a feast and celebration that can last up to a month. The first few days are reserved for catching up with family and many keep an open house where anyone, Muslim or non- Muslim can come and enjoy some good conversation and dive into delicacies like Ketupa, an Eid must-have.</p>\n<h4>Hari Raya Korban</h4>\n<p><strong>When</strong>: The date varies from late August to October</p>\n<p><strong>Where</strong>: All throughout Malaysia, mostly in Muslim communities.</p>\n<p>This is a public holiday to signify the “almost” sacrifice the prophet Ibrahim was willing to make. In the scriptures, Ibrahim was prepared to sacrifice his only son, Ishmael, as commanded by God. However, at the last minute, God commanded Ibrahim to stop and sacrifice a sheep instead.</p>\n<p>People will rise early, attend a sermon at the Mosque then head home for a day-long celebration. This is the time for gift-giving, new clothes and visiting friends. Large meals of goat or sheep which have been sacrificed are prepared and a portion of it, or the monetary equivalent is given to poor families so they too can celebrate.</p>\n<p>Mosques are decorated with lights and firecrackers are sometimes set off at night.</p>\n<p>This is the ideal time to see the unique architecture of the mosques and see how the meat is prepared in the slaughterhouses. Non-Muslims and even tourists are often invited to meals as a way to introduce them to Islamic culture.</p>\n<h4>Deepavali</h4>\n<p><strong>When</strong>: Dates vary from mid-October to November</p>\n<p><strong>Where</strong>: All throughout Malaysia especially in Hindu communities.</p>\n<p>Deepavali is the festival of lights, also a public holiday and one of the most colorful festivals in Malaysia. People decorate their homes with red paper and intricate “kolams” which are floor designs made from colored rice and powders.</p>\n<p>The background has several different legends in Hindu texts. The most common tells the story of how Lord Rama, who had been banished from the city, returned to take His throne. It was an unusually dark night so the people of the city lit lanterns to light the path for him.</p>\n<p>Another one is to honour Lakshmi, the Hindu goddess of prosperity. Clay lanterns are lit and placed all around asking the goddess to bless them. The main significance of the “festival of lights” is to signify the triumph of good over evil.</p>\n<p>This is an amazing time of lights and celebrations. There are firework displays at night and street food stalls are packed with Indian food, so this is the perfect time to indulge. A majority of the Hindu population is in West Malaysia and the capital Kuala Lumpur has two “little India” districts.</p>\n<p>Don’t forget to stop in and visit the amazing Hindu temples while you enjoy Deepavali.</p>\n<h4>Thaipusam</h4>\n<p><strong>When</strong>: late January/ early February</p>\n<p><strong>Where</strong>: Batu Caves on the outskirts of Kuala Lumpur, Waterfall</p>\n<p>Temple, Penang, and other shrines and locations nationwide.</p>\n<p>This is the most unique festival on this list, but I have to warn you, it’s not for the squeamish person. This Tamil celebration is held during the full moon and commemorates Lord Murugan (Hindu god of war) defeating an evil spirit called Soorapadman.</p>\n<p>As a tourist, this is something you will most likely not see again in your lifetime so I highly recommend this festival. Many on our tours have been skeptical about attending, but after they were happy they did.</p>\n<p>This celebration involves a parade through the streets of Kuala Lumpur led by a chariot that with a statue of Lord Murugan. Now here is where it may get a little outlandish. Devotees then make a barefoot walk to the Batu caves carrying jugs of milk and ornate frames called kavadi. The kavadi actually pierce the skin of their chest and backs as a symbol of penance. Some even put a spike through their cheeks.</p>\n<p>Not all devotees pierce their skin, though. Many just make offerings of fruit or flowers or other gifts. Batu caves are the most popular and largest shrine, but there are shrines all throughout Malaysia that celebrate Thaipusam.</p>\n<p>According to my friend Shoba, Penang Waterfall temple is the best place other than the Batu caves to experience Thaipusam.</p>\n<h4>Mooncake Festival</h4>\n<p><strong>When</strong>: End of September or early October</p>\n<p><strong>Where</strong>: All over Malaysia in the Chinese communities with the most popular celebrations in Thean Hou Temple in Kuala Lumpur and Penang.</p>\n<p>I just got an email this morning from a tourist family that was here last year for the Mooncake festival. They said they had been craving mooncakes ever since and wanted to know exactly when next year’s festival was. That’s when they are planning their vacation.</p>\n<p>I also look forward to this mid-autumn festival every year. The mooncake festival celebrates one of the most delicious Chinese delicacies ever made, the mooncake, and includes lantern parades, mooncake tasting and the lion and dragon dancing in the streets. Georgetown puts on a great event as does Nibong Tebal, Butterworth, Kepala Batas, and Bukit Mertajam.</p>\n<p>Hotels and shopping malls hold events and serve all kinds of mooncakes. Best to come and try all the various recipes and see for yourself. You’ll never look at the full moon again without getting hungry.</p>\n<h4>Independence day</h4>\n<p><strong>When</strong>: August 31st</p>\n<p><strong>Where</strong>: Most events take place on Merdeka Square in Kuala Lumpur, however it’s celebrated nationwide.</p>\n<p>This celebration commemorates our independence from the British on August 31st, 1957. It starts with fireworks right at midnight and continues on into the next day with parades, live concerts, food, and performances by civil servants and school children.</p>\n<h4>The Harvest Festival</h4>\n<p><strong>When</strong>: May 30-31</p>\n<p><strong>Where</strong>: Sabah and Labuan</p>\n<p>Traditionally, this festival is a time for farmers and their families to thank the spirits and God for the year’s rice harvest. This is a bit like Thanksgiving day in the US, but instead of turkey, the main course is rice. Rice is considered sacred and is a staple of our diet.</p>\n<p>Nowadays, it’s a celebration of food, fun, dancing and music. Expect a lot of Tapai and Lihing, or rice wine, to be flowing. Other favorites include hinava (fermented fish) and bambangan (a kind of pickled fruit similar to mango).</p>\n<p>In Unduk Ngadau, an annual beauty contest is held and the winner is announced at the end of the festival, and in other parts of the state, there are exhibits, public events. Most tourists love traditional dances and ethnic clothing. Not an experience to pass up.</p>\n<h4>The Dragon Boat Festival</h4>\n<p>When: December</p>\n<p>Where: Penang</p>\n<p>I never miss this festival and it’s definitely a tourist favorite. The Penang International Dragon Boat Festival is a two-day event where boat racers come from all over Malaysia, China, Singapore and Hong Kong to Teluk Bahang Dam to race in traditional boats to the sound of drum beats.</p>\n<p>Besides the boat races, there are local performers and of course my favorite, lots and lots of food available.</p>\n<h4>Nine Emperor Gods Festival</h4>\n<p><strong>When</strong>: Sept-Oct</p>\n<p><strong>Where</strong>: The Nine Emperor Gods Temple, Butterworth, Penang</p>\n<p>This Taoist festival in Penang is not one to miss. Like Thaipusam, it’s a nine-day event that features devotees performing firewalking and piercing their cheeks with long rods. They are awaiting the arrival of the nine Taoist gods and the temple is brilliantly lit and packed with followers dressed in white and carrying incense. It ends with a long procession on the ninth day from the temple to the beachfront to send the goods back home.</p>\n<p>The temple, also known as Rumah Berhala Tow Boo Kong, was started as a small shrine in 1971 which has grown into an elaborate and ornate temple completed in 2000. Many of our tourists ask about it and do visit year-round, but to really get a powerful experience you have to come and see the festival.</p>\n<p>So there are ten popular festivals to plan your vacation around, however, there’s a ton more to discover depending on where and when you visit.</p>\n<p>Some others include Wesak Day (May), Rainforest World Music Festival, Kuching, Sarawak (mid-July), Prophet Muhammad’s Birthday and of course Christmas.</p>\n<p>I’d love to hear about your favorite festival to visit in Malaysia, drop me a note in the comments below.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.859+08	2026-04-03 11:28:35.858+08	published	2026-04-03 11:28:35.861+08	2026-04-03 11:28:35.861+08	t	f	\N
19	19	Discover the Vibrant World of Malaysian Herbs and Traditional Flavours	malaysian-herbs-and-spices	1	Welcome to the vibrant world of Malaysian herbs, where the richness of Malaysian comes alive with every bite you take. In this article, we will dive headfirst into the fascinating realm of Malaysian cuisine and explore the diverse array of herbs that elevate its dishes to a whole new level. From aro	<p>Welcome to the vibrant world of Malaysian herbs, where the richness of Malaysian comes alive with every bite you take. In this article, we will dive headfirst into the fascinating realm of Malaysian cuisine and explore the diverse array of herbs that elevate its dishes to a whole new level. From aromatic leaves to zesty roots, we will uncover the secrets behind these flavorful ingredients and how they play an integral role in creating unique culinary experiences. Join us on a mouthwatering journey through Malaysia’s incredibly rich culinary heritage!</p>\n<h4>The Origins of Ulam: Tracing the Roots of Malaysian Herb Culture</h4>\n<p>The earliest inhabitants of Malaysia were known to use a great variety of herbs and roots in their daily diets. The best example of this is a sidedish better known as ulam. Ulam is the collective name for the indigenous wild leaves, herbs, shoots, nuts, and flowers that are eaten raw or lightly blanched. The dish has cultural and traditional significance in Malaysia and is a part of the country’s culinary heritage. Ulam-based recipes include Nasi Ulam, which is a popular Malaysian mixed herb rice salad that uses local herbs and vegetables as the main ingredients. Ulam has been a part of Malaysian cuisine for centuries and is still widely consumed today.</p>\n<ul><li>Ulam is believed to have originated from the indigenous communities in Malaysia who relied on their surrounding environment for sustenance.</li><li>Over time, ulam became an essential component of Malay cooking, offering a variety of flavours and textures to complement other dishes.</li></ul>\n<h4>Unveiling the Fragrant Leaves of Malaysian Cuisine</h4>\n<p>Malaysian cuisine is characterized by an array of aromatic herbs and spices that add depth and flavour to dishes. Among these, fragrant leaves play a significant role in traditional Malaysian cooking. These leaves not only enhance the aroma but also contribute unique tastes to meals.One such leaf commonly used in Malaysian cuisine is daun kesum or laksa leaf. This herb has a citrusy flavour that pairs well with savoury dishes like laksa, a spicy noodle soup popular in Malaysia. Another popular aromatic leaf is the banana leaf, which is often used as a natural wrapper for grilled meats or steamed rice dishes called nasi lemak. Other fragrant leaves include pandan leaves, which impart a sweet vanilla-like aroma when added to desserts, or betel leaves that are commonly used as wrappers for snacks like otak-otak, a fish cake delicacy.By incorporating these fragrant leaves into their recipes, Malaysians are able to create vibrant and flavorful meals that reflect the country’s rich culinary heritage. So next time you’re exploring Malaysian cuisine, be sure to pay attention to the fragrant leaves – they might just unveil new flavours you never knew existed!</p>\n<h4>Spices and Roots: Unleashing the Zesty Flavors of Malaysian Herbs</h4>\n<p>Malaysian cuisine is known for its bold flavours and vibrant spices. One key aspect of this culinary tradition is the use of an array of herbs that contribute to unique tastes.</p>\n<ol><li><strong>Galangal</strong>: A cousin to ginger, galangal adds a citrusy, peppery kick to dishes like soups and curries.</li><li><strong>Lemongrass</strong>: This fragrant grass lends a fresh lemon-like flavour to many Malaysian dishes, such as rendangs (spicy meat stews) and laksa (coconut-based noodle soup).</li><li><strong>Turmeric</strong>: With its bright yellow colour, turmeric not only adds earthiness but also boasts numerous health benefits.</li><li><strong>Kaffir lime leaves:</strong> These aromatic leaves provide a tangy, citrusy taste that complements both savoury and sweet recipes.</li><li><strong>Pandan leaves:</strong> Used in desserts and drinks, pandan leaves give off a distinctive aroma with hints of vanilla.</li><li><strong>Fenugreek seeds</strong>: Known locally as “halba,” these seeds are commonly used in spice blends for their nutty flavour.</li></ol>\n<p>Incorporating these herbs into your cooking will transport you to the vibrant world of Malaysian cuisine — get ready for an explosion of zesty flavours!</p>\n<h4>The Healing Power of Herbs</h4>\n<p>Malaysia’s herbs aren’t just ingredients in the local cuisine; they’re nature’s wellness treasures passed down through generations. These unassuming greens hold a special place for their remarkable healing qualities. Ginger’s robust flavour hides its power to ease digestion and enhance resilience. Turmeric’s golden hue signifies its anti-inflammatory prowess, supporting joints and bolstering immunity. Lemongrass, with its invigorating aroma, brings relaxation and digestive relief.But the healing journey doesn’t end there. Other herbs also contribute their unique benefits. Daun Kaduk, or wild pepper leaf, offers antimicrobial support, while Bunga Kantan, the vibrant torch ginger flower, brings antioxidants and anti-inflammatory potential. The aromatic Pandan Leaf is believed to possess anti-inflammatory properties. Each of these herbs weaves a holistic narrative of well-being, connecting us to the wisdom of nature.As you embrace the flavours of these herbs, remember that their potential benefits are grounded in tradition and nature’s wisdom. Consulting a healthcare professional before making significant dietary changes is always wise, especially if you have underlying health considerations. With each culinary creation, you’re not just enjoying a meal; you’re partaking in a centuries-old tradition of wellness Incorporate some ulam into your daily life and allow yourself to tap into nature’s pharmacy!</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/torch_ginger_46da785316.jpeg" alt="torch_ginger.jpeg">\n<p>Torch Ginger – Discover the vibrant world of traditional Malaysian herbs and flavors at a market.</p>\n<h4>Discovering Malaysian Herbs</h4>\n<p>Malaysia is a treasure trove of unique herbs that add an extraordinary touch to traditional flavours. Exploring these often lesser-known herbs will expand your culinary horizons and allow you to create truly authentic Malaysian dishes.</p>\n<ol><li><strong>Kesum</strong>, also known as Vietnamese coriander, is a popular herb in Malay cuisine. With a vibrant and peppery taste, this herb adds a delightful kick to Malaysian salads and stir-fries. Its unique flavour profile gives a fresh twist to traditional dishes.</li><li><strong>Daun Kaduk</strong> or wild pepper leaf, has become increasingly rare due to deforestation but remains highly sought after for its bold taste profile. Used widely in Nyonya cooking, it imparts a peppery tang that complements fish dishes perfectly.</li><li><strong>Curry Leaves</strong> These aromatic leaves add a burst of flavour to Malaysian curries and dishes. They are often sautéed with spices at the beginning of cooking to infuse a deep, earthy essence into the cuisine.</li><li><strong>Kaffir Lime Leaves</strong> are known for their citrusy fragrance, these leaves are a staple in Malaysian cooking. They are used to enhance the aroma of soups, stews, and curries, leaving a zesty and refreshing note.</li><li><strong>Turmeric Leaves </strong>are often used for wrapping food and impart a mild turmeric flavour and a hint of earthiness. They’re utilized to enhance the aroma and taste of dishes like rice and grilled meats.</li><li><strong>Bay Leaves</strong> offer a subtle yet distinctive flavour. They are used to season stews and slow-cooked dishes. They infuse warmth and depth into Malaysian comfort foods.</li><li><strong>Water Celery (Water Spinach)</strong> is commonly used in Malaysian stir-fries and noodle dishes, water celery brings a crisp texture and a hint of peppery taste, elevating the overall freshness of the dish.</li><li><strong>Cosmos</strong> contributes a mild, herby taste to Malaysian cuisine. It’s often used in soups and salads, offering a delicate layer of flavour to complement other ingredients.</li><li><strong>Asiatic Pennywort</strong> or Pegaga has a slightly tangy and refreshing flavour. Asiatic pennywort is a popular addition to salads and beverages. It’s believed to have health benefits and is often used in herbal drinks.</li><li><strong>Pandan Leaf</strong> is loved for its sweet aroma. These leaves are used to infuse Malaysian desserts, rice, and beverages. They lend a unique, fragrant touch to various traditional treats.</li><li><strong>Sweet Potato Leaves</strong> are used in Malaysian vegetable dishes, providing a subtle earthy taste. They are often sautéed with spices or included in soups.</li><li><strong>Lemongrass</strong> has a citrusy and herbal scent and is a cornerstone of Malaysian cuisine. It’s a key ingredient in curries, soups, and aromatic broths.</li><li><strong>Banana Leaves</strong> are utilized for wrapping food. Banana leaves impart a subtle, earthy flavour and a hint of sweetness. They’re also used to cook and serve dishes, adding an extra layer of aroma.</li><li><strong>Banana Flower</strong> is a unique ingredient that offers a slightly bitter taste and is commonly used in Malaysian salads and curries. Its distinct texture and flavour provide a memorable culinary experience.</li></ol>\n<p>By tapping into the world of rare and exotic herbs from Malaysia, you’ll embark on an incredible culinary journey filled with tantalizing tastes and unexpected delights! From kesum and daun kaduk to curry leaves and kaffir lime leaves, each herb adds its own distinctive flavour profile to traditional Malaysian flavours. By incorporating these exotic herbs into your cooking, you will embark on a culinary journey filled with tantalizing tastes and unexpected delights. The vibrant world of Malaysian herbs and traditional flavours awaits you, ready to elevate your culinary experiences to new heights.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.869+08	2026-04-03 11:28:35.869+08	published	2026-04-03 11:28:35.871+08	2026-04-03 11:28:35.871+08	t	f	\N
20	20	Must Try Malaysian Street Food Checklist	must-try-malaysian-street-food	1	My guests often ask me “what is the must-try Street Food when I visit Malaysia?”.	<p>My guests often ask me “what is the must-try Street Food when I visit Malaysia?”.</p>\n<p>Honestly speaking the Malaysian streets are a paradise, packed with vendors selling the most delicious and exotic street foods. Whether you’re in a hawker stall or just out taking in the sights, street foods are the perfect way to enjoy the cuisine and get a real feel for Malaysia and its people. The varieties of tastes and flavors you’ll find are all prepared with traditional techniques that represent the diversity of Malaysian culture. And won’t make a huge impact on your wallet.</p>\n<p>I compiled this list of my personal favorites. Before I would send this list out to our clients after they completed their tour and now it’s time to share that list with everyone!</p>\n<p>So here is my Must-Try Malaysian Street Food Checklist.</p>\n<h4>DISHES</h4>\n<h5>Nasi lemak</h5>\n<p>Top of the list and a favorite for tourists and locals alike is Nasi lemak. Considered the national dish, it can be found in both roadside stalls served on a banana leaf and in 5-star restaurants in fine china. This dish is a hearty mix of coconut rice infused with pandan, cucumbers, nuts, anchovies and egg.</p>\n<p>There are several variations and choices of sides depending on where you go. Some more popular sides include deep-fried fish, chicken, fish cake and even curried vegetables. Besides the aromatic rice, the signature of this dish is the spicy sambal or chili paste.</p>\n<h5>Char Kuey Teow</h5>\n<p>Once considered “poor man’s food”, Char Kuey Teow has evolved into a local favorite. Literally translated, the name means ‘stir-fried rice cake strips’ and consists of spicy, flat rice noodles stir-fried over high heat with soy sauce, shrimp, chilis, cockles, bean sprouts, eggs and Chinese chives. If you want more of a Chinese-style dish, you can also find variations of this dish fried in pork lard with slices of Chinese sausage and fishcake.</p>\n<h4>Beef Noodle</h4>\n<p>This dish may have a humble name, but the flavor is anything but ordinary. Large chunks of beef brisket simmered in a spicy broth with rice noodles, chives, bean sprouts and other Asian greens. You can find this dish right on the street or starring in one of the many restaurants that claim to have the best noodles in Malaysia.</p>\n<h4>Yong Tau Foo</h4>\n<p>Another favorite with variations depending on cultural influences is Yong Tau Foo. This dish can be served for breakfast, lunch or dinner. This Hakka dish is white tofu stuffed with either a ground meat mixture or surimi (fish paste) then deep fried to a golden brown.</p>\n<p>Mushrooms and other vegetables, like eggplant, can also be stuffed and fried as a variation to this dish, then served with fried tofu balls.</p>\n<p>You can have your Yong Tau Foo dry, with sauce, or even served as soup.</p>\n<h4>Asam Laksa</h4>\n<p>One of Malaysia’s most beloved dishes is Asam Laksa. This iconic dish is a “must try” when visiting Penang and was ranked 7th on CNN’s World’s Best Food List.</p>\n<p>Served mainly in the late afternoon, this dish is a spicy fish broth soured by tamarind and filled with smooth rice noodles, shredded mackerel, mint, lemon grass, onion, and pineapple. Then garnished with pink ginger flowers, thinly sliced cucumbers, bird’s eye chilis and a sweet prawn paste called heh ko.</p>\n<h4>Roti Canai</h4>\n<p>This popular snack or breakfast dish has its origins in India, but today can be found all over Asia.</p>\n<p>This flatbread is very inexpensive and is uniquely made by first flattening the dough then forming it into a rope and twisting it before rolling it flat again. This process gives the roti flaky layers as it cooks.</p>\n<p>Traditionally served with dhal, a curried lentil soup, or other curries. It’s most popular alongside Teh Tarik, or ‘pulled tea”, as a breakfast dish.</p>\n<h4>Hokkien Mee (Egg and Rice Noodles in Spicy Soup)</h4>\n<p>Also known as Ha Mee, this delicious soup has its origins in China’s Hokkien province and was introduced to Malaysia by Chinese sailors after World War II.</p>\n<p>A bowlful of Hokkein Mee contains a special broth made by stewing prawn heads, clams, pork, and dried fish. Two kinds of noodles – egg noodles and rice vermicelli – are then added along with kankong (or “water spinach”), bean sprouts, tender pork slices, squid, and shrimp then finishes with a hard-cooked egg and a spoonful of homemade chili sauce.</p>\n<h4>Fried Bee Hoon</h4>\n<p>A popular breakfast staple in Malaysia, Fried Bee Hoon has made its way into the hearts of many tourists as a perfect deviation from the usual morning meal.</p>\n<p>Bee Hoon is rice noodles, or vermicelli, which is soaked then stir-fried with soy sauce, oyster sauce, Chinese cabbage, bean sprouts, onion, garlic, ginger and any other variation of vegetables. Garnished with an egg, any style, spring onions and of course, chili sauce.</p>\n<h4>Murtabak</h4>\n<p>Similar to a turnover, Murtabak is a popular snack that was originally sold in Indian Muslim stalls and restaurants. Now it is offered nationwide and with many variations.</p>\n<p>The classic Murtabak is a pancake or pan-fried bread stuffed with minced beef or chicken, garlic, egg and onion. It is served with your choice of curry or gravy, sliced cucumber, syrup-pickled onions or tomato sauce.</p>\n<h4>Koay Teow Th’ng</h4>\n<p>The simplest and most affordable street food on this list is Koay Teow Th’ng. This soup is a clear broth with either duck, pork or chicken depending on the shop you visit. At most places, you can top it up with fish balls. This dish is completed by a garnish of lettuce and chopped spring onions.</p>\n<p>Whatever this flavorful soup may lack in complexity, it makes up for in taste.</p>\n<h2>Snacks</h2>\n<h4>Sweet Potato Balls</h4>\n<p>Another great treat while on the streets of Malaysia is an order of Sweet Potato Balls. One of my personal favorite snacks, these simple balls are made from mashed sweet potatoes, flour and sugar. The mixture is then formed into balls and deep-fried.</p>\n<p>Some stalls may even top them with toasted sesame seeds to give it an extra nutty flavor.</p>\n<h4>Durian Cream Puff</h4>\n<p>Similar to an eclair or other puffs, the Durian Cream Puff is not to be thought of as ordinary. These flaky pastry puffs are baked fresh and then stuffed with a cream filling made from the robust tropical fruit, durian. Despite its unpleasant odor and frightening appearance when still hanging from the tree, durian is one of the most delicious tropical fruits there is.</p>\n<h4>Karipap (Curry Puff)</h4>\n<p>For a quick, on-the-go snack, pick up a Karipap or curry puff. Similar to the empanada originating in Portugal, these half-moon-shaped pies are flaky puff pastries stuffed with curried chicken and potatoes then either deep-fried or baked. These are popular snacks among Malaysians and fit nicely in the palm of your hand, so they are easy to eat while walking.</p>\n<p>You can also find them minus the chicken for vegetarians.</p>\n<p>Tau Sar Piah</p>\n<p>Tau Sar Piah is a flaky, crisp, and buttery pastry with mung bean filling which can be either sweet or savory. I’ve found this traditional Singapore / Malaysian Chinese pastry in the local grocery stores in Malaysia, but those won’t compare to the ones baked fresh on the street.</p>\n<p>Roti Jala (Malaysian net crepes)</p>\n<p>Literally translated, Roti Jala means “net crepes” due to their unique lattice appearance.</p>\n<p>Tender and delicate, Roti Jala goes perfectly with chicken or beef curry but can accompany any chutney you desire. Ground turmeric gives this roti a mild aroma and a nice yellow tint</p>\n<h4>Satay</h4>\n<p>Malaysian nightlife would not be complete without trying this unique, Indonesian-inspired bar-b-que. The irresistible aroma alone will be enough to draw you over to the stall.</p>\n<p>Satay is pieces of beef, chicken or pork on bamboo skewers, marinated in a sweet and spicy satay peanut sauce, then grilled over a charcoal fire to give them that delicious smoky flavor. Served with red onion and cucumber slices for spearing.</p>\n<h4>Lok-Lok</h4>\n<p>Another late-night snack and similar to Satay is Lok-lok. Only this one kicks it up a notch.</p>\n<p>Endless trays of meats and vegetables on bamboo skewers, seasoned and ready to be cooked. You get a plate and choose your skewers, anything from beef, chicken, pork, mutton, and bacon to a variety of veggies. Once you have made your selections, you cook your skewers in a simmering broth to your liking. Nothing could be more fun and delicious!</p>\n<h4>Rojak</h4>\n<p>The work rojak translates to “mixture” in English, which is exactly what this dish is. A salad blend of the freshest fruits and vegetables around.</p>\n<p>I like the sweet version, which is normally fresh tropical fruits, but you can also get the savory which consists of fried bean curd, vegetables, fritters and hard-cooked eggs. Both are awesome and tossed in a tangy sweet sauce that brings the flavors together.</p>\n<p>Rojak is best enjoyed when made fresh, though. If you leave it to sit too long and it becomes soggy.</p>\n<p>Cucur Udang (Prawn Fritters)</p>\n<p>Commonly known amongst Malaysians as “jemput jemput udang”, Cucur Udang are soft, bite-size, prawn fritters fried to perfection.</p>\n<p>Fresh shrimp, corn, white onion, red chilis, and spring onions are blended together with flour and dropped by small spoonfuls into hot oil to produce this awesome snack which can be eaten plain or dipped in chili sauce or peanut sauce.</p>\n<h4>Desserts</h4>\n<h5>Apam Balik</h5>\n<p>I love watching them make this. It’s a simple pancake made from flour, eggs, sugar, baking soda, coconut milk and water then cooked in a large iron pan coated with palm margarine. Once flipped, it is stuffed with crushed peanuts and sweet creamed corn, then folded, like a turnover and cut making it easier to eat on the go.</p>\n<p>You can find other variations which include shredded cheese and even chocolate sprinkles.</p>\n<h4>Tong Sui</h4>\n<p>I have found so many varieties of this popular dessert soup whose name literally translates to “sugar water”. So many varieties in fact, that many stalls have gained fame with their specialty Tong Sui.</p>\n<p>I’m not sure which one is my favorite, but some that I look for are red bean soup, peanut paste soup, black-eyed peas soup, wheat porridge, tofu pudding, and sago (tapioca pearls) with shredded coconut in evaporated milk.</p>\n<p>Whatever your tastes, you will find a Tong Sui to satisfy you.</p>\n<h4>Cendol</h4>\n<p>I like this dessert on those hot days to escape the heat. It’s simple and super inexpensive.</p>\n<p>Cendol is a generous bowl of shaved ice mixed with green rice flour jelly, coconut milk and palm sugar syrup. Add creamed corn for an extra layer of flavor and texture.</p>\n<h4>Drinks</h4>\n<h5>Cham Ice</h5>\n<p>In English, the word cham literally translates to “mix” which is a fitting description for this refreshing beverage, as it’s a mix of coffee, tea and condensed milk served over ice.</p>\n<p>For a healthier version, condensed milk can be substituted for fresh or evaporated milk.</p>\n<h5>Five Flower Tea</h5>\n<p>I love this tea. It’s globally known for its medicinal value as well as its wonderful aroma and taste. It’s brewed from a mixture of honeysuckle, chrysanthemum, silk cotton, Plumeria Rubra and Pueraria lobata.</p>\n<p>It has anti-inflammatory properties which can help alleviate such ailments as fatigue, sore throat, indigestion, poor appetite, insomnia and urinary difficulty</p>\n<h4>Nutmeg Juice</h4>\n<p>In the western world, nutmeg is widely known as an intricate element in pumpkin pie and eggnog. However in Malaysia, the pale yellow fruit from the nutmeg tree is pressed into a sweet and tangy juice that is served streetside in a variety of ways.</p>\n<p>There is bad news though. This delicious juice is only common in Penang. In other parts of Malaysia, you can find the nutmeg fruit candied or even as preserves.</p>\n<h4>Teh Tarik</h4>\n<p>To end this list, I chose one of the most delicious and unique drinks found throughout the country. Teh Tarik.</p>\n<p>Teh Tarik means literally “pulled tea” and is the national drink of Malaysia. Similar to Cham Ice, this beverage is a mixture of black tea and condensed milk, but is served hot and can be found in street stalls as well as the fancier restaurants.</p>\n<p>What’s unique about Teh Tarik is the way it’s prepared. First, the tea and milk are combined, then repeatedly poured from a height between two cups. This thoroughly mixes the tea and milk, cools the beverage to just the right temperature and gives it a nice foam on top, thus enhancing the flavor.</p>\n<p>Teh Tarik is a great accompaniment to Roti canai and is a very popular and traditional breakfast among Malaysians.</p>\n<p>And that sums up my list of must-eat Street Food when visiting Malaysia. Do you have a favorite or have I missed a dish? Let me know in the comments below.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.881+08	2026-04-03 11:28:35.881+08	published	2026-04-03 11:28:35.883+08	2026-04-03 11:28:35.883+08	t	f	\N
21	21	How long does it take to get to Kuala Lumpur from Port Klang?	port-klang-to-kuala-lumpur	1	Taking a cruise to Malaysia is a fun and exciting way to arrive. You’ll get to see the many forested islands as you weave your way up the Malacca Strait and dock at Port Klang just south-west of Kuala Lumpur. And once you dock, there are a few things you can do and although I strongly suggest a day 	<p>Taking a cruise to Malaysia is a fun and exciting way to arrive. You’ll get to see the many forested islands as you weave your way up the Malacca Strait and dock at Port Klang just south-west of Kuala Lumpur. And once you dock, there are a few things you can do and although I strongly suggest a day trip to Kuala Lumpur to get a real feel for Malaysia and its capital, I do recommend understanding the travel times to make sure the cruise doesn’t leave without you.</p>\n<p>Depending on where you are going, it’s approximately 41 km from Port Klang to Kuala Lumpur and only takes about an hour and fifteen minutes. If you choose to travel by taxi or bus, it may take a few minutes longer due to heavy traffic and road conditions.</p>\n<h4>Port Klang</h4>\n<p>You’ll begin your day trip at Port Klang. Port Klang is the closest dock to the capital city, Kuala Lumpur and is the 11th busiest transshipment port and the 17th busiest container port in the world.</p>\n<p>There are three ports at Port Klang: Northport, Southpoint, and Westport. Southpoint is the original port with Northport and Westport coming much later. It was developed by the Malayan Railway and opened on 15 September 1901. At the time is was called Port Swettenham named after Sir Frank Athelstane Swettenham who had initiated a rail system between Klang and Kuala Lumpur. Before this, ships had a difficult time navigating through the jetty. So this new location at the mouth of the river was chosen.</p>\n<p>Before the railway was put in, the trip from Klang to Kuala Lumpur was horse or buffalo-drawn wagons or boat ride along the Klang River to Damansara. This was a long and rather tedious journey and with the rising need to transport tin and other materials from KL, the railway was initiated.</p>\n<p>Today, cruise ships normally dock at Port Klang Cruise Centre, however, there are sometimes exceptions. It’s best to check with the front desk onboard your ship to find out exactly where you will dock. When you get off the ship, first check in with The Port Klang Cruise Centre. There you will find everything you’ll need for your daytrip to Kuala Lumpur: currency exchange, wi-fi, taxi information desk, ATM, tourist information and souvenir shops.</p>\n<p>The nearby town of Klang has a lot to offer. There are street markets, plenty of historical sites and beautiful temples to visit. Even the port itself has a number of shops and restaurants serving up local delicacies like steamed crayfish and salt-baked crab. An excursion to nearby Crab Island could be a great way to spend your time near Klang. Catch the ferry to Crab Island if you are looking for a tranquil day of fun and seafood.</p>\n<h4>Getting to Kuala Lumpur</h4>\n<p>The biggest destination for most tourists coming into Port Klang, is a day trip to Kuala Lumpur. It’s a bit of a journey and the trip getting there and back will take up some of your shore leave time, but in my opinion it’s well worth it. Kuala Lumpur has a unique blend of history and culture that you will surely not want to pass up.</p>\n<p>Some cruise lines offer a shuttle service to Kuala Lumpur. Although convenient, I have heard from many tourists that it can get quite expensive at upwards of US$60 per person as of this writing. I cannot vouch for this price for every cruise line, so as always, best to check with the front desk on your ship. The biggest complaint about the shuttle service I have heard is that it does not stop at any of the sites. It merely picks you up and drops you off at the shopping mall.</p>\n<p>If your cruise line doesn’t offer shuttle service, or you are looking for a less expensive way to enjoy Kuala Lumpur for the day there are three other options. train, bus or taxi/grab. All three will take about the same amount of time, it just depends on your exact destination. The Port Klang Cruise Center will be able to help you make the best decision.</p>\n<p>When traveling to Kuala Lumpur, you have to keep in mind that even though it’s a tourist destination, it’s also a thriving metropolis and the capital of Malaysia. You’ll be well aware of this as you get closer to the city and see the high rises and skyscrapers. So taking into account the regular city traffic expects some delays now and again.</p>\n<p>Usually, peak hours for traffic starting at 7 am and can last until 9:30 am, while in the evening it will start around 4:30 pm and can stay congested until after 8 pm. Lunch time can also get a little heavy, so best to keep track of the time and take these periods into account when making plans.</p>\n<p>The roads are not always in the best of repair. They are bumpy and full of potholes. I’m not trying to dissuade you from taking the trip at all. I just want to give it to you straight so you know what to expect. Visiting Kuala Lumpur is worth a little traffic and discomfort for an hour.</p>\n<p>Let’s take a look at the different choices and see how they compare.</p>\n<h4>Train</h4>\n<p>The komuter KTM train station is about 13km from the port. You’ll have to hop a taxi to get there. The train is the least expensive way to go. Trains generally run once an hour and you can find the timetables in the Cruise center. The issue is, when you get to Kuala Lumpur, to make sure you allow yourself enough time to get back to the station before your train departs to return to the port.</p>\n<p>The train is a favorite simply because most of the sites to see are close to each other and on the train route. The coaches are comfortable, and air-conditioned and you can purchase tickets either at the ticket counter, online or at a ticketing vending machine. It will take you directly to the KL Sentral KTM station or Stesen Kuala Lumpur, right in the heart of Kuala Lumpur. It’s advised when coming back on the train from KL Sentral, to go ahead and get off in Klang (22km away) and take a taxi to the ship, since it will be difficult to find taxis at the Port Klang station.</p>\n<h4>Bus</h4>\n<p>Unless you’re willing spend most of your day sitting on the bus, this option is unfortunately not a viable way for anyone to get to Kuala Lumpur.</p>\n<h4>E-Hailing/Taxi</h4>\n<p>Booking a ride on an e-hailing app or arranging a taxi is the best option for most travellers arriving at Klang Cruise Terminal. The ride to Kuala Lumpur takes about 1h30min, however this really depends on traffic situations. With daily afternoon monsoon rains potentially complicating the journey back to the Cruise Terminal.</p>\n<p>The most common apps for e-hailing are Grab, AirAsia, inDrive and MyCar. Pricing for rides to Kuala Lumpur vary depending on traffic and rider availability, expect to spend at least RM110 in each direction. </p>\n<p>Official taxis have blue, red and/or white colors and they should go be the meter, unless booked through a ride-hailing app.</p>\n<h4>Hired Van/Shuttle</h4>\n<p>Some tourists choose to go this route for the simple fact that a hired van can shuttle you and your party through the different sites. They will stop where you want them to, and another benefit is, if you hire a driver for a round trip, they will know exactly where to pick you up and what time to return so that you can be assured to get back to the ship on time.</p>\n<p>Some private drivers offer their services in their personal vehicles, it’s adviced to check with them if they have an e-hailing license as that means they are also insured. Private Minivans range in size from 6-seaters all the way to 15-seaters. Hiring a minivan might be a cost-effective way to see the city if you manage to gather a couple of people. Do take note that any transportation with 8 participants or above is required to have a licensed guide on board. </p>\n<p>Whatever option you choose, it’s advised to allow plenty of time to get back to your ship and avoid trying to cut it close. You won’t be able to see everything in one day, so leave some sights for next time if it’s starting to get late. There have been tourists who have missed their port call because of traffic. It’s a messy situation and requires them to get a hotel room for the night and make further arrangements with the cruise lines which could cost them more cash.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.893+08	2026-04-03 11:28:35.893+08	published	2026-04-03 11:28:35.895+08	2026-04-03 11:28:35.895+08	t	f	\N
22	22	10 best souvenirs for foodies to bring back from Malaysia	souvenirs-for-foodies	1	I like to joke with tourists to bring an extra bag or suitcase when they are preparing for their trip to Malaysia. Why?	<p>I like to joke with tourists to bring an extra bag or suitcase when they are preparing for their trip to Malaysia. Why?</p>\n<p>Souvenirs.</p>\n<p>Many of our guests are foodies and don’t want to go home with the cheesy refrigerator magnet or snow globe that says Malaysia (when does it snow in Malaysia?), instead, they want something different to really express their Malaysian adventure.</p>\n<p>So I went ahead and compiled a list of 10 unique foodie souvenirs to remember your vacation.</p>\n<h4>Roti jala dispenser/mould- brass</h4>\n<p>Once you have tried roti jala, you are going to want to make it at home. I know this because even just last week a tourist asked me how she can make her own when she returns to the UK.</p>\n<p>Roti jala, also called net bread because of its criss-cross appearance, is a specialty here in Malaysia and a favorite among so many tourists. It’s usually eaten with chicken curry or with durian gravy/sauce and is a simple tea-time snack to prepare.</p>\n<p>To make roti jala at home you will need flour, eggs, milk and the special moulder available here as a take home souvenir (if you are not in Malaysia you could order a simple version from Amazon just like this one). Traditionally, it’s a cup made out of brass with holes in the bottom to ensure proper distribution of the batter. This is how the consistent net appearance is made.</p>\n<p>Nowadays, you can find them made out of plastic and a few different styles. The brass one’s can be hard to come by. You can find a moulder in any bakery shop or market.</p>\n<h4>Moon cake mould</h4>\n<p>Another one many foodie tourists want to rush home and replicate after the festival is the Chinese mooncake.</p>\n<p>The mooncake is an offering only available during the mooncake festival in mid-autumn. Again, this delicacy can’t be made properly without the proper equipment.</p>\n<p>As a souvenir, there are a few types to consider:</p>\n<p><strong>The classic wooden moulder </strong>– The wooden moulds look like a long paddle and it will have 2 or 3 intricately carved designs. This would also make a great decoration for the kitchen.</p>\n<p><strong>Plastic egg or rice moulder</strong> – These are the fun ones for the kids. They come in adorable shapes like fish, car, bunny, hearts, etc.</p>\n<p><strong>Silicon moulds </strong>– These are good as alternatives if you can’t find traditional or stamp mooncake molds.</p>\n<p><strong>Stamp moon cake moulds</strong> – These molds are made of plastic and have three main parts: a barrell for the cake, a disc for the design, and a plunger to press the design onto the cake.</p>\n<p>This is a great way to get your friends back home excited to hear about your Malaysian vacation. Just serve them some homemade mooncakes and tell them all about the festival and the different types of mooncakes you sampled.</p>\n<h4>Airtight tea container</h4>\n<p>When you think Malaysia, think tea. Tourists are amazed at how fresh tasting the tea here is. Drinking tea is a large part of Malaysian culture since the Chinese immigrants introduced it and not only is there great tea grown locally but it’s also imported from China, Sri Lanka and India.</p>\n<p>In order to keep the tea fresh it has to be kept away from heat, light, air, and moisture and should be stored at room temperature in an airtight container. Plastic is not the best material as it will absorb the flavors of whatever is put in it, even if it’s tea and that will permeate to the current batch.</p>\n<p>A good stainless steel or aluminum tea container with a well-fitting lid is just what the doctor ordered. And they look great on the kitchen counter. They may be a little pricey, but the craftsmanship is worth it. As well as having fresh tea all the time.</p>\n<p>Royal Selangor Pewter is the perfect place to pick up one of these.</p>\n<h4>Clay water container (Labu Sayong)</h4>\n<p>Sayong is a village in Perak, Malaysia that is famous for making “labu sayong”, or clay water containers. Labu means “pumpkin” since the local clay is first shaped then a pumpkin glaze is added before baking.</p>\n<p>These beautiful clay pots are very decorative, have several health benefits and keep water naturally cool even in the summer. Since it is made from clay and not plastic, there are no harmful chemicals that can harm your body.</p>\n<p>These can be found in beautiful colors and designs. Best place to find these pots are Central Market in Kuala Lumpur, Sayong Village in Perak, Pasar Payang in Terengganu and also Pasar Khadijah in Kelantan.</p>\n<h4>Coconut utensils</h4>\n<p>Bowls, spoons, lamps even a coinbox all made from coconut shells are an amazing way to brighten up your home. Here in Malaysia, we call the coconut tree the “tree of 1000 uses”. I’m not sure if there are exactly 1000 uses, but I’m here to tell you, there are many.</p>\n<p>After the meat and juice are extracted from the coconut, Malaysian creativity goes to work. They craft these items artistically to make useful household items and the benefits are astounding. Since they are wood they are naturally anti-bacterial, don’t conduct heat (no more burned hands from grabbing a hot spoon to stir) and don’t stick to food.</p>\n<p>Tourists and locals flock to these eco-friendly utensils. Even I use some at home. You can buy them as a set in the Central market in Kuala Lumpur where you’ll find a large selection, but they can be found at markets all throughout Malaysia.</p>\n<h4>Baba and Nyonya food container</h4>\n<p>This is a stackable food or “tiffen” carrier, normally with three tiers and more elaborate ones have five. The bottom tier is traditionally larger and is the one reserved for rice. The tiers sit on top of each other and are held together by the handle, which makes it easy to carry. It can then be opened by unlocking a small catch on either side of the handle.</p>\n<p>Also known locally as Mangkuk Sia, these were popular from colonial times in the late 18th century up until the 1960s, however, some still use it today. They are easy to use, clean and store and make a great replacement for plastic bags or other harmful food packages.</p>\n<p>They are made of brass or stainless steel and can be found either plain or ornately painted with different Asian-inspired designs. These are great for decoration or even to use daily to take food to school or the office.</p>\n<p>So now you know what I carry my lunch in to work every day.</p>\n<h4>Dried chili paste</h4>\n<p>Nowhere in the world are you going to find a dried chili paste like you will in Malaysia. There are so many different ethnic blends and places that add their own special touch, sometimes you can tell culture by its chili paste.</p>\n<p>Malaysian chili paste is normally super hot with added anchovies, whereas Chinese chili paste is simmered longer for a more mellow taste. Indian chili paste has a blend of sweet, spicy and sour.Some places may add other ingredients such as soybeans, salt, vinegar, lime juice or garlic.</p>\n<p>If you’re a fan of spicy, then this is the perfect foodie souvenir. It can be added to the recipe or used as a condiment, your choice.</p>\n<p>If you are in Melaka you will find Chinese or Peranakan dried chili paste. To find Malay go to Pasar Siti Khadijah in Kelantan or Pasar Payang in Terengganu. And if you are in Penang, hop over to Chowrasta to find our famous Penang-style chili paste.</p>\n<h4>Traditional food basket with cover</h4>\n<p>These food baskets are a great souvenir and will really liven up any kitchen. They are woven from the tall, thorny leaves of the pandanus or mengkuang which are collected, boiled and dyed.</p>\n<p>They were once used in the days before people had refrigerators to hold leftover cooked foods. The netting cover keeps the pests out, yet lets the air to circulate so the cooked food could cool properly and not spoil. It also allows someone to look in and see what’s for dinner without having to lift the lid. They are still very popular in a Peranakan households.</p>\n<h4>Curry powder</h4>\n<p>Curry powder is a great take away from your Malaysian vacation. It can be used to make, of course, curry dishes but can also be used as a rub in grilling or frying.</p>\n<p>Curry powder is a mixture of many spices like ground ginger, coriander, cumin, pepper and turmeric. The turmeric is what gives it its pungent aroma and yellow color.</p>\n<p>There are different types to choose from besides the “normal” curry powders depending on your tastes:</p>\n<p><strong>Madras Curry Powder</strong></p>\n<p>This one’s a bit spicy and has more of a red color than yellow since it’s made from dried chilis.</p>\n<p><strong>Vindaloo Curry powder</strong></p>\n<p>This one is even spicier and has many more chilis added</p>\n<p><strong>Maharaja Curry Powder</strong></p>\n<p>This curry powder is milder with a hint of sweetness.</p>\n<h4>Durian Chocolate</h4>\n<p>If you read my article on Durian, then you’ll already know what I’m talking about. If you haven’t read it, then stop what you’re doing now and go read it. It’s a good one.</p>\n<p>Durian chocolate is a great way to introduce your friends and family back home to durian. Or if you were like me, you can keep it all to yourself.</p>\n<p>There are so many more items to take home for great souvenirs. The above list is just what I’ve seen as most popular among tourists. Some other items to consider are : Honey, My Kuali Penang White Curry Instant Noodles, Instant White Coffee (you’ll fall in love with this), Nutmeg Oil and Boh tea.</p>\n<p>What’s one foodie souvenir you would want to get your hands on?</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.908+08	2026-04-03 11:28:35.907+08	published	2026-04-03 11:28:35.91+08	2026-04-03 11:28:35.91+08	t	f	\N
23	23	Traveling Malaysia during the fasting month (the best way to experience Ramadan)	traveling-during-fasting-month	1	Malaysia has a high population of Muslims citizens, more than half the country, making the month of Ramadan a special time nationwide. Many tourists find this as the ideal time for their Malaysian getaway. Some have friends who they visit on Hari Raya, and others just want to have the rich experienc	<p>Malaysia has a high population of Muslims citizens, more than half the country, making the month of Ramadan a special time nationwide. Many tourists find this as the ideal time for their Malaysian getaway. Some have friends who they visit on Hari Raya, and others just want to have the rich experience of visiting Malaysia during the month of Ramadan.</p>\n<p>Some may get the idea that by traveling to Malaysia for vacation during Ramadan month, that they‘ll be an intrusion as a non-muslim. This is not the case. In fact, Malaysia is a multicultural melting pot with many different types of religions, beliefs and ethnic people that live together. Here in Malaysia, we do more than just tolerate one another, we live in harmony and respect of each other and share our best traditions. So even as a non-muslim, there is still plenty to do and enjoy during Ramadan month.</p>\n<p>There may be a few slight restrictions to consider when you come during Ramadan month, however. For instance, Muslim restaurants and some businesses and shops will be closed. But again, don’t let that dissuade you from coming and enjoying the great things Ramadan month in Malaysia has to offer.</p>\n<h4>What exactly is Ramadan?</h4>\n<p>Ramadan (also known as Ramadhan or Ramzan) is the ninth month in the Islamic calendar and is a holy month observed by Muslims worldwide. The word Ramadan comes from the Arabic root ramiḍa or ar-ramaḍ, which means scorching heat or dry ground without food or water.It commemorates the month during which Muhammad received the initial revelations of what would become the Quran and is one of the Five Pillars of Islam. This is what Muslims call “the best of times”.</p>\n<p>During the month of Ramadan, Muslims abstain from eating or drinking at dawn and sunset. This fasting is a way to attain taqwa, the fear of God. The goal is to bring oneself closer to Allah, or God. It is believed that God explained to the prophet Muhammad that fasting was an obligatory practice that should be observed by those who wish “oneness” with Him.</p>\n<p>Ramadan is also a special month for spending time with family and friends and reaching out to the poor and other charities in the community, but most importantly, Ramadan is a time of spiritual reflection.</p>\n<h4>Three parts of Ramadan</h4>\n<p>There are three parts to the month of Ramadan. Ramadan begins, The night of Power, and Eid (or Hari Raya in Indonesia and Malaysia). Each have its own special observances and meanings. For non-Muslims, Hari Raya is an exciting time to join with your Muslim friends and marks the end of Ramadan.</p>\n<h4>Ramadan Begins</h4>\n<p>Ramadan begins typically about a day after the new moon, marking the new month. Islamic scholars calculate the day each year, so it does fall on a different date. Take note: In Johor, Kedah, and Malacca, Ramadan begins is a public holiday and is a day off for the general public. Schools and most businesses are closed.</p>\n<h4>The Night Of Power</h4>\n<p>This is considered the most holiest of nights throughout the year. According to Islamic belief, it’s the night in which the first revelation of the Quran was given to Muhammad saying that this night was “better than one thousand months [of proper worship]”, as stated in Chapter 97:3 of the Quran.</p>\n<h4>Hari Raya Aidilfitri The End Of Ramadan</h4>\n<p>This is the first day of the new month, Shawwal and marks the end of Ramadan. This is a day of feating and celebrating for having successfully endured an entire month of abstaining from food, water, smoking and intimacy and represents the returning back to a normal routine.</p>\n<p>Hari Raya Aidilfitri is considered one of the two most important celebrations for Muslims, the other is Hari Raya Haji which is also a festival that commemorates Abraham’s sacrifice.</p>\n<p>We’ll talk a little more about Hari Raya later on. This is a time when our tourists come back and rave about the food and fun they enjoyed.</p>\n<h4>How is Ramadan Observed?</h4>\n<p>Our Muslim communities, as well as Muslim communities worldwide, take Ramadan very seriously and follow all of the practices and observances required. As mentioned, Ramadan is a month of fasting. During daylight hours, Muslims fast from food, water, sexual activity and smoking. This is obligatory for all adult Muslims except those who are sick, traveling, elderly, pregnant, breastfeeding, diabetic, chronically ill or women who may be menstruating. Although eating during daylight hours is permitted for those mentioned, they still will not eat in public.</p>\n<p>Prayer and spiritual reflection is an important part of Ramadan. Many immerse themselves into studying and reciting the Quran, and vow to recite the Quran in its entirety by the months end.</p>\n<p>This is how the fast is observed:</p>\n<h4>Sahur- The Pre-dawn Meal</h4>\n<p>This fast begins right after Sahur, or the pre dawn meal. This gives them energy for the long day ahead. Normally, sahur is served around 4:30 am, but this depends on which state because in Sabah and Sarawak the break of dawn is earlier compared to the Peninsular of Malaysia. The Sahur time will also be earlier. Once the dawn breaks, no food is taken for the rest of the day until sundown. Malaysia is fortunate that the days are not as long as in some other areas of the world. But it doesn’t matter, Muslims take this sacrifice very seriously and accept it piously.</p>\n<p>Some stay up after Sahur and take the time to reflect and pray, while others will grab a little more sleep. Both are accepted.</p>\n<p>Tourists can experience sahur at any mosque and also many Muslim restaurants do prepare a meal for Sahur, then close afterward. Sahur can be a variety of foods like coconut pancakes or BBQ chicken wings, or just a simple baked macaroni or corn coconut pudding.</p>\n<h4>Buka Puasa- Break fasting meal at sunset</h4>\n<p>This is the best time of the day. After fasting the whole day all Muslims will celebrate the day by breakfasting. Here the term “breakfast” does not refer to the morning meal as it has come to be recognized, but the meaning is the same. Buka Puasa is “breaking the fast”.</p>\n<p>Traditionally, dates are the first thing eaten to break the day’s fast. This is a remembrance of how Muhammad broke his own fast by eating dates. After that, they generally gather for the Maghrib prayer, the fourth of the five daily prayers, after which the main meal is served.</p>\n<p>Its all about sharing and giving. There are no restrictions for non-Muslims to join the breakfast. Everyone is welcome in the feast, so if you perhaps meet a Muslim family while on vacation, don’t be surprised if they invite you to eat with them after sundown.</p>\n<p>Depending on some city councils, do organize public breakfasts meaning they will sponsor food for the public or even anyone to come and join the breakfast. And you will sit together will the locals and enjoy a meal at that particular area. You have to just find out if there are any in your area.</p>\n<h4>Tarawih Prayer</h4>\n<p>During the month of Ramadan, it’s very common to see mosques occupied with people 24/7. Many of our tourists are amazed to see this type of devotion and dedication. What’s unique about visiting the mosque during Ramadan month is its the only time throughout the year you will hear the Tarawih Prayer being recited. However, it’s not obligatory to recite them.</p>\n<p>Usually, after the prayer, there will be some religious lectures that is also open to the public. If you are visiting one of the beautiful mosques during Ramadan month, you may even be invited inside to experience it firsthand.</p>\n<h4>Charities and Charity Work</h4>\n<p>In the Muslim faith, great importance is placed on charity and charity work. In fact, one of The Pillars Of Islam is a certain percentage of one’s wages should be donated to the poor. However, during Ramadan, it is believed the rewards for giving charity are greater, so many take this opportunity for Sadaqah or voluntarily give more than what is normally required which will maximize their reward at the Last Judgement.</p>\n<h4>Experiencing Ramadan Month as a  Tourist</h4>\n<p>For the non-Muslim traveling to Malaysia during Ramadan month, you may not notice much of a difference if you are not interested in visiting the mosques or enjoying the Muslim Ramadan traditions. Some attraction places might close earlier so the Muslims can get themselves ready for breakfast. They will need to buy food, cook and make preparations for the sundown meal. This usually will affect certain specific states like Kelantan, Terengganu,Johor and Kedah. Just check on the timing to reconfirm.</p>\n<p>Traffic in Ramadan will be a bit more congested than normal in the afternoon. Most of the office workers will leave work earlier so they can get home and prepare So, if you need to catch a bus, train or flight ensure you plan ahead for your journey. Just to avoid the heavy traffic.</p>\n<h3>Pasar Ramadan (Ramadan Bazaar)</h3>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_71_d0b570c224.jpeg" alt="asset-71.jpeg">\n<p>If you find yourself in Malaysia during Ramadan month, you will not be able to miss the Pasar Ramadan, or the Ramadan Bazaar. This is a month-long bazar set up in many cities and Muslim communities, almost everywhere throughout Malaysia, that sells an enormous amount of food. And when I say big, I mean big. The Ramadan Bazaar in Kuala Lumpur,Kampung Baru Ramadan Bazaar has over 200 stalls selling just about anything you can imagine and has been known to be almost two kilometers long.</p>\n<p>Different kind of rice from other states, different colours and tastes. Here you can find foods like kerabu rice, dagang rice, nasi lemak, nasi briyani, and nasi ambeng, just to name a few popular dishes. You can choose anything you fancy. The bazaar is not reserved only for Muslims observing Ramadan. Anyone can can enter and eat. I recall a tourist group last year that made a point to visit the bazaar everyday of their stay for breakfast. There was no reason to go to a restaurant, everything they wanted was right there.</p>\n<p>You’ll also find local delicacies ranging from sweet to savory. Try popia goreng, kuih puteri mandi, pulut panggang. These are some dishes that you won’t be able to find normally. Cold drinks are also served. The Bazaar normally opens at 4:30 am then closes around 7:30 am. It will re-open as early as 4pm so people can gather what they need for breakfasting.</p>\n<h4>Hari Raya</h4>\n<p>If you are fortunate enough to be in Malaysia for Hari Raya, prepare for an amazing experience. This is the end of Ramadan month and the end of the fasting. As soon as the new moon is seen on the last day of Ramadan, the fasting is over and the celebration begins.</p>\n<p>However, most Muslims have already been planning and preparing for Hari Raya way in advance. They stock food, buy new clothes and gifts and really let the excitement build. On the morning of Hari Raya, the men perform prayers at the mosque while children ask for forgiveness from their parents. The children also receive small green packets stuffed with cash. After prayers, it’s time to eat and visit with friends.</p>\n<p>Traditionally the first three days of Hari Raya are to be spent catching up with relatives and close friends, however many families open their homes throughout the month for anyone, Muslim or not, to come and enjoy food, fun and laughter with them. Hopefully, you will be fortunate if you had visited one of the mosques or even met some locals at the bazaar to be invited to an open house. Not an experience you’ll want to pass up. Thsi is actually a common practice and believed that by invited non-Muslims and/or foreigners into their homes for Hari Raya, they will receive extra blessings.</p>\n<p>Here in Malaysia, the first two days of Hari Raya are public holidays, so many things will be closed and the cities may look a little deserted as a lot of Muslims will travel to their hometowns to visit their families and spend time celebrating with them. Even once they return to the cities and back to work, the celebrations don’t end. For the rest of the month you’ll still find them throwing parties and having open houses. One month of fasting, followed by one month of festivities.</p>\n<h4>Foods To Try During Hari Raya</h4>\n<p>The delicacies offered during Hari Raya are not to be passed up.Just like pumpkin pie and Thanksgiving in the US, some of these delicacies go hand in hand with Hari Raya and can only be found during this time.</p>\n<h4>Ketput</h4>\n<p>Ketput is one such food item that everyone looks forward to and to be honest, it wouldn’t be Hari Raya without it. Ketput is compressed rice wrapped in coconut leaves in the shape of a diamond then cooked.</p>\n<p>It’s usually served with beef rending (beef cooked with coconut milk and malay spices) and satay (skewered grilled meat), or just with cool slices of cucumber.</p>\n<h4>Lemang</h4>\n<p>Another one of Malaysia’s signature Hari Raya delicacies. Lemang is glutinous coconut rice wrapped in fragrant banana leaves, then stuffed into hollow bamboo sticks and roasted over a fire. I like this best with my rendang or even chicken curry.</p>\n<h4>Dodol</h4>\n<p>Doldol may seem tame given the ingredients are only coconut milk, cane sugar and rice flour, but ask any local and they will tell you this is a difficult one to make. It takes nine hours of constant stirring over a hot fire to come up with the finished product. When you give this a try, remember the work that went into it. It will taste even better.</p>\n<h4>Bubur Lambuk</h4>\n<p>This is a soup that is also quite popular during the Ramadan month as well as Hari Raya. Anise, cardamom, cinnamon and black pepper, among other spices are simmered along with certain vegetables and meat depending on what region or part of Malaysia you are in</p>\n<h4>Lontong</h4>\n<p>Lontong is an amazing Hari Raya dish that has its roots in Indonesia. It’s a coconut soup that’s a combination of nasi impit, vegetables and meat, served in a savoury coconut milk base. Again depending on where you are, there will be variations. Some cooks put peanut sauce in the soup while others add tempeh or a hard-boiled egg. Its served with rice cakes.</p>\n<h4>Some Quick Pro Tips About Travelling During Ramadan</h4>\n<p>• Take note that shops and malls will be pretty packed the week before Ramadan. People like to stock up, especially on dates, which is served every night at breakfasting</p>\n<p>• As the sun goes down, traffic can get quite heavy as everyone rushes home for breakfasting. If you plan to go out to dinner, might want to try and go a little early before the sun goes down.</p>\n<p>• In country flights, busses and trains can be crowded or all booked up since many Muslims will be traveling to see their families. Make sure to reserve way in advance if you plan to travel around the country.</p>\n<p>• If traveling during Ramadan month, try and find hotels near or around Indian or Chinese communities. Some hotels and restaurants may be closed during the day if they are Muslim owned and operated.</p>\n<p>• Pack some snacks if you plan to travel in areas where restaurants and shops may be closed.</p>\n<p>If you are planning your vacation to Malaysia, and it happens to fall within Ramadan month, don’t reschedule, but consider yourself lucky to be able to experience this wonderful culture and religion at such a great time of the year for them. And if you have extra vacation days, stick around for Hari Raya. You won’t be disappointed.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.92+08	2026-04-03 11:28:35.92+08	published	2026-04-03 11:28:35.923+08	2026-04-03 11:28:35.923+08	t	f	\N
\.


--
-- Data for Name: _testimonials_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._testimonials_v (id, parent_id, version_author_name, version_author_location, version_rating, version_review_text, version_review_title, version_author_photo, version_date, version_visibility_verified, version_visibility_featured, version_platform, version_workflow_status, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave) FROM stdin;
6	6	Sarah Johnson	Australia	5	The Flavours of Malaysia tour was the highlight of our trip. Our guide was knowledgeable and the food was incredible!	Amazing experience!	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.266+08	2026-04-03 16:09:42.266+08	draft	2026-04-03 16:09:42.27+08	2026-04-03 16:09:42.27+08	t	f
7	7	Michael Chen	Singapore	5	Great way to experience local culture. The market visit was eye-opening and all the food stops were fantastic.	Highly recommended	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.302+08	2026-04-03 16:09:42.302+08	draft	2026-04-03 16:09:42.305+08	2026-04-03 16:09:42.305+08	t	f
8	8	Emma Williams	United Kingdom	5	We have done food tours around the world, and this one tops them all. Authentic, delicious, and great value.	Best food tour ever	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.329+08	2026-04-03 16:09:42.329+08	draft	2026-04-03 16:09:42.331+08	2026-04-03 16:09:42.331+08	t	f
9	9	David Lee	USA	5	The Penang Heritage tour exceeded our expectations. Our guide shared amazing stories and the food was outstanding.	Penang tour was exceptional	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.359+08	2026-04-03 16:09:42.359+08	draft	2026-04-03 16:09:42.362+08	2026-04-03 16:09:42.362+08	t	f
10	10	Priya Sharma	India	5	As a vegetarian, I was worried about food options in Malaysia. This tour showed me so many delicious vegetarian dishes!	Perfect for vegetarians	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.385+08	2026-04-03 16:09:42.385+08	draft	2026-04-03 16:09:42.388+08	2026-04-03 16:09:42.388+08	t	f
\.


--
-- Data for Name: _tours_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._tours_v (id, parent_id, version_name, version_slug, version_tagline, version_short_description, version_full_description, version_price, version_currency, version_duration, version_duration_minutes, version_location, version_meeting_point, version_max_participants, version_min_participants, version_tailored_available, version_tailored_notes, version_booking_url, version_instant_confirmation, version_scheduled_publish, version_featured, version_popular, version_new, version_published_at, version_status, version_workflow_status, version_meta_title, version_meta_description, version_meta_image_id, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave, version_hero_image_id) FROM stdin;
5	5	Secrets of KL – Nightlife, Street Art & Cocktails!	secrets-of-kl-nightlife	Adults Only Adventure	Simply Enak's adults-only adventure reveals hidden speakeasy bars, classic Malaysian food and the forbidden tales of the red-light district.	This adults-only adventure reveals hidden speakeasy bars, classic Malaysian food, and the forbidden tales of the red-light district.\n\nExperience KL's sophisticated nightlife with insider access. You'll discover hidden speakeasy bars locals love, taste classic Malaysian late-night street food, and hear the forbidden tales that shaped these streets.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)	359	MYR	4 hours	240	Kuala Lumpur	Pasar Seni MRT Station, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.121+08	2026-04-03 11:26:47.12+08	published	2026-04-03 11:26:47.127+08	2026-04-03 11:26:47.127+08	t	f	\N
6	6	Vegetarian Food Tour around Kuala Lumpur	vegetarian-food-tour-around-kuala-lumpur	100% Plant-Based. No Fish Sauce. No Surprises.	Kuala Lumpur has one of Asia's strongest vegetarian scenes. Simply Enak will guide you through 140 years of Indian vegetarian tradition, Buddhist vegetarian restaurants, and modern vegan cafes.	Kuala Lumpur has one of Asia's strongest vegetarian scenes, thanks to 140 years of Indian vegetarian tradition and thriving Buddhist vegetarian culture.\n\nBut here's the catch: "Vegetarian" here often means "no meat" — fish sauce, shrimp paste, and egg still show up. We know which stalls are truly 100% plant-based (no belacan, no oyster sauce, no egg noodles).\n\nWe've mapped the Buddhist vegetarian restaurants, the Indian vegan curry houses, and the Nyonya chefs who can adapt traditional recipes. This isn't "salad and rice." This is Malaysian cuisine at its most creative.\n\n---\n\n## Why Choose Our Vegetarian Food Tour?\n\n**14 Years of Dietary Expertise (Since 2011)**\nWe've accommodated every dietary need since 2011. Vegetarian, vegan, Jain, gluten-free — we know which stalls use belacan (shrimp paste), which use lard, which have dedicated allergen-free prep areas.\n\n**100% Plant-Based Vendors**\nNo fish sauce. No shrimp paste. No oyster sauce. No surprises. Every vendor is verified for strict vegetarian standards. Buddhist vegetarian stalls (素食) exclude all animal products and the five pungent roots.\n\n**Variety Beyond Salad**\nIndian banana leaf rice, Buddhist mock meats, modern vegan cafes, traditional Nyonya vegetarian dishes. This is Malaysian cuisine at its most creative — not an afterthought.\n\n**Small Groups (Max 9 People)**\nNot "up to 15." Not "usually 12." Maximum 9 people, every tour. Because you can ask questions about ingredients. Because you can hear the vendor stories.\n\n---\n\n## What Makes This Tour Different?\n\n| Feature | Simply Enak | Other Tours |\n|---------|-------------|-------------|\n| Vendor Verification | 100% plant-based checked (no belacan, no oyster sauce) | "Vegetarian-friendly" (may contain fish sauce) |\n| Dietary Knowledge | 14 years expertise (vegetarian since 2011) | Basic (ask at each stall) |\n| Variety | 8-10 different dishes across 3-4 vendor types | 5-6 dishes |\n| Group Size | Max 9 | 12-20 |\n| Guide Expertise | Local founders (Pauline & Maarten) | Hired guides |\n| Booking | Direct, no platform fees | Platform (20-25% commission) |\n\n**Sources:** Based on Simply Enak's 14 years dietary accommodation experience, competitor tour descriptions on Viator/GetYourGuide.\n\n**The Bottom Line:** We're not the cheapest. But after 14 years, 2,847 guests, and a 5.0/5.0 rating — we're the most trusted for dietary needs.	289	MYR	4 hours	240	Kuala Lumpur	Brickfields (Little India), Kuala Lumpur	9	2	t	We can create custom vegetarian tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.142+08	2026-04-03 11:26:47.142+08	published	2026-04-03 11:26:47.147+08	2026-04-03 11:26:47.147+08	t	f	\N
7	7	Vegetarian Food Tour around Penang	vegetarian-food-tour-around-penang	Penang's Best Vegetarian Street Food	Penang is surprisingly vegetarian-friendly! Simply Enak will show you the best vegetarian char kway teow, laksa, and Nyonya kuey - all 100% plant-based.	Penang is surprisingly vegetarian-friendly! Despite its reputation for seafood, the island has a thriving vegetarian scene thanks to its large Buddhist community.\n\nWe'll show you vegetarian char kway teow (yes, it exists!), vegetarian laksa, and colorful Nyonya kuey - all 100% plant-based with no fish sauce or shrimp paste.\n\nEvery vendor is verified vegetarian. No surprises. Just amazing food.	289	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	We can create custom vegetarian tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.163+08	2026-04-03 11:26:47.163+08	published	2026-04-03 11:26:47.169+08	2026-04-03 11:26:47.169+08	t	f	\N
8	8	Halal Food Tour around Kuala Lumpur	halal-food-tour-around-kuala-lumpur	100% Halal-Certified. No Pork. No Alcohol.	Malaysia is a Muslim-majority country where halal food is the default. Simply Enak will guide you through verified halal vendors, from Indian Muslim roti canai to Malay nasi lemak.	Malaysia is a Muslim-majority country where halal food is the default - but not every tour understands the nuances.\n\nWe know which wet markets sell pork separately (clearly marked), which hawker stalls are halal-certified, and which "Muslim-owned" restaurants actually serve alcohol.\n\nOur guides grew up navigating these distinctions. You won't have to ask awkward questions or wonder if that sauce contains wine vinegar. Every stop is verified halal - no guesswork, no compromises.	289	MYR	4 hours	240	Kuala Lumpur	Kampung Baru, Kuala Lumpur	9	2	t	We can create custom halal tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.184+08	2026-04-03 11:26:47.184+08	published	2026-04-03 11:26:47.189+08	2026-04-03 11:26:47.189+08	t	f	\N
9	9	Halal Food Tour around Penang	halal-food-tour-around-penang	Penang's Best Halal Street Food	Penang has excellent halal options! Simply Enak will show you halal char kway teow, nasi kandar, and more - all verified halal-certified.	Penang has excellent halal options despite its diverse food scene!\n\nWe'll show you halal char kway teow, legendary nasi kandar, and more - all verified halal-certified vendors.\n\nEvery stop is verified halal. No pork, no alcohol, no cross-contamination.	289	MYR	3.5 hours	210	Penang	Lebuh Chulia, George Town, Penang	9	2	t	We can create custom halal tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.205+08	2026-04-03 11:26:47.204+08	published	2026-04-03 11:26:47.21+08	2026-04-03 11:26:47.21+08	t	f	\N
21	21	Heritage Food Tour around Penang	heritage-food-tour-around-penang	Georgetown UNESCO Heritage & Food	Explore Georgetown UNESCO heritage streets while tasting Peranakan culture through colourful kuey and legendary dishes.	Explore Georgetown UNESCO heritage streets while tasting Peranakan culture through colourful kuey and legendary dishes.\n\nWe'll share Peranakan culture, explore temples and street art, and you'll leave with the history and culture behind Penang's most famous flavours.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.429+08	2026-04-03 11:26:47.429+08	published	2026-04-03 11:26:47.434+08	2026-04-03 11:26:47.434+08	t	f	\N
10	10	Gluten-Free Food Tour around Kuala Lumpur	gluten-free-food-tour-around-kuala-lumpur	Naturally GF. No Soy Sauce Surprises.	Malaysian food is surprisingly gluten-free friendly! But soy sauce hides everywhere. We've mapped the GF-safe vendors who use wheat-free soy sauce.	Malaysian food is surprisingly gluten-free friendly - rice, coconut milk, fresh spices, grilled meats. But here's the catch: soy sauce, oyster sauce, and hoisin hide everywhere.\n\nMost vendors don't know what "gluten" means. They'll say "yes, can!" while pouring dark soy into your dish.\n\nWe've mapped the GF-safe vendors. We know which stalls use wheat-free soy sauce, which rice noodle dishes are contaminated, and which desserts use wheat flour. Your gut won't pay the price.	299	MYR	4 hours	240	Kuala Lumpur	Pasar Seni, Kuala Lumpur	9	2	t	We can create custom GF tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.226+08	2026-04-03 11:26:47.226+08	published	2026-04-03 11:26:47.232+08	2026-04-03 11:26:47.232+08	t	f	\N
11	11	Gluten-Free Food Tour around Penang	gluten-free-food-tour-around-penang	Penang's Best Naturally GF Dishes	Penang has many naturally GF options! Rice noodles, grilled seafood, coconut-based curries. Simply Enak will show you the GF-safe vendors.	Penang has many naturally GF options! Rice noodles, grilled seafood, coconut-based curries - so much is naturally gluten-free.\n\nBut cross-contamination is real. We'll show you the GF-safe vendors who understand celiac disease and use dedicated utensils.	299	MYR	3.5 hours	210	Penang	Gurney Drive, Penang	9	2	t	We can create custom GF tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.248+08	2026-04-03 11:26:47.248+08	published	2026-04-03 11:26:47.253+08	2026-04-03 11:26:47.253+08	t	f	\N
12	12	Vegan Food Tour around Kuala Lumpur	vegan-food-tour-around-kuala-lumpur	100% Plant-Based. No Animal Products.	KL has a thriving vegan scene! Modern vegan cafes, traditional Indian vegan, and Buddhist vegetarian. All 100% plant-based.	KL has a thriving vegan scene! From modern vegan cafes in Bangsar to traditional Indian vegan curry houses and Buddhist vegetarian restaurants.\n\nWe know which stalls are truly 100% plant-based (no honey, no dairy, no egg). Every vendor is verified vegan.	299	MYR	4 hours	240	Kuala Lumpur	Bangsar, Kuala Lumpur	9	2	t	We can create custom vegan tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.265+08	2026-04-03 11:26:47.264+08	published	2026-04-03 11:26:47.27+08	2026-04-03 11:26:47.27+08	t	f	\N
13	13	Vegan Food Tour around Penang	vegan-food-tour-around-penang	Penang's Best Vegan Street Food	Penang has surprising vegan options! Simply Enak will show you vegan char kway teow, laksa, and more - all 100% plant-based.	Penang has surprising vegan options! Despite its reputation for seafood, the island has a thriving vegan scene.\n\nWe'll show you vegan char kway teow, vegan laksa, and colorful Nyonya kuey - all 100% plant-based with no fish sauce, shrimp paste, or egg.	299	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	We can create custom vegan tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.282+08	2026-04-03 11:26:47.282+08	published	2026-04-03 11:26:47.287+08	2026-04-03 11:26:47.287+08	t	f	\N
14	14	Jain Food Tour around Kuala Lumpur	jain-food-tour-around-kuala-lumpur	Strict Jain. No Root Vegetables.	KL's Indian community includes Jains. We know which restaurants have separate Jain kitchens and understand no root vegetables.	KL's Indian community includes a Jain population - which means we have authentic Jain restaurants.\n\nWe know which restaurants have separate Jain kitchens, which vendors understand "no root vegetables" (no onion, garlic, potato, carrot, beet), and which can prepare pure ahimsa cuisine without cross-contamination.	309	MYR	4 hours	240	Kuala Lumpur	Brickfields, Kuala Lumpur	9	2	t	We can create custom Jain tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.299+08	2026-04-03 11:26:47.299+08	published	2026-04-03 11:26:47.304+08	2026-04-03 11:26:47.304+08	t	f	\N
15	15	Jain Food Tour around Penang	jain-food-tour-around-penang	Penang's Jain Cuisine	Penang has Jain options! Simply Enak will show you Jain thali, dal, and more - all prepared without root vegetables.	Penang has Jain options! We know which restaurants understand Jain dietary laws and can prepare food without onion, garlic, or root vegetables.	309	MYR	3.5 hours	210	Penang	Little India, Penang	9	2	t	We can create custom Jain tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.317+08	2026-04-03 11:26:47.317+08	published	2026-04-03 11:26:47.323+08	2026-04-03 11:26:47.323+08	t	f	\N
16	16	Street Food Tour around Kuala Lumpur	street-food-tour-around-kuala-lumpur	Hawker Centres. Roadside Stalls. The Real KL.	KL's street food isn't a trend - it's a way of life. For 140+ years, hawkers have been perfecting recipes at the same roadside stalls.	KL's street food isn't a trend - it's a way of life. For 140+ years, hawkers have been perfecting recipes at the same roadside stalls.\n\nWe take you beyond tourist hawker centres to where locals actually eat: the 5am breakfast stalls, the midnight supper spots, the hidden alleys where the best char kway teow lives.	285	MYR	3.5 hours	210	Kuala Lumpur	Pasar Seni, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.335+08	2026-04-03 11:26:47.334+08	published	2026-04-03 11:26:47.34+08	2026-04-03 11:26:47.34+08	t	f	\N
17	17	Street Food Tour around Penang	street-food-tour-around-penang	Food Capital of Malaysia	What makes Penang the "food capital" of Malaysia? Simply Enak will guide you through the cultural fusion that created dishes you'll only find here.	What makes Penang the "food capital" of Malaysia? We'll guide you through the cultural fusion that created dishes you'll only find here.\n\nAt Chowrasta Market, we'll dare you to try kopitiam "Ngor Ka Sai", signature nutmeg pickles and dodol. You'll watch a master handcraft popiah skin, and taste legendary Asam Laksa balancing sweet, sour and savoury.	285	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.352+08	2026-04-03 11:26:47.352+08	published	2026-04-03 11:26:47.357+08	2026-04-03 11:26:47.357+08	t	f	\N
18	18	Market Food Tour around Kuala Lumpur	market-food-tour-around-kuala-lumpur	Chow Kit Market - KL's Largest Wet Market	Discover a traditional wet market to discover the real ingredients behind Malay cooking - exotic fruits, aromatic spices and more!	Discover a traditional wet market to discover the real ingredients behind Malay cooking - exotic fruits, aromatic spices and more!\n\nChow Kit Market is KL's largest wet market - a sprawling maze where locals have shopped for 100+ years. No souvenir shops. No tourist traps. Just real KL.	289	MYR	3.5 hours	210	Kuala Lumpur	Chow Kit Market, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.372+08	2026-04-03 11:26:47.372+08	published	2026-04-03 11:26:47.379+08	2026-04-03 11:26:47.379+08	t	f	\N
19	19	Market Food Tour around Penang	market-food-tour-around-penang	Chowrasta Market - Penang's Historic Market	Chowrasta Market is Penang's historic market - a sensory overload of spices, fruits, and local delicacies.	Chowrasta Market is Penang's historic market - a sensory overload of spices, fruits, and local delicacies.\n\nWe'll guide you through the maze, introducing you to vendors who've been here for generations. Taste signature nutmeg pickles, watch popiah being made, and discover ingredients you've never seen.	289	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.394+08	2026-04-03 11:26:47.394+08	published	2026-04-03 11:26:47.399+08	2026-04-03 11:26:47.399+08	t	f	\N
20	20	Heritage Food Tour around Kuala Lumpur	heritage-food-tour-around-kuala-lumpur	Temples, Historic Lanes & Amazing Food	Brand new to Malaysia? This is everything you need to know, passing major temples and historic lanes in Chinatown with amazing food!	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian culture and heritage.\n\nEvery dish and vendor has a story.	289	MYR	4 hours	240	Kuala Lumpur	Chinatown, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.412+08	2026-04-03 11:26:47.412+08	published	2026-04-03 11:26:47.417+08	2026-04-03 11:26:47.417+08	t	f	\N
22	22	Night Food Tour around Kuala Lumpur	night-food-tour-around-kuala-lumpur	Adults Only Adventure	Simply Enak's adults-only adventure reveals hidden speakeasy bars, classic Malaysian food and the forbidden tales of the red-light district.	This adults-only adventure reveals hidden speakeasy bars, classic Malaysian food, and the forbidden tales of the red-light district.\n\nExperience KL's sophisticated nightlife with insider access. You'll discover hidden speakeasy bars locals love, taste classic Malaysian late-night street food, and hear the forbidden tales that shaped these streets.	359	MYR	4 hours	240	Kuala Lumpur	Pasar Seni MRT, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.448+08	2026-04-03 11:26:47.448+08	published	2026-04-03 11:26:47.452+08	2026-04-03 11:26:47.452+08	t	f	\N
23	23	Night Food Tour around Penang	night-food-tour-around-penang	Georgetown After Dark	Experience Georgetown's vibrant night food scene. Hawker centres come alive after sunset.	Experience Georgetown's vibrant night food scene. Hawker centres come alive after sunset.\n\nWe'll guide you through the best night hawker stalls, taste sizzling satay, and experience Georgetown's nightlife like a local.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.465+08	2026-04-03 11:26:47.465+08	published	2026-04-03 11:26:47.472+08	2026-04-03 11:26:47.472+08	t	f	\N
24	24	Family Food Tour around Kuala Lumpur	family-food-tour-around-kuala-lumpur	Perfect for Families with Kids	Traveling with kids? Simply Enak's family-friendly tours adjust spice levels, include kid-friendly foods, and move at a comfortable pace.	Traveling with kids? Our family-friendly tours adjust spice levels, include kid-friendly foods, and move at a comfortable pace.\n\nChildren under 12 are 50% off. We know which vendors have high chairs, where the clean bathrooms are, and how to keep kids engaged.	285	MYR	3.5 hours	210	Kuala Lumpur	Pavilion KL, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.487+08	2026-04-03 11:26:47.487+08	published	2026-04-03 11:26:47.492+08	2026-04-03 11:26:47.492+08	t	f	\N
25	25	Family Food Tour around Penang	family-food-tour-around-penang	Penang's Best for Families	Penang is perfect for families! Simply Enak's tours are designed with kids in mind - kid-friendly foods, comfortable pace, and fun stories.	Penang is perfect for families! Our tours are designed with kids in mind - kid-friendly foods, comfortable pace, and fun stories.\n\nChildren under 12 are 50% off. We know the best family-friendly vendors.	285	MYR	3.5 hours	210	Penang	Gurney Drive, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.506+08	2026-04-03 11:26:47.506+08	published	2026-04-03 11:26:47.511+08	2026-04-03 11:26:47.511+08	t	f	\N
26	26	Couples Food Tour around Kuala Lumpur	couples-food-tour-around-kuala-lumpur	Perfect Date Night Experience	Looking for something better than dinner and a movie? Food tours are the ultimate couples experience.	Looking for something better than dinner and a movie? Food tours are the ultimate couples experience.\n\nYou're not just eating together - you're discovering together. Trying new things. Sharing reactions. Creating memories.	289	MYR	4 hours	240	Kuala Lumpur	Bukit Bintang, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.524+08	2026-04-03 11:26:47.524+08	published	2026-04-03 11:26:47.528+08	2026-04-03 11:26:47.528+08	t	f	\N
27	27	Couples Food Tour around Penang	couples-food-tour-around-penang	Georgetown Romance & Food	Georgetown is perfect for couples! Heritage streets, romantic settings, and amazing food.	Georgetown is perfect for couples! Heritage streets, romantic settings, and amazing food.\n\nWe'll guide you through atmospheric stops perfect for couples - sunset views, heritage shophouses, and shareable dishes.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.539+08	2026-04-03 11:26:47.539+08	published	2026-04-03 11:26:47.544+08	2026-04-03 11:26:47.544+08	t	f	\N
28	28	Foodie Tour around Kuala Lumpur	foodie-tour-around-kuala-lumpur	For Serious Food Lovers	You're not a tourist who eats. You're a traveler who eats strategically. This tour is for you.	You're not a tourist who eats. You're a traveler who eats strategically. You research restaurants before booking flights.\n\nWe go deeper: chef interviews, recipe discussions, technique demonstrations. This isn't a tour. It's a masterclass.	299	MYR	4 hours	240	Kuala Lumpur	Jalan Alor, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.557+08	2026-04-03 11:26:47.557+08	published	2026-04-03 11:26:47.562+08	2026-04-03 11:26:47.562+08	t	f	\N
29	29	Foodie Tour around Penang	foodie-tour-around-penang	Penang's Best for Food Lovers	Penang is the food capital of Malaysia - and this tour is for serious food lovers.	Penang is the food capital of Malaysia - and this tour is for serious food lovers.\n\nWe'll take you beyond the tourist spots to where serious foodies eat. Meet vendors who've been perfecting recipes for 40+ years.	299	MYR	4 hours	240	Penang	New Lane Hawker Centre, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.577+08	2026-04-03 11:26:47.577+08	published	2026-04-03 11:26:47.583+08	2026-04-03 11:26:47.583+08	t	f	\N
30	30	Best Food Tour in Chow Kit Market	food-tour-around-chow-kit-market	The Best Chow Kit Market Experience	Looking for the best food tour in Chow Kit? You've found it. Simply Enak has been guiding visitors through this historic market for 14 years. Discover exotic fruits, aromatic spices, and local delicacies with KL's best-rated market tour.	Discover Chow Kit Market, KL's largest wet market - a sprawling maze where locals have shopped for 100+ years. No souvenir shops. No tourist traps. Just real KL.\n\nWe'll guide you through the maze, introducing you to vendors who've been here for generations. Taste exotic fruits, aromatic spices, and local delicacies you've never seen.	289	MYR	3.5 hours	210	Kuala Lumpur	Chow Kit Market, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.595+08	2026-04-03 11:26:47.595+08	published	2026-04-03 11:26:47.599+08	2026-04-03 11:26:47.599+08	t	f	\N
31	31	Best Food Tour in Chinatown Petaling Street	food-tour-around-chinatown-petaling-street	The Best Chinatown KL Experience	Looking for the best food tour in Chinatown KL? You've found it. Simply Enak has been guiding visitors through Petaling Street for 14 years. Discover temples, historic lanes, and amazing food with KL's best-rated Chinatown tour.	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian culture and heritage.\n\nEvery dish and vendor has a story.	289	MYR	4 hours	240	Kuala Lumpur	Petaling Street, Chinatown, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.611+08	2026-04-03 11:26:47.61+08	published	2026-04-03 11:26:47.616+08	2026-04-03 11:26:47.616+08	t	f	\N
32	32	Best Food Tour in Brickfields Little India	food-tour-around-brickfields-little-india	The Best Little India KL Experience	Looking for the best food tour in Little India KL? You've found it. Simply Enak has been guiding visitors through Brickfields for 14 years. Discover authentic Indian vegetarian restaurants and banana leaf rice with KL's best-rated Little India tour.	Brickfields has one of Asia's strongest vegetarian scenes, thanks to 140 years of Indian vegetarian tradition.\n\nWe'll guide you through authentic Indian vegetarian restaurants, banana leaf rice houses, and modern Indian cafes. Every vendor is verified for dietary needs.	289	MYR	4 hours	240	Kuala Lumpur	Brickfields, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.628+08	2026-04-03 11:26:47.628+08	published	2026-04-03 11:26:47.632+08	2026-04-03 11:26:47.632+08	t	f	\N
33	33	Best Food Tour in Kampung Baru Malay Village	food-tour-around-kampung-baru-malay-village	The Best Malay Village Experience KL	Looking for the best food tour in Kampung Baru? You've found it. Simply Enak has been guiding visitors through this traditional Malay village for 14 years. Discover authentic Malay cuisine with KL's best-rated village tour.	Kampung Baru is a traditional Malay village in the heart of KL - a wooden house enclave surrounded by skyscrapers.\n\nWe'll guide you through authentic Malay cuisine, from nasi lemak to rendang, all prepared using traditional recipes passed down through generations.	289	MYR	4 hours	240	Kuala Lumpur	Kampung Baru, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.645+08	2026-04-03 11:26:47.645+08	published	2026-04-03 11:26:47.65+08	2026-04-03 11:26:47.65+08	t	f	\N
34	34	Best Food Tour in Chowrasta Market Penang	food-tour-around-chowrasta-market-penang	The Best Chowrasta Market Experience	Looking for the best food tour in Chowrasta Market? You've found it. Simply Enak has been guiding visitors through Penang's historic market for 14 years. Watch popiah being made, taste Asam Laksa, and discover why we're Penang's best-rated market tour.	What makes Penang the "food capital" of Malaysia? Start at Chowrasta Market, the heart of Penang food culture.\n\nWe'll dare you to try kopitiam "Ngor Ka Sai", signature nutmeg pickles and dodol. You'll watch a master handcraft popiah skin, and taste legendary Asam Laksa.	289	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.664+08	2026-04-03 11:26:47.664+08	published	2026-04-03 11:26:47.668+08	2026-04-03 11:26:47.668+08	t	f	\N
35	35	Best Food Tour in Georgetown Penang	food-tour-around-georgetown-heritage	The Best Georgetown Heritage Experience	Looking for the best food tour in Georgetown Penang? You've found it. Simply Enak has been guiding visitors through UNESCO Georgetown for 14 years. Discover Peranakan culture, temples, street art, and amazing food with Penang's best-rated heritage tour.	Explore Georgetown UNESCO heritage streets while tasting Peranakan culture through colourful kuey and legendary dishes.\n\nWe'll share Peranakan culture, explore temples and street art, and you'll leave with the history and culture behind Penang's most famous flavours.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.678+08	2026-04-03 11:26:47.678+08	published	2026-04-03 11:26:47.682+08	2026-04-03 11:26:47.682+08	t	f	\N
36	36	Best Food Tour in Gurney Drive Penang	food-tour-around-gurney-drive	The Best Gurney Drive Hawker Experience	Looking for the best food tour in Gurney Drive? You've found it. Simply Enak has been guiding visitors through Penang's famous hawker centre for 14 years. Taste sizzling satay, char kway teow, and waterfront dining with Penang's best-rated hawker tour.	Gurney Drive is Penang's most famous hawker centre - a waterfront food paradise.\n\nWe'll guide you through the best stalls, taste sizzling satay, char kway teow, and experience the vibrant hawker culture that makes Penang famous.	285	MYR	3.5 hours	210	Penang	Gurney Drive, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.694+08	2026-04-03 11:26:47.694+08	published	2026-04-03 11:26:47.698+08	2026-04-03 11:26:47.698+08	t	f	\N
37	37	Best Food Tour in Little India Penang	food-tour-around-little-india-lebuh-queen	The Best Little India Lebuh Queen Experience	Looking for the best food tour in Little India Penang? You've found it. Simply Enak has been guiding visitors through Lebuh Queen for 14 years. Discover authentic Indian restaurants, banana leaf rice, and spice shops with Penang's best-rated Little India tour.	Penang's Little India on Lebuh Queen is a sensory explosion of spices, textiles, and authentic Indian food.\n\nWe'll guide you through authentic Indian restaurants, banana leaf rice houses, and sweet shops. Every vendor is verified for dietary needs.	285	MYR	3.5 hours	210	Penang	Lebuh Queen, Little India, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.71+08	2026-04-03 11:26:47.71+08	published	2026-04-03 11:26:47.715+08	2026-04-03 11:26:47.715+08	t	f	\N
1	1	Flavours of Malaysia	flavours-of-malaysia	Off the Beaten Track	Brand new to Malaysia? This is everything you need to know! Simply Enak will guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian culture and heritage.	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. This tour is the perfect introduction to Malaysian culture and heritage.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)	289	MYR	4 hours	240	Kuala Lumpur	Hilton Garden Inn, Kuala Lumpur	9	2	t	All our tours start with a minimum of 2 reservations. Special rates for group bookings of 6+ people.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.005+08	2026-04-03 11:26:47.003+08	published	2026-04-03 11:26:47.018+08	2026-04-03 11:26:47.018+08	t	f	2
2	2	Eat Drink George Town	eat-drink-george-town	Georgetown's Greatest Hits	Hungry for Georgetown's greatest hits? Simply Enak's most-loved Penang tour starts as the sun sets and Georgetown comes alive. Three cultures' evening delights.	Hungry for Georgetown's greatest hits?\n\nOur most-loved Penang tour starts as the sun sets and Georgetown comes alive. We'll guide you through three cultures' evening delights: sizzling satay, the best samosas in Malaysia, and char kway teow fresh off the wok at Chew Jetty.\n\nYou'll watch roti jala being handcrafted like golden lace, hear the secret society tales and forbidden history that shaped these streets, then toast the evening with a Junglebird, Malaysia's own cocktail.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)	359	MYR	4 hours	240	Penang	Masjid Kapitan Keling, George Town, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.047+08	2026-04-03 11:26:47.046+08	published	2026-04-03 11:26:47.053+08	2026-04-03 11:26:47.053+08	t	f	3
3	3	Kuala Lumpur Street Food	kl-street-food	Chinatown Temples & Historic Lanes	Brand new to Malaysia? This is everything you need to know! Simply Enak will guide you through major temples and historic lanes in Chinatown with amazing food.	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian street food culture.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)\n\n---\n\n## Why Choose Our KL Food Tour?\n\n**14 Years in KL (Since 2011)**\nWe've known Aunty Lim since 2011. Uncle Tan since 2012. These aren't business partnerships — they're friendships built over 312+ tours.\n\n**Max 9 People, Always**\nNot "up to 15." Not "usually 12." Maximum 9 people, every tour. Because you can actually hear the stories.\n\n**We Don't Negotiate Vendor Prices**\nOther tours ask for discounts. We don't. Vendors tell us their prices — we pay them. Immediately, in cash, at the stall.\n\n**Dietary Experts**\nVegetarian, vegan, halal, gluten-free, Jain — we've accommodated every dietary need since 2011. We know which stalls use belacan, which use lard, which have allergen-free prep.\n\n---\n\n## Simply Enak vs. Other KL Food Tours\n\n| Feature | Simply Enak | A Chef's Tour | Viator/GetYourGuide Tours |\n|---------|-------------|---------------|---------------------------|\n| Group Size | Max 9 | Max 8 | 12-20 |\n| Price | RM 285 (RM 71/hr) | ~RM 260 (RM 65/hr) | RM 200-350 |\n| Vendor Relationships | 14 years (since 2011) | Varies by guide | Varies by operator |\n| Dietary Accommodation | All needs (14 years expertise) | Basic | Limited |\n| Booking | Direct, no platform fees | Direct or platform | Platform (20-25% commission) |\n| Cancellation | 48 hours free | 48 hours free | 24-72 hours (varies) |\n| Guide Type | Local founders (Pauline & Maarten) | Hired local hosts | Hired guides |\n| Vendor Payment | Cash, immediate, at stall | Unknown | 30-day terms (typical) |\n\n**Sources:** A Chef's Tour website (achefstour.com), Viator supplier terms (20-25% platform commission per Bokun.io 2026), industry standard payment terms.\n\n**The Bottom Line:** We're not the cheapest. We're not the biggest. But after 14 years, 2,847 guests, and a 5.0/5.0 rating — we're the most trusted.	285	MYR	3.5 hours	210	Kuala Lumpur	Tealive, Pasar Seni LRT Station	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.073+08	2026-04-03 11:26:47.073+08	published	2026-04-03 11:26:47.08+08	2026-04-03 11:26:47.08+08	t	f	4
4	4	Penang Street Food	penang-street-food	Food Capital of Malaysia	What makes Penang the "food capital" of Malaysia? Simply Enak will guide you through the cultural fusion that created dishes you'll only find here. At Chowrasta Market, we'll dare you to try kopitiam "Ngor Ka Sai".	What makes Penang the "food capital" of Malaysia?\n\nWe'll guide you through the cultural fusion that created dishes you'll only find here. At Chowrasta Market, we'll dare you to try kopitiam "Ngor Ka Sai", signature nutmeg pickles and dodol.\n\nYou'll watch a master handcraft popiah skin, and taste legendary Asam Laksa balancing sweet, sour and savoury. We'll share Peranakan culture through colourful kuey, explore temples and street art, and you'll leave with the history and culture behind Penang's most famous flavours.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)\n\n---\n\n## Why Choose Our Penang Food Tour?\n\n**14 Years in Penang (Since 2011)**\nWe've been guiding guests through Georgetown since 2011. We know which stalls have been family-run for 40+ years, which recipes haven't changed since your grandmother's kitchen, and which vendors will share stories you won't hear anywhere else.\n\n**Max 9 People, Always**\nNot "up to 15." Not "usually 12." Maximum 9 people, every tour. Because you can actually hear the vendor stories. Because you can ask questions. Because it feels like eating with friends.\n\n**Georgetown UNESCO Heritage**\nWe don't just show you food — we show you why Penang is a UNESCO World Heritage Site. The hawker culture, the kopitiam traditions, the Peranakan influence. You'll understand why Penang food is different from KL, different from Singapore, uniquely Penang.\n\n**Dietary Experts**\nVegetarian, vegan, halal, gluten-free — we've accommodated every dietary need since 2011. We know which stalls use belacan (shrimp paste), which use lard, which have dedicated vegetarian prep.\n\n---\n\n## Simply Enak vs. Other Penang Food Tours\n\n| Feature | Simply Enak | A Chef's Tour | Marriott/ByFood Private Tours |\n|---------|-------------|---------------|-------------------------------|\n| Group Size | Max 9 | Max 8 | Private (2-10 people) |\n| Price | RM 285 (RM 81/hr) | ~RM 215 (RM 54/hr) | RM 400-600 |\n| Vendor Relationships | 14 years (since 2011) | Varies by guide | Varies by operator |\n| Dietary Accommodation | All needs (14 years expertise) | Basic | Limited |\n| Booking | Direct, no platform fees | Direct or platform | Platform/Hotel |\n| Cancellation | 48 hours free | 48 hours free | 24-72 hours (varies) |\n| UNESCO Context | Heritage-focused guide | Food-focused | Food-focused |\n| Guide Type | Local founders (Pauline & Maarten) | Hired local hosts | Hotel-contracted guides |\n\n**Sources:** A Chef's Tour Penang (achefstour.com/penang), Marriott Eat Like A Local (activities.marriott.com), ByFood (byfood.com).\n\n**The Bottom Line:** We're not the cheapest. We're not the biggest. But after 14 years, 2,847 guests, and a 5.0/5.0 rating — we're the most trusted.	285	MYR	3.5 hours	210	Penang	St. George's Church, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.099+08	2026-04-03 11:26:47.099+08	published	2026-04-03 11:26:47.105+08	2026-04-03 11:26:47.105+08	t	f	5
\.


--
-- Data for Name: _tours_v_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._tours_v_rels (id, "order", parent_id, path, dietary_options_id, travel_type_landing_pages_id, specialty_landing_pages_id, food_items_id) FROM stdin;
\.


--
-- Data for Name: _tours_v_version_gallery_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._tours_v_version_gallery_images (_order, _parent_id, id, _uuid, image_id) FROM stdin;
1	5	24	69cf3377d670e2eb5542832c	\N
2	5	25	69cf3377d670e2eb5542832d	\N
3	5	26	69cf3377d670e2eb5542832e	\N
4	5	27	69cf3377d670e2eb5542832f	\N
1	1	1	69cf3376d670e2eb55428301	6
2	1	2	69cf3376d670e2eb55428302	7
3	1	3	69cf3376d670e2eb55428303	8
4	1	4	69cf3376d670e2eb55428304	9
5	1	5	69cf3376d670e2eb55428305	10
1	2	6	69cf3377d670e2eb5542830b	11
2	2	7	69cf3377d670e2eb5542830c	12
3	2	8	69cf3377d670e2eb5542830d	13
4	2	9	69cf3377d670e2eb5542830e	14
5	2	10	69cf3377d670e2eb5542830f	15
6	2	11	69cf3377d670e2eb55428310	16
7	2	12	69cf3377d670e2eb55428311	17
1	3	13	69cf3377d670e2eb55428317	18
2	3	14	69cf3377d670e2eb55428318	19
3	3	15	69cf3377d670e2eb55428319	7
4	3	16	69cf3377d670e2eb5542831a	20
5	3	17	69cf3377d670e2eb5542831b	21
1	4	18	69cf3377d670e2eb55428321	22
2	4	19	69cf3377d670e2eb55428322	23
3	4	20	69cf3377d670e2eb55428323	12
4	4	21	69cf3377d670e2eb55428324	13
5	4	22	69cf3377d670e2eb55428325	10
6	4	23	69cf3377d670e2eb55428326	20
5	5	28	69cf3377d670e2eb55428330	20
\.


--
-- Data for Name: _tours_v_version_highlights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._tours_v_version_highlights (_order, _parent_id, id, highlight, _uuid) FROM stdin;
1	1	1	Major temples in Chinatown	69cf3376d670e2eb55428306
2	1	2	Historic lanes with stories	69cf3376d670e2eb55428307
3	1	3	8-10 authentic Malaysian dishes	69cf3376d670e2eb55428308
4	1	4	Cultural fusion understanding	69cf3376d670e2eb55428309
5	1	5	Small group experience (max 9)	69cf3376d670e2eb5542830a
1	2	6	Sizzling satay and best samosas in Malaysia	69cf3377d670e2eb55428312
2	2	7	Char kway teow fresh off the wok at Chew Jetty	69cf3377d670e2eb55428313
3	2	8	Roti jala handcrafted like golden lace	69cf3377d670e2eb55428314
4	2	9	Secret society tales and forbidden history	69cf3377d670e2eb55428315
5	2	10	Junglebird cocktail toast to the evening	69cf3377d670e2eb55428316
1	3	11	Major temples in Chinatown	69cf3377d670e2eb5542831c
2	3	12	Historic lanes with amazing food	69cf3377d670e2eb5542831d
3	3	13	8-10 authentic Malaysian dishes	69cf3377d670e2eb5542831e
4	3	14	Perfect introduction to Malaysian culture	69cf3377d670e2eb5542831f
5	3	15	Small group experience (max 9)	69cf3377d670e2eb55428320
1	4	16	Kopitiam "Ngor Ka Sai" - signature nutmeg pickles	69cf3377d670e2eb55428327
2	4	17	Watch master handcraft popiah skin	69cf3377d670e2eb55428328
3	4	18	Legendary Asam Laksa - sweet, sour, savoury	69cf3377d670e2eb55428329
4	4	19	Peranakan culture through colourful kuey	69cf3377d670e2eb5542832a
5	4	20	Chowrasta Market with exotic fruits and spices	69cf3377d670e2eb5542832b
1	5	21	Hidden speakeasy bars locals love	69cf3377d670e2eb55428331
2	5	22	Classic Malaysian late-night street food	69cf3377d670e2eb55428332
3	5	23	Forbidden tales of the red-light district	69cf3377d670e2eb55428333
4	5	24	KL's vibrant street art at night	69cf3377d670e2eb55428334
5	5	25	4-5 signature craft cocktails included	69cf3377d670e2eb55428335
1	6	26	Brickfields Little India - 47 vegetarian restaurants per km²	69cf3377d670e2eb55428336
2	6	27	Buddhist vegetarian restaurants with mock meats	69cf3377d670e2eb55428337
3	6	28	Modern vegan cafes in Bangsar	69cf3377d670e2eb55428338
4	6	29	100% plant-based vendors (no fish sauce, no shrimp paste)	69cf3377d670e2eb55428339
5	6	30	Small group experience (max 9)	69cf3377d670e2eb5542833a
1	7	31	Vegetarian char kway teow (yes, it exists!)	69cf3377d670e2eb5542833b
2	7	32	Vegetarian laksa without fish sauce	69cf3377d670e2eb5542833c
3	7	33	Colorful Nyonya kuey (plant-based)	69cf3377d670e2eb5542833d
4	7	34	Chowrasta Market vegetarian section	69cf3377d670e2eb5542833e
5	7	35	Buddhist vegetarian restaurants	69cf3377d670e2eb5542833f
1	8	36	Kampung Baru - traditional Malay village in city center	69cf3377d670e2eb55428340
2	8	37	Indian Muslim roti canai and murtabak	69cf3377d670e2eb55428341
3	8	38	Halal-certified vendors only	69cf3377d670e2eb55428342
4	8	39	No pork, no alcohol, no cross-contamination	69cf3377d670e2eb55428343
5	8	40	Small group experience (max 9)	69cf3377d670e2eb55428344
1	9	41	Halal char kway teow	69cf3377d670e2eb55428345
2	9	42	Legendary nasi kandar	69cf3377d670e2eb55428346
3	9	43	Indian Muslim specialties	69cf3377d670e2eb55428347
4	9	44	Halal-certified vendors only	69cf3377d670e2eb55428348
5	9	45	Small group experience (max 9)	69cf3377d670e2eb55428349
1	10	46	Naturally GF Malaysian dishes	69cf3377d670e2eb5542834a
2	10	47	Wheat-free soy sauce vendors	69cf3377d670e2eb5542834b
3	10	48	No cross-contamination stops	69cf3377d670e2eb5542834c
4	10	49	Celiac-aware guide	69cf3377d670e2eb5542834d
5	10	50	Small group experience (max 9)	69cf3377d670e2eb5542834e
1	11	51	Naturally GF Penang dishes	69cf3377d670e2eb5542834f
2	11	52	Rice noodle dishes (verified)	69cf3377d670e2eb55428350
3	11	53	Grilled seafood (naturally GF)	69cf3377d670e2eb55428351
4	11	54	Dedicated GF utensils	69cf3377d670e2eb55428352
5	11	55	Small group experience (max 9)	69cf3377d670e2eb55428353
1	12	56	Modern vegan cafes in Bangsar	69cf3377d670e2eb55428354
2	12	57	Traditional Indian vegan curry	69cf3377d670e2eb55428355
3	12	58	Buddhist vegetarian mock meats	69cf3377d670e2eb55428356
4	12	59	100% plant-based vendors	69cf3377d670e2eb55428357
5	12	60	Small group experience (max 9)	69cf3377d670e2eb55428358
1	13	61	Vegan char kway teow	69cf3377d670e2eb55428359
2	13	62	Vegan laksa without fish sauce	69cf3377d670e2eb5542835a
3	13	63	Nyonya vegan kuey	69cf3377d670e2eb5542835b
4	13	64	Buddhist vegetarian restaurants	69cf3377d670e2eb5542835c
5	13	65	Small group experience (max 9)	69cf3377d670e2eb5542835d
1	14	66	Separate Jain kitchens	69cf3377d670e2eb5542835e
2	14	67	No root vegetables (onion, garlic, potato)	69cf3377d670e2eb5542835f
3	14	68	Pure ahimsa cuisine	69cf3377d670e2eb55428360
4	14	69	No cross-contamination	69cf3377d670e2eb55428361
5	14	70	Small group experience (max 9)	69cf3377d670e2eb55428362
1	15	71	Jain thali without root vegetables	69cf3377d670e2eb55428363
2	15	72	Dal without onion/garlic	69cf3377d670e2eb55428364
3	15	73	Separate Jain preparation	69cf3377d670e2eb55428365
4	15	74	Understanding vendors	69cf3377d670e2eb55428366
5	15	75	Small group experience (max 9)	69cf3377d670e2eb55428367
1	16	76	Local hawker centres (not tourist traps)	69cf3377d670e2eb55428368
2	16	77	Roadside stalls with 40+ year history	69cf3377d670e2eb55428369
3	16	78	Best char kway teow in KL	69cf3377d670e2eb5542836a
4	16	79	Hidden alleys and local favorites	69cf3377d670e2eb5542836b
5	16	80	Small group experience (max 9)	69cf3377d670e2eb5542836c
1	17	81	Chowrasta Market with exotic spices	69cf3377d670e2eb5542836d
2	17	82	Watch master handcraft popiah skin	69cf3377d670e2eb5542836e
3	17	83	Legendary Asam Laksa	69cf3377d670e2eb5542836f
4	17	84	Kopitiam "Ngor Ka Sai" (dare to try!)	69cf3377d670e2eb55428370
5	17	85	Small group experience (max 9)	69cf3377d670e2eb55428371
1	18	86	Chow Kit Market - KL's largest wet market	69cf3377d670e2eb55428372
2	18	87	Exotic tropical fruits	69cf3377d670e2eb55428373
3	18	88	Aromatic spices and herbs	69cf3377d670e2eb55428374
4	18	89	Local butchers and fishmongers	69cf3377d670e2eb55428375
5	18	90	Small group experience (max 9)	69cf3377d670e2eb55428376
1	19	91	Chowrasta Market historic tour	69cf3377d670e2eb55428377
2	19	92	Watch popiah being handcrafted	69cf3377d670e2eb55428378
3	19	93	Signature nutmeg pickles	69cf3377d670e2eb55428379
4	19	94	Exotic spices and herbs	69cf3377d670e2eb5542837a
5	19	95	Small group experience (max 9)	69cf3377d670e2eb5542837b
1	20	96	Major Chinatown temples	69cf3377d670e2eb5542837c
2	20	97	Historic lanes with stories	69cf3377d670e2eb5542837d
3	20	98	8-10 authentic Malaysian dishes	69cf3377d670e2eb5542837e
4	20	99	Perfect introduction to Malaysian culture	69cf3377d670e2eb5542837f
5	20	100	Small group experience (max 9)	69cf3377d670e2eb55428380
1	21	101	Georgetown UNESCO heritage streets	69cf3377d670e2eb55428381
2	21	102	Peranakan culture through colourful kuey	69cf3377d670e2eb55428382
3	21	103	Temples and street art	69cf3377d670e2eb55428383
4	21	104	History behind Penang's flavours	69cf3377d670e2eb55428384
5	21	105	Small group experience (max 9)	69cf3377d670e2eb55428385
1	22	106	Hidden speakeasy bars locals love	69cf3377d670e2eb55428386
2	22	107	Classic Malaysian late-night food	69cf3377d670e2eb55428387
3	22	108	Forbidden tales of red-light district	69cf3377d670e2eb55428388
4	22	109	Street art at night	69cf3377d670e2eb55428389
5	22	110	4-5 signature cocktails included	69cf3377d670e2eb5542838a
1	23	111	Night hawker centres	69cf3377d670e2eb5542838b
2	23	112	Sizzling satay	69cf3377d670e2eb5542838c
3	23	113	Georgetown after dark	69cf3377d670e2eb5542838d
4	23	114	Local nightlife	69cf3377d670e2eb5542838e
5	23	115	Small group experience (max 9)	69cf3377d670e2eb5542838f
1	24	116	Kid-friendly foods included	69cf3377d670e2eb55428390
2	24	117	Spice levels adjusted for kids	69cf3377d670e2eb55428391
3	24	118	Clean bathroom stops	69cf3377d670e2eb55428392
4	24	119	Engaging stories for children	69cf3377d670e2eb55428393
5	24	120	Children under 12: 50% off	69cf3377d670e2eb55428394
1	25	121	Kid-friendly Penang foods	69cf3377d670e2eb55428395
2	25	122	Comfortable pace for families	69cf3377d670e2eb55428396
3	25	123	Fun stories for children	69cf3377d670e2eb55428397
4	25	124	Family-friendly vendors	69cf3377d670e2eb55428398
5	25	125	Children under 12: 50% off	69cf3377d670e2eb55428399
1	26	126	Romantic atmospheric stops	69cf3377d670e2eb5542839a
2	26	127	Shareable dishes	69cf3377d670e2eb5542839b
3	26	128	Photo opportunities	69cf3377d670e2eb5542839c
4	26	129	Conversation starters	69cf3377d670e2eb5542839d
5	26	130	Small group experience (max 9)	69cf3377d670e2eb5542839e
1	27	131	Georgetown heritage streets	69cf3377d670e2eb5542839f
2	27	132	Romantic atmospheric stops	69cf3377d670e2eb554283a0
3	27	133	Sunset views	69cf3377d670e2eb554283a1
4	27	134	Shareable dishes	69cf3377d670e2eb554283a2
5	27	135	Small group experience (max 9)	69cf3377d670e2eb554283a3
1	28	136	Chef and vendor interviews	69cf3377d670e2eb554283a4
2	28	137	Recipe discussions	69cf3377d670e2eb554283a5
3	28	138	Technique demonstrations	69cf3377d670e2eb554283a6
4	28	139	Deep culinary knowledge	69cf3377d670e2eb554283a7
5	28	140	Small group experience (max 9)	69cf3377d670e2eb554283a8
1	29	141	Master vendors with 40+ year recipes	69cf3377d670e2eb554283a9
2	29	142	Beyond tourist spots	69cf3377d670e2eb554283aa
3	29	143	Deep culinary knowledge	69cf3377d670e2eb554283ab
4	29	144	Food capital of Malaysia	69cf3377d670e2eb554283ac
5	29	145	Small group experience (max 9)	69cf3377d670e2eb554283ad
1	30	146	The best Chow Kit Market experience in KL	69cf3377d670e2eb554283ae
2	30	147	14 years of vendor relationships	69cf3377d670e2eb554283af
3	30	148	Exotic tropical fruits you've never seen	69cf3377d670e2eb554283b0
4	30	149	Aromatic spices and herbs	69cf3377d670e2eb554283b1
5	30	150	Local butchers and fishmongers	69cf3377d670e2eb554283b2
6	30	151	Small group experience (max 9)	69cf3377d670e2eb554283b3
1	31	152	The best Chinatown KL experience	69cf3377d670e2eb554283b4
2	31	153	Major Chinatown temples	69cf3377d670e2eb554283b5
3	31	154	Historic lanes with stories	69cf3377d670e2eb554283b6
4	31	155	8-10 authentic Malaysian dishes	69cf3377d670e2eb554283b7
5	31	156	Perfect introduction to Malaysian culture	69cf3377d670e2eb554283b8
6	31	157	Small group experience (max 9)	69cf3377d670e2eb554283b9
1	32	158	The best Little India KL experience	69cf3377d670e2eb554283ba
2	32	159	Brickfields Little India	69cf3377d670e2eb554283bb
3	32	160	Authentic Indian vegetarian restaurants	69cf3377d670e2eb554283bc
4	32	161	Banana leaf rice houses	69cf3377d670e2eb554283bd
5	32	162	140 years of Indian tradition	69cf3377d670e2eb554283be
6	32	163	Small group experience (max 9)	69cf3377d670e2eb554283bf
1	33	164	The best Kampung Baru experience	69cf3377d670e2eb554283c0
2	33	165	Kampung Baru - traditional Malay village	69cf3377d670e2eb554283c1
3	33	166	Authentic Malay cuisine	69cf3377d670e2eb554283c2
4	33	167	Traditional recipes	69cf3377d670e2eb554283c3
5	33	168	Wooden houses surrounded by skyscrapers	69cf3377d670e2eb554283c4
6	33	169	Small group experience (max 9)	69cf3377d670e2eb554283c5
1	34	170	The best Chowrasta Market experience in Penang	69cf3377d670e2eb554283c6
2	34	171	Watch master handcraft popiah skin	69cf3377d670e2eb554283c7
3	34	172	Legendary Asam Laksa	69cf3377d670e2eb554283c8
4	34	173	Kopitiam "Ngor Ka Sai" (dare to try!)	69cf3377d670e2eb554283c9
5	34	174	Penang's historic market	69cf3377d670e2eb554283ca
6	34	175	Small group experience (max 9)	69cf3377d670e2eb554283cb
1	35	176	The best Georgetown heritage experience	69cf3377d670e2eb554283cc
2	35	177	Georgetown UNESCO heritage streets	69cf3377d670e2eb554283cd
3	35	178	Peranakan culture through colourful kuey	69cf3377d670e2eb554283ce
4	35	179	Temples and street art	69cf3377d670e2eb554283cf
5	35	180	History behind Penang's flavours	69cf3377d670e2eb554283d0
6	35	181	Small group experience (max 9)	69cf3377d670e2eb554283d1
1	36	182	The best Gurney Drive hawker experience	69cf3377d670e2eb554283d2
2	36	183	Gurney Drive - Penang's famous hawker centre	69cf3377d670e2eb554283d3
3	36	184	Waterfront dining experience	69cf3377d670e2eb554283d4
4	36	185	Sizzling satay and char kway teow	69cf3377d670e2eb554283d5
5	36	186	Vibrant hawker culture	69cf3377d670e2eb554283d6
6	36	187	Small group experience (max 9)	69cf3377d670e2eb554283d7
1	37	188	The best Little India Penang experience	69cf3377d670e2eb554283d8
2	37	189	Lebuh Queen Little India	69cf3377d670e2eb554283d9
3	37	190	Authentic Indian restaurants	69cf3377d670e2eb554283da
4	37	191	Banana leaf rice houses	69cf3377d670e2eb554283db
5	37	192	Spice and textile shops	69cf3377d670e2eb554283dc
6	37	193	Small group experience (max 9)	69cf3377d670e2eb554283dd
\.


--
-- Data for Name: _tours_v_version_whats_excluded; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._tours_v_version_whats_excluded (_order, _parent_id, id, item, _uuid) FROM stdin;
\.


--
-- Data for Name: _tours_v_version_whats_included; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._tours_v_version_whats_included (_order, _parent_id, id, item, _uuid) FROM stdin;
\.


--
-- Data for Name: _track_record_page_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._track_record_page_v (id, parent_id, version, version_label, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _vendors_v; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v (id, parent_id, version_name, version_slug, version_type, version_description, version_history, version_year_established, version_generation, version_owner_name, version_cuisine_type, version_location_address, version_location_city, version_location_state, version_location_postcode, version_location_country, version_location_latitude, version_location_longitude, version_location_landmark, version_contact_phone, version_contact_whatsapp, version_contact_email, version_contact_website, version_contact_facebook, version_contact_instagram, version_price_range, version_images_main_id, version_story, version_media_features, version_tips, version_status, version_featured, version_scheduled_publish, version_published_at, version_updated_at, version_created_at, version__status, created_at, updated_at, latest, autosave) FROM stdin;
\.


--
-- Data for Name: _vendors_v_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v_rels (id, "order", parent_id, path, food_items_id, dietary_options_id) FROM stdin;
\.


--
-- Data for Name: _vendors_v_version_awards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v_version_awards (_order, _parent_id, id, award, year, organization, _uuid) FROM stdin;
\.


--
-- Data for Name: _vendors_v_version_closed_on; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v_version_closed_on (_order, _parent_id, id, day, _uuid) FROM stdin;
\.


--
-- Data for Name: _vendors_v_version_facilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v_version_facilities (_order, _parent_id, id, facility, _uuid) FROM stdin;
\.


--
-- Data for Name: _vendors_v_version_images_gallery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v_version_images_gallery (_order, _parent_id, id, image_id, _uuid) FROM stdin;
\.


--
-- Data for Name: _vendors_v_version_operating_hours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v_version_operating_hours (_order, _parent_id, id, day, open_time, close_time, is_closed, notes, _uuid) FROM stdin;
\.


--
-- Data for Name: _vendors_v_version_payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._vendors_v_version_payment_methods (_order, _parent_id, id, method, _uuid) FROM stdin;
\.


--
-- Data for Name: about_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page (id, seo_title, seo_description, parent_id, updated_at, created_at, _locales) FROM stdin;
1	About Simply Enak | Malaysian Food Tours With Heart	Simply Enak has been sharing Malaysian food heritage since 2011. Meet the team, read our story, and see 15 years of press features — from National Geographic to BBC and The Food Ranger.	\N	2026-04-03 11:19:30.492+08	2026-04-03 11:19:30.463+08	\N
\.


--
-- Data for Name: about_page_blocks_founder_story_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_founder_story_block (id, _parent_id, _order, _path, block_name, title, content) FROM stdin;
1	1	0	founderStorySection	founderStoryBlock	Meet Pauline, Our Founder	"<p>Growing up in Malaysia, I spent countless mornings walking through wet markets with my mom. While she haggled for the freshest fish and picked out vegetables, I watched the hawkers craft dishes that had been passed down through generations. The sizzle of char kway teow on a screaming hot wok, the aromatic clouds of curry rising from street stalls, the careful art of folding roti canai. This was my Malaysia.</p><p>When I started bringing friends from other countries around, I realised they were missing this entire world. They'd eat at air-conditioned restaurants with picture menus, never knowing that just two streets away, a grandmother was making laksa the same way her mother taught her 60 years ago.</p><p>Simply Enak started in 2011 because I wanted to share what I experienced as a child. Not the Malaysia you see in guidebooks, but the one I know: the night markets, the family recipes, the vendors who remember your face and your favourite dish. The real Malaysia that tourists walk past every day.</p>"
\.


--
-- Data for Name: about_page_blocks_hero_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_hero_block (id, _parent_id, _order, _path, block_name, title, subtitle) FROM stdin;
1	1	0	heroSection	heroBlock	Our Story	Born in Malaysia. Raised on street food. Sharing the Malaysia we grew up with, one meal at a time.
\.


--
-- Data for Name: about_page_blocks_philosophy_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_philosophy_block (id, _parent_id, _order, _path, block_name, content) FROM stdin;
1	1	0	philosophySection	philosophyBlock	[{"title":"Unscripted & Human","description":"We don't do canned jokes or rehearsed speeches. Our guides are licensed professionals, but they talk to you like friends: sharing real stories, not scripts.","icon":"icon-hands-join"},{"title":"Slow Travel","description":"We walk. We pause. We take the time to appreciate the details: the architecture, the smells, the sounds of the neighbourhood.","icon":"icon-compass"},{"title":"Support Local","description":"We exclusively visit family-run businesses. Your tour fee directly supports the heritage keepers of our food culture.","icon":"icon-heart"}]
\.


--
-- Data for Name: about_page_blocks_stats_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_stats_block (id, _parent_id, _order, _path, block_name) FROM stdin;
1	1	0	statsSection	statsBlock
\.


--
-- Data for Name: about_page_blocks_stats_block_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_stats_block_stats (id, _parent_id, _order, _path, number, label) FROM stdin;
1	1	0	stats	5,000+	Happy Guests
2	1	1	stats	4.9/5	TripAdvisor Rating
3	1	2	stats	15 Years	Experience
4	1	3	stats	Max 9	Group Size
\.


--
-- Data for Name: about_page_blocks_team_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_team_block (id, _parent_id, _order, _path, block_name) FROM stdin;
1	1	0	teamSection	teamBlock
\.


--
-- Data for Name: about_page_blocks_team_block_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_team_block_members (id, _parent_id, _order, _path, name, role, specialty, description, photo) FROM stdin;
1	1	0	members	Pauline	Founder & Lead Guide	15 Years Building Relationships	Started Simply Enak in 2011 after watching too many tourists miss the real Malaysia. Grew up walking wet markets with her mom, learning which vendors had the freshest fish and the ones worth talking to. Now brings that childhood wonder to every tour.	\N
2	1	1	members	Danny	Licensed Guide	Tourism Malaysia Certified	Licensed guide with deep knowledge of Malaysian food heritage and culture. Passionate about sharing the stories behind every dish and connecting travellers with local communities.	\N
3	1	2	members	Wei Shen	Licensed Guide	Tourism Malaysia Certified	Licensed guide specialising in the cultural history of Malaysian cuisine. Expertly navigates the blend of Malay, Chinese, and Indian influences that define Malaysian food culture.	\N
4	1	3	members	Ronald	Licensed Guide	Tourism Malaysia Certified	Licensed guide with extensive knowledge of local neighbourhoods and vendor relationships. Brings energy and real storytelling to every tour.	\N
5	1	4	members	Maarten	Partner	Operations & Growth	Manages operations and business development, ensuring every aspect of Simply Enak stays true to the same standard: stalls we'd take our own families to.	\N
\.


--
-- Data for Name: about_page_blocks_timeline_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_timeline_block (id, _parent_id, _order, _path, block_name) FROM stdin;
1	1	0	timelineSection	timelineBlock
\.


--
-- Data for Name: about_page_blocks_timeline_block_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_blocks_timeline_block_events (id, _parent_id, _order, _path, year, title, description) FROM stdin;
1	1	0	events	2011	Simply Enak Founded	Pauline leads her first food walk through Chow Kit market with a small group of friends. Nobody calls it a tour yet — it's just lunch.
2	1	1	events	2012	Lonely Planet	A Lonely Planet researcher joins one of our Petaling Street tours — incognito, as they always are. Simply Enak makes it into the guidebook, one of the most-read travel references in the world.
3	1	2	events	2013	Le Guide du Routard	France's most-read travel guide lists Simply Enak among Malaysia's top food experiences — our first major international press recognition.
4	1	3	events	2014	KL Food Trails — City Hall & Time Out KL	Partnered with Kuala Lumpur City Hall's Tourism Unit and Time Out KL to map four neighbourhoods that locals eat in every day: Jalan Alor, Kampung Baru, Old KL, and Pudu. The KL Food Trails became a printed map guiding visitors to the stalls and kopitiam that anchor each area — our first step beyond tour guiding into shaping how KL presents its food culture.
5	1	4	events	2015	National Geographic: Confucius Was a Foodie	NatGeo's “Confucius Was a Foodie” series films Season 3 with Pauline guiding the crew through Kuala Lumpur's Chinese culinary heritage. Our vendor relationships open doors cameras usually don't get through.
6	1	5	events	2016	TLC: Taste Off with Chef Aaron Craze	British chef Aaron Craze brings TLC's “Taste Off” to KL. Pauline takes the crew through the hawker stalls and morning markets that make Malaysian food what it is.
7	1	6	events	2017	TVNZ: Karena & Kasey’s Foreign Flavours	Karena and Kasey Bird bring their TVNZ cooking series to Penang — Simply Enak shows them the Georgetown food scene that locals eat at every day.
8	1	7	events	2016	Time Out Penang	Time Out names Simply Enak one of Penang's essential experiences, putting us on the map for food travellers heading north to Georgetown.
9	1	8	events	2016	BBC Sport	A BBC Sport team joins our Penang food trail and films the legendary Tiger Char Kway Teow vendor.
10	1	9	events	2018	Getaway, Channel Nine Australia	Australian travel show Getaway flies host David Reyne to KL. Pauline takes the crew through Chow Kit wet market and Jalan Alor — the segment airs November 2018 to audiences across Australia.
11	1	10	events	2018–2019	The Food Ranger — 3 Videos	Trevor James (The Food Ranger, 6M+ subscribers) films three videos with our team across KL's hawker stalls. Together they've reached millions of views.
12	1	11	events	2019–2020	The Edge TV: Exploring History Through Food	Malaysian business news channel The Edge TV profiles Simply Enak — Pauline takes the crew through the food stalls that tell KL's history.
13	1	12	events	2020	COVID: We Stay	Borders close but we don't disappear. We keep buying from our vendors, keep the relationships alive, and start running virtual food walks — ready for the day travel opens again.
14	1	13	events	2024	Destination Eat Drink Podcast	Pauline joins the Destination Eat Drink podcast to talk about Penang's food culture — Nyonya cooking, nasi kandar, and why Georgetown stays special.
15	1	14	events	Today	5,000+ guests and still eating	Every week, guests from 50+ countries join us at the same stalls we've eaten at for 15 years. The guides know the vendors by name. The vendors know us.
\.


--
-- Data for Name: about_page_breadcrumbs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.about_page_breadcrumbs (_order, _parent_id, id, doc_id, url, label) FROM stdin;
1	1	69cf31c2d4eaf6aa44ea7d1c	1	\N	1
\.


--
-- Data for Name: contact_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_page (id, seo_title, seo_description, hero_title, hero_subtitle, intro_title, intro_subtitle, contact_email, contact_phone, whatsapp_number, contact_hours, social_facebook, social_instagram, faq_content, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
1	Contact Simply Enak | Book Your Food Tour	Get in touch with Simply Enak for tour bookings, questions, or custom requests. We reply within 3 hours.	Tell Us What You're Looking For	Whether you're booking a tour or just curious — we read every message and reply within 3 hours.	How Can We Help?	Choose your reason for reaching out	booking@simplyenak.com	+60 17-287 8929	+60 17-287 8929	Mon – Sun: 9:00 – 20:00	\N	\N	\N	2026-04-03 23:18:04.783+08	2026-04-03 23:18:04.783+08	draft	\N	1	f
\.


--
-- Data for Name: contact_page_breadcrumbs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_page_breadcrumbs (_order, _parent_id, id, doc_id, url, label) FROM stdin;
1	1	69cf31c2d4eaf6aa44ea7d1d	1	\N	1
\.


--
-- Data for Name: corporate_groups_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.corporate_groups_page (id, seo_title, seo_description, hero_eyebrow, hero_title, hero_subtitle, offer_eyebrow, offer_heading, offer_body_1, offer_body_2, benefits_eyebrow, benefits_title, kl_section_eyebrow, kl_section_heading, kl_section_subtext, penang_section_eyebrow, penang_section_heading, penang_section_subtext, how_eyebrow, how_heading, cta_heading, cta_body, cta_email_label, cta_whatsapp_label, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
1	Corporate & Group Food Tours KL & Penang | Simply Enak	Hosting colleagues in KL or Penang? We take work groups to the stalls locals eat at.	For Work Groups & Teams	Corporate & Group Tours	Hosting colleagues in KL or Penang? We take work groups and corporate visitors to the stalls locals eat at.	What We Offer	Not Your Typical Team Building	We don't do scripted team building. Instead, we take you somewhere real: a morning at the hawker stalls that bring people together through food they didn't expect to love.	Our food tours are naturally team-building. You'll walk together, taste together, laugh together. No forced activities, no awkward icebreakers — just good food and the kind of conversations that happen when everyone's eating from the same plate.	Why Choose Us	Group Benefits	Kuala Lumpur	Tours for KL Groups	Perfect for work groups visiting Kuala Lumpur.	Penang	Tours for Penang Groups	Perfect for work groups visiting Penang.	Easy Process	How Group Bookings Work	Ready to Book Your Group Tour?	Contact us to discuss your group's needs. We'll help you choose the perfect tours and arrange everything.	Email Us	WhatsApp	2026-04-03 23:14:17.34+08	2026-04-03 23:14:17.34+08	draft	\N	1	f
\.


--
-- Data for Name: corporate_groups_page_benefit_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.corporate_groups_page_benefit_cards (id, _parent_id, _order, _path, icon, title, description) FROM stdin;
\.


--
-- Data for Name: corporate_groups_page_how_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.corporate_groups_page_how_steps (id, _parent_id, _order, _path, number, title, description) FROM stdin;
1	1	0	howSteps	\N	Contact Us	\N
2	1	1	howSteps	\N	We'll Recommend Tours	\N
3	1	2	howSteps	\N	Confirm & Pay	\N
4	1	3	howSteps	\N	Enjoy the Experience	\N
\.


--
-- Data for Name: corporate_groups_page_offer_perfect_for; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.corporate_groups_page_offer_perfect_for (id, _parent_id, _order, _path, item) FROM stdin;
1	1	0	offerPerfectFor	Work colleagues visiting KL or Penang at the same time
2	1	1	offerPerfectFor	Corporate groups who want to eat where locals eat, not where tourists are sent
3	1	2	offerPerfectFor	Teams wanting an active, engaging activity
4	1	3	offerPerfectFor	International visitors wanting to understand Malaysian culture
5	1	4	offerPerfectFor	Remote teams meeting up for retreats
\.


--
-- Data for Name: dietary_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dietary_options (id, name, slug, icon, color, description, status, scheduled_publish, published_at, updated_at, created_at, _status) FROM stdin;
1	Vegetarian	vegetarian	🥬	#22c55e	No meat, poultry, or fish. May include dairy and eggs depending on the type.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
2	Vegan	vegan	🌱	#16a34a	No animal products whatsoever — no meat, dairy, eggs, honey, or gelatin.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
3	Halal	halal	☪️	#0ea5e9	Prepared according to Islamic dietary law. No pork, no alcohol, meat from certified sources.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
4	Gluten-Free	gluten-free	🌾	#f59e0b	No wheat, barley, rye, or other gluten-containing ingredients.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
5	Dairy-Free	dairy-free	🥛	#8b5cf6	No milk, cheese, butter, cream, or other dairy products.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
6	Nut-Free	nut-free	🥜	#ef4444	No peanuts, tree nuts, or nut-derived ingredients. Important for allergy safety.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
7	Pescatarian	pescatarian	🐟	#06b6d4	No meat or poultry, but fish and seafood are allowed.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
9	Egg-Free	egg-free	🥚	#f97316	No eggs or egg-derived ingredients.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
10	Low-Sodium	low-sodium	🧂	#64748b	Reduced salt content. Suitable for those monitoring sodium intake.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
11	Spicy	spicy	🌶️	#dc2626	Contains chili or hot spices. Can be adjusted for heat tolerance.	published	\N	\N	2026-04-03 13:37:54.003+08	2026-04-03 13:37:54.003+08	published
13	No MSG	no-msg	🚫	#6366f1	No monosodium glutamate added. Important for those sensitive to MSG.	published	\N	\N	2026-04-03 13:48:17.89+08	2026-04-03 13:48:17.89+08	published
15	Kosher	kosher	✡️	#3b82f6	Prepared according to Jewish dietary law. No pork, no shellfish, no mixing meat and dairy.	published	\N	\N	2026-04-03 15:10:40.621+08	2026-04-03 15:10:40.621+08	published
\.


--
-- Data for Name: directions_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.directions_page (id, seo_title, seo_description, hero_title, hero_description, hero_image, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
1	Meeting Points & Directions | Simply Enak Food Tours	Find your Simply Enak meeting point. Step-by-step directions to the start of each food tour in Kuala Lumpur and Penang — by train, taxi, or Grab.	Here's how to find us	Step-by-step directions to every Simply Enak meeting point. Arrive confident — your guide will be waiting.	https://se-website-images.s3.nl-ams.scw.cloud/kuala_lumpur_1641785_1920_01c430a115.jpg	2026-04-03 23:14:17.437+08	2026-04-03 23:14:17.437+08	draft	\N	1	f
\.


--
-- Data for Name: directions_page_general_tips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.directions_page_general_tips (id, _parent_id, _order, _path, tip) FROM stdin;
\.


--
-- Data for Name: directions_page_meeting_points; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.directions_page_meeting_points (id, _parent_id, _order, _path, tour, location_name, address, directions, landmark, map_url, parking_info, public_transport) FROM stdin;
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faqs (id, question, answer, category, sort_order, tags, page_visibility, tour_id, workflow_status, updated_at, created_at, _status, _locales) FROM stdin;
1	How much does a food tour in KL cost?	Join-in tours are RM 285 to RM 359 per person, depending on which tour you choose. Private tours are quoted on request, usually for groups of four or more. Send us a message on WhatsApp and we'll put together something that works for your group.	booking	1	\N	\N	\N	draft	2026-04-03 11:20:22.334+08	2026-04-03 11:20:22.333+08	published	\N
2	How do I book?	Book directly on the tour page at simplyenak.com or message us on WhatsApp at +60 12-345-6789. We confirm within 3 hours during business hours, often sooner. No third-party platforms, no booking fees, no hidden costs — we keep it direct so you get the best price.	booking	2	\N	\N	\N	draft	2026-04-03 11:20:22.362+08	2026-04-03 11:20:22.362+08	published	\N
3	What if I need to cancel?	Free cancellation up to 48 hours before most tours, and 24 hours for some specialty experiences. We'll confirm the specific policy when you book. Life happens — flights get delayed, kids get sick. We're flexible and understanding, because we've been travelers too.	booking	3	\N	\N	\N	draft	2026-04-03 11:20:22.373+08	2026-04-03 11:20:22.373+08	published	\N
4	How long are the tours?	Most tours run 4 to 5 hours at a leisurely pace. We pace based on your group's energy and curiosity — we're not watching a clock. If a vendor has a story worth hearing about their 40 years of cooking, we stop and hear it. That's the Simply Enak difference.	day	4	\N	\N	\N	draft	2026-04-03 11:20:22.385+08	2026-04-03 11:20:22.385+08	published	\N
5	What can I expect on a food tour?	You'll visit 8-10 food stalls over 4-5 hours, tasting 15+ different dishes. Your guide shares stories about the food, culture, and history — like why Aunty Lim's laksa recipe hasn't changed since 1982. Small groups (max 9 people), local prices, no tourist traps. Just real food, real stories.	tour	10	\N	\N	\N	draft	2026-04-03 11:20:22.397+08	2026-04-03 11:20:22.396+08	published	\N
6	Can I take photos during the tour?	Absolutely! We encourage photos — most guests want to remember Aunty Lim's smile or Uncle Tan's wok skills. Vendors are proud of their food and happy to be photographed. We'll also take group photos and can help you capture the perfect shot for Instagram or TripAdvisor.	tour	10	\N	\N	\N	draft	2026-04-03 11:20:22.409+08	2026-04-03 11:20:22.409+08	published	\N
7	How much walking is involved?	Approximately 3km walking distance over 4-5 hours, at a leisurely pace with plenty of stops. We pause at each stall for 20-30 minutes, giving you time to digest, take photos, and listen to vendor stories. Not a power walk — more like a stroll through the neighborhood with friends.	accessibility	10	\N	\N	\N	draft	2026-04-03 11:20:22.419+08	2026-04-03 11:20:22.419+08	published	\N
8	What happens if it rains?	Tours run rain or shine! Malaysia's rain is intense but brief — usually 20-30 minutes then sunshine returns. We have covered alternatives at most stalls and adjust the route if needed. Some guests say eating char kway teow while watching tropical rain is the best part of the tour.	accessibility	10	\N	\N	\N	draft	2026-04-03 11:20:22.429+08	2026-04-03 11:20:22.429+08	published	\N
9	When will I receive confirmation?	We typically confirm within 3 hours during business hours (9am-6pm MYT), often within 30 minutes. For last-minute bookings same-day, message us on WhatsApp and we'll check vendor availability. Weekend tours fill up faster, so book 2-3 days ahead when possible.	booking	10	\N	\N	\N	draft	2026-04-03 11:20:22.438+08	2026-04-03 11:20:22.438+08	published	\N
10	What's the minimum group size for private tours?	Private tours are available for groups of 4 or more people. We customize the route, pace, and food stops based on your group's preferences and dietary needs. Popular for corporate team building, family celebrations, or friends who want an exclusive experience. Message us on WhatsApp for a custom quote.	booking	10	\N	\N	\N	draft	2026-04-03 11:20:22.45+08	2026-04-03 11:20:22.45+08	published	\N
11	I have food allergies. Is it safe?	We take allergies seriously. Let us know when booking about any allergies — peanuts, shellfish, gluten, etc. We'll adjust the route and inform each vendor. Some vendors have dedicated allergen-free prep areas. For severe allergies, we carry epinephrine and know the nearest clinic. Your safety comes first.	food	10	\N	\N	\N	draft	2026-04-03 11:20:22.459+08	2026-04-03 11:20:22.459+08	published	\N
12	Is the food spicy?	Malaysian food can be spicy, but we adjust for your tolerance. Many Chinese dishes serve chili separately — you add your own heat. Malay dishes tend to be spicier by default. We'll warn you before each stop and can request mild versions. Our goal is flavor enjoyment, not fire-breathing.	food	10	\N	\N	\N	draft	2026-04-03 11:20:22.468+08	2026-04-03 11:20:22.468+08	published	\N
13	Are there toilet breaks during the tour?	Yes! We start near a toilet facility and have bathroom breaks planned at 2-3 points during the tour. Most stalls have basic facilities, and we know which shopping centers have clean restrooms along the route. We pace the tour so you're never rushing or uncomfortable.	practical	10	\N	\N	\N	draft	2026-04-03 11:20:22.478+08	2026-04-03 11:20:22.478+08	published	\N
14	Is there parking near the meeting point?	Yes, there's parking near all our meeting points. For Chinatown tours, there's paid parking at Petaling Street market or nearby shopping centers. For Chow Kit, street parking is available. We'll send detailed parking instructions with your booking confirmation. Some areas have limited weekend parking, so arrive 10 minutes early.	practical	10	\N	\N	\N	draft	2026-04-03 11:20:22.487+08	2026-04-03 11:20:22.487+08	published	\N
\.


--
-- Data for Name: food_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_items (id, name, slug, description, category, origin, region, spice_level, preparation_method, typical_price, availability, image_id, cultural_significance, serving_suggestions, popular_variations, pairings, vendor_notes, status, featured, scheduled_publish, published_at, updated_at, created_at, _status) FROM stdin;
\.


--
-- Data for Name: food_items_allergens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_items_allergens (_order, _parent_id, id, allergen) FROM stdin;
\.


--
-- Data for Name: food_items_flavor_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_items_flavor_profile (_order, _parent_id, id, flavor) FROM stdin;
\.


--
-- Data for Name: food_items_ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_items_ingredients (_order, _parent_id, id, ingredient, is_main) FROM stdin;
\.


--
-- Data for Name: food_items_local_names; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_items_local_names (_order, _parent_id, id, language, name, script) FROM stdin;
\.


--
-- Data for Name: food_items_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_items_rels (id, "order", parent_id, path, dietary_options_id, media_id) FROM stdin;
\.


--
-- Data for Name: home_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page (id, faqs, meta_title, meta_description, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
6	\N	Simply Enak | Your Neighborhood Friends in Malaysia	Come as a guest, leave as family. Join locals for Malaysian food tours in KL, Penang, and Ipoh.	2026-04-03 11:49:42.704+08	2026-04-03 11:49:42.704+08	draft	\N	\N	f
\.


--
-- Data for Name: home_page_blocks_about_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_about_block (id, _parent_id, _order, _path, block_name, eyebrow, title, subtitle, description, heritage, image) FROM stdin;
1	6	0	aboutSection	aboutBlock	Our Story	Born in Malaysia. Raised on Street Food.	Sharing the Malaysia we grew up with, one meal at a time.	Simply Enak has been sharing Malaysian food heritage since 2011. We started as a small food walk through Kuala Lumpur's oldest neighborhoods, led by Pauline who grew up exploring wet markets and hawker stalls with her family. Today we host 5,000+ guests a year across KL and Penang — still with the same approach: unscripted, human, and deeply personal.	Since 2011	\N
\.


--
-- Data for Name: home_page_blocks_cta_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_cta_block (id, _parent_id, _order, _path, block_name, eyebrow, title, subtitle) FROM stdin;
1	6	0	ctaSection	ctaBlock	Ready when you are	Let us Eat Together	Join us for your next Malaysian adventure. Small groups, real neighborhoods, unforgettable stories.
\.


--
-- Data for Name: home_page_blocks_cta_block_buttons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_cta_block_buttons (id, _parent_id, _order, _path, label, url, variant) FROM stdin;
1	1	0	buttons	Book Your Experience	/tours	primary
2	1	1	buttons	Chat on WhatsApp	https://wa.me/60172878929	whatsapp
\.


--
-- Data for Name: home_page_blocks_cta_block_features; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_cta_block_features (id, _parent_id, _order, _path, text) FROM stdin;
1	1	0	features	Free cancellation up to 24 hours
2	1	1	features	We reply within 3 hours
3	1	2	features	Max 8 people per tour
\.


--
-- Data for Name: home_page_blocks_hero_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_hero_block (id, _parent_id, _order, _path, block_name, title, highlight, title_end, subtitle, description, price_info, bg_image) FROM stdin;
1	6	0	heroSection	heroBlock	Malaysia's Culture and Heritage	As Only Locals Know It		Walk with a local. Taste real stories. See the side of Malaysia most visitors never reach.	Our walking food tours are rooted in heritage and guided with heart.	From RM 285 - 4-5 hours - Max 9 people	\N
\.


--
-- Data for Name: home_page_blocks_hero_block_badges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_hero_block_badges (id, _parent_id, _order, _path, text) FROM stdin;
1	1	0	badges	40+ Heritage Vendors
2	1	1	badges	Since 2011
3	1	2	badges	4.9-Star Rated
4	1	3	badges	Max 9 Per Tour
5	1	4	badges	Low-Waste Tours
6	1	5	badges	Licensed Local Guides
7	1	6	badges	Family-Run Stalls
8	1	7	badges	Slow Travel Values
9	1	8	badges	5,000+ Guests Hosted
10	1	9	badges	3 Cities, 1 Passion
\.


--
-- Data for Name: home_page_blocks_manifesto_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_manifesto_block (id, _parent_id, _order, _path, block_name, eyebrow, headline, tagline, body, attribution_role) FROM stdin;
1	6	0	manifestoSection	manifestoBlock	Our Belief	In Malaysia, food is how stories get told.	The best ones stay with you.	We believe you cannot tell a story without the people, the food, and the place. Fourteen years in, we are still learning all three.	Co-founder, Simply Enak
\.


--
-- Data for Name: home_page_blocks_pillars_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_pillars_block (id, _parent_id, _order, _path, block_name, intro) FROM stdin;
1	6	0	pillarsSection	pillarsBlock	Everything we do comes back to three things.
\.


--
-- Data for Name: home_page_blocks_pillars_block_pillars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_pillars_block_pillars (id, _parent_id, _order, _path, label, heading, body) FROM stdin;
1	1	0	pillars	The People	Behind every dish is someone who has spent a lifetime perfecting it.	We introduce you to them: the hawkers, the families, the vendors who have fed their neighbourhoods for generations.
2	1	1	pillars	The Food	Malaysian food is one of the most layered cuisines in the world.	Chinese, Malay, Indian, Peranakan - each culture cooking side by side for 200 years. Every dish has a history. We help you taste it.
3	1	2	pillars	The Place	The stalls, the markets, the narrow lanes, the kampung that refused to be demolished.	Malaysias food culture lives in specific places. Many of them are disappearing. Coming here is how they survive.
\.


--
-- Data for Name: home_page_blocks_segments_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_segments_block (id, _parent_id, _order, _path, block_name, heading, subheading, view_all_label) FROM stdin;
1	6	0	segmentsSection	segmentsBlock	There is a tour for your kind of curious	Tell us what matters - we will show you the right one.	View all tours
\.


--
-- Data for Name: home_page_blocks_stats_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_stats_block (id, _parent_id, _order, _path, block_name, title, subtitle) FROM stdin;
1	6	0	expectSection	statsBlock	What to Expect on Tour	How our food tours actually work
\.


--
-- Data for Name: home_page_blocks_stats_block_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_stats_block_stats (id, _parent_id, _order, _path, number, heading, body) FROM stdin;
1	1	0	stats	9	People, maximum.	You are never lost in a crowd. Everyone can ask questions, wander, and actually connect.
2	1	1	stats	40+	Heritage vendors, all real.	Every stop is a vendor we have eaten with for years. No commissions. No tourist traps.
3	1	2	stats	0	Commission from vendors.	We do not take money from the people we visit. Their food speaks for itself.
4	1	3	stats	14	Years in the same neighbourhoods.	We know who opened, who closed, and who has been cooking the same recipe since 1978.
\.


--
-- Data for Name: home_page_blocks_vendors_block; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_vendors_block (id, _parent_id, _order, _path, block_name, eyebrow, title, subtitle) FROM stdin;
1	6	0	vendorsSection	vendorsBlock	The people	Meet the Vendors	The people who make Malaysian food culture what it is
\.


--
-- Data for Name: home_page_blocks_vendors_block_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_page_blocks_vendors_block_links (id, _parent_id, _order, _path, label, url) FROM stdin;
1	1	0	links	\N	/vendors
2	1	1	links	\N	/stories
3	1	2	links	\N	/about
\.


--
-- Data for Name: how_it_works_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_it_works_page (id, hero_title, hero_subtitle, steps_title, inclusions_title, formats_title, formats_subtitle, seo_title, seo_description, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
2	How Our Tours Work	Two formats, one standard: local knowledge, no commissions, real food.	The tour experience	What every tour includes	Two ways to tour with us	The food, the guide, the stalls — all the same. The difference is who you share it with.	\N	\N	2026-04-03 23:14:17.484+08	2026-04-03 23:14:17.484+08	draft	\N	1	f
\.


--
-- Data for Name: how_it_works_page_formats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_it_works_page_formats (id, _parent_id, _order, _path, name, description) FROM stdin;
\.


--
-- Data for Name: how_it_works_page_inclusions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_it_works_page_inclusions (id, _parent_id, _order, _path, item) FROM stdin;
1	2	0	inclusions	Certified local guide
2	2	1	inclusions	Food samples at every stop
3	2	2	inclusions	Cultural context at each stall
4	2	3	inclusions	Bottled water throughout
5	2	4	inclusions	Small group (max 12 guests)
6	2	5	inclusions	No tourist trap restaurants
7	2	6	inclusions	Local prices — always
\.


--
-- Data for Name: how_it_works_page_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_it_works_page_steps (id, _parent_id, _order, _path, number, title, detail) FROM stdin;
1	2	0	steps	1	Pick your tour and format	Browse our five tours across KL and Penang. Choose join-in (book a spot) or private (your group only).
2	2	1	steps	2	Book via WhatsApp or the tour page	Send us a WhatsApp or complete the booking form. We'll confirm your spot and answer any questions.
3	2	2	steps	3	We confirm and send you the prep guide	You'll get a confirmation with meeting point details and our preparation guide.
4	2	3	steps	4	Show up at the meeting point	Look for the Simply Enak guide with a blue badge. Arrive 5 minutes early if you can.
5	2	4	steps	5	Walk, eat, ask anything	Your guide takes you through 8 to 10+ tasting stops over 3.5 to 4 hours.
6	2	5	steps	6	Leave a review if you loved it	Reviews on TripAdvisor and Google help other travellers find us.
\.


--
-- Data for Name: how_to_prepare_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_to_prepare_page (id, seo_title, seo_description, hero_title, hero_description, hero_image, what_to_wear_heading, what_to_bring_heading, what_to_expect_heading, dietary_heading, dietary_intro, directions_cta_text, directions_cta_button, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
1	How to Prepare for Your Food Tour | Simply Enak	Everything you need to know before joining a Simply Enak food tour in Malaysia — what to wear, what to bring, dietary notes, and what to expect.	Come hungry, leave happy	A little preparation makes a big difference. Here's everything you need to know before your food tour.	https://se-website-images.s3.nl-ams.scw.cloud/IMG_20180606_230141_scaled_2d76fcae87.jpg	\N	\N	\N	Dietary requirements	Malaysian food spans Malay, Chinese, Indian, and Peranakan traditions. Most dietary needs are well-catered for — here's what to know.	Ready to find your meeting point?	View meeting point directions	2026-04-03 23:14:17.288+08	2026-04-03 23:14:17.288+08	draft	\N	1	f
\.


--
-- Data for Name: how_to_prepare_page_dietary_notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_to_prepare_page_dietary_notes (id, _parent_id, _order, _path, title, description) FROM stdin;
\.


--
-- Data for Name: how_to_prepare_page_what_to_bring; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_to_prepare_page_what_to_bring (id, _parent_id, _order, _path, title, description) FROM stdin;
1	1	0	whatToBring	Cash (Malaysian ringgit)	\N
2	1	1	whatToBring	Reusable water bottle	\N
3	1	2	whatToBring	Camera or phone	\N
4	1	3	whatToBring	Small daypack	\N
\.


--
-- Data for Name: how_to_prepare_page_what_to_expect; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_to_prepare_page_what_to_expect (id, _parent_id, _order, _path, title, description) FROM stdin;
\.


--
-- Data for Name: how_to_prepare_page_what_to_wear; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.how_to_prepare_page_what_to_wear (id, _parent_id, _order, _path, title, description) FROM stdin;
1	1	0	whatToWear	Light, breathable clothing	\N
2	1	1	whatToWear	Comfortable closed-toe shoes	\N
3	1	2	whatToWear	Modest dress appreciated	\N
4	1	3	whatToWear	Rain jacket (monsoon months)	\N
5	1	4	whatToWear	Avoid wearing white	\N
\.


--
-- Data for Name: landing_pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages (id, title, slug, type, status, icon, color, hero_title, hero_subtitle, hero_description, hero_image, intro_heading, intro_content, challenges_heading, options_heading, options_content, features_heading, tips_heading, tips_content, safe_dishes_heading, avoid_dishes_heading, tours_heading, meta_title, meta_description, published_at, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
1	Vegetarian	vegetarian	dietary	published	🌱	#4CAF50	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Vegetarian Food Tours Malaysia | Simply Enak	Discover Malaysia's best vegetarian food on our plant-friendly food tours. Vegetarian-certified vendors and delicious meat-free options.	\N	2026-04-03 23:17:06.524+08	2026-04-03 23:17:06.524+08	draft	\N	1	f
2	Halal	halal	dietary	published	verified	#00A651	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Halal Food Tours Malaysia | Simply Enak	JAKIM-certified halal food tours in Kuala Lumpur and Penang. We take you to stalls locals trust — no pork, no cross-contamination, no guesswork.	\N	2026-04-03 23:17:06.581+08	2026-04-03 23:17:06.581+08	draft	\N	1	f
3	Gluten-Free	gluten-free	dietary	published	grain	#F59E0B	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Gluten-Free Food Tours Malaysia | Simply Enak	Gluten-free food tours in Kuala Lumpur and Penang. We know which hawker stalls use no soy sauce and which dishes are naturally safe — no guesswork needed.	\N	2026-04-03 23:17:06.628+08	2026-04-03 23:17:06.628+08	draft	\N	1	f
4	Vegan	vegan	dietary	published	eco	#10B981	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Vegan Food Tours Malaysia | Simply Enak	Vegan food tours in Kuala Lumpur and Penang. We take you to Chinese Buddhist vegetarian restaurants and Indian stalls that have cooked without animal products for generations.	\N	2026-04-03 23:17:06.674+08	2026-04-03 23:17:06.674+08	draft	\N	1	f
5	Jain	jain	dietary	published	self_improvement	#F59E0B	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Jain-Friendly Food Tours Malaysia | Simply Enak	Flexible Jain guests welcome on our KL and Penang food tours. We know Brickfields' dedicated Jain kitchens and can advise strict requirements on request.	\N	2026-04-03 23:17:06.721+08	2026-04-03 23:17:06.721+08	draft	\N	1	f
6	Street Food	street-food	specialty	published	lunch_dining	#EF4444	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Street Food | Simply Enak	Legendary street food.	\N	2026-04-03 23:17:06.768+08	2026-04-03 23:17:06.768+08	draft	\N	1	f
7	Market Tour	market-tour	specialty	published	storefront	#F97316	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Market Tours | Simply Enak	Behind scenes.	\N	2026-04-03 23:17:06.816+08	2026-04-03 23:17:06.816+08	draft	\N	1	f
8	Heritage	heritage	specialty	published	history_edu	#7C3AED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Heritage Tours | Simply Enak	400 years history.	\N	2026-04-03 23:17:06.866+08	2026-04-03 23:17:06.866+08	draft	\N	1	f
9	Night Tour	night-tour	specialty	published	nightlight	#1E3A8A	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Night Tours | Simply Enak	After-dark.	\N	2026-04-03 23:17:06.911+08	2026-04-03 23:17:06.911+08	draft	\N	1	f
10	Family-Friendly	family	travel_type	published	family_restroom	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Family Food Tours Malaysia: Kid-Friendly | Simply Enak	Family-friendly food tours in KL and Penang. Kid-sized portions, bathroom breaks, slower pace. Children welcome on all tours. From RM 285.	\N	2026-04-03 23:17:06.963+08	2026-04-03 23:17:06.963+08	draft	\N	1	f
11	Couples	couples	travel_type	published	favorite	#EC4899	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Couples Food Tours Malaysia: Date Night | Simply Enak	Romantic food tours for couples in KL and Penang. Small groups, intimate settings, shared discoveries. Perfect date night. From RM 285.	\N	2026-04-03 23:17:07.008+08	2026-04-03 23:17:07.008+08	draft	\N	1	f
12	Foodie	foodie	travel_type	published	ramen_dining	#F59E0B	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Foodie Tours Malaysia: For Serious Eaters | Simply Enak	Food lover tours in KL and Penang. 10+ tastings, generational vendors, recipe histories. For serious foodies. From RM 285.	\N	2026-04-03 23:17:07.057+08	2026-04-03 23:17:07.057+08	draft	\N	1	f
13	Solo Traveler	solo	travel_type	published	person	#8B5CF6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Solo Traveler Food Tours Malaysia | Join Groups | Simply Enak	Solo food tours in KL and Penang. Join small groups, make friends, eat amazing food. No single supplement. From RM 285.	\N	2026-04-03 23:17:07.102+08	2026-04-03 23:17:07.102+08	draft	\N	1	f
14	Kuala Lumpur	kuala-lumpur	location	published	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Food Story of Kuala Lumpur | Simply Enak Food Tours	Food tours in Kuala Lumpur with Simply Enak. We take you to the hawker stalls and family-run kitchens that have fed locals for decades — and tell you the stories behind them.	\N	2026-04-03 23:17:07.152+08	2026-04-03 23:17:07.152+08	draft	\N	1	f
15	Penang	penang	location	published	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Penang Food Tours – Food Capital of Malaysia | Simply Enak	Food tours in Penang with Simply Enak. We take you to George Town's best hawker stalls — char kway teow over charcoal, assam laksa from 1980s family recipes, and the Peranakan kitchens tourists rarely find.	\N	2026-04-03 23:17:07.201+08	2026-04-03 23:17:07.201+08	draft	\N	1	f
\.


--
-- Data for Name: landing_pages_avoid_dishes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages_avoid_dishes (id, _parent_id, _order, _path, name, description) FROM stdin;
\.


--
-- Data for Name: landing_pages_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages_challenges (id, _parent_id, _order, _path, title, description) FROM stdin;
\.


--
-- Data for Name: landing_pages_highlights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages_highlights (id, _parent_id, _order, _path, title, description) FROM stdin;
\.


--
-- Data for Name: landing_pages_safe_dishes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages_safe_dishes (id, _parent_id, _order, _path, name, description) FROM stdin;
\.


--
-- Data for Name: landing_pages_suitable_tours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages_suitable_tours (id, _parent_id, _order, _path, tour_slug) FROM stdin;
\.


--
-- Data for Name: landing_pages_tips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages_tips (id, _parent_id, _order, _path, title, content) FROM stdin;
\.


--
-- Data for Name: landing_pages_travel_tips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.landing_pages_travel_tips (id, _parent_id, _order, _path, title, content) FROM stdin;
\.


--
-- Data for Name: legal_pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_pages (id, slug, status, headline, content, meta_title, meta_description, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
1	privacy-policy	published	Privacy Policy	[{"type": "paragraph", "children": [{"text": "<p>This Privacy Policy is prepared in accordance with the Personal Data Protection Act 2010 (PDPA) of Malaysia. By using this site or our services, you consent to the Processing of your Personal Data as described in this Policy.</p>\\n\\n<h3>Table of Contents</h3>\\n<ul>\\n<li>Definitions used in this Policy</li>\\n<li>Data protection principles we follow</li>\\n<li>What rights do you have regarding your Personal Data</li>\\n<li>What Personal Data do we gather about you</li>\\n<li>How we use your Personal Data</li>\\n<li>Who else has access to your Personal Data</li>\\n<li>How we secure your data</li>\\n<li>Information about cookies</li>\\n<li>Contact information</li>\\n</ul>\\n\\n<h3>Definitions</h3>\\n<ul>\\n<li><strong>Personal Data</strong> – any information relating to an identified or identifiable natural person.</li>\\n<li><strong>Processing</strong> – any operation or set of operations that is performed on Personal Data or on sets of Personal Data.</li>\\n<li><strong>Data subject</strong> – a natural person whose Personal Data is being Processed.</li>\\n<li><strong>Child</strong> – a natural person under 16 years of age.</li>\\n<li><strong>We/us</strong> – Local Culinary Experiences Sdn. Bhd., also known as Simply Enak.</li>\\n</ul>\\n\\n<h3>Data Subject's Rights</h3>\\n<p>The Data Subject has the following rights:</p>\\n<ul>\\n<li><strong>Right to information</strong> – you have the right to know whether your Personal Data is being processed; what data is gathered, from where it is obtained and why and by whom it is processed.</li>\\n<li><strong>Right to access</strong> – you have the right to access the data collected from/about you, including the right to request and obtain a copy of your Personal Data.</li>\\n<li><strong>Right to rectification</strong> – you have the right to request rectification or erasure of your Personal Data that is inaccurate or incomplete.</li>\\n<li><strong>Right to erasure</strong> – in certain circumstances you can request for your Personal Data to be erased from our records.</li>\\n<li><strong>Right to restrict processing</strong> – where certain conditions apply, you have the right to restrict the Processing of your Personal Data.</li>\\n<li><strong>Right to object to processing</strong> – in certain cases you have the right to object to the Processing of your Personal Data, for example in the case of direct marketing.</li>\\n<li><strong>Right to object to automated Processing</strong> – you have the right to object to automated Processing, including profiling; and not to be subject to a decision based solely on automated Processing.</li>\\n<li><strong>Right to data portability</strong> – you have the right to obtain your Personal Data in a machine-readable format or, if feasible, as a direct transfer from one Processor to another.</li>\\n<li><strong>Right to lodge a complaint</strong> – if we refuse your request under the Rights of Access, we will provide a reason. If you are not satisfied with how your request has been handled, please contact us.</li>\\n<li><strong>Right to withdraw consent</strong> – you have the right to withdraw any given consent for the Processing of your Personal Data.</li>\\n</ul>\\n\\n<h3>Data Protection Principles</h3>\\n<p>We follow these data protection principles:</p>\\n<ul>\\n<li>Processing is lawful, fair, and transparent. We always consider your rights before Processing Personal Data.</li>\\n<li>Processing is limited to the purpose for which Personal Data was gathered.</li>\\n<li>We only gather and Process the minimal amount of Personal Data required for any purpose.</li>\\n<li>We will not store your Personal Data for longer than needed.</li>\\n<li>We will do our best to ensure the accuracy of the data.</li>\\n<li>We will do our best to ensure the integrity and confidentiality of data.</li>\\n</ul>\\n\\n<h3>Data We Gather</h3>\\n<p><strong>Information you have provided us with</strong></p>\\n<p>This might be your email address, name, billing address, home address etc — mainly information that is necessary for delivering you a service or enhancing your experience with us. We save the information you provide us with in order for you to comment or perform other activities on the website. This includes, for example, your name and email address.</p>\\n\\n<p><strong>Information automatically collected about you</strong></p>\\n<p>This includes information that is automatically stored by cookies and other session tools — for example, your IP address and browsing history on this site. This information is used to improve your customer experience. When you use our services or look at the contents of our website, your activities may be logged.</p>\\n\\n<p><strong>Information from our partners</strong></p>\\n<p>We gather information from our trusted partners with confirmation that they have legal grounds to share that information with us.</p>\\n\\n<p><strong>Publicly available information</strong></p>\\n<p>We might gather information about you that is publicly available.</p>\\n\\n<h3>How We Use Your Personal Data</h3>\\n<p>We use your Personal Data in order to:</p>\\n<ul>\\n<li>contact you prior to, during or after your Food Experience;</li>\\n<li>provide our service to you, including registering your account and communicating with you about your bookings;</li>\\n<li>enhance your customer experience;</li>\\n<li>fulfill an obligation under law or contract.</li>\\n</ul>\\n<p>On the grounds of entering into a contract or fulfilling contractual obligations, we Process your Personal Data to identify you, provide you with a service, and communicate for sales or invoicing purposes.</p>\\n<p>On the ground of legitimate interest, we Process your Personal Data to administer and analyze our client base in order to improve the quality and availability of our services, and to conduct satisfaction questionnaires.</p>\\n<p>With your consent we may Process your Personal Data to send you newsletters and campaign offers.</p>\\n<p><strong>Data retention:</strong> Booking and billing records are retained for 7 years as required under Malaysian law (Companies Act 2016 and Income Tax Act 1967). Contact information and correspondence are retained for 3 years after your last tour with us, or until you request erasure — whichever is earlier. Marketing preferences are retained until you withdraw consent.</p>\\n\\n<h3>Who Else Can Access Your Personal Data</h3>\\n<p>We do not share your Personal Data with strangers. In some cases Personal Data is provided to our trusted partners in order to make providing the service possible or to enhance your experience. We share your data with:</p>\\n<p><strong>Our processing partners:</strong> Stripe Payments Malaysia Sdn. Bhd. (credit/debit card processing), Wise Payments Malaysia Sdn. Bhd. (international payments)</p>\\n<p><strong>Our business partners:</strong> The licensed guide(s) who conduct your tour (name and booking details shared to enable delivery of the tour)</p>\\n<p><strong>Connected third parties:</strong> Meta (Facebook/Instagram — for advertising and social sharing), Google Analytics 4 (website analytics and user behaviour)</p>\\n<p>We only work with Processing partners who are able to ensure an adequate level of protection for your Personal Data. We disclose your Personal Data to third parties or public officials when we are legally obliged to do so.</p>\\n\\n<h3>How We Secure Your Data</h3>\\n<p>We do our best to keep your Personal Data safe. Specific measures include:</p>\\n<ul>\\n<li>All data is transmitted over HTTPS with TLS encryption.</li>\\n<li>The website is protected by Cloudflare's web application firewall and DDoS mitigation at the network level.</li>\\n<li>All payment processing is handled exclusively by PCI-DSS Level 1 certified processors (Stripe, PayPal). We do not store card numbers or payment credentials on our systems.</li>\\n<li>Access to Personal Data is restricted to staff who require it to deliver your booking or respond to your enquiry.</li>\\n<li>We monitor our systems for vulnerabilities and apply security updates promptly.</li>\\n</ul>\\n<p>Even though we take these precautions, no system is entirely free from risk. We promise to notify the relevant authorities of any confirmed data breaches and will also notify you directly if there is a threat to your rights or interests.</p>\\n\\n<h3>Children</h3>\\n<p>We do not intend to collect or knowingly collect information from children. We do not target children with our services.</p>\\n\\n<h3>Cookies and Other Technologies</h3>\\n<p>We use cookies and/or similar technologies to analyze customer behaviour, administer the website, track users' movements, and collect information about users. This is done in order to personalize and enhance your experience with us.</p>\\n\\n<h3>Contact Information</h3>\\n<p>For any questions about this Privacy Policy or your Personal Data, please contact us at <a href=\\\\\\"mailto:info@simplyenak.com\\\\\\">info@simplyenak.com</a> or by WhatsApp at <a href=\\\\\\"https://wa.me/60172878929\\\\\\">+60 17-287 8929</a>.</p>\\n\\n<h3>Changes to This Privacy Policy</h3>\\n<p>We reserve the right to make changes to this Privacy Policy. We will notify you of any significant changes. This Policy was last updated in March 2026.</p>", "type": "text"}]}]	Privacy Policy | Simply Enak	Simply Enak (Local Culinary Experiences Sdn. Bhd.) privacy policy — how we collect, use, and protect your personal data.	2026-04-03 13:17:30.013+08	2026-04-03 13:17:30.013+08	published	\N	\N	f
2	terms-conditions	published	Terms & Conditions	[{"type": "paragraph", "children": [{"text": "<p>If you continue to browse and use this website, you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern Simply Enak's relationship with you. If you disagree with any part of these terms and conditions, please do not use our services.</p>\\n\\n<p><strong>The use of this website is subject to the following terms of use:</strong></p>\\n<p>This website contains material that is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions. All trademarks reproduced in this website which are not the property of, or licensed to the operator, are acknowledged on the website.</p>\\n<p>Unauthorized use of this website may give rise to a claim for damages and/or be a criminal offense. Your use of this website and any dispute arising out of such use is subject to the laws of Malaysia.</p>\\n\\n<h3>Tour Terms and Conditions</h3>\\n\\n<h4>1. Food and Beverage Consumption</h4>\\n<p>1.1 All Food and Beverages are both halal and non-halal as per the nature of the food establishments. Alcoholic beverages, food items, souvenirs and other items not purchased by the Guide will not be included in the Tours.</p>\\n<p>1.2 All Food and Beverages consumed during the Tour or food souvenirs are from third-party establishments (restaurants, cafes, markets and other food establishments). We play no role in procuring ingredients or preparing the food/beverages served. We are therefore unable to take any responsibility for any sickness, illness or injury caused to you or your companions as a result of visiting these establishments or consuming their food and beverages.</p>\\n<p>1.3 You understand, accept, and take full responsibility for the potential risks and hazards of consuming foods and beverages during the Tour.</p>\\n\\n<h4>2. Dietary Restrictions, Allergies and Medical Conditions</h4>\\n<p>2.1 You are required to let us know of any (a) dietary restrictions, (b) allergies and (c) other medical conditions related to either walking or eating/drinking, at the time of booking.</p>\\n<p>2.2 While there is no guarantee of our being able to accommodate any dietary restrictions, we will do our level best to do so.</p>\\n<p>2.3 In the case of dietary restrictions or allergies, it is imperative that you remind us before consuming any food/beverage during the Tour, so that we can verify with the establishment regarding the ingredients.</p>\\n<p>2.4 We cannot take any responsibility for any incidents resulting due to allergies caused to you as a result of food or beverage consumption from third party establishments during the Tour.</p>\\n<p>2.5 In the case of any extreme allergies or medical conditions, we reserve the right to request you to not attend the Tour, and will refund the full price of the ticket booking.</p>\\n\\n<h4>3. Tour Participation</h4>\\n<p>3.1 You understand and confirm that your participation in the Tours is completely voluntary.</p>\\n<p>3.2 Children are welcome to join the tour. However, you take full responsibility for ensuring that you and/or your children are mentally and physically capable of participating.</p>\\n<p>3.3 You agree to comply with the instructions of the tour (food) guides.</p>\\n<p>3.4 If your behavior or physical condition is detrimental to the safety or welfare of the group, or if we consider that your general well-being will be put at risk by continuing with the Tour, you may be asked not to participate without the right to any refund.</p>\\n<p>3.5 You fully comprehend and accept all of the risks associated with your participation in the Tours including, without limitation, injury or death resulting from exposure to unfavorable weather conditions, food sickness, allergic reactions, choking, and injuries arising from self-inflicted accidents, other participants, motor vehicles, and pedestrians.</p>\\n\\n<h4>4. Tour Participant Conduct</h4>\\n<p>4.1 At all times during the Tour, you are expected to have consideration for your fellow tour participants and other third parties. We reserve the right to remove any participant whose conduct is deemed to pose a risk or nuisance to others. We will not refund or cover any cost or expenses incurred due to unacceptable behavior.</p>\\n\\n<h4>5. Reservation and Payment</h4>\\n<p>5.1 Prices quoted are in RM (Ringgit Malaysia) unless stated otherwise.</p>\\n<p>5.2 Payment must be made in full 24 hours prior to the tour as confirmation.</p>\\n<p>5.3 Credit card and debit card payments are collected by Stripe Payments Malaysia Sdn. Bhd., and international payments by Wise Payments Malaysia Sdn. Bhd., each acting as an authorized agent of Local Culinary Experiences Sdn Bhd.</p>\\n\\n<h4>6. Cancellation and Refund</h4>\\n<p>6.1 Should you no longer be able to attend the Tour after having received a confirmation of a paid booking, you are required to contact us immediately via email.</p>\\n<p>6.2 Cancellation of join-in / public tour(s) less than 24 hours prior to the start of the tour is not refundable.</p>\\n<p>6.3 Cancellation of join-in / public tour(s) more than 24 hours prior to the start of the tour will receive a full refund, or the tour booking can be rescheduled to another date upon availability.</p>\\n<p>6.4 Cancellation of custom and private tour(s) less than 72 hours prior to the start of the tour is not refundable.</p>\\n<p>6.5 Cancellation of custom and private tour(s) more than 72 hours prior to the start of the tour will receive a full refund, or the tour booking can be rescheduled to another date upon availability.</p>\\n<p>6.6 Simply Enak reserves the right to cancel a Tour at any time in the case of unforeseen circumstances. In such cases, we will fully refund all ticket bookings for that day, or reschedule the Tour to another date of your preference, or provide a free replacement Tour for your next visit.</p>\\n\\n<h4>7. Tour Price</h4>\\n<p>7.1 The tour price includes all Food and Beverages that the tour guides recommend and order for the group at each food establishment throughout the tour.</p>\\n<p>7.2 The tour price does not include any Food and Beverages that the tour participant may choose to order beyond what is ordered by the tour guides.</p>\\n\\n<h4>8. Minimum Tour Attendance</h4>\\n<p>8.1 Our public tours are subject to at least 2 people signing up. In the event we do not have the minimum tour group size, we may reach out for cancellation at least a day prior to the tour and refund any payments made, or offer a one-person private tour.</p>\\n<p>8.2 Our private tours are determined on a case-by-case basis and will be communicated to the participant(s) at the time of booking.</p>\\n\\n<h4>9. Transportation: Walking and Mobile Transport</h4>\\n<p>9.1 While the Tour will not at any point involve more than 20 minutes of continuous walking, the overall walking time may add up to 60 minutes or more. When you sign up for the Tour, you agree that you are fit to walk for at least 60 minutes in total.</p>\\n<p>9.2 You are responsible for your own safety while walking during the Tour. We will do everything in our capacity to follow a safe Tour route, but we do not claim responsibility for any illness, injuries, accidents, loss, damage or theft caused to you by a third party during the Tour.</p>\\n\\n<h4>10. Limitation of Liability</h4>\\n<p>10.1 The guest is aware and agrees that street food will be part of the activity and that any risk taken by the consumption of street food is entirely at the risk of the Guest. The Company shall not be held liable for any sickness or health issues directly or indirectly related to or caused by the consumption of any food and/or beverages as part of the Food Tour.</p>\\n<p>10.2 The guest agrees and acknowledges that it is advisable to purchase private liability insurance prior to participating in a Food Tour conducted by the Company.</p>\\n\\n<h4>11. Personal Belongings</h4>\\n<p>11.1 You are wholly responsible for your own personal belongings throughout the Tour. We are unable to accept responsibility for any belonging that may have been lost or stolen from you during the Tour.</p>\\n\\n<h4>12. Simply Enak's Public Holidays / Non-Working Days</h4>\\n<p>12.1 All major gazetted Malaysian Public Holidays are non-working days for the Company and the Guides. Reservations and queries will be answered within 48 hours from the subsequent working day. Malaysian Public Holidays include: New Year's Day; Chinese New Year Day 1 and 2; Labour Day; Hari Raya Aidilfitri Day 1 and 2; Deepavali; Christmas Day.</p>\\n\\n<h3>Liability Conditions</h3>\\n<p>Simply Enak does not provide liability insurance for the protection of individuals, groups, or organizations who participate in the food tour(s). In consideration for your participation, you hereby release and forever discharge Simply Enak, and its officers, board, and employees from any and all actions, claims and demands for any damage, food poisoning, allergies, loss or injury which may be sustained by participating in the food tour(s).</p>\\n<p>This release extends to all unknown, unforeseen, unanticipated and unsuspected injuries, damages, loss and liability and the consequences thereof, as well as those now disclosed and known to exist.</p>\\n<p>You hereby agree, on behalf of your heirs, executors, administrators, and assigns, to indemnify Simply Enak and its officers, board and employees from any and all actions, claims and demands for any damage, loss or injury which may be sustained by participating in the food tour(s).</p>", "type": "text"}]}]	Terms & Conditions | Simply Enak	Terms and conditions for Simply Enak food tours operated by Local Culinary Experiences Sdn. Bhd. — cancellation policy, dietary restrictions, liability, and more.	2026-04-03 13:17:30.013+08	2026-04-03 13:17:30.013+08	published	\N	\N	f
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (id, name, slug, icon, color, description, status, created_at, updated_at, _status) FROM stdin;
1	Kuala Lumpur	kuala-lumpur	🏙️	#0ea5e9	The capital city — diverse food scene from Malay, Chinese, and Indian traditions	published	2026-04-03 15:08:39.101+08	2026-04-03 15:08:39.101+08	published
2	Penang	penang	🏝️	#22c55e	Malaysia's food capital — Peranakan heritage, hawker culture, and island charm	published	2026-04-03 15:08:39.101+08	2026-04-03 15:08:39.101+08	published
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media (id, alt, caption, usage, prefix, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y, sizes_thumbnail_url, sizes_thumbnail_width, sizes_thumbnail_height, sizes_thumbnail_mime_type, sizes_thumbnail_filesize, sizes_thumbnail_filename, sizes_medium_url, sizes_medium_width, sizes_medium_height, sizes_medium_mime_type, sizes_medium_filesize, sizes_medium_filename, sizes_large_url, sizes_large_width, sizes_large_height, sizes_large_mime_type, sizes_large_filesize, sizes_large_filename) FROM stdin;
2	Flavours of Malaysia	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/Eat_Drink_Georgetown1_72aaaf12b6.jpg	\N	Eat_Drink_Georgetown1_72aaaf12b6.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	Eat Drink George Town	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/Eat_Drink_George_Town_Bart_1527cf1f89.jpeg	\N	Eat_Drink_George_Town_Bart_1527cf1f89.jpeg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4	Kuala Lumpur Street Food	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/kuala_lumpur_street_food_cd4fad4122.jpg	\N	kuala_lumpur_street_food_cd4fad4122.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5	Penang Street Food	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/Eat_Drink_Georgetown2_1e8a13906e.jpg	\N	Eat_Drink_Georgetown2_1e8a13906e.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/85bdaaf7-6156-43db-9463-0a76a575ef5f.jpg	\N	85bdaaf7-6156-43db-9463-0a76a575ef5f.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/6d8b21c8-7f16-47ec-bca3-03c0cd80be26.jpg	\N	6d8b21c8-7f16-47ec-bca3-03c0cd80be26.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/0e3cfb3e-f759-4b83-8321-093593ee5c3a.jpg	\N	0e3cfb3e-f759-4b83-8321-093593ee5c3a.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/5e1d66b2-95d1-4cb0-8b44-9b9a8ed3e95c.jpg	\N	5e1d66b2-95d1-4cb0-8b44-9b9a8ed3e95c.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/ebe24398-ad97-49e2-9696-f049c1b50c92.jpg	\N	ebe24398-ad97-49e2-9696-f049c1b50c92.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/90aca586-c5fe-41f9-b76d-67843888e1b7.jpeg	\N	90aca586-c5fe-41f9-b76d-67843888e1b7.jpeg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/6fea56e5-0344-4817-b202-ce47b4e90f7e.jpg	\N	6fea56e5-0344-4817-b202-ce47b4e90f7e.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/430785dd-1c28-4fed-857a-7153e970f0ee.jpg	\N	430785dd-1c28-4fed-857a-7153e970f0ee.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/b86ded46-f8e4-4ac0-8d93-22c9f556e8e5.jpg	\N	b86ded46-f8e4-4ac0-8d93-22c9f556e8e5.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/d17e2e6a-17f2-45cd-8c77-3f7118700110.jpg	\N	d17e2e6a-17f2-45cd-8c77-3f7118700110.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/07773790-f65a-42d9-abd5-c56ec3419aed.jpg	\N	07773790-f65a-42d9-abd5-c56ec3419aed.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
17	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/451b194e-42f1-4501-8bff-7a2a4a8c66a3.jpg	\N	451b194e-42f1-4501-8bff-7a2a4a8c66a3.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/aa5594e8-8251-4f34-b741-d242f9909d79.jpg	\N	aa5594e8-8251-4f34-b741-d242f9909d79.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
19	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/fe995551-3b28-4e89-bbaa-8a074fbf372a.jpg	\N	fe995551-3b28-4e89-bbaa-8a074fbf372a.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
20	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/5f78aa94-1add-49bc-87e5-ecf6c1c2b1d9.jpg	\N	5f78aa94-1add-49bc-87e5-ecf6c1c2b1d9.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
21	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/293c136b-ebe4-4250-875b-1523991a1856.jpg	\N	293c136b-ebe4-4250-875b-1523991a1856.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/bcb96509-4deb-4eba-8c32-a1cbbe9974c0.jpg	\N	bcb96509-4deb-4eba-8c32-a1cbbe9974c0.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
23	Tour gallery	\N	\N	payload-media	2026-04-03 21:58:55.268+08	2026-04-03 21:58:55.268+08	https://se-website-images.s3.nl-ams.scw.cloud/e047469d-5d9c-4d66-9ef5-c4bd0451a978.jpg	\N	e047469d-5d9c-4d66-9ef5-c4bd0451a978.jpg	image/jpeg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: media_coverage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_coverage (id, category, outlet, year, detail, url, label, logo_domain, highlight, status, updated_at, created_at, _locales) FROM stdin;
1	television	National Geographic	~2015	Confucius Was a Foodie — Season 3	\N	\N	nationalgeographic.com	none	published	2026-04-03 11:19:30.302+08	2026-04-03 11:19:30.3+08	\N
2	television	TLC	~2016	Taste Off with Chef Aaron Craze	\N	\N	tlc.com	none	published	2026-04-03 11:19:30.313+08	2026-04-03 11:19:30.312+08	\N
3	television	BBC Sport	2016	Tiger Char Kway Teow, Penang	https://youtu.be/zZbAAn16JWc	Watch on YouTube	bbc.co.uk	none	published	2026-04-03 11:19:30.319+08	2026-04-03 11:19:30.319+08	\N
4	television	TVNZ	2017	Karena & Kasey's Foreign Flavours — Penang episode, New Zealand primetime	\N	\N	tvnz.co.nz	none	published	2026-04-03 11:19:30.324+08	2026-04-03 11:19:30.324+08	\N
5	television	Channel Nine Australia	2018	Getaway — host David Reyne, Chow Kit & Jalan Alor	\N	\N	9now.com.au	none	published	2026-04-03 11:19:30.329+08	2026-04-03 11:19:30.329+08	\N
6	television	The Edge TV	2019–2020	Exploring History Through Food	https://youtu.be/zlqXAnJMREo	Watch on YouTube	theedge.com.my	none	published	2026-04-03 11:19:30.334+08	2026-04-03 11:19:30.334+08	\N
7	print	Lonely Planet	~2012	Malaysia & Singapore guidebook	\N	\N	lonelyplanet.com	none	published	2026-04-03 11:19:30.339+08	2026-04-03 11:19:30.339+08	\N
8	print	Le Guide du Routard	2013	Malaysia — Kuala Lumpur	https://www.routard.com/guide/kuala_lumpur/4385/activites_.htm	View listing	routard.com	none	published	2026-04-03 11:19:30.344+08	2026-04-03 11:19:30.344+08	\N
9	print	Time Out Penang	2016	Simply Enak food tour feature	https://www.timeout.com/penang/things-to-do/simply-enak	View feature	timeout.com	none	published	2026-04-03 11:19:30.348+08	2026-04-03 11:19:30.348+08	\N
10	youtube	The Food Ranger	2018–2019	Trevor James (6M+ subscribers) — KL hawker stalls	https://youtu.be/poY8iDlC6Tk	Video 1	thefoodranger.com	none	published	2026-04-03 11:19:30.353+08	2026-04-03 11:19:30.353+08	\N
11	youtube	The Food Ranger	2018–2019	KL street food — video 2	https://youtu.be/WlG_9eZWiso	Video 2	thefoodranger.com	none	published	2026-04-03 11:19:30.358+08	2026-04-03 11:19:30.358+08	\N
12	youtube	The Food Ranger	2018–2019	KL street food — video 3	https://youtu.be/iZXFMufNHdo	Video 3	thefoodranger.com	none	published	2026-04-03 11:19:30.363+08	2026-04-03 11:19:30.363+08	\N
13	podcasts	Destination Eat Drink	2024	Pauline on Penang food culture — Nyonya cuisine, nasi kandar, Georgetown	https://radiomisfits.com/ded286/	Listen	radiomisfits.com	none	published	2026-04-03 11:19:30.366+08	2026-04-03 11:19:30.366+08	\N
14	blogs	The Yum List	2012	Dine With a Local — first coverage of Simply Enak	https://www.theyumlist.net/2012/03/dine-with-local-kuala-lumpur-malaysia.html	Read feature	theyumlist.net	first	published	2026-04-03 11:19:30.37+08	2026-04-03 11:19:30.37+08	\N
15	blogs	Minority Nomad	2015	Kuala Lumpur Food Tour with Simply Enak and #i_amKL	https://www.minoritynomad.com/blog/kuala-lumpur-food-tour-with-simply-enak-and-i_amkl	Read feature	minoritynomad.com	none	published	2026-04-03 11:19:30.375+08	2026-04-03 11:19:30.375+08	\N
16	blogs	5 Lost Together	2018	Taking a Food Tour with Simply Enak in Georgetown, Penang	https://www.5losttogether.com/taking-a-food-tour-with-simply-enak-in-georgetown-penang/	Read feature	5losttogether.com	none	published	2026-04-03 11:19:30.379+08	2026-04-03 11:19:30.379+08	\N
17	blogs	The Yum List	2020	Mark Ng, Food Experience Partner	https://www.theyumlist.net/2020/02/mark-ng-simply-enak-food-experience-partner.html	Read feature	theyumlist.net	none	published	2026-04-03 11:19:30.383+08	2026-04-03 11:19:30.383+08	\N
18	blogs	Best Regards From Far	2024	Top 9 Essential Experiences in George Town, Penang — Simply Enak listed	https://bestregardsfromfar.com/2024/05/30/top-9-essential-experiences-in-george-town-penang/	Read feature	bestregardsfromfar.com	none	published	2026-04-03 11:19:30.387+08	2026-04-03 11:19:30.387+08	\N
19	blogs	The Yum List	2026	Simply Enak Street Food Tours, Kuala Lumpur	https://www.theyumlist.net/2026/01/simply-enak-street-food-tours-kuala-lumpur.html	Read feature	theyumlist.net	none	published	2026-04-03 11:19:30.391+08	2026-04-03 11:19:30.391+08	\N
20	blogs	The Yum List	2026	Pauline Lee, Founder of Simply Enak	https://www.theyumlist.net/2026/03/pauline-lee-founder-of-simply-enak.html	Read feature	theyumlist.net	latest	published	2026-04-03 11:19:30.396+08	2026-04-03 11:19:30.396+08	\N
\.


--
-- Data for Name: menus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menus (id, name, location, items, item_count, created_at, updated_at, _status) FROM stdin;
1	Main Navigation	top	[]	4	2026-04-03 13:34:05.857+08	2026-04-03 13:34:05.857+08	published
2	Footer Menu	footer	[]	0	2026-04-03 13:34:05.858+08	2026-04-03 13:34:05.858+08	published
\.


--
-- Data for Name: menus_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menus_items (id, _parent_id, _order, _path, label, url, open_in_new_tab, "order") FROM stdin;
1	1	0	items	Tours	/tours	f	1
2	1	1	items	Stories	/stories	f	2
3	1	2	items	About	/about	f	3
4	1	3	items	Contact	/contact	f	4
\.


--
-- Data for Name: payload_kv; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_kv (id, key, data) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_locked_documents (id, global_slug, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_locked_documents_rels (id, "order", parent_id, path, users_id, media_id, tours_id, stories_id, testimonials_id, faqs_id, media_coverage_id, dietary_options_id, food_items_id, vendors_id, dietary_landing_pages_id, specialty_landing_pages_id, travel_type_landing_pages_id, location_landing_pages_id, about_page_id, contact_page_id, thank_you_pages_id, translations_id, site_settings_id, redirects_id, search_id, home_page_id, legal_pages_id, menus_id, travel_types_id, specialty_experiences_id, locations_id, forms_id, form_submissions_id, how_it_works_page_id, how_to_prepare_page_id, corporate_groups_page_id, track_record_page_id, directions_page_id, landing_pages_id) FROM stdin;
\.


--
-- Data for Name: payload_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_migrations (id, name, batch, updated_at, created_at) FROM stdin;
1	20260402_235142_initial_schema	1	2026-04-03 07:51:48.32+08	2026-04-03 07:51:48.319+08
\.


--
-- Data for Name: payload_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_preferences (id, key, value, updated_at, created_at) FROM stdin;
1	collection-media	{}	2026-04-03 11:12:44.434+08	2026-04-03 11:12:44.433+08
5	collection-faqs	{"editViewType": "default"}	2026-04-03 11:21:47.57+08	2026-04-03 11:21:44.892+08
6	collection-media_coverage	{"limit": 10, "editViewType": "default"}	2026-04-03 11:22:33.743+08	2026-04-03 11:22:22.878+08
8	collection-redirects	{}	2026-04-03 11:23:09.649+08	2026-04-03 11:23:09.649+08
10	collection-users	{}	2026-04-03 11:23:13.836+08	2026-04-03 11:23:13.836+08
4	collection-dietary_landing_pages	{"limit": 10, "editViewType": "default"}	2026-04-03 11:23:19.932+08	2026-04-03 11:14:58.412+08
12	collection-translations	{"limit": 10}	2026-04-03 11:38:59.537+08	2026-04-03 11:29:29.372+08
13	collection-vendors	{}	2026-04-03 12:12:47.492+08	2026-04-03 12:12:47.492+08
7	collection-tours	{"editViewType": "default"}	2026-04-03 12:12:55.653+08	2026-04-03 11:23:05.406+08
20	collection-travel_type_landing_pages	{"editViewType": "default"}	2026-04-03 12:41:10.771+08	2026-04-03 12:41:08.376+08
18	collection-contact_page	{"editViewType": "default"}	2026-04-03 12:41:43.6+08	2026-04-03 12:32:41.804+08
19	collection-about_page	{"editViewType": "default"}	2026-04-03 12:41:48.916+08	2026-04-03 12:32:47.67+08
22	collection-location_landing_pages	{"editViewType": "default"}	2026-04-03 12:41:55.661+08	2026-04-03 12:41:52.91+08
23	collection-specialty_landing_pages	{"editViewType": "default"}	2026-04-03 12:42:04.627+08	2026-04-03 12:42:02.269+08
3	collection-testimonials	{"limit": 10, "editViewType": "default"}	2026-04-03 12:42:20.103+08	2026-04-03 11:12:47.982+08
2	collection-stories	{"editViewType": "default"}	2026-04-03 12:42:24.137+08	2026-04-03 11:12:46.498+08
9	collection-site_settings	{"editViewType": "default"}	2026-04-03 12:42:34.004+08	2026-04-03 11:23:11.946+08
17	collection-thank_you_pages	{"limit": 10, "editViewType": "default"}	2026-04-03 12:51:59.933+08	2026-04-03 12:32:39.305+08
16	collection-home_page	{"limit": 10, "editViewType": "default"}	2026-04-03 13:13:24.119+08	2026-04-03 12:32:35.287+08
11	collection-dietary_options	{"limit": 10}	2026-04-03 13:39:34.968+08	2026-04-03 11:24:19.135+08
14	collection-food_items	{"limit": 10}	2026-04-03 14:45:30.019+08	2026-04-03 12:12:49.317+08
24	collection-home_page-6	{"fields": {"ctaSection": {"collapsed": []}, "ctaSection.0.buttons": {"collapsed": []}, "heroSection.0.badges": {"collapsed": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}}}	2026-04-03 15:03:48.174+08	2026-04-03 14:57:01.899+08
21	collection-travel_type_landing_pages	{"limit": 10}	2026-04-03 15:06:57.893+08	2026-04-03 12:41:08.383+08
25	collection-travel_types	{}	2026-04-03 15:59:28.7+08	2026-04-03 15:59:28.699+08
26	collection-specialty_experiences	{}	2026-04-03 15:59:42.057+08	2026-04-03 15:59:42.057+08
27	collection-locations	{}	2026-04-03 15:59:44.429+08	2026-04-03 15:59:44.429+08
15	collection-legal_pages	{"limit": 10, "editViewType": "default"}	2026-04-03 16:00:46.1+08	2026-04-03 12:28:16.345+08
\.


--
-- Data for Name: payload_preferences_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_preferences_rels (id, "order", parent_id, path, users_id) FROM stdin;
1	\N	1	user	1
7	\N	5	user	1
10	\N	6	user	1
12	\N	8	user	1
14	\N	10	user	1
15	\N	4	user	1
18	\N	12	user	1
19	\N	13	user	1
21	\N	7	user	1
29	\N	20	user	1
30	\N	18	user	1
31	\N	19	user	1
33	\N	22	user	1
35	\N	23	user	1
36	\N	3	user	1
37	\N	2	user	1
38	\N	9	user	1
40	\N	17	user	1
42	\N	16	user	1
44	\N	11	user	1
45	\N	14	user	1
55	\N	24	user	1
56	\N	21	user	1
57	\N	25	user	1
58	\N	26	user	1
59	\N	27	user	1
60	\N	15	user	1
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_settings (id, site_name, tagline, description, hero_title, hero_subtitle, hero_description, hero_image, booking_url, social_media, contact_email, contact_phone, whatsapp_number, address, meta_title, meta_description, updated_at, created_at, main_navigation, mobile_navigation, footer_navigation, footer_copyright_text, sub_page_menus) FROM stdin;
1	Simply Enak	Your Neighborhood Friends in Malaysia	\N	\N	\N	\N	\N	\N	\N	info@simplyenak.com	+60 17-287 8929	+60 17-287 8929	Kuala Lumpur, Malaysia	Simply Enak | Your Neighborhood Friends in Malaysia	Come as a guest, leave as family. Join locals for Malaysian food tours in KL, Penang, and Ipoh. Small groups, real neighborhoods, 5,000+ guests since 2011.	2026-04-03 11:40:56.899+08	2026-04-03 11:40:56.898+08	[{"url": "/tours", "label": "Tours"}, {"url": "/stories", "label": "Stories"}, {"url": "/about", "label": "About"}, {"url": "/contact", "label": "Contact"}]	\N	null	© 2026 Simply Enak. All rights reserved.	\N
\.


--
-- Data for Name: specialty_experiences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specialty_experiences (id, name, slug, icon, color, description, status, created_at, updated_at, _status) FROM stdin;
1	Heritage	heritage	🏛️	#0ea5e9	Historic neighborhoods and traditional recipes	published	2026-04-03 15:08:39.095+08	2026-04-03 15:08:39.095+08	published
2	Market Tour	market-tour	🏪	#22c55e	Wet markets, spice shops, and local producers	published	2026-04-03 15:08:39.095+08	2026-04-03 15:08:39.095+08	published
3	Night Tour	night-tour	🌙	#6366f1	Evening food adventures and night markets	published	2026-04-03 15:08:39.095+08	2026-04-03 15:08:39.095+08	published
4	Street Food	street-food	🍢	#f97316	Hawker stalls and roadside vendors	published	2026-04-03 15:08:39.095+08	2026-04-03 15:08:39.095+08	published
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stories (id, title, slug, author_id, excerpt, content, published_date, status, workflow_status, scheduled_publish, meta_title, meta_description, meta_image_id, updated_at, created_at, _status, featured_image_id, _locales) FROM stdin;
1	The Satay Master of Kampung Baru	satay-master-kampung-baru	1	Pak Din has been fanning charcoal fires for 40 years. His secret isn't just the marinade—it's the patience.	Pak Din has been fanning charcoal fires for 40 years. His secret isn't just the marinade—it's the patience.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.571+08	2026-04-03 11:28:35.569+08	published	\N	\N
2	The Heritage Behind Malaysian Food	heritage-behind-malaysian-food	1	Discover how Malaysian cuisine became a melting pot of Malay, Chinese, Indian, and indigenous influences over centuries of trade and cultural exchange.	Discover how Malaysian cuisine became a melting pot of Malay, Chinese, Indian, and indigenous influences over centuries of trade and cultural exchange.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.627+08	2026-04-03 11:28:35.627+08	published	\N	\N
3	Understanding Mamak Culture	understanding-mamak-culture	1	The 24-hour open-air restaurants that serve as Malaysia's living room. Why teh tarik and roti canai unite the nation.	The 24-hour open-air restaurants that serve as Malaysia's living room. Why teh tarik and roti canai unite the nation.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.645+08	2026-04-03 11:28:35.645+08	published	\N	\N
4	Family Recipes Passed Down Through Generations	family-recipes-generations	1	Family recipes passed down through generations	Family recipes passed down through generations	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.661+08	2026-04-03 11:28:35.661+08	published	\N	\N
5	Why We Don't Do 'Tourist' Food	why-we-dont-do-tourist-food	1	There's a difference between the food served to tourists and the food locals eat. Here is how to spot the difference and why it matters.	There's a difference between the food served to tourists and the food locals eat. Here is how to spot the difference and why it matters.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.674+08	2026-04-03 11:28:35.674+08	published	\N	\N
6	Why Street Food Is The Soul Of Malaysia	street-food-soul-malaysia	1	From hawker centers to roadside stalls, street food isn't just about eating—it's where communities gather, stories are shared, and traditions are preserved.	From hawker centers to roadside stalls, street food isn't just about eating—it's where communities gather, stories are shared, and traditions are preserved.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.686+08	2026-04-03 11:28:35.686+08	published	\N	\N
7	11 Foods To Try During Hari Raya	11-foods-hari-raya	1	Hari Raya marks the end of Ramadan with a month of celebrations and amazing dishes, many of which can only be found this time of the year.	Hari Raya marks the end of Ramadan with a month of celebrations and amazing dishes, many of which can only be found this time of the year.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.698+08	2026-04-03 11:28:35.698+08	published	\N	\N
8	What "Vegetarian" Actually Means in Kuala Lumpur	what-vegetarian-actually-means-kuala-lumpur	1	In KL, vegetarian food is rooted in Buddhist and Hindu spiritual practice, not wellness trends. The rules are completely different depending on who cooked your food. Here's what you need to know before you order.	**TL;DR:** Vegetarian food in KL is nothing like vegetarian food back home. Here, it's rooted in Buddhist and Hindu spiritual practice, not health trends — and that changes everything about what ends up on your plate. Some dishes include eggs. Some exclude onion and garlic entirely. Some Buddhists only eat vegetarian twice a month. Read this before you order, and you'll eat far better.\n\n---\n\nThe first time someone in KL tells you they're vegetarian, don't assume you know what that means.\n\nBack home — whether that's London, Sydney, or New York — vegetarian usually means one thing: no meat. It's a dietary choice. Maybe ethical, maybe health-related. The rules are pretty clear.\n\nIn Kuala Lumpur, the same word covers something completely different. Vegetarian food here grew out of Buddhist merit-making, Hindu devotion, and Taoist spiritual discipline. These are practices that go back centuries. The food that came from them is some of the most interesting you'll eat in this city — but only if you understand what you're looking at.\n\nWe've been taking people through KL's [vegetarian food spots](http://localhost:4321/tours/dietary/vegetarian) for 14 years. The question we hear most isn't "where do I eat?" It's "why does vegetarian food here work so differently?" This post answers that.\n\n---\n\n## Why Vegetarian Food in KL Isn't What You Expect\n\nKL sits at a cultural crossroads. Three distinct communities have shaped how vegetarian food looks and tastes here: Chinese Buddhist, Tamil Hindu, and increasingly, health-conscious Malaysians following a newer plant-based wave.\n\n[35% of Malaysians now regularly eat plant-based meals](https://www.statista.com/statistics/1075705/malaysia-plant-based-food-consumers/), according to Statista's 2025 data. But that number includes people eating vegetarian for very different reasons. Some are doing it for health. Many are doing it for faith. And the food on their plates reflects that difference completely.\n\nThe wellness trend is real. But it's layered on top of something much older. The Buddhist and Hindu vegetarian traditions in Malaysia weren't imported last decade. They arrived with the communities themselves, generations ago, and took root in neighbourhoods, temples, and family kitchens across the city.\n\nWhen you understand that, the food starts to make sense.\n\n---\n\n## So What Does "Vegetarian" Actually Mean Here?\n\nIn Malaysia, "vegetarian" means something different depending on who cooked your food. Chinese Buddhist vegetarian food typically excludes all meat, eggs, dairy, and the five pungent roots: onion, garlic, chives, spring onion, and leeks. South Indian vegetarian food often includes eggs and dairy, but no beef. The word is the same. The plate can look completely different.\n\nThis trips up visitors constantly. You order something labelled vegetarian at a Chinese Buddhist stall and wonder why there's no garlic flavour. You order at a Tamil restaurant and find egg in your thosai. Neither is wrong. They're just different traditions with different rules.\n\nThe [Chinese Buddhist tradition](https://en.wikipedia.org/wiki/Malaysian_Chinese_cuisine) is particularly fascinating. What you'll find at Buddhist temple canteens and 素食 (sù shí) stalls is often entirely plant-based, long before "vegan" became a marketing word. The five pungent roots are avoided because they're believed to stimulate the mind and disturb meditation. So the flavour base is completely different from what you'd expect — no allium sharpness, more subtle, often sweeter.\n\nSouth Indian vegetarian food follows the Hindu tradition. Eggs and dairy are frequently included. The flavour profiles are bolder: tamarind, mustard seeds, curry leaves, coconut. Banana leaf rice with vegetable curries, thosai with sambar, idli with coconut chutney. Rich, complex, and filling.\n\nSame word. Very different kitchens.\n\n---\n\n## The Buddhist Calendar and the Days Everything Changes\n\nHere's something most visitors never know, and we love watching people's faces when we explain it.\n\nMany Chinese Buddhists in Malaysia eat vegetarian on the 1st and 15th of each lunar month. It's a merit-making practice. A way of honouring the occasion with discipline and restraint.\n\nOn those days, [something shifts in the city's food scene](https://teahouse.buddhistdoor.net/eye-on-southeast-asia-lunch-at-a-malaysian-temples-vegetarian-canteen/). Stalls that normally sell mixed food put out vegetarian menus. Temple canteens run buffets that start at dawn and sell out before lunch. Regular hawker centres fill up early with regulars who only eat vegetarian twice a month but take it seriously when they do.\n\nUncle Chen, one of the vendors we visit on our [Chinatown food walks](http://localhost:4321/tours/kl-street-food), makes his handmade steamed buns every morning. On the 1st and 15th, his vegetarian varieties go first. Always. He's been watching this pattern for decades.\n\nIf you happen to be in KL on one of those days, go early. The food is worth it, and the atmosphere in the stalls and temple canteens is something you won't see on a regular Tuesday.\n\n---\n\n## Does That Mean Vegetarian Food Here Is Always Egg-Free?\n\nNo, and this is probably the most important thing to know before you order. Chinese Buddhist vegetarian food is usually fully plant-based: no eggs, no dairy, no five pungent roots. South Indian vegetarian food regularly includes eggs and dairy. A "vegetarian" label means different things at different stalls, so always ask.\n\nThe simplest way to tell the difference before you order: look for the characters 素食 (sù shí). That's the Chinese term for Buddhist vegetarian food. If you see that sign, you're in a place following the stricter definition. No meat, no eggs, no dairy, no onion, no garlic.\n\nAt Indian stalls, the word "vegetarian" is usually displayed in English or Tamil. The rules are different there: eggs may be in, dairy is common, and the flavour base will reflect it. Neither approach is more "correct." They're just rooted in different spiritual traditions.\n\nThe practical takeaway: when in doubt, ask. Point to the dish and say "ada telur?" (any eggs?). Most stall owners are happy to explain. In our experience, they appreciate the curiosity.\n\n---\n\n## Where This Food Actually Comes From\n\nThe Chinese Buddhist vegetarian tradition in Malaysia came with the Hokkien, Cantonese, and Hakka immigrants who built KL's Chinatown and surrounding neighbourhoods. They brought their temple practices with them. The vegetarian food culture that exists in those streets today traces directly back to those communities, and the family kitchens and temple canteens that kept the tradition alive across generations.\n\nThe Tamil Hindu tradition arrived with South Indian labourers and traders. The banana leaf rice stalls in Brickfields and Little India serve food that connects directly to South Indian temple cuisine: rice, lentils, coconut-based curries, pickles, and pappadum, all made without beef or pork.\n\nWalk through [Kuala Lumpur's food neighbourhoods](http://localhost:4321/tours/locations/kuala-lumpur) and you're walking through that layered history. It's there in the signage, in the ingredients, in the way certain stalls smell different from the ones next to them.\n\nOur Chow Kit Market tour puts you right in the middle of it. The [Chow Kit wet market](http://localhost:4321/tours/chow-kit-market) is where you see the raw ingredients of both traditions side by side: the tofu blocks and mock meat products from the Buddhist suppliers, the fresh curry leaves and dried lentils from the Indian grocers. It's the best single place in KL to understand how these food cultures coexist.\n\nThe [plant-based food industry in Malaysia is growing at 18% annually](https://malaysiaexpatguide.com/plant-based-eating-in-malaysia/) right now, driven partly by a new generation of health-conscious Malaysians. But what makes KL's vegetarian scene genuinely interesting isn't the new wave. It's the century-old foundation underneath it.\n\n---\n\n## How Do I Navigate Vegetarian Food in KL as a Visitor?\n\nThe single most useful thing you can learn: look for 素食 signs in Chinese script. That tells you the place follows Buddhist vegetarian standards — no meat, no eggs, no dairy, no five pungent roots. These spots are everywhere once you know what to look for.\n\nAt Indian restaurants and stalls, ask about eggs and dairy directly. Most places are happy to tell you exactly what's in a dish.\n\nAt Malay hawker stalls, be careful. Many dishes that look vegetarian contain belacan (shrimp paste) or were cooked in lard. This isn't carelessness — it's just that "vegetarian" in the Western sense isn't always the default assumption. We'll cover this in detail in our next guide on the [hidden meat problem in KL hawker food](http://localhost:4321/tours). For now: always ask, and enjoy the conversation that usually follows.\n\nThe spots that locals know are vegetarian — temple canteens, Buddhist stalls, long-running family operations — [often don't advertise themselves](https://www.veganfoodquest.com/vegan-guide-to-kuala-lumpur/). They don't need to. The community already knows. That's exactly where we take guests.\n\n---\n\n## KL Is One of the Great Vegetarian Cities in Asia\n\nHere's the short version of everything above.\n\nVegetarian food in KL is a spiritual category before it's a dietary one. The rules genuinely differ by tradition: Chinese Buddhist food is often stricter than Western veganism, while South Indian vegetarian food follows a completely different logic. And on the 1st and 15th of the lunar month, the whole scene shifts.\n\nOnce you understand the cultural logic, the food makes beautiful sense. It's not confusing — it's rich. And it opens up parts of the city that most visitors never reach.\n\nWe've been navigating this for 14 years. Come eat with us, and we'll show you the spots, the stalls, and the stories that don't make it onto any map. [Have a look at what we do together.](http://localhost:4321/tours/dietary/vegetarian)\n\n---\n\n## Frequently Asked Questions\n\n**Is KL good for vegetarians?**\nYes, genuinely. KL has one of the most developed vegetarian food scenes in Southeast Asia, rooted in Chinese Buddhist and South Indian Hindu traditions that go back generations. The variety is enormous, from temple canteens to hawker stalls to full restaurants. Once you know how to read the signs, you'll eat very well.\n\n**What does 素食 mean and how do I spot it?**\n素食 (pronounced sù shí) is the Chinese term for Buddhist vegetarian food. It means the food excludes all meat, eggs, dairy, and the five pungent roots (onion, garlic, chives, spring onion, leeks). Look for this on signage outside stalls and restaurants — it's your clearest guide to strictly plant-based food in KL's Chinese areas.\n\n**Why do some vegetarian dishes in Malaysia have no onion or garlic?**\nThis comes from the Chinese Buddhist tradition, which avoids the five pungent roots: onion, garlic, chives, spring onion, and leeks. They're believed to stimulate the mind and disturb spiritual practice. If your vegetarian dish tastes unusually mild or subtly sweet, that's likely why. It's a feature, not an oversight.\n\n**What is the Buddhist vegetarian tradition in Malaysia, and why do some people only eat vegetarian twice a month?**\nMany Malaysian Chinese Buddhists observe vegetarian days on the 1st and 15th of the lunar calendar as a merit-making practice. It's a form of spiritual discipline rather than a permanent dietary choice. On those days, vegetarian stalls get busy early and temple canteens run special menus.\n\n**Can Simply Enak accommodate vegetarian guests on their tours?**\nYes, completely. We've been accommodating vegetarian guests for 14 years, and we know exactly where to take you. Our tours include stops that work beautifully for vegetarians — from the Chow Kit Market to Chinatown's Buddhist stalls. Just let us know when you book and we'll make sure every stop works for you.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.708+08	2026-04-03 11:28:35.708+08	published	\N	\N
9	The Hidden Meat Problem: Why Vegetables in KL Aren't Always What They Seem	hidden-meat-problem-vegetarian-kl	1	Ordering vegetables at a mixed hawker stall in KL doesn't make your meal vegetarian. Belacan, lard, oyster sauce and meat-based broths hide in plain sight. Here's where they are and how to navigate them.	**TL;DR:** Ordering vegetables at a mixed hawker stall in KL doesn't make your meal vegetarian. Belacan (shrimp paste) is in almost every Malay vegetable dish. Lard is the default cooking fat at many Chinese stalls. Broths are usually pork-based. Oyster sauce is on almost every plate of Chinese greens. This post shows you where the animal products hide and how to navigate them.\n\n---\n\nHere's something that surprises almost every vegetarian visitor to KL.\n\nYou sit down at a hawker stall. You point to the vegetable dish. It looks perfectly innocent: kangkung, stir-fried with chilli and garlic. No meat in sight.\n\nWhat you can't see is the belacan.\n\nBelacan is fermented shrimp paste. It goes into the wok before the vegetables do, and it's in a huge proportion of Malay vegetable dishes. [Sambal belacan is to Malaysians what ketchup is to the West](https://www.linsfood.com/sambal-belacan-malay-chilli-paste/): ubiquitous, invisible if you don't know to ask, and packed with umami from fermented seafood.\n\nIf you're vegetarian and eating at mixed hawker stalls in KL, this is the guide you need. We've been navigating this for 14 years, and we want to save you the discovery.\n\n---\n\n## What Is Belacan, and Why Is It Everywhere?\n\nBelacan is a fermented shrimp paste made from tiny dried shrimp, compressed into blocks and aged until pungent and deeply savoury. It is one of the foundational flavours in Malay cooking, used the way a French cook uses butter or an Italian cook uses olive oil: as the base that everything else is built on.\n\nThe most famous example is [kangkung belacan](https://www.singaporeanmalaysianrecipes.com/kangkung-belacan-recipe/): stir-fried water spinach with shrimp paste. The name literally tells you what's in it. But most visitors don't read the name. They see a plate of greens and assume it's safe.\n\nBelacan also goes into sambal, which is served alongside almost every Malay dish. It's in nasi goreng. It flavours the broth in some laksa varieties. It seasons the chilli sauces at mixed stalls. You often can't taste it as seafood — the fermentation transforms it into something deeper, smokier, more complex.\n\nAt a dedicated 素食 Buddhist stall, none of this is an issue. At a mixed Malay hawker stall, it's worth asking every time.\n\n---\n\n## The Lard Question at Chinese Stalls\n\nChinese hawker cooking has its own hidden ingredient: pork lard.\n\nLard gives Chinese stir-fries a rich, aromatic quality that vegetable oil can't replicate. Many Chinese hawkers use it by default, even for vegetable dishes. The most famous example is char kway teow: flat rice noodles stir-fried in a blazing hot wok. The smoky, charred flavour comes partly from the lard that coats the pan.\n\nA plate of stir-fried kailan or tofu at a mixed Chinese stall may have been cooked in lard, even if no meat appears on the plate.\n\nThen there's oyster sauce. [Oyster sauce is made from oyster extract](https://en.wikipedia.org/wiki/Oyster_sauce) and is the default sauce for Chinese-style greens across Malaysia. It's in the glossy sauce on your gai lan. It's in the dipping sauce beside your tofu. It's often added without anyone thinking to mention it, because for most diners it's not a concern.\n\nVegetarian oyster sauce does exist and is common at Buddhist 素食 stalls. At mixed Chinese stalls, the default is the real thing.\n\n---\n\n## Which Dishes Are Most Likely to Catch You Out?\n\n**Kangkung belacan** — stir-fried water spinach. Almost always contains shrimp paste, even at non-Malay stalls.\n\n**Nasi goreng** — fried rice. Usually seasoned with belacan, oyster sauce, or anchovies. Vegetarian versions exist only at 素食 stalls.\n\n**Char kway teow** — flat noodles, very often cooked in lard with prawns and lard croutons mixed through.\n\n**Vegetable soups** — the broth at a mixed hawker stall is almost always pork-based or chicken-based, even if vegetables are the only solid ingredient.\n\n**Chinese greens (gai lan, kailan, bayam)** — default sauce is oyster sauce, default cooking fat is often lard.\n\n**Laksa** — the broth contains dried shrimp, prawn paste, or seafood stock in most versions. Vegetarian laksa is available but specific to certain stalls.\n\n**Sambal** — virtually any sambal at a Malay stall contains belacan. Even served on the side, it came from the same wok.\n\n---\n\n## How Do You Actually Navigate This?\n\nThe safest approach: eat at stalls built for vegetarians, not mixed stalls that try to accommodate you.\n\nLook for [素食 (sù shí) signs](http://localhost:4321/tours/dietary/vegetarian) in Chinese script. These stalls use vegetable oil, mushroom-based sauces, and no belacan. The whole kitchen is set up for vegetarian cooking.\n\nAt Indian vegetarian restaurants, the kitchen is built around a completely different tradition. No lard. No belacan. Ask about eggs and dairy, but you don't have to worry about shrimp paste or pork.\n\nAt Malay hawker stalls, the phrase to know is: "Tak mahu belacan, tak mahu ikan" — no belacan, no fish. Some vendors can accommodate this; many cannot, because the belacan goes into the base sambal before individual orders are cooked. It's worth asking, and most stall owners will tell you honestly if they can help.\n\nAt mixed Chinese stalls, ask "Tak guna lard?" (No lard?) and "Ada sos tiram?" (Is there oyster sauce?). Some vendors have vegetable oil and vegetarian oyster sauce available. Many don't.\n\nThe stalls where you can eat freely without asking every question are the Buddhist 素食 stalls and Indian vegetarian places. [Our Chow Kit Market tour](http://localhost:4321/tours/chow-kit-market) takes you through both, so you can see, smell, and taste the difference in a single morning.\n\n---\n\n## Why This Isn't Anyone's Fault\n\nIt's worth saying clearly: vendors using belacan and lard aren't trying to catch you out.\n\nThese ingredients are part of how Malaysian cooking has worked for generations. The concept of "vegetarian" as a dietary default, where you'd expect any restaurant to accommodate you, is a relatively recent idea. In the hawker context, "vegetables" means no meat on the plate. The cooking medium and the flavour base aren't part of that definition.\n\nKnowing this changes how you navigate it. You're not looking for vendors who forgot to mention something. You're looking for the kitchens that were built around a different tradition from the start: the Buddhist 素食 stalls, the Indian vegetarian places, the temple canteens that have been feeding vegetarians properly for decades.\n\nThat's exactly what [we show people on our tours in Kuala Lumpur](http://localhost:4321/tours/locations/kuala-lumpur). Not how to negotiate with mixed stalls, but how to find the stalls that already work beautifully for you.\n\n---\n\n## Frequently Asked Questions\n\n**Is belacan in all Malay vegetable dishes?**\nNot every single one, but most. Belacan goes into sambal, which is the base sauce for a huge number of Malay vegetable dishes. Kangkung belacan, nasi goreng, and most stir-fried Malay vegetables contain it. At 素食 stalls, belacan is never used.\n\n**How do I ask a vendor if there's belacan in a dish?**\nSay "ada belacan?" — is there belacan? Most vendors will answer honestly. If they're not sure, they'll say so. At dedicated 素食 stalls, you don't need to ask at all.\n\n**Is char kway teow vegetarian?**\nAlmost never at a mixed stall. The classic version is made with lard, pork lard croutons, prawns, and sometimes cockles. Vegetarian char kway teow exists at Buddhist 素食 stalls, made with vegetable oil and no seafood.\n\n**Can I ask Chinese hawker stalls to cook without lard?**\nSome can and will. Others use lard as part of the base preparation and can't separate it from individual orders. It's always worth asking, but the most reliable option is a 素食 stall where the whole kitchen runs on vegetable oil.\n\n**Do Indian vegetarian restaurants in KL use belacan or lard?**\nNo. South Indian and Tamil vegetarian cooking has its own tradition that does not include belacan, lard, or pork-based ingredients. These restaurants are a safe option for vegetarians, though it's worth asking about eggs and dairy depending on your needs.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.724+08	2026-04-03 11:28:35.724+08	published	\N	\N
10	How to Find Vegetarian Restaurants in KL, Penang and Ipoh	how-to-find-vegetarian-restaurants-kl-penang-ipoh	1	Vegetarian restaurants in Malaysia don't always advertise themselves. Many are temple canteens and Buddhist community stalls known only by word of mouth. Here's how to find them in KL, Penang and Ipoh.	**TL;DR:** Vegetarian restaurants in Malaysia don't always advertise themselves. Many are attached to temples, run by Buddhist communities, and found through local knowledge. Once you know the signs to look for — the 素食 characters, the timing, the right neighbourhoods — they're everywhere. This guide shows you how to find them in KL, Penang and Ipoh.\n\n---\n\nHere's the thing about the best vegetarian spots in Malaysia.\n\nThey're not trying to attract you.\n\nThe Buddhist temple canteen off Jalan Ampang in KL doesn't need a website. The lunch-only 素食 stall tucked behind the wet market in Ipoh doesn't need Instagram. The decades-old vegetarian shop beside a George Town temple in Penang doesn't need a TripAdvisor listing. The communities that eat there already know exactly where they are.\n\nThis is what makes finding vegetarian food in Malaysia different from finding it anywhere else. You're not looking for restaurants competing for your attention. You're looking for places that exist to serve a community — and have been doing so for generations.\n\nHere's how to find them.\n\n---\n\n## The 素食 Sign: Your Single Most Reliable Guide\n\nThe single most useful thing you can learn: look for the characters 素食 (pronounced sù shí).\n\n素食 is the Chinese term for Buddhist vegetarian food. Any stall or restaurant displaying these characters follows strict vegetarian kitchen standards: no meat, no seafood, no eggs, no dairy, and no five pungent roots (onion, garlic, chives, spring onion, leeks). The whole kitchen is built around these rules. You don't have to ask.\n\nYou'll find 素食 signs in Chinatown, in older neighbourhood shophouses, on hawker stall banners in predominantly Chinese areas. Once you start looking, they're everywhere.\n\nIn KL, walk the older streets around Petaling Street and Chinatown. In [Penang](http://localhost:4321/tours/locations/penang), George Town's pre-war shophouse rows have 素食 stalls tucked between hardware shops and coffee houses. In Ipoh, the Old Town area has a strong Buddhist community and several long-running 素食 spots.\n\nThese are the places locals go. They often have no English signage. They open early and close by midday. And the food is some of the most carefully made vegetarian cooking you'll find in this country.\n\n---\n\n## Temple Canteens: The Spots Nobody Advertises\n\nThe most reliable vegetarian food in KL is often inside or beside a Buddhist temple.\n\n[The Dharma Realm Guan Yin Sagely Monastery](https://teahouse.buddhistdoor.net/eye-on-southeast-asia-lunch-at-a-malaysian-temples-vegetarian-canteen/) on Jalan Ampang is one of KL's most striking religious landmarks. Behind the main monastery building is a large canteen that serves over twenty freshly cooked vegetarian dishes every morning. The food is strictly Buddhist vegetarian: no eggs, no dairy, no pungent roots. A full plate costs around RM 5-8. There's no tourist signage pointing you there.\n\nKun Yam Thong Temple, also on Jalan Ampang, runs a vegetarian canteen during lunch hours. Locals have been coming here for years. There's nothing online to send you there.\n\nThese canteens are welcoming to everyone, not only Buddhists. They're community spaces. But you have to know they exist to walk through the door.\n\nIn Penang, Annalakshmi at the Temple of Fine Arts in Pulau Tikus operates on a donation basis. The cooks and servers are all volunteers. The food is Indian vegetarian, cooked fresh and served buffet-style. Penangites know it well. Most visitors walk straight past it.\n\n[We take guests to spots like these](http://localhost:4321/tours/dietary/vegetarian) precisely because they won't find them on their own — not because they're secret, but because they don't announce themselves.\n\n---\n\n## How the 1st and 15th Changes Your Options\n\nIf you're in KL, Penang or Ipoh on the 1st or 15th of the lunar calendar, your vegetarian options multiply.\n\nOn those days, many Chinese Buddhists observe vegetarian eating as a merit-making practice. Stalls that normally serve mixed food put out vegetarian menus. Vendors who only cook vegetarian twice a month still do it properly, because it's a discipline they've kept for decades.\n\nTemple canteens get busier. 素食 stalls appear at regular hawker centres that aren't there on other days. The vegetarian section of the wet market sees more traffic.\n\nIf you have flexibility on travel dates, this is worth factoring in. [Our Chinatown food walks](http://localhost:4321/tours/kl-street-food) pass through some of these stalls on their active days.\n\n---\n\n## The Apps and Tools That Help\n\n**[HappyCow](https://www.happycow.net/asia/malaysia/kuala-lumpur/)** is the most comprehensive tool for finding vegetarian and vegan restaurants across Malaysia. [Penang alone has 23 fully vegan and 151 vegetarian-friendly restaurants listed](https://www.happycow.net/best-vegan-restaurants/penang-malaysia). [Ipoh has 65](https://www.happycow.net/asia/malaysia/ipoh/). KL has hundreds.\n\nThe caveat: many of the best vegetarian spots in Malaysia, especially temple canteens and older 素食 stalls, are not listed anywhere. HappyCow is a starting point, not the full picture.\n\nGoogle Maps is also useful. Search for "素食" directly in Chinese characters and you'll get results that an English search for "vegetarian" would miss entirely — because these places don't use English to describe themselves.\n\n---\n\n## KL: Where to Start Looking\n\nThe clearest concentrations of vegetarian food in KL:\n\n**Chinatown (Petaling Street and nearby streets):** 素食 stalls, Buddhist vegetarian shops, and temple canteens within walking distance of each other. Go in the morning for the most options.\n\n**Brickfields (Little India):** South Indian vegetarian restaurants, banana leaf rice stalls, and dosa shops. A completely different vegetarian tradition from the Chinese Buddhist spots, and equally good.\n\n**Jalan Ampang (near KLCC):** Two of KL's most well-known temple canteens within a short walk. Budget RM 5-10 for a full, filling plate.\n\nOur [Chow Kit Market tour](http://localhost:4321/tours/chow-kit-market) passes through areas where you'll see both traditions side by side. It's the single clearest way to understand how the two vegetarian food cultures of KL coexist.\n\n---\n\n## Penang: The Richest Vegetarian Scene in the North\n\nPenang has one of the most developed vegetarian food scenes in Malaysia, driven by its large, long-established Chinese Buddhist community and its South Indian Tamil heritage.\n\nThe pre-war shophouses of George Town contain 素食 shops that have been there for decades. Most open for breakfast and lunch only. The food is simple, affordable, and very good.\n\nPenang's Indian vegetarian scene, concentrated around Little India near Penang Road, runs alongside the Chinese Buddhist scene entirely separately. Two different traditions, both thriving, within a few streets of each other.\n\nMak Cik Salmah, one of the vendors we work with in Penang, knows these neighbourhoods as well as anyone. When we're there, she guides us to the spots that don't appear on any app.\n\n---\n\n## Ipoh: Quieter, But Worth the Search\n\nIpoh has a smaller vegetarian scene than KL or Penang, but a strong Buddhist community means 素食 stalls are well-established in the Old Town area.\n\nThe coffee shops of Old Town Ipoh are famous across Malaysia. The vegetarian stalls that share those spaces are talked about less. Arrive before noon: most close by 12:30pm. What you find is genuinely good, and very affordable.\n\n---\n\n## The Honest Answer\n\nThe most reliable way to find good vegetarian food in KL, Penang or Ipoh is to know the community — or go with someone who does.\n\nApps get you started. The 素食 sign gets you most of the way. But the temple canteen with no sign, the 素食 stall that only appears on certain days, the Penang shop that's been vegetarian since before it was a category: those you find through people.\n\nThat's what we've been building for 14 years. [Come eat with us](http://localhost:4321/tours), and we'll show you the ones worth finding.\n\n---\n\n## Frequently Asked Questions\n\n**What does 素食 mean, and how do I use it to find vegetarian restaurants?**\n素食 (sù shí) is the Chinese term for Buddhist vegetarian food. Search for it directly in Google Maps or look for the characters on shop signage. It's far more reliable than searching "vegetarian" in English, as many 素食 stalls have no English signage at all.\n\n**Are there vegetarian restaurants in KL that aren't listed on HappyCow?**\nYes, many. Temple canteens, older 素食 stalls, and community-run lunch spots often have no online presence. They're known within the community but invisible to apps and search engines. Going with a local guide is the most reliable way to find them.\n\n**What time do vegetarian restaurants in KL and Penang open and close?**\nMost Buddhist 素食 stalls and temple canteens open early, around 7am, and close by midday or early afternoon. If you arrive after 1pm, many will be sold out. Indian vegetarian restaurants typically have longer hours. Plan to eat vegetarian in the morning or at lunch and you'll have far more choice.\n\n**Is Penang better for vegetarians than KL?**\nDifferent rather than better. Penang has a more concentrated vegetarian scene within walking distance in George Town, mixing Chinese Buddhist and South Indian traditions. KL has more overall variety but is more spread out. Both cities have excellent options once you know where to look.\n\n**Can Simply Enak help me find vegetarian food in KL, Penang and Ipoh?**\nYes. We've been navigating these cities and their food cultures for 14 years. Whether you join a tour or just want advice, we're happy to point you toward the spots we eat at ourselves.	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.749+08	2026-04-03 11:28:35.748+08	published	\N	\N
11	11 Foods To Try During Hari Raya	11-foods-to-try-during-hari-raya	1	There’s nothing in this world like the food you will find in Malaysia during Hari Raya. Don’t get me wrong, we have amazing food all year round and for special occasions, but the delicacies served during Hari Raya are at the top of most of our tourists’ “must-have” lists.	<p>There’s nothing in this world like the food you will find in Malaysia during Hari Raya. Don’t get me wrong, we have amazing food all year round and for special occasions, but the delicacies served during Hari Raya are at the top of most of our tourists’ “must-have” lists.</p>\n<p>Hari Raya marks the end of Ramadan, or the fasting month, for Muslims worldwide, and especially here in Malaysia. So what follows a month of fasting? A whole month of celebrations and eating amazing dishes, many of which can only be found this time of the year. But you don’t have to be Muslim to enjoy them and experience everything that Hari Raya has to offer. But we can talk about other aspects of Hari Raya later. Let’s dive right in and talk about my personal favorite subject, food.</p>\n<h3>11 Traditional Hari Raya Dishes</h3>\n<h4>Lemang</h4>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_66_4cc0e593c3.jpeg" alt="asset-66.jpeg">\n<p>Lemang can take four to five hours just to cook, but I’m here to tell you it is well worth it. The cooking process alone is unique and has gone unchanged since its beginning. Lemang is essentially coconut milk, sticky rice, and a little salt wrapped in fragrant banana leaves, then stuffed into hollow bamboo sticks and roasted over a fire.</p>\n<p>The banana leaves stop the rice from sticking to the bamboo tube.</p>\n<p>You’ll know Lemang when you see them all lined up in a row being cooked in stalls. They are set against the fire, slightly slanted then turned every so often so everything gets cooked evenly. The Lemang is then served with shredded beef, chicken or even curries of your liking.</p>\n<h4>Ketupat</h4>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_67_7dc1c18a70.jpeg" alt="asset-67.jpeg">\n<p>Another great way to enjoy rice that tourists and locals line up for is Ketupat, the symbol of Hari Raya Like Lemang, Ketupat is unique and can be served in place of traditional steamed rice.</p>\n<p>Ketupat is like a dumpling where rice is packed into a diamond-shaped pocket made from woven palm. It’s then boiled. Once fully cooked, the woven palm wrapper is cut and peeled away so the rice inside can be sliced and served with whatever meal you would normally have with regular rice. I like to encourage our tourists to like to try a combination of Ketupat and Lemang on the same plate with their meat and vegetables since that’s the way I like it as well.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/Rendang_6869ee0f79.jpg" alt="Rendang.jpg">\n<p>It’s impossible for me to write about or even talk about Rendang without craving it. And once you try this traditional festival dish on your next trip to Malaysia, you will have the same experience. It’s the most famous beef recipe in Malaysia, Indonesia, and Singapore. It’s so delicious in fact, that in 2011, rendeng was number one in CNN’s “World’s 50 Most Delicious Foods.”</p>\n<p>An all-time favourite for the festive table, rendang is often prepared with either beef or chicken infused with aromatic spices and coconut milk for hours. Many culinary experts around the world like to refer to rendang as a curry because of the way it’s slowly stewed on low heat and the array of spices, but it’s richer than a curry and has less sauce, so many Malaysians don’t consider it a curry</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Bubur Lambuk</h4>\n<p>Bubur Lambuk is a type of porridge that has many variations, however Kuma, or date powder, is often the main ingredient. It really depends where in Malaysia you go, ut all of the tourists who have tried the many variations say they are all delicious. The recipe traditionally calls for a flavourful combination of anise, cardamom, cinnamon and black pepper, among other spices. Vegetables and meat are added as well.</p>\n<p>This is a dish that can actually be found being served for free at many Mosques and food banks during the month of Ramadan. It is a symbol of the tradition of feeding the poor during the Holy month, which is one of the pillars of the faith.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_64_63a54c56d4.jpeg" alt="asset-64.jpeg">\n<p>While the base ingredients to make this sweet Hari Raya dessert – coconut milk, cane sugar and rice flour – appear unassuming enough, in truth this is one of the most challenging recipes on this list. The cooking process involves continuously stirring the sticky mixture in a hot wok for nine hours. Then it is rolled, portioned out and individually wrapped.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.762+08	2026-04-03 11:28:35.762+08	published	\N	\N
12	Bak Chang – The traditional food of the Chinese Dumpling Festival	chinese-dumpling-festival	1	The Chinese Dumpling Festival is the perfect time to plan your Malaysian getaway and indulge in one of the most delicious delicacies that can be found at any festival time. The Bak Chang or Zhong in Cantonese and Zhang in Hokkien. These are glutinous rice dumplings stuffed with various fillings, and	<p>The Chinese Dumpling Festival is the perfect time to plan your Malaysian getaway and indulge in one of the most delicious delicacies that can be found at any festival time. The Bak Chang or Zhong in Cantonese and Zhang in Hokkien. These are glutinous rice dumplings stuffed with various fillings, and wrapped in bamboo or lotus leaves. They can be triangle shaped, square or round. But the shape doesn’t matter, they are all delicious. Just ask anyone who had been here during festival time and tried them. And they can be sweet, spicy, savory or all of the above. It all depends on who you buy them from and what part of Malaysia they have been influenced by.</p>\n<h4>About The Festival</h4>\n<p>The Chinese Dumpling festival falls on the fifth day of the fifth lunar month, so every year it’s calculated on a different date. For 2019, it will fall on June 7th. Alternately it’s called the Double Fifth festival or the Dragon Boat Festival in Penang.</p>\n<p>It’s believed the festival originated during the Warring States period in China, when Qu Yuan, a well-loved poet, jumped into the Miluo river and drowned himself when his country fell to the enemy. The villagers jumped into their boats and raced out to find and salvage his body, hence the boat races. When they couldn’t find his body, they threw dumplings into the river for the fish to eat, so they wouldn’t eat his body.</p>\n<p>An alternate version tells the story that the admirers of Qu Yuan dropped sticky rice bamboo wrappers into the river to feed him in the afterlife.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/Bakchang_Zhong_Festival_Malaysia2_4b50ed1e83.jpeg" alt="Bakchang_Zhong_Festival_Malaysia2.jpeg">\n<h4>THE ZHONG</h4>\n<p>Though the origins of Zhong, points to Southern China, this heritage food is also well acclaimed across the Malaysian Chinese communities. The Kuala Lumpur (Cantonese speaking KL-ites) refer it as Zong, the Northern Penang name it Bak Chang in the local Hokkien dialect and the Baba-Nyonya Peranakan call this dish Chang. For the purposes of this post from here on out I’ll refer to the dumpling as the Zhong.</p>\n<p>Some of the traditional and modern types of Zhong available are:</p>\n<h4>THE HOKKIEN HAM YUK ZHONG (肉粽) / BAK CHANG IN HOKKIEN DIALECT (肉粽)</h4>\n<p>Salty Meat Dumplings are typically filled with fatty pork belly marinated with five spice herb powders, salted egg yolks, dried shrimp, mushrooms and my favorite chestnuts. The glutinous rice is pre-fried with dark soya sauce to give it a dark brown colour.</p>\n<h4>THE CANTONESE ZHONG / LOK TAU ZHONG (绿豆粽)</h4>\n<p>Another savory Meat Dumplings, favoured by the Cantonese descendants are typically filled with leaner pork meat, yellow mung beans, salted egg yolks, mushrooms and chestnuts. This version is white or paler in colour, the difference with no dark soya sauce added. Occasionally it comes in the form of a pillow longitude shape.</p>\n<h4>NYONYA ZHONG (娘惹粽)</h4>\n<p>A specialty of Peranakan cuisine, the fillings are minced pork with candied winter melon, ground roasted peanuts and taucheo (Chinese soybean paste made from yellow soybeans). Traditionally the dumpling has a bit of blue rice coloured from the butterfly pea flower.</p>\n<h4>KAN SUI ZHONG (碱水粽)</h4>\n<p>Literally translated as “alkaline water Zong”, this is a dessert item or a snack for tea time. The glutinous rice is treated with lye water hence the distinctive yellow color. It’s usually plain, with no filling and if there are It’s a sweet stuffing, for example, red bean paste. It’s often complimented with sugar, gula melaka (Malay for palm sugar) or a delicious local coconut spread named kaya.</p>\n<h4>THE ULTIMATE GIANT ZHONG (WHICH CAN WEIGH UP TO 2 KG)</h4>\n<p>Savoury Meat Dumplings typically filled with fatty pork belly, duck meat marinated with five spice herb powder, roasted pork, salted egg yolks, dried shrimp, mushrooms and chestnuts. Someone once shared that it was a portion to feed and be shared amongst the family.</p>\n<h4>THE VEGETARIAN</h4>\n<p>There are few vegetarian choices from glutinous rice, to healthy grains (of brown rice, red rice or sticky millet) with soy cubes, mushroom, chestnut and black eye peas.</p>\n<h4>THE GRAND FINALE</h4>\n<p>This is a more modern version of the Giant Zong sold by the 5-6 stars hotels and the luxurious ingredients are its greatest prize. From Abalone, to Japanese dried scallops, to expensive quality mushrooms, various healthy and exotic rice grains, to truffles and anything that will lure the consumer to buy.</p>\n<h4>ZHONG IS FAMILY TIME</h4>\n<p>The process of making it is truly an art and takes many cumbersome steps, from purchasing the ingredients to preparation to frying, folding and steaming/boiling. For Malaysian families, everyone gets involved in making Zhong for the festival, and each one of us has our own role and individual strength or skill, for instance folding the bamboo leaves with stuffing and tying them up. We appreciate and respect each others’ roles, even those of the children. When I was a kid I was delighted to eat Zhong after witnessing and taking part in the hours and hours of work it took to make them.</p>\n<p>The most delicious Zhong sold around KL would be freshly homemade from generation-old family recipes, which have been passed on from moms or grandmas. In my heart the best Zhong recipe by far comes from my late grandma, no one has and probably will be able to surpass that level of standard on the ‘delicious-Zhong meter.’ There are no shortcuts to traditional recipes and there are some things in life that are irreplaceable.</p>\n<p>I attempted to make Zhong according to my grandma’s recipe a few months ago. I pulled some family members together and we got everything we needed and went to work. The outcome was a disaster. The taste, texture, and everything fell short of what I was used to.</p>\n<p>There are a few stalls that sell them throughout the year, and they’re pretty good, but I am a little biased toward my family’s recipe, although that shouldn’t stop you from trying them at all. For the best Zhong however, visit us at festival time. That’s when you’ll get the classic recipes. Happy Tuen Ng Jit!</p>\n<p>You might be able to sample a Zhong yourself when you are joining our Kuala Lumpur Street Food Tour or our Penang Street Food Tour, just ask your guide if it’s available and we’ll try our best to get you to taste one.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_64_63a54c56d4.jpeg" alt="asset-64.jpeg">\n<p>While the base ingredients to make this sweet Hari Raya dessert – coconut milk, cane sugar and rice flour – appear unassuming enough, in truth this is one of the most challenging recipes on this list. The cooking process involves continuously stirring the sticky mixture in a hot wok for nine hours. Then it is rolled, portioned out and individually wrapped.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.777+08	2026-04-03 11:28:35.777+08	published	\N	\N
13	Do Malaysians Eat Dog Meat? (and other strange dishes Malaysians eat)	dog-meat	1	Every once in a while on a tour I get the odd question, based on what I call global rumors. One such question and rumor is: Do Malaysians eat dog meat?	<p>Every once in a while on a tour I get the odd question, based on what I call global rumors. One such question and rumor is: <strong>Do Malaysians eat dog meat?</strong></p>\n<p>Although not illegal in Malaysia, the short answer is — no. Malaysians do not eat dog (or cats). This is a major misconception since dogs and cats can at times be found on the menu in other Asian countries like China, South Korea, and Viet Nam.</p>\n<p>However, there are a few what many would call exotic and other call just plain strange, foods in Malaysian cuisine.</p>\n<p><strong>Here are some examples:</strong></p>\n<h4>Frog on a Stick</h4>\n<p>Frog legs aren’t that strange to Westerners and are even quite common in Chinese cuisine, such as frog leg porridge, but the whole frog?</p>\n<p>In a well-known night market called Jalan Alor in Kuala Lumpur, there’s a stall there that serves the whole frog battered and deep fried on a stick. Add a little chili powder on top to kick it up a notch. It’s not easy being green.</p>\n<h4>Bull Penis Soup</h4>\n<p>I have to be honest. Some of the dishes on this list I have eaten and enjoyed and some I have not. I suppose it’s mostly psychological. But this is one I had to try.</p>\n<p>And it’s delicious. The dish is called <strong>Sup Torpedo</strong> and the bull penis is the star. The broth is like a curry and it’s served with Indian spices. Sup Torpedo is said to work wonders for male virility. In some places, you can request the testicles as well, if you are hungry enough.</p>\n<h4>Porcupine Rendang</h4>\n<p>Rendang is a spicy meat dish that originates in the Malay archipelago. It’s prepared by stir-frying meat in a spice paste with coconut milk, lemongrass and tamarind.</p>\n<p>Mainly made with beef, there is one place in Selangor that has taken Rendang to a new level. They are using porcupine meat.</p>\n<p>I’ve never made it out there to try it, but reports tell me it’s a little on the chewy side, however, the spices and preparation take away any of the gamey flavors it may have.</p>\n<h4>Sago Grubs</h4>\n<p>Yup, grubs. Mainly a delicacy in Sabah and Sarawak, many Malaysians don’t even have the courage to twist the heads off these live, squirming worms and pop them in their mouths. But don’t worry, if eating them live is not your thing you can find them cooked in various ways. Stir fry is the most common.</p>\n<p>Truth be told, these little guys are packed with vitamins and minerals and are actually a healthier choice than chicken or beef.</p>\n<p>No one ever said eating healthier was easy, right?</p>\n<h4>Chicken feet</h4>\n<p>As far as weird may go, this one is actually pretty tame and I snack on these all the time. They can be prepared many ways and eaten the same as you would chicken wings.</p>\n<p>Next time you sit down for a Chinese Dim Sum lunch, try a plate of hot and tasty braised chicken feet.</p>\n<h4>Fried Pigs Brains</h4>\n<p>The smooth, custard flavor of these normal-looking meatballs is definitely an acquired taste. This is a specialty item that I have only seen in a select few places.</p>\n<h4>Cow’s Lung</h4>\n<p>Internal organs seem to be a hit in South East Asian countries, and Malaysia fits right in there. It’s not particularly a bad thing when you consider that it’s better than letting it go to waste.</p>\n<p>Cow’s lung is a popular dish commonly called paru or paru Goreng. It is cow lung, brushed with seasoning then fried and goes great with nasi (rice).</p>\n<h4>Crispy Honey Bees</h4>\n<p>This is one that shocked me more than the Sago grubs. But when you stop and think about the nutritional value and can get past the psychological barriers, it makes sense to give these a try.</p>\n<p>Honey bees and larvae are either fried or sautéed and then served up as a snack. They taste a lot like chicken, or so I am told.</p>\n<p>So Malaysians may not eat dogs, but they do have some dishes that make their way onto the “strange” list. At least by Western opinions. There are a lot more dishes, like sup gearbox, satay parut and liver satay that are weird and phenomenal that I’ll discuss in a later article.</p>\n<p>Did I miss any dish you enjoyed on your visit to Malaysia? Or anything that shocked you even more than the above? Let me know in the comments below.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.791+08	2026-04-03 11:28:35.791+08	published	\N	\N
14	Do Malaysians Speak English	do-malaysians-speak-english	1	As a tour guide, it’s always fun to watch the amazed and delighted expressions on tourists’ faces when they have their first real experience interacting with the locals.	<p>As a tour guide, it’s always fun to watch the amazed and delighted expressions on tourists’ faces when they have their first real experience interacting with the locals.</p>\n<p>When it comes to the airport staff and guides, they expect them to speak English, it’s their job, but when they approach a vendor or any random person on the street they prepare to spill out broken sentences backed with exaggerated hand gestures. The Malaysian local smiles and speaks to them in perfect English.</p>\n<p>Well, nearly perfect. It’s called Malaysian English.</p>\n<p>And the response from the tourist is almost always the same.</p>\n<p>“Oh, I didn’t know Malaysians can speak such good English!</p>\n<p>” Yes, Malaysians do speak English, so don’t be shy to go ahead and speak as you normally would and they will reply to you in Malaysian English. Of course, there will be some differences in the usage of words, perhaps phonetics and a little Malaysian flare will be added in. But these types of differences exist even among English-speaking countries such as the US, UK and Australia. So if you’re a first-timer in Malaysia, you’re bound to hear (and even pick up) some local lingo throughout your stay.</p>\n<p>Interesting fact: When it comes to language — or languages, I should say, Malaysia hosts an impressive 137 languages, dialects and indigenous sub-dialects throughout the nation. Let’s’ take a look at languages in Malaysia, so you’ll have a better understanding of what to expect and to feel a little more at ease.</p>\n<h4>Maylay: The Official</h4>\n<p>So this is where it might get a little confusing. Malay is the official national language of Malaysia, which is broken up into ten dialects. Of those, Bahasa Melayu is the official, standardized dialect which is also spoken in Indonesia, Singapore, Brunei and Thailand for a total of about 18 million speakers worldwide. So when we use the word, Malay, to describe the official language, we are referring to the Bahasa Melayu dialect. Coincidentally, Indonesian, spoken by 170 million people, is also a form of Malay.</p>\n<p>The earliest known record of Malay is found on inscriptions in southern Sumatra and on the island of Bangka, and dates back to 683-6 CE. At that time it was written in Indian script and heavily influenced by Sanskrit. It was transformed in the 14th century to Arabic, then again in the 17th century to the modern Latin alphabet.</p>\n<h4>British English</h4>\n<p>By the mid-18th century, the British had set up trading posts on the Malay peninsula. With them, they brought politics, goods for trade and English. Since 1819, the British already had control of Singapore and English began to have an influence on the Malaysian language, and vice versa. Words like paddy, lorry, amok, rattan, bamboo, and sarong are just a few examples of Malay infiltration into the English language.</p>\n<p>The English used in Malaysia today is based on British English and is called Malaysian English. They follow British spellings, however, American slang is strong, especially among Malaysian youth.</p>\n<p>Like Malay, English plays an important role to bridge the gap between dialects and languages, such as among Chinese or Tamil speakers, so they can communicate comfortably. When talking to people who don’t understand their language, they will instead use Malay, English or a mixture mentioned before, Manglish.</p>\n<h4>Manglish or Malaysian Standard English (MySE)</h4>\n<p>This is where the fun begins. This is such a fun language to listen to and even more fun to speak, And it’s almost impossible not to pick up a little bit, even on a short tour.</p>\n<p>About a month ago I overheard a tourist talking to her daughter back home in the US. Her and her husband were on their second trip to Malaysia and she was having a little trouble with the connection, so she was talking a bit loud. What caught my attention was when she said “See HOW la,” which is Manglish for something like “I’ll see and let you know.”</p>\n<p>The entire group stopped and stared at her, myself included then we all erupted with laughter when she had realized what she said. And with an almost perfect accent! This isn’t the first time I have heard tourists speaking Manglish and I always get a kick out of it.</p>\n<p>Let me give some examples of Manglish and how certain words are used, so you’ll have an idea of how the blend of the two languages fit together.</p>\n<p>Warning: Manglish can be addicting — please use Manglish responsibly.</p>\n<h4>Digging into Manglish</h4>\n<p>Manglish shouldn’t be confused with Malaysian English. Even though they may have similar names, unlike Malaysian English which follows the rules with some local flare added, Manglish doesn’t always follow the grammatical structure of British English.</p>\n<p>Manglish also has influences from other languages as, Hokkien, Mandarin, Cantonese, and Tamil.</p>\n<p>Take note: As with any country and language, Manglish can vary from region to region in its usage and slang according to certain influences.</p>\n<h4>La</h4>\n<p>Understanding “la” is fundamental. It can be used in a variety of ways in daily communication and describes different kinds of emotions, but it really has no specific meaning.</p>\n<p>• Frustration – what la</p>\n<p>• To emphasize – ya la</p>\n<p>• Feeling so so – OK la</p>\n<p>• Trying to chill – come on la</p>\n<p>• To ask – serious la?</p>\n<p>• Denying – no la</p>\n<p>Example:</p>\n<p>You to the vendor: Can you give me a discount?</p>\n<p>In Manglish: Ei, cheaper la!</p>\n<p>There’s no definite answer to where the usage of “la” came from, however, the Chinese do make use of “lah” and lay claim to its influence.</p>\n<p>Here are a few interesting words used by locals that have a different twist on their original meaning.</p>\n<h4>Boss</h4>\n<p>Only used with males, it literally means what it’s supposed to mean, but here in Malaysia, it’s widely used as a sign of respect or to make someone feel important. It’s not an official calling, but more of a respectful way to address someone. Even, if we are in the Mamak restaurant, it’s normal to call the waiter boss.</p>\n<p>Example:</p>\n<p>Loan officer: Your application is denied because you don’t meet the qualifications.</p>\n<p>You : Please la, boss. Can’t you help me this time? Can la, boss?</p>\n<h4>One</h4>\n<p>This one can be confusing. No pun intended. When a local uses the word “one” they aren’t referring to the number. It’s used more for emphasis.</p>\n<p>Example:</p>\n<p>Local: So handsome one. Going out with leng loi is it?</p>\n<p>Meaning: So handsome! Going out with a girl?</p>\n<h6>Spender</h6>\n<p>This isn’t what you would think it is. This is not referring to a person who likes to spend lavishly on things they don’t need. No, in our local lingo spender means a male’s brief. Yes, you read correctly. Spender is underwear. I don’t think an example is really needed here.</p>\n<h4>Tackle</h4>\n<p>For football fans, this word has a pretty common meaning, kill the guy with the ball. In other places in English, it can be used to describe taking on a huge problem or challenge. It can also mean fishing gear. In Manglish, it means none of these. Here is an example of a bit of a gap between English and Manglish.</p>\n<p>If you hear a local saying he wants to tackle a girl, please don’t call the police. In Manglish, “tackle” means to get a girl’s attention.</p>\n<p>The Mix Doesn’t Stop There</p>\n<p>Manglish has a converse side to the above. Besides English words being used in different variations, Malay words make their way into English sentences.</p>\n<p>Here are some examples of how Malay words are used in conjunction with English.</p>\n<h4>Tapau</h4>\n<p>Tapau means to take away or pack up the food.</p>\n<p>Example:</p>\n<p>(To the waiter) Boss, can you tapau this chicken and rice for me?</p>\n<p>Bos, tapau chicken rice, can?</p>\n<h4>Kautim</h4>\n<p>This word comes from Cantonese and means “to settle” as in to finish some work or to settle a problem.</p>\n<p>Example:</p>\n<p>Boss: Lee, don’t forget to update me on that deal tomorrow.</p>\n<p>Lee: Don’t worry boss. I will kautim it for you. Other interesting words you may hear:</p>\n<h4>Mat Salleh</h4>\n<p>This word is referring to westerners, but not in a derogatory way.</p>\n<p>Example:</p>\n<p>Local (to the taxi driver): Tolong jap tunjuk Mat Salleh tu macam mana nak gi Kuantan.</p>\n<p>Meaning: Please help to assist the westerner, he wanted to go to Kuantan.</p>\n<h4>Jambu</h4>\n<p>Jambu’s original meaning was supposed to be a guava fruit but has been transformed to refer to a cute boy like the author of this article and Korean boy bands.</p>\n<p>Other Dialects and Influences The British were not the only outside culture to make its mark on Malaysia. For instance, In southern Malaysia, Mandarin is widely spoken and taught in schools due to the high Chinese-Malaysian population. They also speak other Chinese dialects such as Hokkien, Cantonese, Hakka, Hainanese, Hok-chew, Yue, and Min. However, a lot of the smaller dialects are facing extinction as Mandarin becomes more dominant.</p>\n<p>Tamil is another popular language used by the Indian-Malaysians. Sinhalese is a language mainly by the Sri Lankan population and Thai is spoken in some parts but is considered a minority language.</p>\n<h4>Indigenous Languages Of Malaysia</h4>\n<p>There are over 30 native tribes in Malaysia each with its own unique ancestral language including sub-dialects. Kazadandusuns and Iban are the most recognizable among the native languages.</p>\n<p>Don’t feel pressured to learn a whole new language before your vacation. Although the locals do appreciate the respect for their mother tongue, they are always more than happy to practice their English with a real westerner.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.807+08	2026-04-03 11:28:35.807+08	published	\N	\N
15	A Tourist’ Guide To Eating Durians in Malaysia	eating-durians	1	When you come to Malaysia you will hear about a flavour that is as common as vanilla in the West. It’s called durian. And in my opinion — it’s delicious.	<p>When you come to Malaysia you will hear about a flavour that is as common as vanilla in the West. It’s called durian. And in my opinion — it’s delicious.</p>\n<p>I actually consider myself a bit of a durian connoisseur. You’ll hear me or other tour guides talking about durian puffs, durian ice cream, durian milkshakes, durian fritters, durian shaved ice and durian candy….</p>\n<p>But when you first see the actual durian fruit you would never think it to be anything edible, with its tough, thorny exterior. And when you smell a durian, you definitely won’t think it’s anything edible.</p>\n<p>Yes, durians stink.</p>\n<p>I often wonder how the vendors can stand it. The durian’s ungodly smell is so powerful and lingering that it’s literally banned in many hotels, aeroplanes, hospitals, malls and other public areas. The pungent odour has been described by tourists as smelling like sewage, gasoline, or even rotten vegetables wrapped in an old sock.</p>\n<p>Now I don’t want to suede you or set your prejudices against taking the plunge into your next exotic fruit adventure. Durian is, as they say, the King of Tropical Fruit. It “stinks like hell, but tastes like heaven”.</p>\n<p>If this is your first time hearing about Durians or you are keen to expand your knowledge, here’s a great introduction to eating Durians Malaysia.</p>\n<h4>What Exactly Is Durian?</h4>\n<p>Interesting fact, the word “<strong>durian</strong>” actually comes from the Malay word duri, meaning “thorn”. Durian is a large fruit from one of the nine fruit-bearing species of durian tree, and not all of them taste the same. It can look similar to jackfruit, but the durian has a thick, thorny rind ranging in colour from a husk green to brown, whereas the jackfruit has more of a green, pebbly rind.</p>\n<p>It can come in a variety of shapes and sizes, depending on the species, from oblong to round and it typically weighs about one to three kilos (2 to 7 lb). It can grow as long as 30 centimetres (12 in) and get up to 15 centimetres (6 in) in diameter.</p>\n<h4>Why Is The Durian Considered The King Of Tropical Fruit?</h4>\n<p>I’ll say it again. It’s out of this world delicious. Once you get through that thorny exterior and past the smell, you’ll find a sweet, rich and creamy pulp that Malaysians put in many of their food items.</p>\n<p>For example, you can find it in cakes if you hop inside our local cake shop called <strong>Secret Recipe</strong>. If Ice cream is your thing, <strong>Inside Scoop</strong> is the place to go for durian ice cream. And if you are a chocoholic like me, check out <strong>Beryl’s Chocolate Shop</strong> where they use real durian flesh in their chocolate.</p>\n<p>I recently spoke with a tourist couple who just got back from Temerloh, Pahang which is about 130 kilometres from Kuala Lumpur. They were raving about the Ikan <strong>Patin Masak Tempoyak (Tempoyak</strong> cooked with fresh Silver Catfish) which is a dish Temerloh is famous for.</p>\n<p>Tempoyak is a Malaysian condiment made by mixing some salt with the flesh of the durian and letting it ferment at room temperature for three to five days. Its normally made with the lower class durian during peak season when they are in excess. Another great dish to try is Tempoyak with Petai beans.</p>\n<h4>I’m seriously getting hungry.</h4>\n<p>Durian are like apples — in a way</p>\n<p>Like apples, durians come in different varieties, so don’t expect them all to taste the same or to taste like any other fruit you have ever tried in the West. They have a unique explosion of multi-dimensional flavours that’s a combination of sweet, savoury and creamy all at once.</p>\n<p>Some have compared it to whipped cream with a hint of chives, whereas others have said it’s like garlic and caramelized sugar. Everyone’s palate is different and will detect different things. I sat with some tourists a while ago as they tasted durian for the first time. One said it was like butterscotch pudding with almonds, but another guy said it was like red wine simmered in onions.</p>\n<p>So which variety of durian is best? Again it’s like apples. Some prefer the pulpy Washington red whereas others like the crispness of a granny smith. You will have to decide which you like best.</p>\n<h4>Let’s go through some of the varieties and how they look and taste:</h4>\n<p><strong>Durian kampung</strong> — Probably the least expensive to find is the durian kampung. It tends to be sweeter, but the taste can be a bit unpredictable. It may not necessarily have the most flesh and some may contain big seeds so it may not be as filling as expected, which is a good thing so you have room to try more.</p>\n<p><strong>D21 and D24</strong> — These are the best entry-level durian known mainly for their consistency in a bittersweet taste and creamy texture. What makes this durian good for first-timers is that it has a mild aroma, so it won’t be too overwhelming.</p>\n<p><strong>Musang King or Mao Shan Wang</strong> — This is the most expensive and probably the best-tasting durian. It has a distinctive star shape on the bottom, so make sure you check for that before forking over the big cash. Mao Shan Wang is a rich and creamy durian with several layers of flavour from bitter to sweet.</p>\n<p><strong>Black Thorn</strong> — This one originated in Penang and has a dark, rich yellow pulp that’s sweet and custardy. You can tell the blackthorn because the thorns are darker on the ends.</p>\n<p><strong>Red Prawn or Udang Merah</strong> — The taste of this one really depends on the age of the tree it came from, which you would have no way of telling so it’s best to ask the vendor. The younger the tree, the sweeter the fruit. Older trees produce more bitter fruit. Another unique characteristic is its reddish-orange colour compared to the creamy yellow and whites of most other durians.</p>\n<p><strong>D88</strong> — I had one of these last weekends and it filled me up so much that I skipped lunch. It had a great flesh-to-seed ratio and a bittersweet fibrous texture with a bit of an alcoholic aftertaste.</p>\n<p><strong>Golden Phoenix </strong>— This durian is grown from older trees that are only available in Johor. It has a pungent odour and a thin skin that is easily opened. These durians lean to the bitter side and tend to be watery, but a lot of people are drawn to this texture and taste.</p>\n<p><strong>XO Durian</strong> — This pale yellow durian can almost taste like an alcoholic drink because of its fermented, watery flesh.</p>\n<p><strong>Raja Kunyit </strong>— This one is my favourite. It has a firm, smooth, custard-type texture and is sweeter with just a hint of a bitter aftertaste. What’s great about this one is it’s almost seedless. It has just tiny, underdeveloped seeds that can be easily removed (or spit out) from the flesh.</p>\n<p><strong>Tawa or D162 Durians</strong> — This is another fleshy durian with small seeds. It’s almost pure white and has a light, creamy texture that is less sweet than other varieties.</p>\n<p><strong>Hor Lor Durians</strong> — Another one that originated in Penang, it’s a favourite of some because of its drier consistency and sweeter taste.</p>\n<p>The above is just a brief introduction to the exciting world of durian. There are many other varieties to taste and savour and even more are being developed by durian farmers all over the country. Are you now ready to be a durian connoisseur?</p>\n<h4>How Do You Choose A Quality Durian?</h4>\n<p>It’s important for the budding durian expert to be able to know how to choose a good, quality durian. I’ve found sometimes vendors may try to pass off the old stocks to the tourists and less experienced ones, so it’s best to ask around for the more reputable ones. Even better to take a guide with you.</p>\n<p>So to understand a little more about what to look for when picking a durian, you have to keep in mind that durians are not “picked” from the trees. Instead, the harvesters in Malaysia wait for the durian to fall and this usually happens at night. They’ll sleep by the tree (but not under it! That’s way too dangerous!) waiting for the durian to hit the ground.</p>\n<p>Once the durian falls from the tree, it’s ripe and should be eaten within about four to five days. That’s not a very big window to hit.</p>\n<p>But trust me, you’ll want to pick durian that is in this range. Unripe durian is tasteless and has thick, leathery flesh that’s difficult to pull away from the seed, and the overripe will be too bitter and have a stronger fermented taste. The best time to find and indulge in durian is June – July.</p>\n<p>When you pick up the fruit, give them a shake. If you hear the fruits knocking against the shell, chances are the fruit is dry and has a good consistency. When the knocking sound isn’t there, the fruit is likely more wet and soggy. Another thing to look for is thick thorns and avoid any that are cracked on the bottom. This is a sign the fruit has over-ripened.</p>\n<p>When you pick up the durian, it should feel light and not heavy and waterlogged. Next, give it a good whiff down the seams. If you are struggling to get any scent or get a slight raw fruit smell, then it’s under-ripe. If the smell knocks you over, then it is probably overripe. Even though the durian has a strong odour by nature, you want to find a nice, sweet medium between little smell and overpowering. In Malaysia, you will find that most durian sellers cut a triangular shape into the durian to give the buyer a better idea of the quality they are buying.</p>\n<p>Durian prices and grades vary depending on the species and their weight.</p>\n<p><strong>Expert Tip:</strong></p>\n<p>Look out for wormholes in the durian skin, when you find them you know that someone had a taster before you did. The older generation takes these worms as a sign of a good quality durian, some even go as far as eating the worms.</p>\n<h4>How To Open Your Durian</h4>\n<p>Now that you got your durian, how are you going to open the darn thing? Depending on which variety you chose, this can be a daunting task. It takes some skill, but with practice, anyone can do it.</p>\n<p>First, flip the durian stem side down. You’ll want to use some gloves or a kitchen towel to handle the durian. Then insert a knife in the bottom centre as far as you can get it and wiggle it back and forth. Doing this should rupture the seams.</p>\n<p>Pull the knife out and grab the durian with your fingers inside the opening from the knife. By using sheer, brute force, pull open your durian into two halves.</p>\n<h4>Eating Durian</h4>\n<p>Durian is naturally rich in potassium, dietary fibre, iron, vitamin C, and vitamin B complex which makes it excellent for improving skin health, and building muscle, and is good for healthy bowel movements. Further, it also contains minerals like manganese, copper, iron and magnesium and is a great source of potassium and the essential amino acid, tryptophan.</p>\n<p>In conventional Chinese wisdom, durian fruit is eaten along with purple mangosteen fruit, a fragrant and slightly acidic fruit that tastes kind of like a mix between orange and peach. The belief is that the “heaty” nature (ying) of durian will be balanced by the cooling properties (yang) of mangosteen.</p>\n<p>Also, being that durian is “heaty”, the rule is they should not be eaten with other “heaty” foods or beverages such as alcohol, coffee, curry or tom yum. And it can be a powerful aphrodisiac.</p>\n<p>There is no scientific evidence to back these claims, however, I say why to risk it and just go with what they say.</p>\n<p><strong>Pro Tip:</strong> To get rid of the aftertaste that may linger after eating durian, try drinking some coconut water and pop a breath mint. The coconut water will also help reduce the odour of the “durian burp”.</p>\n<h4>Durian Farms</h4>\n<p>Durians are planted on a large scale in Penang state and also in Pahang and are one of the most valuable crops for Malaysia. Starting in June to July and lasting until September, truckloads of durian can be seen all over Malaysia, originating from places like Johor and Pahang.</p>\n<p>An interesting recent study has proven that the flying fox bat, once considered a pest, is mainly responsible for the pollination of the durian flowers. So without the bats — no durian!</p>\n<p>I love taking the drive out to the farms, getting my hands on the best Durians when they are in season and enjoying the beautiful scenery. Interested in joining? Or do you have a favourite Durian? Let me know in the comments below.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.821+08	2026-04-03 11:28:35.821+08	published	\N	\N
16	Is It Safe To Eat Roadside Food In Malaysia?	food-safety	1	Last week I was out with guests on a tour from the West and, after my typical lengthy descriptions of the best street foods to eat, one of my friends pulls me aside and whispered:	<p>Last week I was out with guests on a tour from the West and, after my typical lengthy descriptions of the best street foods to eat, one of my friends pulls me aside and whispered:</p>\n<p>“Looks great, but — is it safe to eat?”</p>\n<p>I actually get that question quite a bit. We’ve all heard horror stories about the dangers of eating when traveling abroad. Especially to underdeveloped nations that may not have the strict food safety laws and guidelines that most Western countries do. Many people are concerned they might die from food poisoning or end up spending their entire trip clinging to a bottle of Pepto.</p>\n<p>It’s not an uncommon fear and there’s always a risk. However, if you follow just a few rules of thumb listed below and pay closer attention to things you most likely do already, like washing your hands before you eat, then you should have no trouble enjoying all the great street foods Malaysia has to offer.</p>\n<p>Here are some things to consider before heading out to the hawker:</p>\n<h4>Let Your Stomach Adjust</h4>\n<p>When I first had Malaysian food, it was the spices that had me popping tums more than anything else. Take it slow and be careful for the first few days not to overindulge in spicy foods if your gut isn’t used to it. Give your stomach a little time to get localized.</p>\n<p>Remember, there are other risks as well like the heat and dehydration (especially if alcohol is part of your nightlife) that can also have an affect on how you digest your food. I always like to carry a good bottle of water with me whenever I hit the streets.</p>\n<p>Speaking Of Water…</p>\n<p>Although tap water in the larger cities is deemed safe to drink, it’s best when coming from the West to stick to bottled water while on the streets. Extra filtration has been added for water in restaurants and most likely your hotel and the water used for teas and soups have been boiled.</p>\n<p>But what about the ice? Ice is normally safe as most vendors buy their ice from a licensed distributor who used only filtered water. If you find a vendor making their own ice from tap water, best to move on.</p>\n<h4>Look For Running Water</h4>\n<p>Keep an eye out for stalls that have access to running tap water and are using soap to wash their utensils, chopstix, cups and plates. Generally speaking, Malaysians are in the habit of washing everything before serving, however, you may see some that are merely wiping down the plate or utensil with a tissue or cloth. Avoid these stalls.</p>\n<p>You may see a stall with a pot or bucket of water that you may think they are using for washing utensils, plates and cups. This is actually for washing your hands.</p>\n<h4>Best Times To Visit The Stalls</h4>\n<p>Stalls like to prepare for the coming rush at certain times of the day, so some items may be prepared in advance to accommodate for the high volume. Strategically plan your street food snacking to coincide with mealtimes like breakfast, lunch, and dinner. Doing this will ensure you are getting the freshest and hottest food.</p>\n<p>I always go for items that are within just a few minutes of being cooked and bypass anything that looks like it may have been sitting for a while. One thing to remember is the food “danger zone” is roughly 5 to 60 °C (41 to 140 °F). This is the ideal temperature range for bacteria and food pathogens to thrive.</p>\n<p>Deep-fried foods have been put through temperatures well above this and eggs and other foods that are cooked to order are also normally safe to eat. Rice that has been around for a while should be avoided.</p>\n<h4>Read Food Blogs</h4>\n<p>Food bloggers are constantly on the Malaysian streets searching for the best street food stalls to write about, so credibility goes a long way. If a blogger has featured a vendor, chances are the quality and standards of hygiene and taste are pretty high.</p>\n<p>Join the Simply Enak Food Guide. I’ll visit a vendor several times and at various times throughout the day to see how they operate and taste the quality, then report back and let you know if I recommend it.</p>\n<p>And lastly…</p>\n<h4>Find The Busier Stalls</h4>\n<p>Look for the busier stalls that have the most locals in line. This means they will be putting up the freshest cooked food as the turnover will be high, and probably either the best prices or the most delicious. Or both!</p>\n<h4>Bubur Lambuk</h4>\n<p>Bubur Lambuk is a type of porridge that has many variations, however Kuma, or date powder, is often the main ingredient. It really depends where in Malaysia you go, ut all of the tourists who have tried the many variations say they are all delicious. The recipe traditionally calls for a flavourful combination of anise, cardamom, cinnamon and black pepper, among other spices. Vegetables and meat are added as well.</p>\n<p>This is a dish that can actually be found being served for free at many Mosques and food banks during the month of Ramadan. It is a symbol of the tradition of feeding the poor during the Holy month, which is one of the pillars of the faith.</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_64_63a54c56d4.jpeg" alt="asset-64.jpeg">\n<p>While the base ingredients to make this sweet Hari Raya dessert – coconut milk, cane sugar and rice flour – appear unassuming enough, in truth this is one of the most challenging recipes on this list. The cooking process involves continuously stirring the sticky mixture in a hot wok for nine hours. Then it is rolled, portioned out and individually wrapped.</p>\n<p>All this effort does pay off beautifully at the end when you bite into an incredibly rich and flavourful dessert that’s as popular with adults as it is with children. Doldol can also be found in durian, soursop, apple, jackfruit, and milk flavours.</p>\n<p>Interestingly, rendang contains natural preservatives due to its recipe which calls for a unique fusion of ground spices and coconut milk, which gives the dish a shelf life up to four weeks.</p>\n<h4>Lontong</h4>\n<p>Lontong is a combination of nasi impit, vegetables and meat, served together with a savory coconut milk base. Lotong can be eaten as a full meal since it has everything included in it.</p>\n<p>Depending on the region it’s prepared in, there are several variations. Some cooks include peanuts in the gravy while others add tempeh or a hard-boiled egg. The bright orange coconut soup is usually served separately from the ingredients to avoid softening the rice cakes.</p>\n<h4>Serunding</h4>\n<p>This is a popular snack during Hari Raya and it’s a must try in my opinion. Its what we call a “meat floss” and can be made from any meat like beef, chicken, anchovy, prawn, and fish. The meat is seasoned and cooked until dry, sort of like a way to preserve it.</p>\n<p>It can be eaten in many different ways too like a filling for pastries, on a bun or even as a burger.</p>\n<h4>Sayur Lodeh</h4>\n<p>Sayur Lodeh originated in Indonesia, but has made its way into Malaysia and we accepted with open arms. A great Hari Raya tradition, this is a hearty coconut stew made with a variety of vegetables like eggplant, green beans and long beans to name a few. It can also have tofu, temph or really anything the cook likes.</p>\n<p>Sometimes tumeric can find its way into the dish so if you see a version that has a yellow tint to it, don’t be alarmed. It’s just a little extra flavor. Go for it.</p>\n<h4>Kuih-muih</h4>\n<p>What can I say about Kuih-muih? If you are into desserts and sweets as much as I am, you are going love this traditional, sugary Malay dessert. This is almost an unlimited collection of bite sized biscuits, cakes and jellies with an astounding array of flavors. Kids go crazy for them.</p>\n<h4>Asam Pedas</h4>\n<p>If a spicy tart fish stew sounds good to you (it does to me) then you will have to try Asam Pedas. This is a dish that is mainly found in homes on the Hari Raya table, however some restaurants will serve it during celebration time.</p>\n<p>Again this is a stew that slow cooks for a long time as the broth and spices seep into the meat and you end up with a delicious meal.</p>\n<h4>Satay</h4>\n<p>Now satay is something can be found normally year round. Why si it on this list? Satay is meat on a stick (chicken, beef, lamb), grilled over charcoal to perfection and served with pineapple or sliced cucumbers and a spicy peanut sauce. Need I say more?</p>\n<p>This is actually very popular during Hari Raya since it’s a great accompaniment to lumbong or ketupat.</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.834+08	2026-04-03 11:28:35.834+08	published	\N	\N
17	9 Hidden Gems To Visit In Kuala Lumpur	hidden-gems-in-kuala-lumpur	1	If you’ve been to Kuala Lumpur before, you may have already seen many of the larger attractions from KLCC to the Botanical Gardens. A lot of tourists we get are return visitors and are looking for something a little more or off the beaten path. So we have decided to put together a list of attraction	<p>If you’ve been to Kuala Lumpur before, you may have already seen many of the larger attractions from KLCC to the Botanical Gardens. A lot of tourists we get are return visitors and are looking for something a little more or off the beaten path. So we have decided to put together a list of attractions for those who are keen to explore an alternative side of Kuala Lumpur.</p>\n<p>All of the below suggestions are within walking distance of the Chinatown area.</p>\n<h4>1. Zhongshan Building – Jalan Rotan – Kampung Attap</h4>\n<p>I am hearing a lot of feedback from tourists lately about this one. Back in the 1950s the Zhongshan Building housed a row of interconnected shophouses. Since then over the years it has been the home to Selangor Zhongshan Association, a frozen foods distributor and various local merchants. So it’s a unique building with a lot of history.</p>\n<p>Today it is back in operation as a three-building independent arts and research hub. Indie you will find the art gallery of OUR art projects, a contemporary art gallery founded by Snow Ng and Liza Ho. After being funded by ThinkCity, a not-for-profit subsidiary of Khazanah Nasional. They opened their art gallery on the first floor. However since there was so much extra space, they decided to lease some of it to other artists.</p>\n<p>Also inside you will find Tandang Records music store, Tommy le Baker’s Kampung Attap outpost and a lot more.</p>\n<h4>2. Peter Hoe Evolution – Boutique shop</h4>\n<p>This is the place to find the perfect souvenir. Peter Hoe Evolution is a unique and amazing shop in Jalan Doraisamy (also known as The Row KL) with a wide selection of homeware, clothes and souvenirs. It’s broken up into three sections: a retail store, boutique and café where you can lounge on silk pillows and enjoy goodies baked by Malaysia’s own Peter Hoe himself.</p>\n<p>The retail store fuses Asian and modern styles with its handmade crafts and merchandise designed by Peter Hoe and made by many local artisans and craftsmen. Here you can find beautiful woven mats, rattan baskets and other treasures. Recently a tourist couple came back with some beautiful handmade candles and brightly colored flowery shirts and I knew right away they had been to Peter Hoe Evolution.</p>\n<p>Also inside is a boutique with clothes designed by local fashion designer Justin Yap.</p>\n<h3>3. Malaysian Cartoon and Comic house</h3>\n<p>If you don’t already associate Malaysia with classic cartoons and comic art, after you visit this place you will. If you are a fan of comic books, comic strips and cartoons then this is the place to go.</p>\n<p>The Malaysian Cartoon and Comic house and sits right in Taman Botani Perdana (KL Lake Gardens) The walls are lined with hundreds of comic dating back to the 1930’s. These comics predate modern methods and were hand drawn and words delicately added. Don’t worry, many have English subtitles or explanations so you can enjoy them too.</p>\n<p>A Lot of the earlier comics feature Malaysian heroes and local legends like Mah Suri, Puteri Langkawi. You’ll also find some political satire comics and magazine and newspaper drawings.</p>\n<p>What a lot of history buff tourists find interesting are the Japanese and British comics that were used as wartime propaganda to try and get the Malaysian people on their side.</p>\n<h4>4. PS150 bar</h4>\n<p>So we are talking about hidden gems and hidden is the word to describe the PS150 bar. PS150 is a classy brothel-styled cocktail bar on Petaling Street in Chinatown. And it’s not that easy to find. Tucked away under the popular cafe, Merchant’s Lane next to a stationary store, it’s fashioned like a pre-war speakeasy from a time when alcohol was illegal.</p>\n<p>You enter through a toy shop where you’ll find the PS 150 dressed in a very Chinese style with Far East accents, a reminder of the earlier days of Kuala Lumpur. There are three parts: The main bar with some of the best cocktails in town, the outside courtyard and they have private “opium den” booths available as well if you are looking to get dressed up and spend some quality alone time with your significant other.</p>\n<h4>5. BarZehn</h4>\n<p>Speaking of the speakeasy, hidden behind two faded blue doors with peeling paint on graffiti ladend street, you’ll find one of Kuala Lumpur’s best-kept secrets. And I’m letting the cat out of the bag.</p>\n<p>Once through the blue doors, you’ll follow a hallway to a flight of stairs. Take those stairs down and push through a couple more doors to find a dimly lit, opulent and plush lounge with vintage posters lining the walls.</p>\n<p>Literally meaning the “Eight Treasures”, BarZhen is a reference to a famous alcoholic concoction in Chinese herbology that has been used as a remedy for a variety of illnesses. Many of the bar’s signature cocktails follow a traditional Chinese style including using potent herbs to give you an eye-opening jolt.</p>\n<p>In the mood to try a cup of spiked tea? Try BarZhen’s best-selling drink, Lycium Maca Osmanthus Tea. You can also find great drinks infused with Ginseng, Tongkat Ali, and Wolfberry.</p>\n<h4>6. Tian Jing Hotel</h4>\n<p>The phrase Tianjin literally translates from Chinese meaning “Air Well”. Located right in the heart of Chinatown, the Tian Jing Hotel has only 15 rooms, but they are amazing and live up to their name. They are constructed with the wisdom of ancient Chinese architecture to make use of and maximize natural light, expand air circulation, and keep a cool balance at room temperature. The antique furniture in the hotel has been collected from all over Malaysia and each piece has a unique story.</p>\n<p>If you are unable to get a room for the night, don’t worry. You can still stop in and indulge yourself at Tian Jing Hotel’s Lim Kee Cafe famous for their desserts. I was just there last Sunday and had their raspberry tiramisu which I highly recommend. You can also get a generous scoop of ice cream. They have flavors like pandan, teh tarik, mascarpone and soursop.</p>\n<h4>7. Bank Negara Museum and Art Gallery</h4>\n<p>Another hidden gem that many will find interesting is the Bank Negara Museum and Art Gallery located at Jalan Dato’ Onn. It’s a museum dedicated not only to Malaysian works of art, but to providing an educational avenue for anyone who is interested in better understanding of the Malaysian economy and its economic history. It also shows how the bank played an important role in the nation’s economic development and financial regulation from 1959 to the present day.</p>\n<p>This is a great one for those who love to experience impressive works of art and learn some economic history at the same time. The museum itself comprises six galleries: the Art Gallery, Economic Gallery, Islamic Finance Gallery, Numismatics Gallery, Children’s Gallery and the Bank Negara Malaysia Gallery. It underlines the bank as a major patron of the art housing over 1,500 contemporary Malaysian and ASEAN artworks acquired since 1962.</p>\n<p>The museum is open daily and free to get in. In my opinion, it’s a worthwhile stop.</p>\n<h4>8. Yat Hang Trading</h4>\n<p>For those who read my post on souvenirs, this is one of the places you’ll be able to find the mooncake moulders and a few of the other items that you foodies will love. Yat Hang Trading has been in business for over 100 years and has everything from typical Chinese utensils, to decades-old hand-painted ceramics. Anything that could be used in a traditional Chinese home or eatery.</p>\n<p>Many of the other local Chinese restaurants and bars get their utensils from Yat Hang Trading. In fact, if you stop at the PS150 bar, the snack bowls on the bar came from there. There’s plenty of authentic Malaysian- Chinese merchandise to choose from so if you’re looking around for that one perfect Malaysian souvenir that can also be useful in the home, this is the place to check out. You’ll also get to experience some of Kuala Lumpur history.</p>\n<h4>9. A Decent Nasi Lemak Inside Kl City Gallery Arch Cafe</h4>\n<p>When you visit Malaysia you are bound to try the national dish. In fact, with all the tourists on our tours I insist that they do. So why not try it at the place that has the finest, traditional recipes in all of Kuala Lumpur? I just talked to a tourist couple yesterday who have been here once a year for the last 4 years and they told me they go to the Arch Cafe inside Kl City Gallery on their first day here and their last day. And they always get the Nasi Lemak.</p>\n<p>The food isn’t the only thing that attracts visitors to the Arch Cafe. The tables and chairs are over a century old and were collected from the oldest coffee shop in old Market square and pudu. They have been used not only by prominent politicians, judges and other figures in Malaysian history, but also by the notorious Chinese gangsters from that era.</p>\n<p>So these are our picks for the hidden gems of Kuala Lumpur. What gems have you found around Kuala Lumpur? Let us know and we’ll update this post.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.847+08	2026-04-03 11:28:35.847+08	published	\N	\N
18	Plan your trip around these festivities in Malaysia	malaysian-festivities	1	An adventure to Malaysia is exciting. There are so many new things to see, taste, smell and do. There’s the beach, exotic foods, great people to meet, hundreds of different ethnic groups to learn about, and amazing nightlife. But there is more to experience in Malaysia than just everyday life. For i	<p>An adventure to Malaysia is exciting. There are so many new things to see, taste, smell and do. There’s the beach, exotic foods, great people to meet, hundreds of different ethnic groups to learn about, and amazing nightlife. But there is more to experience in Malaysia than just everyday life. For instance, New Orleans is a great town to visit year-round, but the best time to visit is of course on Mardi Gras.</p>\n<p>I’m talking about my favorite times of the year. Festival time.</p>\n<p>There are about two festivals a month throughout the year in different parts of Malaysia. Most festivals revolve around culture or religion and since Malaysia is a great blend of religions including Hindus, Muslims, Christians, Sikhs, and Buddhists and hundreds of different ethnic groups there is always something going on.</p>\n<p>East and West Malaysia may have separate cultural events and some may have open houses with dancing and lots of food spread out for everyone to enjoy, yet others are a time of fasting and prayer and visiting the temple or mosque.</p>\n<p>Here are ten must-see festivals in Malaysia to plan your adventure around.</p>\n<h4>Chinese New Year</h4>\n<p><strong>When</strong>: Can fall anywhere between lat January to Mid February.</p>\n<p><strong>Where</strong>: All throughout Malaysia in the Chinese communities.</p>\n<p>The Chinese communities transform the entire country into a vibrant, colorful festival of dancing dragons and paper lanterns. Chinese New year is the biggest event of the year for the Chinese communities and everyone gets involved.</p>\n<p>Lions and Dragons (not real ones of course) dance in a colorful yearly ritual to bring good fortune and prosperity in the New Year and to chase away any evil spirits or bad omens. The Chinese Malaysians will have people in costume doing these dances in businesses, their homes and some cities have events of traditional music and ceremonies.</p>\n<p>Shopping malls and many public places hang red lantern decorations (red is a lucky color) and children are given “ang pow” or a small red envelope filled with money. Another common tradition is giving away oranges to people that visit your home during this time.</p>\n<p>Chinese New year is also a time to find good-fortune foods like pineapple tarts, love letters (thin folded wafers) and peanut cookies just to name a few.</p>\n<h4>Eid (Hari Raya Aidilfitri)</h4>\n<p><strong>When</strong>: Late May to Mid June</p>\n<p><strong>Where</strong>: All throughout Malaysia, mostly in Muslim communities.</p>\n<p>Also called Hari Raya Puasa, this celebration marks the end of Ramadan’s month-long fasting for Muslims and celebrates the triumph of self-discipline and symbolizes rebirth or refinement. The phrase Hari Raya literally translates to “celebration day” and this is one huge celebration day, probably the biggest in Malaysia.</p>\n<p>It has no fixed date each year, instead, the religious experts calculate the date according to the lunar Hijri month. For one month, Muslims observe strict fasting from sunrise to sunset. They abstain from eating, drinking and smoking, and strive to resist any bad thoughts or desires.</p>\n<p>At sunrise on the last day, they attend the mosque for prayer then return home for a feast and celebration that can last up to a month. The first few days are reserved for catching up with family and many keep an open house where anyone, Muslim or non- Muslim can come and enjoy some good conversation and dive into delicacies like Ketupa, an Eid must-have.</p>\n<h4>Hari Raya Korban</h4>\n<p><strong>When</strong>: The date varies from late August to October</p>\n<p><strong>Where</strong>: All throughout Malaysia, mostly in Muslim communities.</p>\n<p>This is a public holiday to signify the “almost” sacrifice the prophet Ibrahim was willing to make. In the scriptures, Ibrahim was prepared to sacrifice his only son, Ishmael, as commanded by God. However, at the last minute, God commanded Ibrahim to stop and sacrifice a sheep instead.</p>\n<p>People will rise early, attend a sermon at the Mosque then head home for a day-long celebration. This is the time for gift-giving, new clothes and visiting friends. Large meals of goat or sheep which have been sacrificed are prepared and a portion of it, or the monetary equivalent is given to poor families so they too can celebrate.</p>\n<p>Mosques are decorated with lights and firecrackers are sometimes set off at night.</p>\n<p>This is the ideal time to see the unique architecture of the mosques and see how the meat is prepared in the slaughterhouses. Non-Muslims and even tourists are often invited to meals as a way to introduce them to Islamic culture.</p>\n<h4>Deepavali</h4>\n<p><strong>When</strong>: Dates vary from mid-October to November</p>\n<p><strong>Where</strong>: All throughout Malaysia especially in Hindu communities.</p>\n<p>Deepavali is the festival of lights, also a public holiday and one of the most colorful festivals in Malaysia. People decorate their homes with red paper and intricate “kolams” which are floor designs made from colored rice and powders.</p>\n<p>The background has several different legends in Hindu texts. The most common tells the story of how Lord Rama, who had been banished from the city, returned to take His throne. It was an unusually dark night so the people of the city lit lanterns to light the path for him.</p>\n<p>Another one is to honour Lakshmi, the Hindu goddess of prosperity. Clay lanterns are lit and placed all around asking the goddess to bless them. The main significance of the “festival of lights” is to signify the triumph of good over evil.</p>\n<p>This is an amazing time of lights and celebrations. There are firework displays at night and street food stalls are packed with Indian food, so this is the perfect time to indulge. A majority of the Hindu population is in West Malaysia and the capital Kuala Lumpur has two “little India” districts.</p>\n<p>Don’t forget to stop in and visit the amazing Hindu temples while you enjoy Deepavali.</p>\n<h4>Thaipusam</h4>\n<p><strong>When</strong>: late January/ early February</p>\n<p><strong>Where</strong>: Batu Caves on the outskirts of Kuala Lumpur, Waterfall</p>\n<p>Temple, Penang, and other shrines and locations nationwide.</p>\n<p>This is the most unique festival on this list, but I have to warn you, it’s not for the squeamish person. This Tamil celebration is held during the full moon and commemorates Lord Murugan (Hindu god of war) defeating an evil spirit called Soorapadman.</p>\n<p>As a tourist, this is something you will most likely not see again in your lifetime so I highly recommend this festival. Many on our tours have been skeptical about attending, but after they were happy they did.</p>\n<p>This celebration involves a parade through the streets of Kuala Lumpur led by a chariot that with a statue of Lord Murugan. Now here is where it may get a little outlandish. Devotees then make a barefoot walk to the Batu caves carrying jugs of milk and ornate frames called kavadi. The kavadi actually pierce the skin of their chest and backs as a symbol of penance. Some even put a spike through their cheeks.</p>\n<p>Not all devotees pierce their skin, though. Many just make offerings of fruit or flowers or other gifts. Batu caves are the most popular and largest shrine, but there are shrines all throughout Malaysia that celebrate Thaipusam.</p>\n<p>According to my friend Shoba, Penang Waterfall temple is the best place other than the Batu caves to experience Thaipusam.</p>\n<h4>Mooncake Festival</h4>\n<p><strong>When</strong>: End of September or early October</p>\n<p><strong>Where</strong>: All over Malaysia in the Chinese communities with the most popular celebrations in Thean Hou Temple in Kuala Lumpur and Penang.</p>\n<p>I just got an email this morning from a tourist family that was here last year for the Mooncake festival. They said they had been craving mooncakes ever since and wanted to know exactly when next year’s festival was. That’s when they are planning their vacation.</p>\n<p>I also look forward to this mid-autumn festival every year. The mooncake festival celebrates one of the most delicious Chinese delicacies ever made, the mooncake, and includes lantern parades, mooncake tasting and the lion and dragon dancing in the streets. Georgetown puts on a great event as does Nibong Tebal, Butterworth, Kepala Batas, and Bukit Mertajam.</p>\n<p>Hotels and shopping malls hold events and serve all kinds of mooncakes. Best to come and try all the various recipes and see for yourself. You’ll never look at the full moon again without getting hungry.</p>\n<h4>Independence day</h4>\n<p><strong>When</strong>: August 31st</p>\n<p><strong>Where</strong>: Most events take place on Merdeka Square in Kuala Lumpur, however it’s celebrated nationwide.</p>\n<p>This celebration commemorates our independence from the British on August 31st, 1957. It starts with fireworks right at midnight and continues on into the next day with parades, live concerts, food, and performances by civil servants and school children.</p>\n<h4>The Harvest Festival</h4>\n<p><strong>When</strong>: May 30-31</p>\n<p><strong>Where</strong>: Sabah and Labuan</p>\n<p>Traditionally, this festival is a time for farmers and their families to thank the spirits and God for the year’s rice harvest. This is a bit like Thanksgiving day in the US, but instead of turkey, the main course is rice. Rice is considered sacred and is a staple of our diet.</p>\n<p>Nowadays, it’s a celebration of food, fun, dancing and music. Expect a lot of Tapai and Lihing, or rice wine, to be flowing. Other favorites include hinava (fermented fish) and bambangan (a kind of pickled fruit similar to mango).</p>\n<p>In Unduk Ngadau, an annual beauty contest is held and the winner is announced at the end of the festival, and in other parts of the state, there are exhibits, public events. Most tourists love traditional dances and ethnic clothing. Not an experience to pass up.</p>\n<h4>The Dragon Boat Festival</h4>\n<p>When: December</p>\n<p>Where: Penang</p>\n<p>I never miss this festival and it’s definitely a tourist favorite. The Penang International Dragon Boat Festival is a two-day event where boat racers come from all over Malaysia, China, Singapore and Hong Kong to Teluk Bahang Dam to race in traditional boats to the sound of drum beats.</p>\n<p>Besides the boat races, there are local performers and of course my favorite, lots and lots of food available.</p>\n<h4>Nine Emperor Gods Festival</h4>\n<p><strong>When</strong>: Sept-Oct</p>\n<p><strong>Where</strong>: The Nine Emperor Gods Temple, Butterworth, Penang</p>\n<p>This Taoist festival in Penang is not one to miss. Like Thaipusam, it’s a nine-day event that features devotees performing firewalking and piercing their cheeks with long rods. They are awaiting the arrival of the nine Taoist gods and the temple is brilliantly lit and packed with followers dressed in white and carrying incense. It ends with a long procession on the ninth day from the temple to the beachfront to send the goods back home.</p>\n<p>The temple, also known as Rumah Berhala Tow Boo Kong, was started as a small shrine in 1971 which has grown into an elaborate and ornate temple completed in 2000. Many of our tourists ask about it and do visit year-round, but to really get a powerful experience you have to come and see the festival.</p>\n<p>So there are ten popular festivals to plan your vacation around, however, there’s a ton more to discover depending on where and when you visit.</p>\n<p>Some others include Wesak Day (May), Rainforest World Music Festival, Kuching, Sarawak (mid-July), Prophet Muhammad’s Birthday and of course Christmas.</p>\n<p>I’d love to hear about your favorite festival to visit in Malaysia, drop me a note in the comments below.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.859+08	2026-04-03 11:28:35.858+08	published	\N	\N
19	Discover the Vibrant World of Malaysian Herbs and Traditional Flavours	malaysian-herbs-and-spices	1	Welcome to the vibrant world of Malaysian herbs, where the richness of Malaysian comes alive with every bite you take. In this article, we will dive headfirst into the fascinating realm of Malaysian cuisine and explore the diverse array of herbs that elevate its dishes to a whole new level. From aro	<p>Welcome to the vibrant world of Malaysian herbs, where the richness of Malaysian comes alive with every bite you take. In this article, we will dive headfirst into the fascinating realm of Malaysian cuisine and explore the diverse array of herbs that elevate its dishes to a whole new level. From aromatic leaves to zesty roots, we will uncover the secrets behind these flavorful ingredients and how they play an integral role in creating unique culinary experiences. Join us on a mouthwatering journey through Malaysia’s incredibly rich culinary heritage!</p>\n<h4>The Origins of Ulam: Tracing the Roots of Malaysian Herb Culture</h4>\n<p>The earliest inhabitants of Malaysia were known to use a great variety of herbs and roots in their daily diets. The best example of this is a sidedish better known as ulam. Ulam is the collective name for the indigenous wild leaves, herbs, shoots, nuts, and flowers that are eaten raw or lightly blanched. The dish has cultural and traditional significance in Malaysia and is a part of the country’s culinary heritage. Ulam-based recipes include Nasi Ulam, which is a popular Malaysian mixed herb rice salad that uses local herbs and vegetables as the main ingredients. Ulam has been a part of Malaysian cuisine for centuries and is still widely consumed today.</p>\n<ul><li>Ulam is believed to have originated from the indigenous communities in Malaysia who relied on their surrounding environment for sustenance.</li><li>Over time, ulam became an essential component of Malay cooking, offering a variety of flavours and textures to complement other dishes.</li></ul>\n<h4>Unveiling the Fragrant Leaves of Malaysian Cuisine</h4>\n<p>Malaysian cuisine is characterized by an array of aromatic herbs and spices that add depth and flavour to dishes. Among these, fragrant leaves play a significant role in traditional Malaysian cooking. These leaves not only enhance the aroma but also contribute unique tastes to meals.One such leaf commonly used in Malaysian cuisine is daun kesum or laksa leaf. This herb has a citrusy flavour that pairs well with savoury dishes like laksa, a spicy noodle soup popular in Malaysia. Another popular aromatic leaf is the banana leaf, which is often used as a natural wrapper for grilled meats or steamed rice dishes called nasi lemak. Other fragrant leaves include pandan leaves, which impart a sweet vanilla-like aroma when added to desserts, or betel leaves that are commonly used as wrappers for snacks like otak-otak, a fish cake delicacy.By incorporating these fragrant leaves into their recipes, Malaysians are able to create vibrant and flavorful meals that reflect the country’s rich culinary heritage. So next time you’re exploring Malaysian cuisine, be sure to pay attention to the fragrant leaves – they might just unveil new flavours you never knew existed!</p>\n<h4>Spices and Roots: Unleashing the Zesty Flavors of Malaysian Herbs</h4>\n<p>Malaysian cuisine is known for its bold flavours and vibrant spices. One key aspect of this culinary tradition is the use of an array of herbs that contribute to unique tastes.</p>\n<ol><li><strong>Galangal</strong>: A cousin to ginger, galangal adds a citrusy, peppery kick to dishes like soups and curries.</li><li><strong>Lemongrass</strong>: This fragrant grass lends a fresh lemon-like flavour to many Malaysian dishes, such as rendangs (spicy meat stews) and laksa (coconut-based noodle soup).</li><li><strong>Turmeric</strong>: With its bright yellow colour, turmeric not only adds earthiness but also boasts numerous health benefits.</li><li><strong>Kaffir lime leaves:</strong> These aromatic leaves provide a tangy, citrusy taste that complements both savoury and sweet recipes.</li><li><strong>Pandan leaves:</strong> Used in desserts and drinks, pandan leaves give off a distinctive aroma with hints of vanilla.</li><li><strong>Fenugreek seeds</strong>: Known locally as “halba,” these seeds are commonly used in spice blends for their nutty flavour.</li></ol>\n<p>Incorporating these herbs into your cooking will transport you to the vibrant world of Malaysian cuisine — get ready for an explosion of zesty flavours!</p>\n<h4>The Healing Power of Herbs</h4>\n<p>Malaysia’s herbs aren’t just ingredients in the local cuisine; they’re nature’s wellness treasures passed down through generations. These unassuming greens hold a special place for their remarkable healing qualities. Ginger’s robust flavour hides its power to ease digestion and enhance resilience. Turmeric’s golden hue signifies its anti-inflammatory prowess, supporting joints and bolstering immunity. Lemongrass, with its invigorating aroma, brings relaxation and digestive relief.But the healing journey doesn’t end there. Other herbs also contribute their unique benefits. Daun Kaduk, or wild pepper leaf, offers antimicrobial support, while Bunga Kantan, the vibrant torch ginger flower, brings antioxidants and anti-inflammatory potential. The aromatic Pandan Leaf is believed to possess anti-inflammatory properties. Each of these herbs weaves a holistic narrative of well-being, connecting us to the wisdom of nature.As you embrace the flavours of these herbs, remember that their potential benefits are grounded in tradition and nature’s wisdom. Consulting a healthcare professional before making significant dietary changes is always wise, especially if you have underlying health considerations. With each culinary creation, you’re not just enjoying a meal; you’re partaking in a centuries-old tradition of wellness Incorporate some ulam into your daily life and allow yourself to tap into nature’s pharmacy!</p>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/torch_ginger_46da785316.jpeg" alt="torch_ginger.jpeg">\n<p>Torch Ginger – Discover the vibrant world of traditional Malaysian herbs and flavors at a market.</p>\n<h4>Discovering Malaysian Herbs</h4>\n<p>Malaysia is a treasure trove of unique herbs that add an extraordinary touch to traditional flavours. Exploring these often lesser-known herbs will expand your culinary horizons and allow you to create truly authentic Malaysian dishes.</p>\n<ol><li><strong>Kesum</strong>, also known as Vietnamese coriander, is a popular herb in Malay cuisine. With a vibrant and peppery taste, this herb adds a delightful kick to Malaysian salads and stir-fries. Its unique flavour profile gives a fresh twist to traditional dishes.</li><li><strong>Daun Kaduk</strong> or wild pepper leaf, has become increasingly rare due to deforestation but remains highly sought after for its bold taste profile. Used widely in Nyonya cooking, it imparts a peppery tang that complements fish dishes perfectly.</li><li><strong>Curry Leaves</strong> These aromatic leaves add a burst of flavour to Malaysian curries and dishes. They are often sautéed with spices at the beginning of cooking to infuse a deep, earthy essence into the cuisine.</li><li><strong>Kaffir Lime Leaves</strong> are known for their citrusy fragrance, these leaves are a staple in Malaysian cooking. They are used to enhance the aroma of soups, stews, and curries, leaving a zesty and refreshing note.</li><li><strong>Turmeric Leaves </strong>are often used for wrapping food and impart a mild turmeric flavour and a hint of earthiness. They’re utilized to enhance the aroma and taste of dishes like rice and grilled meats.</li><li><strong>Bay Leaves</strong> offer a subtle yet distinctive flavour. They are used to season stews and slow-cooked dishes. They infuse warmth and depth into Malaysian comfort foods.</li><li><strong>Water Celery (Water Spinach)</strong> is commonly used in Malaysian stir-fries and noodle dishes, water celery brings a crisp texture and a hint of peppery taste, elevating the overall freshness of the dish.</li><li><strong>Cosmos</strong> contributes a mild, herby taste to Malaysian cuisine. It’s often used in soups and salads, offering a delicate layer of flavour to complement other ingredients.</li><li><strong>Asiatic Pennywort</strong> or Pegaga has a slightly tangy and refreshing flavour. Asiatic pennywort is a popular addition to salads and beverages. It’s believed to have health benefits and is often used in herbal drinks.</li><li><strong>Pandan Leaf</strong> is loved for its sweet aroma. These leaves are used to infuse Malaysian desserts, rice, and beverages. They lend a unique, fragrant touch to various traditional treats.</li><li><strong>Sweet Potato Leaves</strong> are used in Malaysian vegetable dishes, providing a subtle earthy taste. They are often sautéed with spices or included in soups.</li><li><strong>Lemongrass</strong> has a citrusy and herbal scent and is a cornerstone of Malaysian cuisine. It’s a key ingredient in curries, soups, and aromatic broths.</li><li><strong>Banana Leaves</strong> are utilized for wrapping food. Banana leaves impart a subtle, earthy flavour and a hint of sweetness. They’re also used to cook and serve dishes, adding an extra layer of aroma.</li><li><strong>Banana Flower</strong> is a unique ingredient that offers a slightly bitter taste and is commonly used in Malaysian salads and curries. Its distinct texture and flavour provide a memorable culinary experience.</li></ol>\n<p>By tapping into the world of rare and exotic herbs from Malaysia, you’ll embark on an incredible culinary journey filled with tantalizing tastes and unexpected delights! From kesum and daun kaduk to curry leaves and kaffir lime leaves, each herb adds its own distinctive flavour profile to traditional Malaysian flavours. By incorporating these exotic herbs into your cooking, you will embark on a culinary journey filled with tantalizing tastes and unexpected delights. The vibrant world of Malaysian herbs and traditional flavours awaits you, ready to elevate your culinary experiences to new heights.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.869+08	2026-04-03 11:28:35.869+08	published	\N	\N
20	Must Try Malaysian Street Food Checklist	must-try-malaysian-street-food	1	My guests often ask me “what is the must-try Street Food when I visit Malaysia?”.	<p>My guests often ask me “what is the must-try Street Food when I visit Malaysia?”.</p>\n<p>Honestly speaking the Malaysian streets are a paradise, packed with vendors selling the most delicious and exotic street foods. Whether you’re in a hawker stall or just out taking in the sights, street foods are the perfect way to enjoy the cuisine and get a real feel for Malaysia and its people. The varieties of tastes and flavors you’ll find are all prepared with traditional techniques that represent the diversity of Malaysian culture. And won’t make a huge impact on your wallet.</p>\n<p>I compiled this list of my personal favorites. Before I would send this list out to our clients after they completed their tour and now it’s time to share that list with everyone!</p>\n<p>So here is my Must-Try Malaysian Street Food Checklist.</p>\n<h4>DISHES</h4>\n<h5>Nasi lemak</h5>\n<p>Top of the list and a favorite for tourists and locals alike is Nasi lemak. Considered the national dish, it can be found in both roadside stalls served on a banana leaf and in 5-star restaurants in fine china. This dish is a hearty mix of coconut rice infused with pandan, cucumbers, nuts, anchovies and egg.</p>\n<p>There are several variations and choices of sides depending on where you go. Some more popular sides include deep-fried fish, chicken, fish cake and even curried vegetables. Besides the aromatic rice, the signature of this dish is the spicy sambal or chili paste.</p>\n<h5>Char Kuey Teow</h5>\n<p>Once considered “poor man’s food”, Char Kuey Teow has evolved into a local favorite. Literally translated, the name means ‘stir-fried rice cake strips’ and consists of spicy, flat rice noodles stir-fried over high heat with soy sauce, shrimp, chilis, cockles, bean sprouts, eggs and Chinese chives. If you want more of a Chinese-style dish, you can also find variations of this dish fried in pork lard with slices of Chinese sausage and fishcake.</p>\n<h4>Beef Noodle</h4>\n<p>This dish may have a humble name, but the flavor is anything but ordinary. Large chunks of beef brisket simmered in a spicy broth with rice noodles, chives, bean sprouts and other Asian greens. You can find this dish right on the street or starring in one of the many restaurants that claim to have the best noodles in Malaysia.</p>\n<h4>Yong Tau Foo</h4>\n<p>Another favorite with variations depending on cultural influences is Yong Tau Foo. This dish can be served for breakfast, lunch or dinner. This Hakka dish is white tofu stuffed with either a ground meat mixture or surimi (fish paste) then deep fried to a golden brown.</p>\n<p>Mushrooms and other vegetables, like eggplant, can also be stuffed and fried as a variation to this dish, then served with fried tofu balls.</p>\n<p>You can have your Yong Tau Foo dry, with sauce, or even served as soup.</p>\n<h4>Asam Laksa</h4>\n<p>One of Malaysia’s most beloved dishes is Asam Laksa. This iconic dish is a “must try” when visiting Penang and was ranked 7th on CNN’s World’s Best Food List.</p>\n<p>Served mainly in the late afternoon, this dish is a spicy fish broth soured by tamarind and filled with smooth rice noodles, shredded mackerel, mint, lemon grass, onion, and pineapple. Then garnished with pink ginger flowers, thinly sliced cucumbers, bird’s eye chilis and a sweet prawn paste called heh ko.</p>\n<h4>Roti Canai</h4>\n<p>This popular snack or breakfast dish has its origins in India, but today can be found all over Asia.</p>\n<p>This flatbread is very inexpensive and is uniquely made by first flattening the dough then forming it into a rope and twisting it before rolling it flat again. This process gives the roti flaky layers as it cooks.</p>\n<p>Traditionally served with dhal, a curried lentil soup, or other curries. It’s most popular alongside Teh Tarik, or ‘pulled tea”, as a breakfast dish.</p>\n<h4>Hokkien Mee (Egg and Rice Noodles in Spicy Soup)</h4>\n<p>Also known as Ha Mee, this delicious soup has its origins in China’s Hokkien province and was introduced to Malaysia by Chinese sailors after World War II.</p>\n<p>A bowlful of Hokkein Mee contains a special broth made by stewing prawn heads, clams, pork, and dried fish. Two kinds of noodles – egg noodles and rice vermicelli – are then added along with kankong (or “water spinach”), bean sprouts, tender pork slices, squid, and shrimp then finishes with a hard-cooked egg and a spoonful of homemade chili sauce.</p>\n<h4>Fried Bee Hoon</h4>\n<p>A popular breakfast staple in Malaysia, Fried Bee Hoon has made its way into the hearts of many tourists as a perfect deviation from the usual morning meal.</p>\n<p>Bee Hoon is rice noodles, or vermicelli, which is soaked then stir-fried with soy sauce, oyster sauce, Chinese cabbage, bean sprouts, onion, garlic, ginger and any other variation of vegetables. Garnished with an egg, any style, spring onions and of course, chili sauce.</p>\n<h4>Murtabak</h4>\n<p>Similar to a turnover, Murtabak is a popular snack that was originally sold in Indian Muslim stalls and restaurants. Now it is offered nationwide and with many variations.</p>\n<p>The classic Murtabak is a pancake or pan-fried bread stuffed with minced beef or chicken, garlic, egg and onion. It is served with your choice of curry or gravy, sliced cucumber, syrup-pickled onions or tomato sauce.</p>\n<h4>Koay Teow Th’ng</h4>\n<p>The simplest and most affordable street food on this list is Koay Teow Th’ng. This soup is a clear broth with either duck, pork or chicken depending on the shop you visit. At most places, you can top it up with fish balls. This dish is completed by a garnish of lettuce and chopped spring onions.</p>\n<p>Whatever this flavorful soup may lack in complexity, it makes up for in taste.</p>\n<h2>Snacks</h2>\n<h4>Sweet Potato Balls</h4>\n<p>Another great treat while on the streets of Malaysia is an order of Sweet Potato Balls. One of my personal favorite snacks, these simple balls are made from mashed sweet potatoes, flour and sugar. The mixture is then formed into balls and deep-fried.</p>\n<p>Some stalls may even top them with toasted sesame seeds to give it an extra nutty flavor.</p>\n<h4>Durian Cream Puff</h4>\n<p>Similar to an eclair or other puffs, the Durian Cream Puff is not to be thought of as ordinary. These flaky pastry puffs are baked fresh and then stuffed with a cream filling made from the robust tropical fruit, durian. Despite its unpleasant odor and frightening appearance when still hanging from the tree, durian is one of the most delicious tropical fruits there is.</p>\n<h4>Karipap (Curry Puff)</h4>\n<p>For a quick, on-the-go snack, pick up a Karipap or curry puff. Similar to the empanada originating in Portugal, these half-moon-shaped pies are flaky puff pastries stuffed with curried chicken and potatoes then either deep-fried or baked. These are popular snacks among Malaysians and fit nicely in the palm of your hand, so they are easy to eat while walking.</p>\n<p>You can also find them minus the chicken for vegetarians.</p>\n<p>Tau Sar Piah</p>\n<p>Tau Sar Piah is a flaky, crisp, and buttery pastry with mung bean filling which can be either sweet or savory. I’ve found this traditional Singapore / Malaysian Chinese pastry in the local grocery stores in Malaysia, but those won’t compare to the ones baked fresh on the street.</p>\n<p>Roti Jala (Malaysian net crepes)</p>\n<p>Literally translated, Roti Jala means “net crepes” due to their unique lattice appearance.</p>\n<p>Tender and delicate, Roti Jala goes perfectly with chicken or beef curry but can accompany any chutney you desire. Ground turmeric gives this roti a mild aroma and a nice yellow tint</p>\n<h4>Satay</h4>\n<p>Malaysian nightlife would not be complete without trying this unique, Indonesian-inspired bar-b-que. The irresistible aroma alone will be enough to draw you over to the stall.</p>\n<p>Satay is pieces of beef, chicken or pork on bamboo skewers, marinated in a sweet and spicy satay peanut sauce, then grilled over a charcoal fire to give them that delicious smoky flavor. Served with red onion and cucumber slices for spearing.</p>\n<h4>Lok-Lok</h4>\n<p>Another late-night snack and similar to Satay is Lok-lok. Only this one kicks it up a notch.</p>\n<p>Endless trays of meats and vegetables on bamboo skewers, seasoned and ready to be cooked. You get a plate and choose your skewers, anything from beef, chicken, pork, mutton, and bacon to a variety of veggies. Once you have made your selections, you cook your skewers in a simmering broth to your liking. Nothing could be more fun and delicious!</p>\n<h4>Rojak</h4>\n<p>The work rojak translates to “mixture” in English, which is exactly what this dish is. A salad blend of the freshest fruits and vegetables around.</p>\n<p>I like the sweet version, which is normally fresh tropical fruits, but you can also get the savory which consists of fried bean curd, vegetables, fritters and hard-cooked eggs. Both are awesome and tossed in a tangy sweet sauce that brings the flavors together.</p>\n<p>Rojak is best enjoyed when made fresh, though. If you leave it to sit too long and it becomes soggy.</p>\n<p>Cucur Udang (Prawn Fritters)</p>\n<p>Commonly known amongst Malaysians as “jemput jemput udang”, Cucur Udang are soft, bite-size, prawn fritters fried to perfection.</p>\n<p>Fresh shrimp, corn, white onion, red chilis, and spring onions are blended together with flour and dropped by small spoonfuls into hot oil to produce this awesome snack which can be eaten plain or dipped in chili sauce or peanut sauce.</p>\n<h4>Desserts</h4>\n<h5>Apam Balik</h5>\n<p>I love watching them make this. It’s a simple pancake made from flour, eggs, sugar, baking soda, coconut milk and water then cooked in a large iron pan coated with palm margarine. Once flipped, it is stuffed with crushed peanuts and sweet creamed corn, then folded, like a turnover and cut making it easier to eat on the go.</p>\n<p>You can find other variations which include shredded cheese and even chocolate sprinkles.</p>\n<h4>Tong Sui</h4>\n<p>I have found so many varieties of this popular dessert soup whose name literally translates to “sugar water”. So many varieties in fact, that many stalls have gained fame with their specialty Tong Sui.</p>\n<p>I’m not sure which one is my favorite, but some that I look for are red bean soup, peanut paste soup, black-eyed peas soup, wheat porridge, tofu pudding, and sago (tapioca pearls) with shredded coconut in evaporated milk.</p>\n<p>Whatever your tastes, you will find a Tong Sui to satisfy you.</p>\n<h4>Cendol</h4>\n<p>I like this dessert on those hot days to escape the heat. It’s simple and super inexpensive.</p>\n<p>Cendol is a generous bowl of shaved ice mixed with green rice flour jelly, coconut milk and palm sugar syrup. Add creamed corn for an extra layer of flavor and texture.</p>\n<h4>Drinks</h4>\n<h5>Cham Ice</h5>\n<p>In English, the word cham literally translates to “mix” which is a fitting description for this refreshing beverage, as it’s a mix of coffee, tea and condensed milk served over ice.</p>\n<p>For a healthier version, condensed milk can be substituted for fresh or evaporated milk.</p>\n<h5>Five Flower Tea</h5>\n<p>I love this tea. It’s globally known for its medicinal value as well as its wonderful aroma and taste. It’s brewed from a mixture of honeysuckle, chrysanthemum, silk cotton, Plumeria Rubra and Pueraria lobata.</p>\n<p>It has anti-inflammatory properties which can help alleviate such ailments as fatigue, sore throat, indigestion, poor appetite, insomnia and urinary difficulty</p>\n<h4>Nutmeg Juice</h4>\n<p>In the western world, nutmeg is widely known as an intricate element in pumpkin pie and eggnog. However in Malaysia, the pale yellow fruit from the nutmeg tree is pressed into a sweet and tangy juice that is served streetside in a variety of ways.</p>\n<p>There is bad news though. This delicious juice is only common in Penang. In other parts of Malaysia, you can find the nutmeg fruit candied or even as preserves.</p>\n<h4>Teh Tarik</h4>\n<p>To end this list, I chose one of the most delicious and unique drinks found throughout the country. Teh Tarik.</p>\n<p>Teh Tarik means literally “pulled tea” and is the national drink of Malaysia. Similar to Cham Ice, this beverage is a mixture of black tea and condensed milk, but is served hot and can be found in street stalls as well as the fancier restaurants.</p>\n<p>What’s unique about Teh Tarik is the way it’s prepared. First, the tea and milk are combined, then repeatedly poured from a height between two cups. This thoroughly mixes the tea and milk, cools the beverage to just the right temperature and gives it a nice foam on top, thus enhancing the flavor.</p>\n<p>Teh Tarik is a great accompaniment to Roti canai and is a very popular and traditional breakfast among Malaysians.</p>\n<p>And that sums up my list of must-eat Street Food when visiting Malaysia. Do you have a favorite or have I missed a dish? Let me know in the comments below.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.881+08	2026-04-03 11:28:35.881+08	published	\N	\N
21	How long does it take to get to Kuala Lumpur from Port Klang?	port-klang-to-kuala-lumpur	1	Taking a cruise to Malaysia is a fun and exciting way to arrive. You’ll get to see the many forested islands as you weave your way up the Malacca Strait and dock at Port Klang just south-west of Kuala Lumpur. And once you dock, there are a few things you can do and although I strongly suggest a day 	<p>Taking a cruise to Malaysia is a fun and exciting way to arrive. You’ll get to see the many forested islands as you weave your way up the Malacca Strait and dock at Port Klang just south-west of Kuala Lumpur. And once you dock, there are a few things you can do and although I strongly suggest a day trip to Kuala Lumpur to get a real feel for Malaysia and its capital, I do recommend understanding the travel times to make sure the cruise doesn’t leave without you.</p>\n<p>Depending on where you are going, it’s approximately 41 km from Port Klang to Kuala Lumpur and only takes about an hour and fifteen minutes. If you choose to travel by taxi or bus, it may take a few minutes longer due to heavy traffic and road conditions.</p>\n<h4>Port Klang</h4>\n<p>You’ll begin your day trip at Port Klang. Port Klang is the closest dock to the capital city, Kuala Lumpur and is the 11th busiest transshipment port and the 17th busiest container port in the world.</p>\n<p>There are three ports at Port Klang: Northport, Southpoint, and Westport. Southpoint is the original port with Northport and Westport coming much later. It was developed by the Malayan Railway and opened on 15 September 1901. At the time is was called Port Swettenham named after Sir Frank Athelstane Swettenham who had initiated a rail system between Klang and Kuala Lumpur. Before this, ships had a difficult time navigating through the jetty. So this new location at the mouth of the river was chosen.</p>\n<p>Before the railway was put in, the trip from Klang to Kuala Lumpur was horse or buffalo-drawn wagons or boat ride along the Klang River to Damansara. This was a long and rather tedious journey and with the rising need to transport tin and other materials from KL, the railway was initiated.</p>\n<p>Today, cruise ships normally dock at Port Klang Cruise Centre, however, there are sometimes exceptions. It’s best to check with the front desk onboard your ship to find out exactly where you will dock. When you get off the ship, first check in with The Port Klang Cruise Centre. There you will find everything you’ll need for your daytrip to Kuala Lumpur: currency exchange, wi-fi, taxi information desk, ATM, tourist information and souvenir shops.</p>\n<p>The nearby town of Klang has a lot to offer. There are street markets, plenty of historical sites and beautiful temples to visit. Even the port itself has a number of shops and restaurants serving up local delicacies like steamed crayfish and salt-baked crab. An excursion to nearby Crab Island could be a great way to spend your time near Klang. Catch the ferry to Crab Island if you are looking for a tranquil day of fun and seafood.</p>\n<h4>Getting to Kuala Lumpur</h4>\n<p>The biggest destination for most tourists coming into Port Klang, is a day trip to Kuala Lumpur. It’s a bit of a journey and the trip getting there and back will take up some of your shore leave time, but in my opinion it’s well worth it. Kuala Lumpur has a unique blend of history and culture that you will surely not want to pass up.</p>\n<p>Some cruise lines offer a shuttle service to Kuala Lumpur. Although convenient, I have heard from many tourists that it can get quite expensive at upwards of US$60 per person as of this writing. I cannot vouch for this price for every cruise line, so as always, best to check with the front desk on your ship. The biggest complaint about the shuttle service I have heard is that it does not stop at any of the sites. It merely picks you up and drops you off at the shopping mall.</p>\n<p>If your cruise line doesn’t offer shuttle service, or you are looking for a less expensive way to enjoy Kuala Lumpur for the day there are three other options. train, bus or taxi/grab. All three will take about the same amount of time, it just depends on your exact destination. The Port Klang Cruise Center will be able to help you make the best decision.</p>\n<p>When traveling to Kuala Lumpur, you have to keep in mind that even though it’s a tourist destination, it’s also a thriving metropolis and the capital of Malaysia. You’ll be well aware of this as you get closer to the city and see the high rises and skyscrapers. So taking into account the regular city traffic expects some delays now and again.</p>\n<p>Usually, peak hours for traffic starting at 7 am and can last until 9:30 am, while in the evening it will start around 4:30 pm and can stay congested until after 8 pm. Lunch time can also get a little heavy, so best to keep track of the time and take these periods into account when making plans.</p>\n<p>The roads are not always in the best of repair. They are bumpy and full of potholes. I’m not trying to dissuade you from taking the trip at all. I just want to give it to you straight so you know what to expect. Visiting Kuala Lumpur is worth a little traffic and discomfort for an hour.</p>\n<p>Let’s take a look at the different choices and see how they compare.</p>\n<h4>Train</h4>\n<p>The komuter KTM train station is about 13km from the port. You’ll have to hop a taxi to get there. The train is the least expensive way to go. Trains generally run once an hour and you can find the timetables in the Cruise center. The issue is, when you get to Kuala Lumpur, to make sure you allow yourself enough time to get back to the station before your train departs to return to the port.</p>\n<p>The train is a favorite simply because most of the sites to see are close to each other and on the train route. The coaches are comfortable, and air-conditioned and you can purchase tickets either at the ticket counter, online or at a ticketing vending machine. It will take you directly to the KL Sentral KTM station or Stesen Kuala Lumpur, right in the heart of Kuala Lumpur. It’s advised when coming back on the train from KL Sentral, to go ahead and get off in Klang (22km away) and take a taxi to the ship, since it will be difficult to find taxis at the Port Klang station.</p>\n<h4>Bus</h4>\n<p>Unless you’re willing spend most of your day sitting on the bus, this option is unfortunately not a viable way for anyone to get to Kuala Lumpur.</p>\n<h4>E-Hailing/Taxi</h4>\n<p>Booking a ride on an e-hailing app or arranging a taxi is the best option for most travellers arriving at Klang Cruise Terminal. The ride to Kuala Lumpur takes about 1h30min, however this really depends on traffic situations. With daily afternoon monsoon rains potentially complicating the journey back to the Cruise Terminal.</p>\n<p>The most common apps for e-hailing are Grab, AirAsia, inDrive and MyCar. Pricing for rides to Kuala Lumpur vary depending on traffic and rider availability, expect to spend at least RM110 in each direction. </p>\n<p>Official taxis have blue, red and/or white colors and they should go be the meter, unless booked through a ride-hailing app.</p>\n<h4>Hired Van/Shuttle</h4>\n<p>Some tourists choose to go this route for the simple fact that a hired van can shuttle you and your party through the different sites. They will stop where you want them to, and another benefit is, if you hire a driver for a round trip, they will know exactly where to pick you up and what time to return so that you can be assured to get back to the ship on time.</p>\n<p>Some private drivers offer their services in their personal vehicles, it’s adviced to check with them if they have an e-hailing license as that means they are also insured. Private Minivans range in size from 6-seaters all the way to 15-seaters. Hiring a minivan might be a cost-effective way to see the city if you manage to gather a couple of people. Do take note that any transportation with 8 participants or above is required to have a licensed guide on board. </p>\n<p>Whatever option you choose, it’s advised to allow plenty of time to get back to your ship and avoid trying to cut it close. You won’t be able to see everything in one day, so leave some sights for next time if it’s starting to get late. There have been tourists who have missed their port call because of traffic. It’s a messy situation and requires them to get a hotel room for the night and make further arrangements with the cruise lines which could cost them more cash.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.893+08	2026-04-03 11:28:35.893+08	published	\N	\N
22	10 best souvenirs for foodies to bring back from Malaysia	souvenirs-for-foodies	1	I like to joke with tourists to bring an extra bag or suitcase when they are preparing for their trip to Malaysia. Why?	<p>I like to joke with tourists to bring an extra bag or suitcase when they are preparing for their trip to Malaysia. Why?</p>\n<p>Souvenirs.</p>\n<p>Many of our guests are foodies and don’t want to go home with the cheesy refrigerator magnet or snow globe that says Malaysia (when does it snow in Malaysia?), instead, they want something different to really express their Malaysian adventure.</p>\n<p>So I went ahead and compiled a list of 10 unique foodie souvenirs to remember your vacation.</p>\n<h4>Roti jala dispenser/mould- brass</h4>\n<p>Once you have tried roti jala, you are going to want to make it at home. I know this because even just last week a tourist asked me how she can make her own when she returns to the UK.</p>\n<p>Roti jala, also called net bread because of its criss-cross appearance, is a specialty here in Malaysia and a favorite among so many tourists. It’s usually eaten with chicken curry or with durian gravy/sauce and is a simple tea-time snack to prepare.</p>\n<p>To make roti jala at home you will need flour, eggs, milk and the special moulder available here as a take home souvenir (if you are not in Malaysia you could order a simple version from Amazon just like this one). Traditionally, it’s a cup made out of brass with holes in the bottom to ensure proper distribution of the batter. This is how the consistent net appearance is made.</p>\n<p>Nowadays, you can find them made out of plastic and a few different styles. The brass one’s can be hard to come by. You can find a moulder in any bakery shop or market.</p>\n<h4>Moon cake mould</h4>\n<p>Another one many foodie tourists want to rush home and replicate after the festival is the Chinese mooncake.</p>\n<p>The mooncake is an offering only available during the mooncake festival in mid-autumn. Again, this delicacy can’t be made properly without the proper equipment.</p>\n<p>As a souvenir, there are a few types to consider:</p>\n<p><strong>The classic wooden moulder </strong>– The wooden moulds look like a long paddle and it will have 2 or 3 intricately carved designs. This would also make a great decoration for the kitchen.</p>\n<p><strong>Plastic egg or rice moulder</strong> – These are the fun ones for the kids. They come in adorable shapes like fish, car, bunny, hearts, etc.</p>\n<p><strong>Silicon moulds </strong>– These are good as alternatives if you can’t find traditional or stamp mooncake molds.</p>\n<p><strong>Stamp moon cake moulds</strong> – These molds are made of plastic and have three main parts: a barrell for the cake, a disc for the design, and a plunger to press the design onto the cake.</p>\n<p>This is a great way to get your friends back home excited to hear about your Malaysian vacation. Just serve them some homemade mooncakes and tell them all about the festival and the different types of mooncakes you sampled.</p>\n<h4>Airtight tea container</h4>\n<p>When you think Malaysia, think tea. Tourists are amazed at how fresh tasting the tea here is. Drinking tea is a large part of Malaysian culture since the Chinese immigrants introduced it and not only is there great tea grown locally but it’s also imported from China, Sri Lanka and India.</p>\n<p>In order to keep the tea fresh it has to be kept away from heat, light, air, and moisture and should be stored at room temperature in an airtight container. Plastic is not the best material as it will absorb the flavors of whatever is put in it, even if it’s tea and that will permeate to the current batch.</p>\n<p>A good stainless steel or aluminum tea container with a well-fitting lid is just what the doctor ordered. And they look great on the kitchen counter. They may be a little pricey, but the craftsmanship is worth it. As well as having fresh tea all the time.</p>\n<p>Royal Selangor Pewter is the perfect place to pick up one of these.</p>\n<h4>Clay water container (Labu Sayong)</h4>\n<p>Sayong is a village in Perak, Malaysia that is famous for making “labu sayong”, or clay water containers. Labu means “pumpkin” since the local clay is first shaped then a pumpkin glaze is added before baking.</p>\n<p>These beautiful clay pots are very decorative, have several health benefits and keep water naturally cool even in the summer. Since it is made from clay and not plastic, there are no harmful chemicals that can harm your body.</p>\n<p>These can be found in beautiful colors and designs. Best place to find these pots are Central Market in Kuala Lumpur, Sayong Village in Perak, Pasar Payang in Terengganu and also Pasar Khadijah in Kelantan.</p>\n<h4>Coconut utensils</h4>\n<p>Bowls, spoons, lamps even a coinbox all made from coconut shells are an amazing way to brighten up your home. Here in Malaysia, we call the coconut tree the “tree of 1000 uses”. I’m not sure if there are exactly 1000 uses, but I’m here to tell you, there are many.</p>\n<p>After the meat and juice are extracted from the coconut, Malaysian creativity goes to work. They craft these items artistically to make useful household items and the benefits are astounding. Since they are wood they are naturally anti-bacterial, don’t conduct heat (no more burned hands from grabbing a hot spoon to stir) and don’t stick to food.</p>\n<p>Tourists and locals flock to these eco-friendly utensils. Even I use some at home. You can buy them as a set in the Central market in Kuala Lumpur where you’ll find a large selection, but they can be found at markets all throughout Malaysia.</p>\n<h4>Baba and Nyonya food container</h4>\n<p>This is a stackable food or “tiffen” carrier, normally with three tiers and more elaborate ones have five. The bottom tier is traditionally larger and is the one reserved for rice. The tiers sit on top of each other and are held together by the handle, which makes it easy to carry. It can then be opened by unlocking a small catch on either side of the handle.</p>\n<p>Also known locally as Mangkuk Sia, these were popular from colonial times in the late 18th century up until the 1960s, however, some still use it today. They are easy to use, clean and store and make a great replacement for plastic bags or other harmful food packages.</p>\n<p>They are made of brass or stainless steel and can be found either plain or ornately painted with different Asian-inspired designs. These are great for decoration or even to use daily to take food to school or the office.</p>\n<p>So now you know what I carry my lunch in to work every day.</p>\n<h4>Dried chili paste</h4>\n<p>Nowhere in the world are you going to find a dried chili paste like you will in Malaysia. There are so many different ethnic blends and places that add their own special touch, sometimes you can tell culture by its chili paste.</p>\n<p>Malaysian chili paste is normally super hot with added anchovies, whereas Chinese chili paste is simmered longer for a more mellow taste. Indian chili paste has a blend of sweet, spicy and sour.Some places may add other ingredients such as soybeans, salt, vinegar, lime juice or garlic.</p>\n<p>If you’re a fan of spicy, then this is the perfect foodie souvenir. It can be added to the recipe or used as a condiment, your choice.</p>\n<p>If you are in Melaka you will find Chinese or Peranakan dried chili paste. To find Malay go to Pasar Siti Khadijah in Kelantan or Pasar Payang in Terengganu. And if you are in Penang, hop over to Chowrasta to find our famous Penang-style chili paste.</p>\n<h4>Traditional food basket with cover</h4>\n<p>These food baskets are a great souvenir and will really liven up any kitchen. They are woven from the tall, thorny leaves of the pandanus or mengkuang which are collected, boiled and dyed.</p>\n<p>They were once used in the days before people had refrigerators to hold leftover cooked foods. The netting cover keeps the pests out, yet lets the air to circulate so the cooked food could cool properly and not spoil. It also allows someone to look in and see what’s for dinner without having to lift the lid. They are still very popular in a Peranakan households.</p>\n<h4>Curry powder</h4>\n<p>Curry powder is a great take away from your Malaysian vacation. It can be used to make, of course, curry dishes but can also be used as a rub in grilling or frying.</p>\n<p>Curry powder is a mixture of many spices like ground ginger, coriander, cumin, pepper and turmeric. The turmeric is what gives it its pungent aroma and yellow color.</p>\n<p>There are different types to choose from besides the “normal” curry powders depending on your tastes:</p>\n<p><strong>Madras Curry Powder</strong></p>\n<p>This one’s a bit spicy and has more of a red color than yellow since it’s made from dried chilis.</p>\n<p><strong>Vindaloo Curry powder</strong></p>\n<p>This one is even spicier and has many more chilis added</p>\n<p><strong>Maharaja Curry Powder</strong></p>\n<p>This curry powder is milder with a hint of sweetness.</p>\n<h4>Durian Chocolate</h4>\n<p>If you read my article on Durian, then you’ll already know what I’m talking about. If you haven’t read it, then stop what you’re doing now and go read it. It’s a good one.</p>\n<p>Durian chocolate is a great way to introduce your friends and family back home to durian. Or if you were like me, you can keep it all to yourself.</p>\n<p>There are so many more items to take home for great souvenirs. The above list is just what I’ve seen as most popular among tourists. Some other items to consider are : Honey, My Kuali Penang White Curry Instant Noodles, Instant White Coffee (you’ll fall in love with this), Nutmeg Oil and Boh tea.</p>\n<p>What’s one foodie souvenir you would want to get your hands on?</p>\n<p>The above list is just a sampling of some of the traditional foods you’ll find during Hari Raya month. If you are fortunate to be invited into a Muslim home to celebrate with them, they may have other family traditional dishes as well. Keep in mind, that even though the food is delicious and a lot of work goes into it, the food is only the medium to bringing families together during this celebration.</p>\n<h4>Enjoy Hari Raya As A Tourist</h4>\n<p>There are so many ways besides food to enjoy the month of Hari Raya as a tourist. Here are a few to think about.</p>\n<h4>Open House</h4>\n<p>A favorite way of many of our tourists is to get invited to an open house to experience first hand how to celebrate alongside a Muslim family and indulge in all the delicacies. It’s not difficult to make amazing Muslim friends in Malaysia and in their faith they do receive extra blessings for inviting a foreigner into their homes for food and celebration.</p>\n<p>Even our government organizes a National Open House for the public to come and enjoy the food.</p>\n<h4>Shopping</h4>\n<p>Hari Raya is a time for new clothes and dressing to impress. As a tourist, you can definitely take advantage of the incredible savings during Hari Raya sales. So if you are visiting this time of the year, make sure to leave some space in your suitcase for what you will bring home.</p>\n<h4>More about Hari Raya (and tips on celebrating with the Muslims)</h4>\n<ol><li>Hari Raya lasts for the whole month</li><li>Hari Raya Eidulfitri and Hari Raya Aiduladha is not the same celebration</li><li>It’s rude to eat or drink while standing up</li><li>Guys don’t shake hands with ladies in the house</li><li>There are no strict rules on gifting</li><li>Inauspicious colours are not a thing</li><li>Don’t visit houses after 9 pm unless you are invited.</li></ol>\n<p>The celebration marks the end of Ramadan, the holy month of fasting and is a culmination of the month-long struggle towards a higher spiritual state. Ramadan holds special significance for Muslims, since the Quran, the book of Muslim scripture, was revealed during this month.</p>\n<p>Fireworks are always a part of Hari Raya which can be both fun and dangerous. In some places fireworks have been banned, but there are always some around to get the real feel for Hari Raya.</p>\n<p>Since it is a season of giving, you may hear about or encounter (or even get one yourself!) a “green packet”. These little packets are tokens given by the older generation to the young singles around them. What’s inside? Joy. It could be cash or some other trinket to bring luck and happiness.</p>\n<p>Even though Hari Raya is a celebration, it still hold a special significance to the Muslim community and they take it just as seriously as they do with Ramadan. Charity is openly practiced especially on the last day of Ramadan and all through Hari Raya you can see families giving food and money to the poor or even inviting them into their homes so they can all celebrate together. Come and visit us in Malaysia during Hari Raya and you will surely get invited. Let’s eat!</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.908+08	2026-04-03 11:28:35.907+08	published	\N	\N
23	Traveling Malaysia during the fasting month (the best way to experience Ramadan)	traveling-during-fasting-month	1	Malaysia has a high population of Muslims citizens, more than half the country, making the month of Ramadan a special time nationwide. Many tourists find this as the ideal time for their Malaysian getaway. Some have friends who they visit on Hari Raya, and others just want to have the rich experienc	<p>Malaysia has a high population of Muslims citizens, more than half the country, making the month of Ramadan a special time nationwide. Many tourists find this as the ideal time for their Malaysian getaway. Some have friends who they visit on Hari Raya, and others just want to have the rich experience of visiting Malaysia during the month of Ramadan.</p>\n<p>Some may get the idea that by traveling to Malaysia for vacation during Ramadan month, that they‘ll be an intrusion as a non-muslim. This is not the case. In fact, Malaysia is a multicultural melting pot with many different types of religions, beliefs and ethnic people that live together. Here in Malaysia, we do more than just tolerate one another, we live in harmony and respect of each other and share our best traditions. So even as a non-muslim, there is still plenty to do and enjoy during Ramadan month.</p>\n<p>There may be a few slight restrictions to consider when you come during Ramadan month, however. For instance, Muslim restaurants and some businesses and shops will be closed. But again, don’t let that dissuade you from coming and enjoying the great things Ramadan month in Malaysia has to offer.</p>\n<h4>What exactly is Ramadan?</h4>\n<p>Ramadan (also known as Ramadhan or Ramzan) is the ninth month in the Islamic calendar and is a holy month observed by Muslims worldwide. The word Ramadan comes from the Arabic root ramiḍa or ar-ramaḍ, which means scorching heat or dry ground without food or water.It commemorates the month during which Muhammad received the initial revelations of what would become the Quran and is one of the Five Pillars of Islam. This is what Muslims call “the best of times”.</p>\n<p>During the month of Ramadan, Muslims abstain from eating or drinking at dawn and sunset. This fasting is a way to attain taqwa, the fear of God. The goal is to bring oneself closer to Allah, or God. It is believed that God explained to the prophet Muhammad that fasting was an obligatory practice that should be observed by those who wish “oneness” with Him.</p>\n<p>Ramadan is also a special month for spending time with family and friends and reaching out to the poor and other charities in the community, but most importantly, Ramadan is a time of spiritual reflection.</p>\n<h4>Three parts of Ramadan</h4>\n<p>There are three parts to the month of Ramadan. Ramadan begins, The night of Power, and Eid (or Hari Raya in Indonesia and Malaysia). Each have its own special observances and meanings. For non-Muslims, Hari Raya is an exciting time to join with your Muslim friends and marks the end of Ramadan.</p>\n<h4>Ramadan Begins</h4>\n<p>Ramadan begins typically about a day after the new moon, marking the new month. Islamic scholars calculate the day each year, so it does fall on a different date. Take note: In Johor, Kedah, and Malacca, Ramadan begins is a public holiday and is a day off for the general public. Schools and most businesses are closed.</p>\n<h4>The Night Of Power</h4>\n<p>This is considered the most holiest of nights throughout the year. According to Islamic belief, it’s the night in which the first revelation of the Quran was given to Muhammad saying that this night was “better than one thousand months [of proper worship]”, as stated in Chapter 97:3 of the Quran.</p>\n<h4>Hari Raya Aidilfitri The End Of Ramadan</h4>\n<p>This is the first day of the new month, Shawwal and marks the end of Ramadan. This is a day of feating and celebrating for having successfully endured an entire month of abstaining from food, water, smoking and intimacy and represents the returning back to a normal routine.</p>\n<p>Hari Raya Aidilfitri is considered one of the two most important celebrations for Muslims, the other is Hari Raya Haji which is also a festival that commemorates Abraham’s sacrifice.</p>\n<p>We’ll talk a little more about Hari Raya later on. This is a time when our tourists come back and rave about the food and fun they enjoyed.</p>\n<h4>How is Ramadan Observed?</h4>\n<p>Our Muslim communities, as well as Muslim communities worldwide, take Ramadan very seriously and follow all of the practices and observances required. As mentioned, Ramadan is a month of fasting. During daylight hours, Muslims fast from food, water, sexual activity and smoking. This is obligatory for all adult Muslims except those who are sick, traveling, elderly, pregnant, breastfeeding, diabetic, chronically ill or women who may be menstruating. Although eating during daylight hours is permitted for those mentioned, they still will not eat in public.</p>\n<p>Prayer and spiritual reflection is an important part of Ramadan. Many immerse themselves into studying and reciting the Quran, and vow to recite the Quran in its entirety by the months end.</p>\n<p>This is how the fast is observed:</p>\n<h4>Sahur- The Pre-dawn Meal</h4>\n<p>This fast begins right after Sahur, or the pre dawn meal. This gives them energy for the long day ahead. Normally, sahur is served around 4:30 am, but this depends on which state because in Sabah and Sarawak the break of dawn is earlier compared to the Peninsular of Malaysia. The Sahur time will also be earlier. Once the dawn breaks, no food is taken for the rest of the day until sundown. Malaysia is fortunate that the days are not as long as in some other areas of the world. But it doesn’t matter, Muslims take this sacrifice very seriously and accept it piously.</p>\n<p>Some stay up after Sahur and take the time to reflect and pray, while others will grab a little more sleep. Both are accepted.</p>\n<p>Tourists can experience sahur at any mosque and also many Muslim restaurants do prepare a meal for Sahur, then close afterward. Sahur can be a variety of foods like coconut pancakes or BBQ chicken wings, or just a simple baked macaroni or corn coconut pudding.</p>\n<h4>Buka Puasa- Break fasting meal at sunset</h4>\n<p>This is the best time of the day. After fasting the whole day all Muslims will celebrate the day by breakfasting. Here the term “breakfast” does not refer to the morning meal as it has come to be recognized, but the meaning is the same. Buka Puasa is “breaking the fast”.</p>\n<p>Traditionally, dates are the first thing eaten to break the day’s fast. This is a remembrance of how Muhammad broke his own fast by eating dates. After that, they generally gather for the Maghrib prayer, the fourth of the five daily prayers, after which the main meal is served.</p>\n<p>Its all about sharing and giving. There are no restrictions for non-Muslims to join the breakfast. Everyone is welcome in the feast, so if you perhaps meet a Muslim family while on vacation, don’t be surprised if they invite you to eat with them after sundown.</p>\n<p>Depending on some city councils, do organize public breakfasts meaning they will sponsor food for the public or even anyone to come and join the breakfast. And you will sit together will the locals and enjoy a meal at that particular area. You have to just find out if there are any in your area.</p>\n<h4>Tarawih Prayer</h4>\n<p>During the month of Ramadan, it’s very common to see mosques occupied with people 24/7. Many of our tourists are amazed to see this type of devotion and dedication. What’s unique about visiting the mosque during Ramadan month is its the only time throughout the year you will hear the Tarawih Prayer being recited. However, it’s not obligatory to recite them.</p>\n<p>Usually, after the prayer, there will be some religious lectures that is also open to the public. If you are visiting one of the beautiful mosques during Ramadan month, you may even be invited inside to experience it firsthand.</p>\n<h4>Charities and Charity Work</h4>\n<p>In the Muslim faith, great importance is placed on charity and charity work. In fact, one of The Pillars Of Islam is a certain percentage of one’s wages should be donated to the poor. However, during Ramadan, it is believed the rewards for giving charity are greater, so many take this opportunity for Sadaqah or voluntarily give more than what is normally required which will maximize their reward at the Last Judgement.</p>\n<h4>Experiencing Ramadan Month as a  Tourist</h4>\n<p>For the non-Muslim traveling to Malaysia during Ramadan month, you may not notice much of a difference if you are not interested in visiting the mosques or enjoying the Muslim Ramadan traditions. Some attraction places might close earlier so the Muslims can get themselves ready for breakfast. They will need to buy food, cook and make preparations for the sundown meal. This usually will affect certain specific states like Kelantan, Terengganu,Johor and Kedah. Just check on the timing to reconfirm.</p>\n<p>Traffic in Ramadan will be a bit more congested than normal in the afternoon. Most of the office workers will leave work earlier so they can get home and prepare So, if you need to catch a bus, train or flight ensure you plan ahead for your journey. Just to avoid the heavy traffic.</p>\n<h3>Pasar Ramadan (Ramadan Bazaar)</h3>\n<img src="https://se-website-images.s3.nl-ams.scw.cloud/asset_71_d0b570c224.jpeg" alt="asset-71.jpeg">\n<p>If you find yourself in Malaysia during Ramadan month, you will not be able to miss the Pasar Ramadan, or the Ramadan Bazaar. This is a month-long bazar set up in many cities and Muslim communities, almost everywhere throughout Malaysia, that sells an enormous amount of food. And when I say big, I mean big. The Ramadan Bazaar in Kuala Lumpur,Kampung Baru Ramadan Bazaar has over 200 stalls selling just about anything you can imagine and has been known to be almost two kilometers long.</p>\n<p>Different kind of rice from other states, different colours and tastes. Here you can find foods like kerabu rice, dagang rice, nasi lemak, nasi briyani, and nasi ambeng, just to name a few popular dishes. You can choose anything you fancy. The bazaar is not reserved only for Muslims observing Ramadan. Anyone can can enter and eat. I recall a tourist group last year that made a point to visit the bazaar everyday of their stay for breakfast. There was no reason to go to a restaurant, everything they wanted was right there.</p>\n<p>You’ll also find local delicacies ranging from sweet to savory. Try popia goreng, kuih puteri mandi, pulut panggang. These are some dishes that you won’t be able to find normally. Cold drinks are also served. The Bazaar normally opens at 4:30 am then closes around 7:30 am. It will re-open as early as 4pm so people can gather what they need for breakfasting.</p>\n<h4>Hari Raya</h4>\n<p>If you are fortunate enough to be in Malaysia for Hari Raya, prepare for an amazing experience. This is the end of Ramadan month and the end of the fasting. As soon as the new moon is seen on the last day of Ramadan, the fasting is over and the celebration begins.</p>\n<p>However, most Muslims have already been planning and preparing for Hari Raya way in advance. They stock food, buy new clothes and gifts and really let the excitement build. On the morning of Hari Raya, the men perform prayers at the mosque while children ask for forgiveness from their parents. The children also receive small green packets stuffed with cash. After prayers, it’s time to eat and visit with friends.</p>\n<p>Traditionally the first three days of Hari Raya are to be spent catching up with relatives and close friends, however many families open their homes throughout the month for anyone, Muslim or not, to come and enjoy food, fun and laughter with them. Hopefully, you will be fortunate if you had visited one of the mosques or even met some locals at the bazaar to be invited to an open house. Not an experience you’ll want to pass up. Thsi is actually a common practice and believed that by invited non-Muslims and/or foreigners into their homes for Hari Raya, they will receive extra blessings.</p>\n<p>Here in Malaysia, the first two days of Hari Raya are public holidays, so many things will be closed and the cities may look a little deserted as a lot of Muslims will travel to their hometowns to visit their families and spend time celebrating with them. Even once they return to the cities and back to work, the celebrations don’t end. For the rest of the month you’ll still find them throwing parties and having open houses. One month of fasting, followed by one month of festivities.</p>\n<h4>Foods To Try During Hari Raya</h4>\n<p>The delicacies offered during Hari Raya are not to be passed up.Just like pumpkin pie and Thanksgiving in the US, some of these delicacies go hand in hand with Hari Raya and can only be found during this time.</p>\n<h4>Ketput</h4>\n<p>Ketput is one such food item that everyone looks forward to and to be honest, it wouldn’t be Hari Raya without it. Ketput is compressed rice wrapped in coconut leaves in the shape of a diamond then cooked.</p>\n<p>It’s usually served with beef rending (beef cooked with coconut milk and malay spices) and satay (skewered grilled meat), or just with cool slices of cucumber.</p>\n<h4>Lemang</h4>\n<p>Another one of Malaysia’s signature Hari Raya delicacies. Lemang is glutinous coconut rice wrapped in fragrant banana leaves, then stuffed into hollow bamboo sticks and roasted over a fire. I like this best with my rendang or even chicken curry.</p>\n<h4>Dodol</h4>\n<p>Doldol may seem tame given the ingredients are only coconut milk, cane sugar and rice flour, but ask any local and they will tell you this is a difficult one to make. It takes nine hours of constant stirring over a hot fire to come up with the finished product. When you give this a try, remember the work that went into it. It will taste even better.</p>\n<h4>Bubur Lambuk</h4>\n<p>This is a soup that is also quite popular during the Ramadan month as well as Hari Raya. Anise, cardamom, cinnamon and black pepper, among other spices are simmered along with certain vegetables and meat depending on what region or part of Malaysia you are in</p>\n<h4>Lontong</h4>\n<p>Lontong is an amazing Hari Raya dish that has its roots in Indonesia. It’s a coconut soup that’s a combination of nasi impit, vegetables and meat, served in a savoury coconut milk base. Again depending on where you are, there will be variations. Some cooks put peanut sauce in the soup while others add tempeh or a hard-boiled egg. Its served with rice cakes.</p>\n<h4>Some Quick Pro Tips About Travelling During Ramadan</h4>\n<p>• Take note that shops and malls will be pretty packed the week before Ramadan. People like to stock up, especially on dates, which is served every night at breakfasting</p>\n<p>• As the sun goes down, traffic can get quite heavy as everyone rushes home for breakfasting. If you plan to go out to dinner, might want to try and go a little early before the sun goes down.</p>\n<p>• In country flights, busses and trains can be crowded or all booked up since many Muslims will be traveling to see their families. Make sure to reserve way in advance if you plan to travel around the country.</p>\n<p>• If traveling during Ramadan month, try and find hotels near or around Indian or Chinese communities. Some hotels and restaurants may be closed during the day if they are Muslim owned and operated.</p>\n<p>• Pack some snacks if you plan to travel in areas where restaurants and shops may be closed.</p>\n<p>If you are planning your vacation to Malaysia, and it happens to fall within Ramadan month, don’t reschedule, but consider yourself lucky to be able to experience this wonderful culture and religion at such a great time of the year for them. And if you have extra vacation days, stick around for Hari Raya. You won’t be disappointed.</p>	\N	draft	draft	\N	\N	\N	\N	2026-04-03 11:28:35.92+08	2026-04-03 11:28:35.92+08	published	\N	\N
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.testimonials (id, author_name, author_location, rating, review_text, review_title, author_photo, date, visibility_verified, visibility_featured, platform, workflow_status, updated_at, created_at, _status, _locales) FROM stdin;
6	Sarah Johnson	Australia	5	The Flavours of Malaysia tour was the highlight of our trip. Our guide was knowledgeable and the food was incredible!	Amazing experience!	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.266+08	2026-04-03 16:09:42.266+08	draft	\N
7	Michael Chen	Singapore	5	Great way to experience local culture. The market visit was eye-opening and all the food stops were fantastic.	Highly recommended	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.302+08	2026-04-03 16:09:42.302+08	draft	\N
8	Emma Williams	United Kingdom	5	We have done food tours around the world, and this one tops them all. Authentic, delicious, and great value.	Best food tour ever	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.329+08	2026-04-03 16:09:42.329+08	draft	\N
9	David Lee	USA	5	The Penang Heritage tour exceeded our expectations. Our guide shared amazing stories and the food was outstanding.	Penang tour was exceptional	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.359+08	2026-04-03 16:09:42.359+08	draft	\N
10	Priya Sharma	India	5	As a vegetarian, I was worried about food options in Malaysia. This tour showed me so many delicious vegetarian dishes!	Perfect for vegetarians	https://se-website-images.s3.nl-ams.scw.cloud/karen_testimonial_faadb8a58e.jpg	\N	t	f	TripAdvisor	draft	2026-04-03 16:09:42.385+08	2026-04-03 16:09:42.385+08	draft	\N
\.


--
-- Data for Name: thank_you_pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.thank_you_pages (id, title, type, slug, status, hero_section_heading, hero_section_subheading, hero_section_icon, message, contact_info_show_contact, contact_info_email, contact_info_phone, contact_info_response_time, cta_section_show_cta, seo_meta_title, seo_meta_description, updated_at, created_at, _locales) FROM stdin;
1	We Can't Wait to Show You Our Malaysia	booking	thank-you-booking	published	We Can't Wait to Show You Our Malaysia	Your tour is confirmed	✅	[{"type": "paragraph", "children": [{"text": "We Can't Wait to Show You Our Malaysia content loaded from import.", "type": "text"}]}]	t	info@simplyenak.com	+60 17-287 8929	We'll respond within 3 hours	t	Thank You | Simply Enak	Your Simply Enak tour is confirmed.	2026-04-03 13:17:42.2+08	2026-04-03 13:17:42.2+08	\N
2	Thanks for Reaching Out	contact	thank-you-contact	published	Thanks for Reaching Out	We'll get back to you soon	💬	[{"type": "paragraph", "children": [{"text": "Thanks for Reaching Out content loaded from import.", "type": "text"}]}]	t	info@simplyenak.com	+60 17-287 8929	We'll respond within 3 hours	t	Thank You | Simply Enak	Thanks for contacting Simply Enak.	2026-04-03 13:17:42.2+08	2026-04-03 13:17:42.2+08	\N
3	Thanks for Your Interest	inquiry	thank-you-inquiry	published	Thanks for Your Interest	Let's plan your perfect Malaysian food adventure	🍜	[{"type": "paragraph", "children": [{"text": "Thanks for Your Interest content loaded from import.", "type": "text"}]}]	t	info@simplyenak.com	+60 17-287 8929	We'll respond within 3 hours	t	Thank You | Simply Enak	Thanks for your interest in Simply Enak.	2026-04-03 13:17:42.2+08	2026-04-03 13:17:42.2+08	\N
\.


--
-- Data for Name: thank_you_pages_cta_section_cta_buttons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.thank_you_pages_cta_section_cta_buttons (_order, _parent_id, id, text, url, variant) FROM stdin;
\.


--
-- Data for Name: thank_you_pages_next_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.thank_you_pages_next_steps (_order, _parent_id, id, step) FROM stdin;
\.


--
-- Data for Name: tours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tours (id, name, slug, tagline, short_description, full_description, price, currency, duration, duration_minutes, location, meeting_point, max_participants, min_participants, tailored_available, tailored_notes, booking_url, instant_confirmation, scheduled_publish, featured, popular, new, published_at, status, workflow_status, meta_title, meta_description, meta_image_id, updated_at, created_at, _status, hero_image_id, _locales) FROM stdin;
5	Secrets of KL – Nightlife, Street Art & Cocktails!	secrets-of-kl-nightlife	Adults Only Adventure	Simply Enak's adults-only adventure reveals hidden speakeasy bars, classic Malaysian food and the forbidden tales of the red-light district.	This adults-only adventure reveals hidden speakeasy bars, classic Malaysian food, and the forbidden tales of the red-light district.\n\nExperience KL's sophisticated nightlife with insider access. You'll discover hidden speakeasy bars locals love, taste classic Malaysian late-night street food, and hear the forbidden tales that shaped these streets.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)	359	MYR	4 hours	240	Kuala Lumpur	Pasar Seni MRT Station, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.121+08	2026-04-03 11:26:47.12+08	published	\N	\N
6	Vegetarian Food Tour around Kuala Lumpur	vegetarian-food-tour-around-kuala-lumpur	100% Plant-Based. No Fish Sauce. No Surprises.	Kuala Lumpur has one of Asia's strongest vegetarian scenes. Simply Enak will guide you through 140 years of Indian vegetarian tradition, Buddhist vegetarian restaurants, and modern vegan cafes.	Kuala Lumpur has one of Asia's strongest vegetarian scenes, thanks to 140 years of Indian vegetarian tradition and thriving Buddhist vegetarian culture.\n\nBut here's the catch: "Vegetarian" here often means "no meat" — fish sauce, shrimp paste, and egg still show up. We know which stalls are truly 100% plant-based (no belacan, no oyster sauce, no egg noodles).\n\nWe've mapped the Buddhist vegetarian restaurants, the Indian vegan curry houses, and the Nyonya chefs who can adapt traditional recipes. This isn't "salad and rice." This is Malaysian cuisine at its most creative.\n\n---\n\n## Why Choose Our Vegetarian Food Tour?\n\n**14 Years of Dietary Expertise (Since 2011)**\nWe've accommodated every dietary need since 2011. Vegetarian, vegan, Jain, gluten-free — we know which stalls use belacan (shrimp paste), which use lard, which have dedicated allergen-free prep areas.\n\n**100% Plant-Based Vendors**\nNo fish sauce. No shrimp paste. No oyster sauce. No surprises. Every vendor is verified for strict vegetarian standards. Buddhist vegetarian stalls (素食) exclude all animal products and the five pungent roots.\n\n**Variety Beyond Salad**\nIndian banana leaf rice, Buddhist mock meats, modern vegan cafes, traditional Nyonya vegetarian dishes. This is Malaysian cuisine at its most creative — not an afterthought.\n\n**Small Groups (Max 9 People)**\nNot "up to 15." Not "usually 12." Maximum 9 people, every tour. Because you can ask questions about ingredients. Because you can hear the vendor stories.\n\n---\n\n## What Makes This Tour Different?\n\n| Feature | Simply Enak | Other Tours |\n|---------|-------------|-------------|\n| Vendor Verification | 100% plant-based checked (no belacan, no oyster sauce) | "Vegetarian-friendly" (may contain fish sauce) |\n| Dietary Knowledge | 14 years expertise (vegetarian since 2011) | Basic (ask at each stall) |\n| Variety | 8-10 different dishes across 3-4 vendor types | 5-6 dishes |\n| Group Size | Max 9 | 12-20 |\n| Guide Expertise | Local founders (Pauline & Maarten) | Hired guides |\n| Booking | Direct, no platform fees | Platform (20-25% commission) |\n\n**Sources:** Based on Simply Enak's 14 years dietary accommodation experience, competitor tour descriptions on Viator/GetYourGuide.\n\n**The Bottom Line:** We're not the cheapest. But after 14 years, 2,847 guests, and a 5.0/5.0 rating — we're the most trusted for dietary needs.	289	MYR	4 hours	240	Kuala Lumpur	Brickfields (Little India), Kuala Lumpur	9	2	t	We can create custom vegetarian tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.142+08	2026-04-03 11:26:47.142+08	published	\N	\N
7	Vegetarian Food Tour around Penang	vegetarian-food-tour-around-penang	Penang's Best Vegetarian Street Food	Penang is surprisingly vegetarian-friendly! Simply Enak will show you the best vegetarian char kway teow, laksa, and Nyonya kuey - all 100% plant-based.	Penang is surprisingly vegetarian-friendly! Despite its reputation for seafood, the island has a thriving vegetarian scene thanks to its large Buddhist community.\n\nWe'll show you vegetarian char kway teow (yes, it exists!), vegetarian laksa, and colorful Nyonya kuey - all 100% plant-based with no fish sauce or shrimp paste.\n\nEvery vendor is verified vegetarian. No surprises. Just amazing food.	289	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	We can create custom vegetarian tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.163+08	2026-04-03 11:26:47.163+08	published	\N	\N
8	Halal Food Tour around Kuala Lumpur	halal-food-tour-around-kuala-lumpur	100% Halal-Certified. No Pork. No Alcohol.	Malaysia is a Muslim-majority country where halal food is the default. Simply Enak will guide you through verified halal vendors, from Indian Muslim roti canai to Malay nasi lemak.	Malaysia is a Muslim-majority country where halal food is the default - but not every tour understands the nuances.\n\nWe know which wet markets sell pork separately (clearly marked), which hawker stalls are halal-certified, and which "Muslim-owned" restaurants actually serve alcohol.\n\nOur guides grew up navigating these distinctions. You won't have to ask awkward questions or wonder if that sauce contains wine vinegar. Every stop is verified halal - no guesswork, no compromises.	289	MYR	4 hours	240	Kuala Lumpur	Kampung Baru, Kuala Lumpur	9	2	t	We can create custom halal tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.184+08	2026-04-03 11:26:47.184+08	published	\N	\N
9	Halal Food Tour around Penang	halal-food-tour-around-penang	Penang's Best Halal Street Food	Penang has excellent halal options! Simply Enak will show you halal char kway teow, nasi kandar, and more - all verified halal-certified.	Penang has excellent halal options despite its diverse food scene!\n\nWe'll show you halal char kway teow, legendary nasi kandar, and more - all verified halal-certified vendors.\n\nEvery stop is verified halal. No pork, no alcohol, no cross-contamination.	289	MYR	3.5 hours	210	Penang	Lebuh Chulia, George Town, Penang	9	2	t	We can create custom halal tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.205+08	2026-04-03 11:26:47.204+08	published	\N	\N
10	Gluten-Free Food Tour around Kuala Lumpur	gluten-free-food-tour-around-kuala-lumpur	Naturally GF. No Soy Sauce Surprises.	Malaysian food is surprisingly gluten-free friendly! But soy sauce hides everywhere. We've mapped the GF-safe vendors who use wheat-free soy sauce.	Malaysian food is surprisingly gluten-free friendly - rice, coconut milk, fresh spices, grilled meats. But here's the catch: soy sauce, oyster sauce, and hoisin hide everywhere.\n\nMost vendors don't know what "gluten" means. They'll say "yes, can!" while pouring dark soy into your dish.\n\nWe've mapped the GF-safe vendors. We know which stalls use wheat-free soy sauce, which rice noodle dishes are contaminated, and which desserts use wheat flour. Your gut won't pay the price.	299	MYR	4 hours	240	Kuala Lumpur	Pasar Seni, Kuala Lumpur	9	2	t	We can create custom GF tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.226+08	2026-04-03 11:26:47.226+08	published	\N	\N
11	Gluten-Free Food Tour around Penang	gluten-free-food-tour-around-penang	Penang's Best Naturally GF Dishes	Penang has many naturally GF options! Rice noodles, grilled seafood, coconut-based curries. Simply Enak will show you the GF-safe vendors.	Penang has many naturally GF options! Rice noodles, grilled seafood, coconut-based curries - so much is naturally gluten-free.\n\nBut cross-contamination is real. We'll show you the GF-safe vendors who understand celiac disease and use dedicated utensils.	299	MYR	3.5 hours	210	Penang	Gurney Drive, Penang	9	2	t	We can create custom GF tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.248+08	2026-04-03 11:26:47.248+08	published	\N	\N
12	Vegan Food Tour around Kuala Lumpur	vegan-food-tour-around-kuala-lumpur	100% Plant-Based. No Animal Products.	KL has a thriving vegan scene! Modern vegan cafes, traditional Indian vegan, and Buddhist vegetarian. All 100% plant-based.	KL has a thriving vegan scene! From modern vegan cafes in Bangsar to traditional Indian vegan curry houses and Buddhist vegetarian restaurants.\n\nWe know which stalls are truly 100% plant-based (no honey, no dairy, no egg). Every vendor is verified vegan.	299	MYR	4 hours	240	Kuala Lumpur	Bangsar, Kuala Lumpur	9	2	t	We can create custom vegan tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.265+08	2026-04-03 11:26:47.264+08	published	\N	\N
13	Vegan Food Tour around Penang	vegan-food-tour-around-penang	Penang's Best Vegan Street Food	Penang has surprising vegan options! Simply Enak will show you vegan char kway teow, laksa, and more - all 100% plant-based.	Penang has surprising vegan options! Despite its reputation for seafood, the island has a thriving vegan scene.\n\nWe'll show you vegan char kway teow, vegan laksa, and colorful Nyonya kuey - all 100% plant-based with no fish sauce, shrimp paste, or egg.	299	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	We can create custom vegan tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.282+08	2026-04-03 11:26:47.282+08	published	\N	\N
14	Jain Food Tour around Kuala Lumpur	jain-food-tour-around-kuala-lumpur	Strict Jain. No Root Vegetables.	KL's Indian community includes Jains. We know which restaurants have separate Jain kitchens and understand no root vegetables.	KL's Indian community includes a Jain population - which means we have authentic Jain restaurants.\n\nWe know which restaurants have separate Jain kitchens, which vendors understand "no root vegetables" (no onion, garlic, potato, carrot, beet), and which can prepare pure ahimsa cuisine without cross-contamination.	309	MYR	4 hours	240	Kuala Lumpur	Brickfields, Kuala Lumpur	9	2	t	We can create custom Jain tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.299+08	2026-04-03 11:26:47.299+08	published	\N	\N
15	Jain Food Tour around Penang	jain-food-tour-around-penang	Penang's Jain Cuisine	Penang has Jain options! Simply Enak will show you Jain thali, dal, and more - all prepared without root vegetables.	Penang has Jain options! We know which restaurants understand Jain dietary laws and can prepare food without onion, garlic, or root vegetables.	309	MYR	3.5 hours	210	Penang	Little India, Penang	9	2	t	We can create custom Jain tours for groups of 6+.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.317+08	2026-04-03 11:26:47.317+08	published	\N	\N
16	Street Food Tour around Kuala Lumpur	street-food-tour-around-kuala-lumpur	Hawker Centres. Roadside Stalls. The Real KL.	KL's street food isn't a trend - it's a way of life. For 140+ years, hawkers have been perfecting recipes at the same roadside stalls.	KL's street food isn't a trend - it's a way of life. For 140+ years, hawkers have been perfecting recipes at the same roadside stalls.\n\nWe take you beyond tourist hawker centres to where locals actually eat: the 5am breakfast stalls, the midnight supper spots, the hidden alleys where the best char kway teow lives.	285	MYR	3.5 hours	210	Kuala Lumpur	Pasar Seni, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.335+08	2026-04-03 11:26:47.334+08	published	\N	\N
17	Street Food Tour around Penang	street-food-tour-around-penang	Food Capital of Malaysia	What makes Penang the "food capital" of Malaysia? Simply Enak will guide you through the cultural fusion that created dishes you'll only find here.	What makes Penang the "food capital" of Malaysia? We'll guide you through the cultural fusion that created dishes you'll only find here.\n\nAt Chowrasta Market, we'll dare you to try kopitiam "Ngor Ka Sai", signature nutmeg pickles and dodol. You'll watch a master handcraft popiah skin, and taste legendary Asam Laksa balancing sweet, sour and savoury.	285	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.352+08	2026-04-03 11:26:47.352+08	published	\N	\N
18	Market Food Tour around Kuala Lumpur	market-food-tour-around-kuala-lumpur	Chow Kit Market - KL's Largest Wet Market	Discover a traditional wet market to discover the real ingredients behind Malay cooking - exotic fruits, aromatic spices and more!	Discover a traditional wet market to discover the real ingredients behind Malay cooking - exotic fruits, aromatic spices and more!\n\nChow Kit Market is KL's largest wet market - a sprawling maze where locals have shopped for 100+ years. No souvenir shops. No tourist traps. Just real KL.	289	MYR	3.5 hours	210	Kuala Lumpur	Chow Kit Market, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.372+08	2026-04-03 11:26:47.372+08	published	\N	\N
19	Market Food Tour around Penang	market-food-tour-around-penang	Chowrasta Market - Penang's Historic Market	Chowrasta Market is Penang's historic market - a sensory overload of spices, fruits, and local delicacies.	Chowrasta Market is Penang's historic market - a sensory overload of spices, fruits, and local delicacies.\n\nWe'll guide you through the maze, introducing you to vendors who've been here for generations. Taste signature nutmeg pickles, watch popiah being made, and discover ingredients you've never seen.	289	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.394+08	2026-04-03 11:26:47.394+08	published	\N	\N
20	Heritage Food Tour around Kuala Lumpur	heritage-food-tour-around-kuala-lumpur	Temples, Historic Lanes & Amazing Food	Brand new to Malaysia? This is everything you need to know, passing major temples and historic lanes in Chinatown with amazing food!	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian culture and heritage.\n\nEvery dish and vendor has a story.	289	MYR	4 hours	240	Kuala Lumpur	Chinatown, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.412+08	2026-04-03 11:26:47.412+08	published	\N	\N
21	Heritage Food Tour around Penang	heritage-food-tour-around-penang	Georgetown UNESCO Heritage & Food	Explore Georgetown UNESCO heritage streets while tasting Peranakan culture through colourful kuey and legendary dishes.	Explore Georgetown UNESCO heritage streets while tasting Peranakan culture through colourful kuey and legendary dishes.\n\nWe'll share Peranakan culture, explore temples and street art, and you'll leave with the history and culture behind Penang's most famous flavours.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.429+08	2026-04-03 11:26:47.429+08	published	\N	\N
22	Night Food Tour around Kuala Lumpur	night-food-tour-around-kuala-lumpur	Adults Only Adventure	Simply Enak's adults-only adventure reveals hidden speakeasy bars, classic Malaysian food and the forbidden tales of the red-light district.	This adults-only adventure reveals hidden speakeasy bars, classic Malaysian food, and the forbidden tales of the red-light district.\n\nExperience KL's sophisticated nightlife with insider access. You'll discover hidden speakeasy bars locals love, taste classic Malaysian late-night street food, and hear the forbidden tales that shaped these streets.	359	MYR	4 hours	240	Kuala Lumpur	Pasar Seni MRT, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.448+08	2026-04-03 11:26:47.448+08	published	\N	\N
23	Night Food Tour around Penang	night-food-tour-around-penang	Georgetown After Dark	Experience Georgetown's vibrant night food scene. Hawker centres come alive after sunset.	Experience Georgetown's vibrant night food scene. Hawker centres come alive after sunset.\n\nWe'll guide you through the best night hawker stalls, taste sizzling satay, and experience Georgetown's nightlife like a local.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.465+08	2026-04-03 11:26:47.465+08	published	\N	\N
24	Family Food Tour around Kuala Lumpur	family-food-tour-around-kuala-lumpur	Perfect for Families with Kids	Traveling with kids? Simply Enak's family-friendly tours adjust spice levels, include kid-friendly foods, and move at a comfortable pace.	Traveling with kids? Our family-friendly tours adjust spice levels, include kid-friendly foods, and move at a comfortable pace.\n\nChildren under 12 are 50% off. We know which vendors have high chairs, where the clean bathrooms are, and how to keep kids engaged.	285	MYR	3.5 hours	210	Kuala Lumpur	Pavilion KL, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.487+08	2026-04-03 11:26:47.487+08	published	\N	\N
25	Family Food Tour around Penang	family-food-tour-around-penang	Penang's Best for Families	Penang is perfect for families! Simply Enak's tours are designed with kids in mind - kid-friendly foods, comfortable pace, and fun stories.	Penang is perfect for families! Our tours are designed with kids in mind - kid-friendly foods, comfortable pace, and fun stories.\n\nChildren under 12 are 50% off. We know the best family-friendly vendors.	285	MYR	3.5 hours	210	Penang	Gurney Drive, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.506+08	2026-04-03 11:26:47.506+08	published	\N	\N
26	Couples Food Tour around Kuala Lumpur	couples-food-tour-around-kuala-lumpur	Perfect Date Night Experience	Looking for something better than dinner and a movie? Food tours are the ultimate couples experience.	Looking for something better than dinner and a movie? Food tours are the ultimate couples experience.\n\nYou're not just eating together - you're discovering together. Trying new things. Sharing reactions. Creating memories.	289	MYR	4 hours	240	Kuala Lumpur	Bukit Bintang, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.524+08	2026-04-03 11:26:47.524+08	published	\N	\N
27	Couples Food Tour around Penang	couples-food-tour-around-penang	Georgetown Romance & Food	Georgetown is perfect for couples! Heritage streets, romantic settings, and amazing food.	Georgetown is perfect for couples! Heritage streets, romantic settings, and amazing food.\n\nWe'll guide you through atmospheric stops perfect for couples - sunset views, heritage shophouses, and shareable dishes.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.539+08	2026-04-03 11:26:47.539+08	published	\N	\N
28	Foodie Tour around Kuala Lumpur	foodie-tour-around-kuala-lumpur	For Serious Food Lovers	You're not a tourist who eats. You're a traveler who eats strategically. This tour is for you.	You're not a tourist who eats. You're a traveler who eats strategically. You research restaurants before booking flights.\n\nWe go deeper: chef interviews, recipe discussions, technique demonstrations. This isn't a tour. It's a masterclass.	299	MYR	4 hours	240	Kuala Lumpur	Jalan Alor, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.557+08	2026-04-03 11:26:47.557+08	published	\N	\N
29	Foodie Tour around Penang	foodie-tour-around-penang	Penang's Best for Food Lovers	Penang is the food capital of Malaysia - and this tour is for serious food lovers.	Penang is the food capital of Malaysia - and this tour is for serious food lovers.\n\nWe'll take you beyond the tourist spots to where serious foodies eat. Meet vendors who've been perfecting recipes for 40+ years.	299	MYR	4 hours	240	Penang	New Lane Hawker Centre, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.577+08	2026-04-03 11:26:47.577+08	published	\N	\N
30	Best Food Tour in Chow Kit Market	food-tour-around-chow-kit-market	The Best Chow Kit Market Experience	Looking for the best food tour in Chow Kit? You've found it. Simply Enak has been guiding visitors through this historic market for 14 years. Discover exotic fruits, aromatic spices, and local delicacies with KL's best-rated market tour.	Discover Chow Kit Market, KL's largest wet market - a sprawling maze where locals have shopped for 100+ years. No souvenir shops. No tourist traps. Just real KL.\n\nWe'll guide you through the maze, introducing you to vendors who've been here for generations. Taste exotic fruits, aromatic spices, and local delicacies you've never seen.	289	MYR	3.5 hours	210	Kuala Lumpur	Chow Kit Market, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.595+08	2026-04-03 11:26:47.595+08	published	\N	\N
31	Best Food Tour in Chinatown Petaling Street	food-tour-around-chinatown-petaling-street	The Best Chinatown KL Experience	Looking for the best food tour in Chinatown KL? You've found it. Simply Enak has been guiding visitors through Petaling Street for 14 years. Discover temples, historic lanes, and amazing food with KL's best-rated Chinatown tour.	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian culture and heritage.\n\nEvery dish and vendor has a story.	289	MYR	4 hours	240	Kuala Lumpur	Petaling Street, Chinatown, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.611+08	2026-04-03 11:26:47.61+08	published	\N	\N
32	Best Food Tour in Brickfields Little India	food-tour-around-brickfields-little-india	The Best Little India KL Experience	Looking for the best food tour in Little India KL? You've found it. Simply Enak has been guiding visitors through Brickfields for 14 years. Discover authentic Indian vegetarian restaurants and banana leaf rice with KL's best-rated Little India tour.	Brickfields has one of Asia's strongest vegetarian scenes, thanks to 140 years of Indian vegetarian tradition.\n\nWe'll guide you through authentic Indian vegetarian restaurants, banana leaf rice houses, and modern Indian cafes. Every vendor is verified for dietary needs.	289	MYR	4 hours	240	Kuala Lumpur	Brickfields, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.628+08	2026-04-03 11:26:47.628+08	published	\N	\N
33	Best Food Tour in Kampung Baru Malay Village	food-tour-around-kampung-baru-malay-village	The Best Malay Village Experience KL	Looking for the best food tour in Kampung Baru? You've found it. Simply Enak has been guiding visitors through this traditional Malay village for 14 years. Discover authentic Malay cuisine with KL's best-rated village tour.	Kampung Baru is a traditional Malay village in the heart of KL - a wooden house enclave surrounded by skyscrapers.\n\nWe'll guide you through authentic Malay cuisine, from nasi lemak to rendang, all prepared using traditional recipes passed down through generations.	289	MYR	4 hours	240	Kuala Lumpur	Kampung Baru, Kuala Lumpur	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.645+08	2026-04-03 11:26:47.645+08	published	\N	\N
34	Best Food Tour in Chowrasta Market Penang	food-tour-around-chowrasta-market-penang	The Best Chowrasta Market Experience	Looking for the best food tour in Chowrasta Market? You've found it. Simply Enak has been guiding visitors through Penang's historic market for 14 years. Watch popiah being made, taste Asam Laksa, and discover why we're Penang's best-rated market tour.	What makes Penang the "food capital" of Malaysia? Start at Chowrasta Market, the heart of Penang food culture.\n\nWe'll dare you to try kopitiam "Ngor Ka Sai", signature nutmeg pickles and dodol. You'll watch a master handcraft popiah skin, and taste legendary Asam Laksa.	289	MYR	3.5 hours	210	Penang	Chowrasta Market, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.664+08	2026-04-03 11:26:47.664+08	published	\N	\N
35	Best Food Tour in Georgetown Penang	food-tour-around-georgetown-heritage	The Best Georgetown Heritage Experience	Looking for the best food tour in Georgetown Penang? You've found it. Simply Enak has been guiding visitors through UNESCO Georgetown for 14 years. Discover Peranakan culture, temples, street art, and amazing food with Penang's best-rated heritage tour.	Explore Georgetown UNESCO heritage streets while tasting Peranakan culture through colourful kuey and legendary dishes.\n\nWe'll share Peranakan culture, explore temples and street art, and you'll leave with the history and culture behind Penang's most famous flavours.	359	MYR	4 hours	240	Penang	Georgetown, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.678+08	2026-04-03 11:26:47.678+08	published	\N	\N
36	Best Food Tour in Gurney Drive Penang	food-tour-around-gurney-drive	The Best Gurney Drive Hawker Experience	Looking for the best food tour in Gurney Drive? You've found it. Simply Enak has been guiding visitors through Penang's famous hawker centre for 14 years. Taste sizzling satay, char kway teow, and waterfront dining with Penang's best-rated hawker tour.	Gurney Drive is Penang's most famous hawker centre - a waterfront food paradise.\n\nWe'll guide you through the best stalls, taste sizzling satay, char kway teow, and experience the vibrant hawker culture that makes Penang famous.	285	MYR	3.5 hours	210	Penang	Gurney Drive, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.694+08	2026-04-03 11:26:47.694+08	published	\N	\N
37	Best Food Tour in Little India Penang	food-tour-around-little-india-lebuh-queen	The Best Little India Lebuh Queen Experience	Looking for the best food tour in Little India Penang? You've found it. Simply Enak has been guiding visitors through Lebuh Queen for 14 years. Discover authentic Indian restaurants, banana leaf rice, and spice shops with Penang's best-rated Little India tour.	Penang's Little India on Lebuh Queen is a sensory explosion of spices, textiles, and authentic Indian food.\n\nWe'll guide you through authentic Indian restaurants, banana leaf rice houses, and sweet shops. Every vendor is verified for dietary needs.	285	MYR	3.5 hours	210	Penang	Lebuh Queen, Little India, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.71+08	2026-04-03 11:26:47.71+08	published	\N	\N
1	Flavours of Malaysia	flavours-of-malaysia	Off the Beaten Track	Brand new to Malaysia? This is everything you need to know! Simply Enak will guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian culture and heritage.	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. This tour is the perfect introduction to Malaysian culture and heritage.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)	289	MYR	4 hours	240	Kuala Lumpur	Hilton Garden Inn, Kuala Lumpur	9	2	t	All our tours start with a minimum of 2 reservations. Special rates for group bookings of 6+ people.	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.005+08	2026-04-03 11:26:47.003+08	published	2	\N
2	Eat Drink George Town	eat-drink-george-town	Georgetown's Greatest Hits	Hungry for Georgetown's greatest hits? Simply Enak's most-loved Penang tour starts as the sun sets and Georgetown comes alive. Three cultures' evening delights.	Hungry for Georgetown's greatest hits?\n\nOur most-loved Penang tour starts as the sun sets and Georgetown comes alive. We'll guide you through three cultures' evening delights: sizzling satay, the best samosas in Malaysia, and char kway teow fresh off the wok at Chew Jetty.\n\nYou'll watch roti jala being handcrafted like golden lace, hear the secret society tales and forbidden history that shaped these streets, then toast the evening with a Junglebird, Malaysia's own cocktail.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)	359	MYR	4 hours	240	Penang	Masjid Kapitan Keling, George Town, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.047+08	2026-04-03 11:26:47.046+08	published	3	\N
3	Kuala Lumpur Street Food	kl-street-food	Chinatown Temples & Historic Lanes	Brand new to Malaysia? This is everything you need to know! Simply Enak will guide you through major temples and historic lanes in Chinatown with amazing food.	Brand new to Malaysia? This is everything you need to know!\n\nWe'll guide you through major temples and historic lanes in Chinatown with amazing food. Perfect introduction to Malaysian street food culture.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)\n\n---\n\n## Why Choose Our KL Food Tour?\n\n**14 Years in KL (Since 2011)**\nWe've known Aunty Lim since 2011. Uncle Tan since 2012. These aren't business partnerships — they're friendships built over 312+ tours.\n\n**Max 9 People, Always**\nNot "up to 15." Not "usually 12." Maximum 9 people, every tour. Because you can actually hear the stories.\n\n**We Don't Negotiate Vendor Prices**\nOther tours ask for discounts. We don't. Vendors tell us their prices — we pay them. Immediately, in cash, at the stall.\n\n**Dietary Experts**\nVegetarian, vegan, halal, gluten-free, Jain — we've accommodated every dietary need since 2011. We know which stalls use belacan, which use lard, which have allergen-free prep.\n\n---\n\n## Simply Enak vs. Other KL Food Tours\n\n| Feature | Simply Enak | A Chef's Tour | Viator/GetYourGuide Tours |\n|---------|-------------|---------------|---------------------------|\n| Group Size | Max 9 | Max 8 | 12-20 |\n| Price | RM 285 (RM 71/hr) | ~RM 260 (RM 65/hr) | RM 200-350 |\n| Vendor Relationships | 14 years (since 2011) | Varies by guide | Varies by operator |\n| Dietary Accommodation | All needs (14 years expertise) | Basic | Limited |\n| Booking | Direct, no platform fees | Direct or platform | Platform (20-25% commission) |\n| Cancellation | 48 hours free | 48 hours free | 24-72 hours (varies) |\n| Guide Type | Local founders (Pauline & Maarten) | Hired local hosts | Hired guides |\n| Vendor Payment | Cash, immediate, at stall | Unknown | 30-day terms (typical) |\n\n**Sources:** A Chef's Tour website (achefstour.com), Viator supplier terms (20-25% platform commission per Bokun.io 2026), industry standard payment terms.\n\n**The Bottom Line:** We're not the cheapest. We're not the biggest. But after 14 years, 2,847 guests, and a 5.0/5.0 rating — we're the most trusted.	285	MYR	3.5 hours	210	Kuala Lumpur	Tealive, Pasar Seni LRT Station	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.073+08	2026-04-03 11:26:47.073+08	published	4	\N
4	Penang Street Food	penang-street-food	Food Capital of Malaysia	What makes Penang the "food capital" of Malaysia? Simply Enak will guide you through the cultural fusion that created dishes you'll only find here. At Chowrasta Market, we'll dare you to try kopitiam "Ngor Ka Sai".	What makes Penang the "food capital" of Malaysia?\n\nWe'll guide you through the cultural fusion that created dishes you'll only find here. At Chowrasta Market, we'll dare you to try kopitiam "Ngor Ka Sai", signature nutmeg pickles and dodol.\n\nYou'll watch a master handcraft popiah skin, and taste legendary Asam Laksa balancing sweet, sour and savoury. We'll share Peranakan culture through colourful kuey, explore temples and street art, and you'll leave with the history and culture behind Penang's most famous flavours.\n\nEvery dish and vendor has a story. Dietary needs? No problem :)\n\n---\n\n## Why Choose Our Penang Food Tour?\n\n**14 Years in Penang (Since 2011)**\nWe've been guiding guests through Georgetown since 2011. We know which stalls have been family-run for 40+ years, which recipes haven't changed since your grandmother's kitchen, and which vendors will share stories you won't hear anywhere else.\n\n**Max 9 People, Always**\nNot "up to 15." Not "usually 12." Maximum 9 people, every tour. Because you can actually hear the vendor stories. Because you can ask questions. Because it feels like eating with friends.\n\n**Georgetown UNESCO Heritage**\nWe don't just show you food — we show you why Penang is a UNESCO World Heritage Site. The hawker culture, the kopitiam traditions, the Peranakan influence. You'll understand why Penang food is different from KL, different from Singapore, uniquely Penang.\n\n**Dietary Experts**\nVegetarian, vegan, halal, gluten-free — we've accommodated every dietary need since 2011. We know which stalls use belacan (shrimp paste), which use lard, which have dedicated vegetarian prep.\n\n---\n\n## Simply Enak vs. Other Penang Food Tours\n\n| Feature | Simply Enak | A Chef's Tour | Marriott/ByFood Private Tours |\n|---------|-------------|---------------|-------------------------------|\n| Group Size | Max 9 | Max 8 | Private (2-10 people) |\n| Price | RM 285 (RM 81/hr) | ~RM 215 (RM 54/hr) | RM 400-600 |\n| Vendor Relationships | 14 years (since 2011) | Varies by guide | Varies by operator |\n| Dietary Accommodation | All needs (14 years expertise) | Basic | Limited |\n| Booking | Direct, no platform fees | Direct or platform | Platform/Hotel |\n| Cancellation | 48 hours free | 48 hours free | 24-72 hours (varies) |\n| UNESCO Context | Heritage-focused guide | Food-focused | Food-focused |\n| Guide Type | Local founders (Pauline & Maarten) | Hired local hosts | Hotel-contracted guides |\n\n**Sources:** A Chef's Tour Penang (achefstour.com/penang), Marriott Eat Like A Local (activities.marriott.com), ByFood (byfood.com).\n\n**The Bottom Line:** We're not the cheapest. We're not the biggest. But after 14 years, 2,847 guests, and a 5.0/5.0 rating — we're the most trusted.	285	MYR	3.5 hours	210	Penang	St. George's Church, Penang	9	2	t	\N	\N	t	\N	f	f	f	\N	draft	draft	\N	\N	\N	2026-04-03 11:26:47.099+08	2026-04-03 11:26:47.099+08	published	5	\N
\.


--
-- Data for Name: tours_gallery_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tours_gallery_images (_order, _parent_id, id, image_id) FROM stdin;
1	5	69cf3377d670e2eb5542832c	\N
2	5	69cf3377d670e2eb5542832d	\N
3	5	69cf3377d670e2eb5542832e	\N
4	5	69cf3377d670e2eb5542832f	\N
1	1	69cf3376d670e2eb55428301	6
2	1	69cf3376d670e2eb55428302	7
3	1	69cf3376d670e2eb55428303	8
4	1	69cf3376d670e2eb55428304	9
5	1	69cf3376d670e2eb55428305	10
1	2	69cf3377d670e2eb5542830b	11
2	2	69cf3377d670e2eb5542830c	12
3	2	69cf3377d670e2eb5542830d	13
4	2	69cf3377d670e2eb5542830e	14
5	2	69cf3377d670e2eb5542830f	15
6	2	69cf3377d670e2eb55428310	16
7	2	69cf3377d670e2eb55428311	17
1	3	69cf3377d670e2eb55428317	18
2	3	69cf3377d670e2eb55428318	19
3	3	69cf3377d670e2eb55428319	7
4	3	69cf3377d670e2eb5542831a	20
5	3	69cf3377d670e2eb5542831b	21
1	4	69cf3377d670e2eb55428321	22
2	4	69cf3377d670e2eb55428322	23
3	4	69cf3377d670e2eb55428323	12
4	4	69cf3377d670e2eb55428324	13
5	4	69cf3377d670e2eb55428325	10
6	4	69cf3377d670e2eb55428326	20
5	5	69cf3377d670e2eb55428330	20
\.


--
-- Data for Name: tours_highlights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tours_highlights (_order, _parent_id, id, highlight) FROM stdin;
1	1	69cf3376d670e2eb55428306	Major temples in Chinatown
2	1	69cf3376d670e2eb55428307	Historic lanes with stories
3	1	69cf3376d670e2eb55428308	8-10 authentic Malaysian dishes
4	1	69cf3376d670e2eb55428309	Cultural fusion understanding
5	1	69cf3376d670e2eb5542830a	Small group experience (max 9)
1	2	69cf3377d670e2eb55428312	Sizzling satay and best samosas in Malaysia
2	2	69cf3377d670e2eb55428313	Char kway teow fresh off the wok at Chew Jetty
3	2	69cf3377d670e2eb55428314	Roti jala handcrafted like golden lace
4	2	69cf3377d670e2eb55428315	Secret society tales and forbidden history
5	2	69cf3377d670e2eb55428316	Junglebird cocktail toast to the evening
1	3	69cf3377d670e2eb5542831c	Major temples in Chinatown
2	3	69cf3377d670e2eb5542831d	Historic lanes with amazing food
3	3	69cf3377d670e2eb5542831e	8-10 authentic Malaysian dishes
4	3	69cf3377d670e2eb5542831f	Perfect introduction to Malaysian culture
5	3	69cf3377d670e2eb55428320	Small group experience (max 9)
1	4	69cf3377d670e2eb55428327	Kopitiam "Ngor Ka Sai" - signature nutmeg pickles
2	4	69cf3377d670e2eb55428328	Watch master handcraft popiah skin
3	4	69cf3377d670e2eb55428329	Legendary Asam Laksa - sweet, sour, savoury
4	4	69cf3377d670e2eb5542832a	Peranakan culture through colourful kuey
5	4	69cf3377d670e2eb5542832b	Chowrasta Market with exotic fruits and spices
1	5	69cf3377d670e2eb55428331	Hidden speakeasy bars locals love
2	5	69cf3377d670e2eb55428332	Classic Malaysian late-night street food
3	5	69cf3377d670e2eb55428333	Forbidden tales of the red-light district
4	5	69cf3377d670e2eb55428334	KL's vibrant street art at night
5	5	69cf3377d670e2eb55428335	4-5 signature craft cocktails included
1	6	69cf3377d670e2eb55428336	Brickfields Little India - 47 vegetarian restaurants per km²
2	6	69cf3377d670e2eb55428337	Buddhist vegetarian restaurants with mock meats
3	6	69cf3377d670e2eb55428338	Modern vegan cafes in Bangsar
4	6	69cf3377d670e2eb55428339	100% plant-based vendors (no fish sauce, no shrimp paste)
5	6	69cf3377d670e2eb5542833a	Small group experience (max 9)
1	7	69cf3377d670e2eb5542833b	Vegetarian char kway teow (yes, it exists!)
2	7	69cf3377d670e2eb5542833c	Vegetarian laksa without fish sauce
3	7	69cf3377d670e2eb5542833d	Colorful Nyonya kuey (plant-based)
4	7	69cf3377d670e2eb5542833e	Chowrasta Market vegetarian section
5	7	69cf3377d670e2eb5542833f	Buddhist vegetarian restaurants
1	8	69cf3377d670e2eb55428340	Kampung Baru - traditional Malay village in city center
2	8	69cf3377d670e2eb55428341	Indian Muslim roti canai and murtabak
3	8	69cf3377d670e2eb55428342	Halal-certified vendors only
4	8	69cf3377d670e2eb55428343	No pork, no alcohol, no cross-contamination
5	8	69cf3377d670e2eb55428344	Small group experience (max 9)
1	9	69cf3377d670e2eb55428345	Halal char kway teow
2	9	69cf3377d670e2eb55428346	Legendary nasi kandar
3	9	69cf3377d670e2eb55428347	Indian Muslim specialties
4	9	69cf3377d670e2eb55428348	Halal-certified vendors only
5	9	69cf3377d670e2eb55428349	Small group experience (max 9)
1	10	69cf3377d670e2eb5542834a	Naturally GF Malaysian dishes
2	10	69cf3377d670e2eb5542834b	Wheat-free soy sauce vendors
3	10	69cf3377d670e2eb5542834c	No cross-contamination stops
4	10	69cf3377d670e2eb5542834d	Celiac-aware guide
5	10	69cf3377d670e2eb5542834e	Small group experience (max 9)
1	11	69cf3377d670e2eb5542834f	Naturally GF Penang dishes
2	11	69cf3377d670e2eb55428350	Rice noodle dishes (verified)
3	11	69cf3377d670e2eb55428351	Grilled seafood (naturally GF)
4	11	69cf3377d670e2eb55428352	Dedicated GF utensils
5	11	69cf3377d670e2eb55428353	Small group experience (max 9)
1	12	69cf3377d670e2eb55428354	Modern vegan cafes in Bangsar
2	12	69cf3377d670e2eb55428355	Traditional Indian vegan curry
3	12	69cf3377d670e2eb55428356	Buddhist vegetarian mock meats
4	12	69cf3377d670e2eb55428357	100% plant-based vendors
5	12	69cf3377d670e2eb55428358	Small group experience (max 9)
1	13	69cf3377d670e2eb55428359	Vegan char kway teow
2	13	69cf3377d670e2eb5542835a	Vegan laksa without fish sauce
3	13	69cf3377d670e2eb5542835b	Nyonya vegan kuey
4	13	69cf3377d670e2eb5542835c	Buddhist vegetarian restaurants
5	13	69cf3377d670e2eb5542835d	Small group experience (max 9)
1	14	69cf3377d670e2eb5542835e	Separate Jain kitchens
2	14	69cf3377d670e2eb5542835f	No root vegetables (onion, garlic, potato)
3	14	69cf3377d670e2eb55428360	Pure ahimsa cuisine
4	14	69cf3377d670e2eb55428361	No cross-contamination
5	14	69cf3377d670e2eb55428362	Small group experience (max 9)
1	15	69cf3377d670e2eb55428363	Jain thali without root vegetables
2	15	69cf3377d670e2eb55428364	Dal without onion/garlic
3	15	69cf3377d670e2eb55428365	Separate Jain preparation
4	15	69cf3377d670e2eb55428366	Understanding vendors
5	15	69cf3377d670e2eb55428367	Small group experience (max 9)
1	16	69cf3377d670e2eb55428368	Local hawker centres (not tourist traps)
2	16	69cf3377d670e2eb55428369	Roadside stalls with 40+ year history
3	16	69cf3377d670e2eb5542836a	Best char kway teow in KL
4	16	69cf3377d670e2eb5542836b	Hidden alleys and local favorites
5	16	69cf3377d670e2eb5542836c	Small group experience (max 9)
1	17	69cf3377d670e2eb5542836d	Chowrasta Market with exotic spices
2	17	69cf3377d670e2eb5542836e	Watch master handcraft popiah skin
3	17	69cf3377d670e2eb5542836f	Legendary Asam Laksa
4	17	69cf3377d670e2eb55428370	Kopitiam "Ngor Ka Sai" (dare to try!)
5	17	69cf3377d670e2eb55428371	Small group experience (max 9)
1	18	69cf3377d670e2eb55428372	Chow Kit Market - KL's largest wet market
2	18	69cf3377d670e2eb55428373	Exotic tropical fruits
3	18	69cf3377d670e2eb55428374	Aromatic spices and herbs
4	18	69cf3377d670e2eb55428375	Local butchers and fishmongers
5	18	69cf3377d670e2eb55428376	Small group experience (max 9)
1	19	69cf3377d670e2eb55428377	Chowrasta Market historic tour
2	19	69cf3377d670e2eb55428378	Watch popiah being handcrafted
3	19	69cf3377d670e2eb55428379	Signature nutmeg pickles
4	19	69cf3377d670e2eb5542837a	Exotic spices and herbs
5	19	69cf3377d670e2eb5542837b	Small group experience (max 9)
1	20	69cf3377d670e2eb5542837c	Major Chinatown temples
2	20	69cf3377d670e2eb5542837d	Historic lanes with stories
3	20	69cf3377d670e2eb5542837e	8-10 authentic Malaysian dishes
4	20	69cf3377d670e2eb5542837f	Perfect introduction to Malaysian culture
5	20	69cf3377d670e2eb55428380	Small group experience (max 9)
1	21	69cf3377d670e2eb55428381	Georgetown UNESCO heritage streets
2	21	69cf3377d670e2eb55428382	Peranakan culture through colourful kuey
3	21	69cf3377d670e2eb55428383	Temples and street art
4	21	69cf3377d670e2eb55428384	History behind Penang's flavours
5	21	69cf3377d670e2eb55428385	Small group experience (max 9)
1	22	69cf3377d670e2eb55428386	Hidden speakeasy bars locals love
2	22	69cf3377d670e2eb55428387	Classic Malaysian late-night food
3	22	69cf3377d670e2eb55428388	Forbidden tales of red-light district
4	22	69cf3377d670e2eb55428389	Street art at night
5	22	69cf3377d670e2eb5542838a	4-5 signature cocktails included
1	23	69cf3377d670e2eb5542838b	Night hawker centres
2	23	69cf3377d670e2eb5542838c	Sizzling satay
3	23	69cf3377d670e2eb5542838d	Georgetown after dark
4	23	69cf3377d670e2eb5542838e	Local nightlife
5	23	69cf3377d670e2eb5542838f	Small group experience (max 9)
1	24	69cf3377d670e2eb55428390	Kid-friendly foods included
2	24	69cf3377d670e2eb55428391	Spice levels adjusted for kids
3	24	69cf3377d670e2eb55428392	Clean bathroom stops
4	24	69cf3377d670e2eb55428393	Engaging stories for children
5	24	69cf3377d670e2eb55428394	Children under 12: 50% off
1	25	69cf3377d670e2eb55428395	Kid-friendly Penang foods
2	25	69cf3377d670e2eb55428396	Comfortable pace for families
3	25	69cf3377d670e2eb55428397	Fun stories for children
4	25	69cf3377d670e2eb55428398	Family-friendly vendors
5	25	69cf3377d670e2eb55428399	Children under 12: 50% off
1	26	69cf3377d670e2eb5542839a	Romantic atmospheric stops
2	26	69cf3377d670e2eb5542839b	Shareable dishes
3	26	69cf3377d670e2eb5542839c	Photo opportunities
4	26	69cf3377d670e2eb5542839d	Conversation starters
5	26	69cf3377d670e2eb5542839e	Small group experience (max 9)
1	27	69cf3377d670e2eb5542839f	Georgetown heritage streets
2	27	69cf3377d670e2eb554283a0	Romantic atmospheric stops
3	27	69cf3377d670e2eb554283a1	Sunset views
4	27	69cf3377d670e2eb554283a2	Shareable dishes
5	27	69cf3377d670e2eb554283a3	Small group experience (max 9)
1	28	69cf3377d670e2eb554283a4	Chef and vendor interviews
2	28	69cf3377d670e2eb554283a5	Recipe discussions
3	28	69cf3377d670e2eb554283a6	Technique demonstrations
4	28	69cf3377d670e2eb554283a7	Deep culinary knowledge
5	28	69cf3377d670e2eb554283a8	Small group experience (max 9)
1	29	69cf3377d670e2eb554283a9	Master vendors with 40+ year recipes
2	29	69cf3377d670e2eb554283aa	Beyond tourist spots
3	29	69cf3377d670e2eb554283ab	Deep culinary knowledge
4	29	69cf3377d670e2eb554283ac	Food capital of Malaysia
5	29	69cf3377d670e2eb554283ad	Small group experience (max 9)
1	30	69cf3377d670e2eb554283ae	The best Chow Kit Market experience in KL
2	30	69cf3377d670e2eb554283af	14 years of vendor relationships
3	30	69cf3377d670e2eb554283b0	Exotic tropical fruits you've never seen
4	30	69cf3377d670e2eb554283b1	Aromatic spices and herbs
5	30	69cf3377d670e2eb554283b2	Local butchers and fishmongers
6	30	69cf3377d670e2eb554283b3	Small group experience (max 9)
1	31	69cf3377d670e2eb554283b4	The best Chinatown KL experience
2	31	69cf3377d670e2eb554283b5	Major Chinatown temples
3	31	69cf3377d670e2eb554283b6	Historic lanes with stories
4	31	69cf3377d670e2eb554283b7	8-10 authentic Malaysian dishes
5	31	69cf3377d670e2eb554283b8	Perfect introduction to Malaysian culture
6	31	69cf3377d670e2eb554283b9	Small group experience (max 9)
1	32	69cf3377d670e2eb554283ba	The best Little India KL experience
2	32	69cf3377d670e2eb554283bb	Brickfields Little India
3	32	69cf3377d670e2eb554283bc	Authentic Indian vegetarian restaurants
4	32	69cf3377d670e2eb554283bd	Banana leaf rice houses
5	32	69cf3377d670e2eb554283be	140 years of Indian tradition
6	32	69cf3377d670e2eb554283bf	Small group experience (max 9)
1	33	69cf3377d670e2eb554283c0	The best Kampung Baru experience
2	33	69cf3377d670e2eb554283c1	Kampung Baru - traditional Malay village
3	33	69cf3377d670e2eb554283c2	Authentic Malay cuisine
4	33	69cf3377d670e2eb554283c3	Traditional recipes
5	33	69cf3377d670e2eb554283c4	Wooden houses surrounded by skyscrapers
6	33	69cf3377d670e2eb554283c5	Small group experience (max 9)
1	34	69cf3377d670e2eb554283c6	The best Chowrasta Market experience in Penang
2	34	69cf3377d670e2eb554283c7	Watch master handcraft popiah skin
3	34	69cf3377d670e2eb554283c8	Legendary Asam Laksa
4	34	69cf3377d670e2eb554283c9	Kopitiam "Ngor Ka Sai" (dare to try!)
5	34	69cf3377d670e2eb554283ca	Penang's historic market
6	34	69cf3377d670e2eb554283cb	Small group experience (max 9)
1	35	69cf3377d670e2eb554283cc	The best Georgetown heritage experience
2	35	69cf3377d670e2eb554283cd	Georgetown UNESCO heritage streets
3	35	69cf3377d670e2eb554283ce	Peranakan culture through colourful kuey
4	35	69cf3377d670e2eb554283cf	Temples and street art
5	35	69cf3377d670e2eb554283d0	History behind Penang's flavours
6	35	69cf3377d670e2eb554283d1	Small group experience (max 9)
1	36	69cf3377d670e2eb554283d2	The best Gurney Drive hawker experience
2	36	69cf3377d670e2eb554283d3	Gurney Drive - Penang's famous hawker centre
3	36	69cf3377d670e2eb554283d4	Waterfront dining experience
4	36	69cf3377d670e2eb554283d5	Sizzling satay and char kway teow
5	36	69cf3377d670e2eb554283d6	Vibrant hawker culture
6	36	69cf3377d670e2eb554283d7	Small group experience (max 9)
1	37	69cf3377d670e2eb554283d8	The best Little India Penang experience
2	37	69cf3377d670e2eb554283d9	Lebuh Queen Little India
3	37	69cf3377d670e2eb554283da	Authentic Indian restaurants
4	37	69cf3377d670e2eb554283db	Banana leaf rice houses
5	37	69cf3377d670e2eb554283dc	Spice and textile shops
6	37	69cf3377d670e2eb554283dd	Small group experience (max 9)
\.


--
-- Data for Name: tours_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tours_rels (id, "order", parent_id, path, dietary_options_id, travel_type_landing_pages_id, specialty_landing_pages_id, food_items_id, travel_types_id, specialty_experiences_id) FROM stdin;
\.


--
-- Data for Name: tours_whats_excluded; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tours_whats_excluded (_order, _parent_id, id, item) FROM stdin;
\.


--
-- Data for Name: tours_whats_included; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tours_whats_included (_order, _parent_id, id, item) FROM stdin;
\.


--
-- Data for Name: track_record_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.track_record_page (id, seo_title, seo_description, hero_title, hero_subtitle, philosophy_quote, how_we_work_eyebrow, created_at, updated_at, _status, _locales, _latestversion, _autosave) FROM stdin;
1	Track Record | 15 Years of Food Tours in Malaysia | Simply Enak	From multinational corporations to Michelin-starred chefs, families celebrating milestones to national press. See who has trusted Simply Enak with their table for 15 years.	15 Years of People Who Trusted Us With Their Table	From global corporations to Michelin-starred chefs, families celebrating milestones to journalists chasing the real Malaysia.	We visit the same stalls and neighbourhoods on every tour, but no two mornings run the same. The conversations follow the crowd, the weather, your group's curiosity, and which uncle feels like talking that day.	How we work	2026-04-03 23:14:17.388+08	2026-04-03 23:14:17.388+08	draft	\N	1	f
\.


--
-- Data for Name: track_record_page_awards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.track_record_page_awards (id, _parent_id, _order, _path, award, year, organization) FROM stdin;
\.


--
-- Data for Name: track_record_page_case_studies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.track_record_page_case_studies (id, _parent_id, _order, _path, client, type, description) FROM stdin;
\.


--
-- Data for Name: track_record_page_press; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.track_record_page_press (id, _parent_id, _order, _path, outlet, url) FROM stdin;
\.


--
-- Data for Name: track_record_page_segments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.track_record_page_segments (id, _parent_id, _order, _path, num, emoji, name, description) FROM stdin;
1	1	0	segments	01	🏢	Corporate & Team Building	Multinational companies using food to build real team bonds
2	1	1	segments	02	👨‍👩‍👧‍👦	Families	Multi-generational groups celebrating milestones together
3	1	2	segments	03	✈️	Travel Agencies	B2B partners who add real depth to their Malaysia packages
4	1	3	segments	04	📷	Media & Press	Journalists and creators chasing the real Malaysia
5	1	4	segments	05	🔪	Chefs & Culinary Pros	Professional kitchens sourcing knowledge at the vendor level
\.


--
-- Data for Name: track_record_page_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.track_record_page_stats (id, _parent_id, _order, _path, number, label) FROM stdin;
1	1	0	stats	5,000+	Guests
2	1	1	stats	5	Guest Types
3	1	2	stats	5	Continents
4	1	3	stats	40+	Heritage Vendors
\.


--
-- Data for Name: travel_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.travel_types (id, name, slug, icon, color, description, status, created_at, updated_at, _status) FROM stdin;
1	Couples	couples	💑	#ec4899	Romantic food experiences for two	published	2026-04-03 15:08:39.087+08	2026-04-03 15:08:39.087+08	published
2	Family-Friendly	family	👨‍👩‍👧‍👦	#f59e0b	Tours suitable for all ages	published	2026-04-03 15:08:39.087+08	2026-04-03 15:08:39.087+08	published
3	Foodie	foodie	🍜	#ef4444	Deep dives into Malaysian cuisine	published	2026-04-03 15:08:39.087+08	2026-04-03 15:08:39.087+08	published
4	Solo Traveler	solo	🎒	#8b5cf6	Perfect for independent explorers	published	2026-04-03 15:08:39.087+08	2026-04-03 15:08:39.087+08	published
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, role, full_name, department, updated_at, created_at, email, reset_password_token, reset_password_expiration, salt, hash, login_attempts, lock_until) FROM stdin;
1	admin	Admin User	\N	2026-04-03 10:08:37.05+08	2026-04-03 10:08:37.049+08	admin@simplyenak.com	\N	\N	84d3104c3ef7d857f3e56005e061047666dbc44e075731e24e8954f33a50af79	6a134de1ae2f297e5f1454af324bd6aaa50588d65ec8a63cf18b68490cc41cdb8d0dc61ed80294aa323ec20009a5f31d9dd5b0ff07c6710e3a38cf7a84a2593d312c9104885bd1ba4c8e0f1a1cd80bcae191a6de75c7378db87f410e396b6e0f1240fecde26f6294703c057a65ee8b740d5211ae2fdd00b52f3bd8455567baf7632ff2ac3391994011259e363b53ba8a9aa6b351443f4b51bdaed5dd165cc91f65188e22e6e6d269ffb906129954d312b5bf203d2597cafb790af56addbc82b07deb253f569fdbd7691bef7a27a7bd3d8dd8f102c9abc315b952bce0f26d26e06005a4d8cc130d9cb5147fdf203eda14ad2ec78c37a9899b97ad84891169eab5b4cc3d8d694eacfafc3da8362a8770e1ffcab92d7d76232fa0829f2e2e8cec9197d3f81ad414de8d86f66b1be5a5149a8ac4c51f6b60a21cb030e640ed8d520c9095d973b58970b7a7a39cdd32f15bc327e48be3f7ae4099d70d0eece2564ec7d2d39c3a726c9e96c369d5fcac9c18649b50a921451d0549ef7febdd32674caabb5e865037c868094ffb3007807d20907ecea73e80a9548d7d7c47d455ba849cbd4e53e6e766e2ff2a1ac353b7d695d3c955fac1b098e0bbce2f5255ff41d89fcb94770d4cec861595bfe35f5a9d083e0aee5dc7ca50c6744350728c12273afd35c6cb66e36f5a32b1e84ca431bbae8c9c91d2161c3669ce068523bf215c9108	0	\N
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors (id, name, slug, type, description, history, year_established, generation, owner_name, cuisine_type, location_address, location_city, location_state, location_postcode, location_country, location_latitude, location_longitude, location_landmark, contact_phone, contact_whatsapp, contact_email, contact_website, contact_facebook, contact_instagram, price_range, images_main_id, story, media_features, tips, status, featured, scheduled_publish, published_at, updated_at, created_at, _status) FROM stdin;
\.


--
-- Data for Name: vendors_awards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors_awards (_order, _parent_id, id, award, year, organization) FROM stdin;
\.


--
-- Data for Name: vendors_closed_on; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors_closed_on (_order, _parent_id, id, day) FROM stdin;
\.


--
-- Data for Name: vendors_facilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors_facilities (_order, _parent_id, id, facility) FROM stdin;
\.


--
-- Data for Name: vendors_images_gallery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors_images_gallery (_order, _parent_id, id, image_id) FROM stdin;
\.


--
-- Data for Name: vendors_operating_hours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors_operating_hours (_order, _parent_id, id, day, open_time, close_time, is_closed, notes) FROM stdin;
\.


--
-- Data for Name: vendors_payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors_payment_methods (_order, _parent_id, id, method) FROM stdin;
\.


--
-- Data for Name: vendors_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors_rels (id, "order", parent_id, path, food_items_id, dietary_options_id) FROM stdin;
\.


--
-- Name: _contact_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._contact_page_v_id_seq', 1, false);


--
-- Name: _corporate_groups_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._corporate_groups_page_v_id_seq', 1, false);


--
-- Name: _dietary_options_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._dietary_options_v_id_seq', 14, true);


--
-- Name: _directions_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._directions_page_v_id_seq', 1, false);


--
-- Name: _faqs_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._faqs_v_id_seq', 14, true);


--
-- Name: _food_items_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._food_items_v_id_seq', 1, false);


--
-- Name: _food_items_v_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._food_items_v_rels_id_seq', 1, false);


--
-- Name: _food_items_v_version_allergens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._food_items_v_version_allergens_id_seq', 1, false);


--
-- Name: _food_items_v_version_flavor_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._food_items_v_version_flavor_profile_id_seq', 1, false);


--
-- Name: _food_items_v_version_ingredients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._food_items_v_version_ingredients_id_seq', 1, false);


--
-- Name: _food_items_v_version_local_names_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._food_items_v_version_local_names_id_seq', 1, false);


--
-- Name: _home_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._home_page_v_id_seq', 1, false);


--
-- Name: _how_it_works_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._how_it_works_page_v_id_seq', 1, false);


--
-- Name: _how_to_prepare_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._how_to_prepare_page_v_id_seq', 1, false);


--
-- Name: _landing_pages_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._landing_pages_v_id_seq', 1, false);


--
-- Name: _legal_pages_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._legal_pages_v_id_seq', 1, false);


--
-- Name: _menus_items_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._menus_items_v_id_seq', 4, true);


--
-- Name: _stories_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._stories_v_id_seq', 23, true);


--
-- Name: _testimonials_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._testimonials_v_id_seq', 10, true);


--
-- Name: _tours_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._tours_v_id_seq', 37, true);


--
-- Name: _tours_v_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._tours_v_rels_id_seq', 1, false);


--
-- Name: _tours_v_version_gallery_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._tours_v_version_gallery_images_id_seq', 28, true);


--
-- Name: _tours_v_version_highlights_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._tours_v_version_highlights_id_seq', 193, true);


--
-- Name: _tours_v_version_whats_excluded_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._tours_v_version_whats_excluded_id_seq', 1, false);


--
-- Name: _tours_v_version_whats_included_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._tours_v_version_whats_included_id_seq', 1, false);


--
-- Name: _track_record_page_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._track_record_page_v_id_seq', 1, false);


--
-- Name: _vendors_v_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_id_seq', 1, false);


--
-- Name: _vendors_v_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_rels_id_seq', 1, false);


--
-- Name: _vendors_v_version_awards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_version_awards_id_seq', 1, false);


--
-- Name: _vendors_v_version_closed_on_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_version_closed_on_id_seq', 1, false);


--
-- Name: _vendors_v_version_facilities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_version_facilities_id_seq', 1, false);


--
-- Name: _vendors_v_version_images_gallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_version_images_gallery_id_seq', 1, false);


--
-- Name: _vendors_v_version_operating_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_version_operating_hours_id_seq', 1, false);


--
-- Name: _vendors_v_version_payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public._vendors_v_version_payment_methods_id_seq', 1, false);


--
-- Name: about_page_blocks_founder_story_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_founder_story_block_id_seq', 1, true);


--
-- Name: about_page_blocks_hero_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_hero_block_id_seq', 1, true);


--
-- Name: about_page_blocks_philosophy_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_philosophy_block_id_seq', 1, true);


--
-- Name: about_page_blocks_stats_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_stats_block_id_seq', 1, true);


--
-- Name: about_page_blocks_stats_block_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_stats_block_stats_id_seq', 4, true);


--
-- Name: about_page_blocks_team_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_team_block_id_seq', 1, true);


--
-- Name: about_page_blocks_team_block_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_team_block_members_id_seq', 5, true);


--
-- Name: about_page_blocks_timeline_block_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_timeline_block_events_id_seq', 15, true);


--
-- Name: about_page_blocks_timeline_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_blocks_timeline_block_id_seq', 1, true);


--
-- Name: about_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.about_page_id_seq', 1, true);


--
-- Name: contact_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_page_id_seq', 1, true);


--
-- Name: corporate_groups_page_benefit_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.corporate_groups_page_benefit_cards_id_seq', 1, false);


--
-- Name: corporate_groups_page_how_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.corporate_groups_page_how_steps_id_seq', 4, true);


--
-- Name: corporate_groups_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.corporate_groups_page_id_seq', 1, true);


--
-- Name: corporate_groups_page_offer_perfect_for_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.corporate_groups_page_offer_perfect_for_id_seq', 5, true);


--
-- Name: dietary_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dietary_options_id_seq', 16, true);


--
-- Name: directions_page_general_tips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.directions_page_general_tips_id_seq', 1, false);


--
-- Name: directions_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.directions_page_id_seq', 1, true);


--
-- Name: directions_page_meeting_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.directions_page_meeting_points_id_seq', 1, false);


--
-- Name: faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faqs_id_seq', 14, true);


--
-- Name: food_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.food_items_id_seq', 1, false);


--
-- Name: food_items_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.food_items_rels_id_seq', 1, false);


--
-- Name: home_page_blocks_about_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_about_block_id_seq', 1, true);


--
-- Name: home_page_blocks_hero_block_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_hero_block_badges_id_seq', 10, true);


--
-- Name: home_page_blocks_hero_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_hero_block_id_seq', 1, true);


--
-- Name: home_page_blocks_manifesto_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_manifesto_block_id_seq', 1, true);


--
-- Name: home_page_blocks_pillars_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_pillars_block_id_seq', 1, true);


--
-- Name: home_page_blocks_pillars_block_pillars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_pillars_block_pillars_id_seq', 3, true);


--
-- Name: home_page_blocks_segments_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_segments_block_id_seq', 1, true);


--
-- Name: home_page_blocks_stats_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_stats_block_id_seq', 1, true);


--
-- Name: home_page_blocks_stats_block_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_stats_block_stats_id_seq', 4, true);


--
-- Name: home_page_blocks_vendors_block_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_vendors_block_id_seq', 1, true);


--
-- Name: home_page_blocks_vendors_block_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_blocks_vendors_block_links_id_seq', 3, true);


--
-- Name: home_page_cta_section_buttons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_cta_section_buttons_id_seq', 2, true);


--
-- Name: home_page_cta_section_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_cta_section_features_id_seq', 3, true);


--
-- Name: home_page_cta_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_cta_section_id_seq', 1, true);


--
-- Name: home_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_page_id_seq', 6, true);


--
-- Name: how_it_works_page_formats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_it_works_page_formats_id_seq', 1, false);


--
-- Name: how_it_works_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_it_works_page_id_seq', 2, true);


--
-- Name: how_it_works_page_inclusions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_it_works_page_inclusions_id_seq', 7, true);


--
-- Name: how_it_works_page_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_it_works_page_steps_id_seq', 6, true);


--
-- Name: how_to_prepare_page_dietary_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_to_prepare_page_dietary_notes_id_seq', 1, false);


--
-- Name: how_to_prepare_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_to_prepare_page_id_seq', 1, true);


--
-- Name: how_to_prepare_page_what_to_bring_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_to_prepare_page_what_to_bring_id_seq', 4, true);


--
-- Name: how_to_prepare_page_what_to_expect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_to_prepare_page_what_to_expect_id_seq', 5, true);


--
-- Name: how_to_prepare_page_what_to_wear_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.how_to_prepare_page_what_to_wear_id_seq', 5, true);


--
-- Name: landing_pages_avoid_dishes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_avoid_dishes_id_seq', 1, false);


--
-- Name: landing_pages_challenges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_challenges_id_seq', 1, false);


--
-- Name: landing_pages_highlights_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_highlights_id_seq', 1, false);


--
-- Name: landing_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_id_seq', 15, true);


--
-- Name: landing_pages_safe_dishes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_safe_dishes_id_seq', 1, false);


--
-- Name: landing_pages_suitable_tours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_suitable_tours_id_seq', 1, false);


--
-- Name: landing_pages_tips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_tips_id_seq', 1, false);


--
-- Name: landing_pages_travel_tips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.landing_pages_travel_tips_id_seq', 1, false);


--
-- Name: legal_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.legal_pages_id_seq', 2, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locations_id_seq', 4, true);


--
-- Name: media_coverage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_coverage_id_seq', 20, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_id_seq', 23, true);


--
-- Name: menus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menus_id_seq', 2, true);


--
-- Name: payload_kv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_kv_id_seq', 1, false);


--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_locked_documents_id_seq', 1, false);


--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_locked_documents_rels_id_seq', 1, false);


--
-- Name: payload_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_migrations_id_seq', 1, true);


--
-- Name: payload_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_preferences_id_seq', 27, true);


--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_preferences_rels_id_seq', 60, true);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 1, true);


--
-- Name: specialty_experiences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specialty_experiences_id_seq', 6, true);


--
-- Name: stories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stories_id_seq', 23, true);


--
-- Name: testimonials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.testimonials_id_seq', 10, true);


--
-- Name: thank_you_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.thank_you_pages_id_seq', 3, true);


--
-- Name: tours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tours_id_seq', 37, true);


--
-- Name: tours_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tours_rels_id_seq', 1, false);


--
-- Name: track_record_page_awards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.track_record_page_awards_id_seq', 1, false);


--
-- Name: track_record_page_case_studies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.track_record_page_case_studies_id_seq', 1, false);


--
-- Name: track_record_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.track_record_page_id_seq', 1, true);


--
-- Name: track_record_page_press_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.track_record_page_press_id_seq', 1, false);


--
-- Name: track_record_page_segments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.track_record_page_segments_id_seq', 5, true);


--
-- Name: track_record_page_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.track_record_page_stats_id_seq', 4, true);


--
-- Name: travel_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.travel_types_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vendors_id_seq', 1, false);


--
-- Name: vendors_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vendors_rels_id_seq', 1, false);


--
-- Name: _contact_page_v _contact_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._contact_page_v
    ADD CONSTRAINT _contact_page_v_pkey PRIMARY KEY (id);


--
-- Name: _corporate_groups_page_v _corporate_groups_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._corporate_groups_page_v
    ADD CONSTRAINT _corporate_groups_page_v_pkey PRIMARY KEY (id);


--
-- Name: _dietary_options_v _dietary_options_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._dietary_options_v
    ADD CONSTRAINT _dietary_options_v_pkey PRIMARY KEY (id);


--
-- Name: _directions_page_v _directions_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._directions_page_v
    ADD CONSTRAINT _directions_page_v_pkey PRIMARY KEY (id);


--
-- Name: _faqs_v _faqs_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._faqs_v
    ADD CONSTRAINT _faqs_v_pkey PRIMARY KEY (id);


--
-- Name: _food_items_v _food_items_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v
    ADD CONSTRAINT _food_items_v_pkey PRIMARY KEY (id);


--
-- Name: _food_items_v_rels _food_items_v_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_rels
    ADD CONSTRAINT _food_items_v_rels_pkey PRIMARY KEY (id);


--
-- Name: _food_items_v_version_allergens _food_items_v_version_allergens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_allergens
    ADD CONSTRAINT _food_items_v_version_allergens_pkey PRIMARY KEY (id);


--
-- Name: _food_items_v_version_flavor_profile _food_items_v_version_flavor_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_flavor_profile
    ADD CONSTRAINT _food_items_v_version_flavor_profile_pkey PRIMARY KEY (id);


--
-- Name: _food_items_v_version_ingredients _food_items_v_version_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_ingredients
    ADD CONSTRAINT _food_items_v_version_ingredients_pkey PRIMARY KEY (id);


--
-- Name: _food_items_v_version_local_names _food_items_v_version_local_names_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_local_names
    ADD CONSTRAINT _food_items_v_version_local_names_pkey PRIMARY KEY (id);


--
-- Name: _home_page_v _home_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._home_page_v
    ADD CONSTRAINT _home_page_v_pkey PRIMARY KEY (id);


--
-- Name: _how_it_works_page_v _how_it_works_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._how_it_works_page_v
    ADD CONSTRAINT _how_it_works_page_v_pkey PRIMARY KEY (id);


--
-- Name: _how_to_prepare_page_v _how_to_prepare_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._how_to_prepare_page_v
    ADD CONSTRAINT _how_to_prepare_page_v_pkey PRIMARY KEY (id);


--
-- Name: _landing_pages_v _landing_pages_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._landing_pages_v
    ADD CONSTRAINT _landing_pages_v_pkey PRIMARY KEY (id);


--
-- Name: _legal_pages_v _legal_pages_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._legal_pages_v
    ADD CONSTRAINT _legal_pages_v_pkey PRIMARY KEY (id);


--
-- Name: menus_items _menus_items_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus_items
    ADD CONSTRAINT _menus_items_v_pkey PRIMARY KEY (id);


--
-- Name: _stories_v _stories_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._stories_v
    ADD CONSTRAINT _stories_v_pkey PRIMARY KEY (id);


--
-- Name: _testimonials_v _testimonials_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._testimonials_v
    ADD CONSTRAINT _testimonials_v_pkey PRIMARY KEY (id);


--
-- Name: _tours_v _tours_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v
    ADD CONSTRAINT _tours_v_pkey PRIMARY KEY (id);


--
-- Name: _tours_v_rels _tours_v_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_rels
    ADD CONSTRAINT _tours_v_rels_pkey PRIMARY KEY (id);


--
-- Name: _tours_v_version_gallery_images _tours_v_version_gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_gallery_images
    ADD CONSTRAINT _tours_v_version_gallery_images_pkey PRIMARY KEY (id);


--
-- Name: _tours_v_version_highlights _tours_v_version_highlights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_highlights
    ADD CONSTRAINT _tours_v_version_highlights_pkey PRIMARY KEY (id);


--
-- Name: _tours_v_version_whats_excluded _tours_v_version_whats_excluded_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_whats_excluded
    ADD CONSTRAINT _tours_v_version_whats_excluded_pkey PRIMARY KEY (id);


--
-- Name: _tours_v_version_whats_included _tours_v_version_whats_included_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_whats_included
    ADD CONSTRAINT _tours_v_version_whats_included_pkey PRIMARY KEY (id);


--
-- Name: _track_record_page_v _track_record_page_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._track_record_page_v
    ADD CONSTRAINT _track_record_page_v_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v _vendors_v_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v
    ADD CONSTRAINT _vendors_v_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v_rels _vendors_v_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_rels
    ADD CONSTRAINT _vendors_v_rels_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v_version_awards _vendors_v_version_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_awards
    ADD CONSTRAINT _vendors_v_version_awards_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v_version_closed_on _vendors_v_version_closed_on_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_closed_on
    ADD CONSTRAINT _vendors_v_version_closed_on_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v_version_facilities _vendors_v_version_facilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_facilities
    ADD CONSTRAINT _vendors_v_version_facilities_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v_version_images_gallery _vendors_v_version_images_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_images_gallery
    ADD CONSTRAINT _vendors_v_version_images_gallery_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v_version_operating_hours _vendors_v_version_operating_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_operating_hours
    ADD CONSTRAINT _vendors_v_version_operating_hours_pkey PRIMARY KEY (id);


--
-- Name: _vendors_v_version_payment_methods _vendors_v_version_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_payment_methods
    ADD CONSTRAINT _vendors_v_version_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_founder_story_block about_page_blocks_founder_story_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_founder_story_block
    ADD CONSTRAINT about_page_blocks_founder_story_block_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_hero_block about_page_blocks_hero_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_hero_block
    ADD CONSTRAINT about_page_blocks_hero_block_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_philosophy_block about_page_blocks_philosophy_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_philosophy_block
    ADD CONSTRAINT about_page_blocks_philosophy_block_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_stats_block about_page_blocks_stats_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_stats_block
    ADD CONSTRAINT about_page_blocks_stats_block_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_stats_block_stats about_page_blocks_stats_block_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_stats_block_stats
    ADD CONSTRAINT about_page_blocks_stats_block_stats_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_team_block_members about_page_blocks_team_block_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_team_block_members
    ADD CONSTRAINT about_page_blocks_team_block_members_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_team_block about_page_blocks_team_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_team_block
    ADD CONSTRAINT about_page_blocks_team_block_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_timeline_block_events about_page_blocks_timeline_block_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_timeline_block_events
    ADD CONSTRAINT about_page_blocks_timeline_block_events_pkey PRIMARY KEY (id);


--
-- Name: about_page_blocks_timeline_block about_page_blocks_timeline_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_timeline_block
    ADD CONSTRAINT about_page_blocks_timeline_block_pkey PRIMARY KEY (id);


--
-- Name: about_page_breadcrumbs about_page_breadcrumbs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_breadcrumbs
    ADD CONSTRAINT about_page_breadcrumbs_pkey PRIMARY KEY (id);


--
-- Name: about_page about_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page
    ADD CONSTRAINT about_page_pkey PRIMARY KEY (id);


--
-- Name: contact_page_breadcrumbs contact_page_breadcrumbs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_page_breadcrumbs
    ADD CONSTRAINT contact_page_breadcrumbs_pkey PRIMARY KEY (id);


--
-- Name: contact_page contact_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_page
    ADD CONSTRAINT contact_page_pkey PRIMARY KEY (id);


--
-- Name: corporate_groups_page_benefit_cards corporate_groups_page_benefit_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corporate_groups_page_benefit_cards
    ADD CONSTRAINT corporate_groups_page_benefit_cards_pkey PRIMARY KEY (id);


--
-- Name: corporate_groups_page_how_steps corporate_groups_page_how_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corporate_groups_page_how_steps
    ADD CONSTRAINT corporate_groups_page_how_steps_pkey PRIMARY KEY (id);


--
-- Name: corporate_groups_page_offer_perfect_for corporate_groups_page_offer_perfect_for_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corporate_groups_page_offer_perfect_for
    ADD CONSTRAINT corporate_groups_page_offer_perfect_for_pkey PRIMARY KEY (id);


--
-- Name: corporate_groups_page corporate_groups_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corporate_groups_page
    ADD CONSTRAINT corporate_groups_page_pkey PRIMARY KEY (id);


--
-- Name: dietary_options dietary_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dietary_options
    ADD CONSTRAINT dietary_options_pkey PRIMARY KEY (id);


--
-- Name: directions_page_general_tips directions_page_general_tips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directions_page_general_tips
    ADD CONSTRAINT directions_page_general_tips_pkey PRIMARY KEY (id);


--
-- Name: directions_page_meeting_points directions_page_meeting_points_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directions_page_meeting_points
    ADD CONSTRAINT directions_page_meeting_points_pkey PRIMARY KEY (id);


--
-- Name: directions_page directions_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directions_page
    ADD CONSTRAINT directions_page_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: food_items_allergens food_items_allergens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_allergens
    ADD CONSTRAINT food_items_allergens_pkey PRIMARY KEY (id);


--
-- Name: food_items_flavor_profile food_items_flavor_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_flavor_profile
    ADD CONSTRAINT food_items_flavor_profile_pkey PRIMARY KEY (id);


--
-- Name: food_items_ingredients food_items_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_ingredients
    ADD CONSTRAINT food_items_ingredients_pkey PRIMARY KEY (id);


--
-- Name: food_items_local_names food_items_local_names_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_local_names
    ADD CONSTRAINT food_items_local_names_pkey PRIMARY KEY (id);


--
-- Name: food_items food_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items
    ADD CONSTRAINT food_items_pkey PRIMARY KEY (id);


--
-- Name: food_items_rels food_items_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_rels
    ADD CONSTRAINT food_items_rels_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_about_block home_page_blocks_about_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_about_block
    ADD CONSTRAINT home_page_blocks_about_block_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_hero_block_badges home_page_blocks_hero_block_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_hero_block_badges
    ADD CONSTRAINT home_page_blocks_hero_block_badges_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_hero_block home_page_blocks_hero_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_hero_block
    ADD CONSTRAINT home_page_blocks_hero_block_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_manifesto_block home_page_blocks_manifesto_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_manifesto_block
    ADD CONSTRAINT home_page_blocks_manifesto_block_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_pillars_block_pillars home_page_blocks_pillars_block_pillars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_pillars_block_pillars
    ADD CONSTRAINT home_page_blocks_pillars_block_pillars_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_pillars_block home_page_blocks_pillars_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_pillars_block
    ADD CONSTRAINT home_page_blocks_pillars_block_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_segments_block home_page_blocks_segments_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_segments_block
    ADD CONSTRAINT home_page_blocks_segments_block_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_stats_block home_page_blocks_stats_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_stats_block
    ADD CONSTRAINT home_page_blocks_stats_block_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_stats_block_stats home_page_blocks_stats_block_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_stats_block_stats
    ADD CONSTRAINT home_page_blocks_stats_block_stats_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_vendors_block_links home_page_blocks_vendors_block_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_vendors_block_links
    ADD CONSTRAINT home_page_blocks_vendors_block_links_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_vendors_block home_page_blocks_vendors_block_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_vendors_block
    ADD CONSTRAINT home_page_blocks_vendors_block_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_cta_block_buttons home_page_cta_section_buttons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block_buttons
    ADD CONSTRAINT home_page_cta_section_buttons_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_cta_block_features home_page_cta_section_features_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block_features
    ADD CONSTRAINT home_page_cta_section_features_pkey PRIMARY KEY (id);


--
-- Name: home_page_blocks_cta_block home_page_cta_section_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block
    ADD CONSTRAINT home_page_cta_section_pkey PRIMARY KEY (id);


--
-- Name: home_page home_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page
    ADD CONSTRAINT home_page_pkey PRIMARY KEY (id);


--
-- Name: how_it_works_page_formats how_it_works_page_formats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_it_works_page_formats
    ADD CONSTRAINT how_it_works_page_formats_pkey PRIMARY KEY (id);


--
-- Name: how_it_works_page_inclusions how_it_works_page_inclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_it_works_page_inclusions
    ADD CONSTRAINT how_it_works_page_inclusions_pkey PRIMARY KEY (id);


--
-- Name: how_it_works_page how_it_works_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_it_works_page
    ADD CONSTRAINT how_it_works_page_pkey PRIMARY KEY (id);


--
-- Name: how_it_works_page_steps how_it_works_page_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_it_works_page_steps
    ADD CONSTRAINT how_it_works_page_steps_pkey PRIMARY KEY (id);


--
-- Name: how_to_prepare_page_dietary_notes how_to_prepare_page_dietary_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_dietary_notes
    ADD CONSTRAINT how_to_prepare_page_dietary_notes_pkey PRIMARY KEY (id);


--
-- Name: how_to_prepare_page how_to_prepare_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page
    ADD CONSTRAINT how_to_prepare_page_pkey PRIMARY KEY (id);


--
-- Name: how_to_prepare_page_what_to_bring how_to_prepare_page_what_to_bring_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_what_to_bring
    ADD CONSTRAINT how_to_prepare_page_what_to_bring_pkey PRIMARY KEY (id);


--
-- Name: how_to_prepare_page_what_to_expect how_to_prepare_page_what_to_expect_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_what_to_expect
    ADD CONSTRAINT how_to_prepare_page_what_to_expect_pkey PRIMARY KEY (id);


--
-- Name: how_to_prepare_page_what_to_wear how_to_prepare_page_what_to_wear_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_what_to_wear
    ADD CONSTRAINT how_to_prepare_page_what_to_wear_pkey PRIMARY KEY (id);


--
-- Name: landing_pages_avoid_dishes landing_pages_avoid_dishes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_avoid_dishes
    ADD CONSTRAINT landing_pages_avoid_dishes_pkey PRIMARY KEY (id);


--
-- Name: landing_pages_challenges landing_pages_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_challenges
    ADD CONSTRAINT landing_pages_challenges_pkey PRIMARY KEY (id);


--
-- Name: landing_pages_highlights landing_pages_highlights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_highlights
    ADD CONSTRAINT landing_pages_highlights_pkey PRIMARY KEY (id);


--
-- Name: landing_pages landing_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages
    ADD CONSTRAINT landing_pages_pkey PRIMARY KEY (id);


--
-- Name: landing_pages_safe_dishes landing_pages_safe_dishes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_safe_dishes
    ADD CONSTRAINT landing_pages_safe_dishes_pkey PRIMARY KEY (id);


--
-- Name: landing_pages landing_pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages
    ADD CONSTRAINT landing_pages_slug_key UNIQUE (slug);


--
-- Name: landing_pages_suitable_tours landing_pages_suitable_tours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_suitable_tours
    ADD CONSTRAINT landing_pages_suitable_tours_pkey PRIMARY KEY (id);


--
-- Name: landing_pages_tips landing_pages_tips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_tips
    ADD CONSTRAINT landing_pages_tips_pkey PRIMARY KEY (id);


--
-- Name: landing_pages_travel_tips landing_pages_travel_tips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_travel_tips
    ADD CONSTRAINT landing_pages_travel_tips_pkey PRIMARY KEY (id);


--
-- Name: legal_pages legal_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_pages
    ADD CONSTRAINT legal_pages_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: locations locations_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_slug_key UNIQUE (slug);


--
-- Name: media_coverage media_coverage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_coverage
    ADD CONSTRAINT media_coverage_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: payload_kv payload_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_kv
    ADD CONSTRAINT payload_kv_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents payload_locked_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents
    ADD CONSTRAINT payload_locked_documents_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pkey PRIMARY KEY (id);


--
-- Name: payload_migrations payload_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_migrations
    ADD CONSTRAINT payload_migrations_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences payload_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences
    ADD CONSTRAINT payload_preferences_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences_rels payload_preferences_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: specialty_experiences specialty_experiences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialty_experiences
    ADD CONSTRAINT specialty_experiences_pkey PRIMARY KEY (id);


--
-- Name: specialty_experiences specialty_experiences_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialty_experiences
    ADD CONSTRAINT specialty_experiences_slug_key UNIQUE (slug);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: stories stories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_slug_unique UNIQUE (slug);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: thank_you_pages_cta_section_cta_buttons thank_you_pages_cta_section_cta_buttons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thank_you_pages_cta_section_cta_buttons
    ADD CONSTRAINT thank_you_pages_cta_section_cta_buttons_pkey PRIMARY KEY (id);


--
-- Name: thank_you_pages_next_steps thank_you_pages_next_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thank_you_pages_next_steps
    ADD CONSTRAINT thank_you_pages_next_steps_pkey PRIMARY KEY (id);


--
-- Name: thank_you_pages thank_you_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thank_you_pages
    ADD CONSTRAINT thank_you_pages_pkey PRIMARY KEY (id);


--
-- Name: tours_gallery_images tours_gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_gallery_images
    ADD CONSTRAINT tours_gallery_images_pkey PRIMARY KEY (id);


--
-- Name: tours_highlights tours_highlights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_highlights
    ADD CONSTRAINT tours_highlights_pkey PRIMARY KEY (id);


--
-- Name: tours tours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_pkey PRIMARY KEY (id);


--
-- Name: tours_rels tours_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_rels
    ADD CONSTRAINT tours_rels_pkey PRIMARY KEY (id);


--
-- Name: tours tours_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_slug_unique UNIQUE (slug);


--
-- Name: tours_whats_excluded tours_whats_excluded_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_whats_excluded
    ADD CONSTRAINT tours_whats_excluded_pkey PRIMARY KEY (id);


--
-- Name: tours_whats_included tours_whats_included_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_whats_included
    ADD CONSTRAINT tours_whats_included_pkey PRIMARY KEY (id);


--
-- Name: track_record_page_awards track_record_page_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_awards
    ADD CONSTRAINT track_record_page_awards_pkey PRIMARY KEY (id);


--
-- Name: track_record_page_case_studies track_record_page_case_studies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_case_studies
    ADD CONSTRAINT track_record_page_case_studies_pkey PRIMARY KEY (id);


--
-- Name: track_record_page track_record_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page
    ADD CONSTRAINT track_record_page_pkey PRIMARY KEY (id);


--
-- Name: track_record_page_press track_record_page_press_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_press
    ADD CONSTRAINT track_record_page_press_pkey PRIMARY KEY (id);


--
-- Name: track_record_page_segments track_record_page_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_segments
    ADD CONSTRAINT track_record_page_segments_pkey PRIMARY KEY (id);


--
-- Name: track_record_page_stats track_record_page_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_stats
    ADD CONSTRAINT track_record_page_stats_pkey PRIMARY KEY (id);


--
-- Name: travel_types travel_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.travel_types
    ADD CONSTRAINT travel_types_pkey PRIMARY KEY (id);


--
-- Name: travel_types travel_types_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.travel_types
    ADD CONSTRAINT travel_types_slug_key UNIQUE (slug);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors_awards vendors_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_awards
    ADD CONSTRAINT vendors_awards_pkey PRIMARY KEY (id);


--
-- Name: vendors_closed_on vendors_closed_on_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_closed_on
    ADD CONSTRAINT vendors_closed_on_pkey PRIMARY KEY (id);


--
-- Name: vendors_facilities vendors_facilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_facilities
    ADD CONSTRAINT vendors_facilities_pkey PRIMARY KEY (id);


--
-- Name: vendors_images_gallery vendors_images_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_images_gallery
    ADD CONSTRAINT vendors_images_gallery_pkey PRIMARY KEY (id);


--
-- Name: vendors_operating_hours vendors_operating_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_operating_hours
    ADD CONSTRAINT vendors_operating_hours_pkey PRIMARY KEY (id);


--
-- Name: vendors_payment_methods vendors_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_payment_methods
    ADD CONSTRAINT vendors_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: vendors_rels vendors_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_rels
    ADD CONSTRAINT vendors_rels_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_slug_unique UNIQUE (slug);


--
-- Name: _dietary_options_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_autosave_idx ON public._dietary_options_v USING btree (autosave);


--
-- Name: _dietary_options_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_created_at_idx ON public._dietary_options_v USING btree (created_at);


--
-- Name: _dietary_options_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_latest_idx ON public._dietary_options_v USING btree (latest);


--
-- Name: _dietary_options_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_parent_idx ON public._dietary_options_v USING btree (parent_id);


--
-- Name: _dietary_options_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_updated_at_idx ON public._dietary_options_v USING btree (updated_at);


--
-- Name: _dietary_options_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_version_version__status_idx ON public._dietary_options_v USING btree (version__status);


--
-- Name: _dietary_options_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_version_version_created_at_idx ON public._dietary_options_v USING btree (version_created_at);


--
-- Name: _dietary_options_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_version_version_slug_idx ON public._dietary_options_v USING btree (version_slug);


--
-- Name: _dietary_options_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _dietary_options_v_version_version_updated_at_idx ON public._dietary_options_v USING btree (version_updated_at);


--
-- Name: _faqs_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_autosave_idx ON public._faqs_v USING btree (autosave);


--
-- Name: _faqs_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_created_at_idx ON public._faqs_v USING btree (created_at);


--
-- Name: _faqs_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_latest_idx ON public._faqs_v USING btree (latest);


--
-- Name: _faqs_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_parent_idx ON public._faqs_v USING btree (parent_id);


--
-- Name: _faqs_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_updated_at_idx ON public._faqs_v USING btree (updated_at);


--
-- Name: _faqs_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_version_version__status_idx ON public._faqs_v USING btree (version__status);


--
-- Name: _faqs_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_version_version_created_at_idx ON public._faqs_v USING btree (version_created_at);


--
-- Name: _faqs_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _faqs_v_version_version_updated_at_idx ON public._faqs_v USING btree (version_updated_at);


--
-- Name: _food_items_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_autosave_idx ON public._food_items_v USING btree (autosave);


--
-- Name: _food_items_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_created_at_idx ON public._food_items_v USING btree (created_at);


--
-- Name: _food_items_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_latest_idx ON public._food_items_v USING btree (latest);


--
-- Name: _food_items_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_parent_idx ON public._food_items_v USING btree (parent_id);


--
-- Name: _food_items_v_rels_dietary_options_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_rels_dietary_options_id_idx ON public._food_items_v_rels USING btree (dietary_options_id);


--
-- Name: _food_items_v_rels_media_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_rels_media_id_idx ON public._food_items_v_rels USING btree (media_id);


--
-- Name: _food_items_v_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_rels_order_idx ON public._food_items_v_rels USING btree ("order");


--
-- Name: _food_items_v_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_rels_parent_idx ON public._food_items_v_rels USING btree (parent_id);


--
-- Name: _food_items_v_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_rels_path_idx ON public._food_items_v_rels USING btree (path);


--
-- Name: _food_items_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_updated_at_idx ON public._food_items_v USING btree (updated_at);


--
-- Name: _food_items_v_version_allergens_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_allergens_order_idx ON public._food_items_v_version_allergens USING btree (_order);


--
-- Name: _food_items_v_version_allergens_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_allergens_parent_id_idx ON public._food_items_v_version_allergens USING btree (_parent_id);


--
-- Name: _food_items_v_version_flavor_profile_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_flavor_profile_order_idx ON public._food_items_v_version_flavor_profile USING btree (_order);


--
-- Name: _food_items_v_version_flavor_profile_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_flavor_profile_parent_id_idx ON public._food_items_v_version_flavor_profile USING btree (_parent_id);


--
-- Name: _food_items_v_version_ingredients_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_ingredients_order_idx ON public._food_items_v_version_ingredients USING btree (_order);


--
-- Name: _food_items_v_version_ingredients_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_ingredients_parent_id_idx ON public._food_items_v_version_ingredients USING btree (_parent_id);


--
-- Name: _food_items_v_version_local_names_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_local_names_order_idx ON public._food_items_v_version_local_names USING btree (_order);


--
-- Name: _food_items_v_version_local_names_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_local_names_parent_id_idx ON public._food_items_v_version_local_names USING btree (_parent_id);


--
-- Name: _food_items_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_version__status_idx ON public._food_items_v USING btree (version__status);


--
-- Name: _food_items_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_version_created_at_idx ON public._food_items_v USING btree (version_created_at);


--
-- Name: _food_items_v_version_version_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_version_image_idx ON public._food_items_v USING btree (version_image_id);


--
-- Name: _food_items_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_version_slug_idx ON public._food_items_v USING btree (version_slug);


--
-- Name: _food_items_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _food_items_v_version_version_updated_at_idx ON public._food_items_v USING btree (version_updated_at);


--
-- Name: _home_page_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_page_v_latest_idx ON public._home_page_v USING btree (latest);


--
-- Name: _home_page_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _home_page_v_parent_idx ON public._home_page_v USING btree (parent_id);


--
-- Name: _legal_pages_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _legal_pages_v_latest_idx ON public._legal_pages_v USING btree (latest);


--
-- Name: _legal_pages_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _legal_pages_v_parent_idx ON public._legal_pages_v USING btree (parent_id);


--
-- Name: _stories_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_autosave_idx ON public._stories_v USING btree (autosave);


--
-- Name: _stories_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_created_at_idx ON public._stories_v USING btree (created_at);


--
-- Name: _stories_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_latest_idx ON public._stories_v USING btree (latest);


--
-- Name: _stories_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_parent_idx ON public._stories_v USING btree (parent_id);


--
-- Name: _stories_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_updated_at_idx ON public._stories_v USING btree (updated_at);


--
-- Name: _stories_v_version_meta_version_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_version_meta_version_meta_image_idx ON public._stories_v USING btree (version_meta_image_id);


--
-- Name: _stories_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_version_version__status_idx ON public._stories_v USING btree (version__status);


--
-- Name: _stories_v_version_version_author_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_version_version_author_idx ON public._stories_v USING btree (version_author_id);


--
-- Name: _stories_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_version_version_created_at_idx ON public._stories_v USING btree (version_created_at);


--
-- Name: _stories_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_version_version_slug_idx ON public._stories_v USING btree (version_slug);


--
-- Name: _stories_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _stories_v_version_version_updated_at_idx ON public._stories_v USING btree (version_updated_at);


--
-- Name: _testimonials_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_autosave_idx ON public._testimonials_v USING btree (autosave);


--
-- Name: _testimonials_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_created_at_idx ON public._testimonials_v USING btree (created_at);


--
-- Name: _testimonials_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_latest_idx ON public._testimonials_v USING btree (latest);


--
-- Name: _testimonials_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_parent_idx ON public._testimonials_v USING btree (parent_id);


--
-- Name: _testimonials_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_updated_at_idx ON public._testimonials_v USING btree (updated_at);


--
-- Name: _testimonials_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_version_version__status_idx ON public._testimonials_v USING btree (version__status);


--
-- Name: _testimonials_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_version_version_created_at_idx ON public._testimonials_v USING btree (version_created_at);


--
-- Name: _testimonials_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _testimonials_v_version_version_updated_at_idx ON public._testimonials_v USING btree (version_updated_at);


--
-- Name: _tours_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_autosave_idx ON public._tours_v USING btree (autosave);


--
-- Name: _tours_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_created_at_idx ON public._tours_v USING btree (created_at);


--
-- Name: _tours_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_latest_idx ON public._tours_v USING btree (latest);


--
-- Name: _tours_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_parent_idx ON public._tours_v USING btree (parent_id);


--
-- Name: _tours_v_rels_dietary_options_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_rels_dietary_options_id_idx ON public._tours_v_rels USING btree (dietary_options_id);


--
-- Name: _tours_v_rels_food_items_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_rels_food_items_id_idx ON public._tours_v_rels USING btree (food_items_id);


--
-- Name: _tours_v_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_rels_order_idx ON public._tours_v_rels USING btree ("order");


--
-- Name: _tours_v_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_rels_parent_idx ON public._tours_v_rels USING btree (parent_id);


--
-- Name: _tours_v_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_rels_path_idx ON public._tours_v_rels USING btree (path);


--
-- Name: _tours_v_rels_specialty_landing_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_rels_specialty_landing_pages_id_idx ON public._tours_v_rels USING btree (specialty_landing_pages_id);


--
-- Name: _tours_v_rels_travel_type_landing_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_rels_travel_type_landing_pages_id_idx ON public._tours_v_rels USING btree (travel_type_landing_pages_id);


--
-- Name: _tours_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_updated_at_idx ON public._tours_v USING btree (updated_at);


--
-- Name: _tours_v_version_gallery_images_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_gallery_images_order_idx ON public._tours_v_version_gallery_images USING btree (_order);


--
-- Name: _tours_v_version_gallery_images_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_gallery_images_parent_id_idx ON public._tours_v_version_gallery_images USING btree (_parent_id);


--
-- Name: _tours_v_version_highlights_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_highlights_order_idx ON public._tours_v_version_highlights USING btree (_order);


--
-- Name: _tours_v_version_highlights_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_highlights_parent_id_idx ON public._tours_v_version_highlights USING btree (_parent_id);


--
-- Name: _tours_v_version_meta_version_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_meta_version_meta_image_idx ON public._tours_v USING btree (version_meta_image_id);


--
-- Name: _tours_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_version__status_idx ON public._tours_v USING btree (version__status);


--
-- Name: _tours_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_version_created_at_idx ON public._tours_v USING btree (version_created_at);


--
-- Name: _tours_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_version_slug_idx ON public._tours_v USING btree (version_slug);


--
-- Name: _tours_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_version_updated_at_idx ON public._tours_v USING btree (version_updated_at);


--
-- Name: _tours_v_version_whats_excluded_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_whats_excluded_order_idx ON public._tours_v_version_whats_excluded USING btree (_order);


--
-- Name: _tours_v_version_whats_excluded_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_whats_excluded_parent_id_idx ON public._tours_v_version_whats_excluded USING btree (_parent_id);


--
-- Name: _tours_v_version_whats_included_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_whats_included_order_idx ON public._tours_v_version_whats_included USING btree (_order);


--
-- Name: _tours_v_version_whats_included_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _tours_v_version_whats_included_parent_id_idx ON public._tours_v_version_whats_included USING btree (_parent_id);


--
-- Name: _vendors_v_autosave_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_autosave_idx ON public._vendors_v USING btree (autosave);


--
-- Name: _vendors_v_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_created_at_idx ON public._vendors_v USING btree (created_at);


--
-- Name: _vendors_v_latest_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_latest_idx ON public._vendors_v USING btree (latest);


--
-- Name: _vendors_v_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_parent_idx ON public._vendors_v USING btree (parent_id);


--
-- Name: _vendors_v_rels_dietary_options_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_rels_dietary_options_id_idx ON public._vendors_v_rels USING btree (dietary_options_id);


--
-- Name: _vendors_v_rels_food_items_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_rels_food_items_id_idx ON public._vendors_v_rels USING btree (food_items_id);


--
-- Name: _vendors_v_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_rels_order_idx ON public._vendors_v_rels USING btree ("order");


--
-- Name: _vendors_v_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_rels_parent_idx ON public._vendors_v_rels USING btree (parent_id);


--
-- Name: _vendors_v_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_rels_path_idx ON public._vendors_v_rels USING btree (path);


--
-- Name: _vendors_v_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_updated_at_idx ON public._vendors_v USING btree (updated_at);


--
-- Name: _vendors_v_version_awards_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_awards_order_idx ON public._vendors_v_version_awards USING btree (_order);


--
-- Name: _vendors_v_version_awards_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_awards_parent_id_idx ON public._vendors_v_version_awards USING btree (_parent_id);


--
-- Name: _vendors_v_version_closed_on_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_closed_on_order_idx ON public._vendors_v_version_closed_on USING btree (_order);


--
-- Name: _vendors_v_version_closed_on_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_closed_on_parent_id_idx ON public._vendors_v_version_closed_on USING btree (_parent_id);


--
-- Name: _vendors_v_version_facilities_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_facilities_order_idx ON public._vendors_v_version_facilities USING btree (_order);


--
-- Name: _vendors_v_version_facilities_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_facilities_parent_id_idx ON public._vendors_v_version_facilities USING btree (_parent_id);


--
-- Name: _vendors_v_version_images_gallery_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_images_gallery_image_idx ON public._vendors_v_version_images_gallery USING btree (image_id);


--
-- Name: _vendors_v_version_images_gallery_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_images_gallery_order_idx ON public._vendors_v_version_images_gallery USING btree (_order);


--
-- Name: _vendors_v_version_images_gallery_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_images_gallery_parent_id_idx ON public._vendors_v_version_images_gallery USING btree (_parent_id);


--
-- Name: _vendors_v_version_images_version_images_main_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_images_version_images_main_idx ON public._vendors_v USING btree (version_images_main_id);


--
-- Name: _vendors_v_version_operating_hours_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_operating_hours_order_idx ON public._vendors_v_version_operating_hours USING btree (_order);


--
-- Name: _vendors_v_version_operating_hours_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_operating_hours_parent_id_idx ON public._vendors_v_version_operating_hours USING btree (_parent_id);


--
-- Name: _vendors_v_version_payment_methods_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_payment_methods_order_idx ON public._vendors_v_version_payment_methods USING btree (_order);


--
-- Name: _vendors_v_version_payment_methods_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_payment_methods_parent_id_idx ON public._vendors_v_version_payment_methods USING btree (_parent_id);


--
-- Name: _vendors_v_version_version__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_version__status_idx ON public._vendors_v USING btree (version__status);


--
-- Name: _vendors_v_version_version_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_version_created_at_idx ON public._vendors_v USING btree (version_created_at);


--
-- Name: _vendors_v_version_version_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_version_slug_idx ON public._vendors_v USING btree (version_slug);


--
-- Name: _vendors_v_version_version_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _vendors_v_version_version_updated_at_idx ON public._vendors_v USING btree (version_updated_at);


--
-- Name: about_blocks_founder_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_founder_parent_idx ON public.about_page_blocks_founder_story_block USING btree (_parent_id);


--
-- Name: about_blocks_hero_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_hero_parent_idx ON public.about_page_blocks_hero_block USING btree (_parent_id);


--
-- Name: about_blocks_philosophy_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_philosophy_parent_idx ON public.about_page_blocks_philosophy_block USING btree (_parent_id);


--
-- Name: about_blocks_stats_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_stats_parent_idx ON public.about_page_blocks_stats_block USING btree (_parent_id);


--
-- Name: about_blocks_stats_stats_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_stats_stats_parent_idx ON public.about_page_blocks_stats_block_stats USING btree (_parent_id);


--
-- Name: about_blocks_team_members_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_team_members_parent_idx ON public.about_page_blocks_team_block_members USING btree (_parent_id);


--
-- Name: about_blocks_team_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_team_parent_idx ON public.about_page_blocks_team_block USING btree (_parent_id);


--
-- Name: about_blocks_timeline_events_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_timeline_events_parent_idx ON public.about_page_blocks_timeline_block_events USING btree (_parent_id);


--
-- Name: about_blocks_timeline_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_blocks_timeline_parent_idx ON public.about_page_blocks_timeline_block USING btree (_parent_id);


--
-- Name: about_page_breadcrumbs_doc_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_page_breadcrumbs_doc_idx ON public.about_page_breadcrumbs USING btree (doc_id);


--
-- Name: about_page_breadcrumbs_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_page_breadcrumbs_order_idx ON public.about_page_breadcrumbs USING btree (_order);


--
-- Name: about_page_breadcrumbs_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_page_breadcrumbs_parent_id_idx ON public.about_page_breadcrumbs USING btree (_parent_id);


--
-- Name: about_page_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_page_created_at_idx ON public.about_page USING btree (created_at);


--
-- Name: about_page_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_page_parent_idx ON public.about_page USING btree (parent_id);


--
-- Name: about_page_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX about_page_updated_at_idx ON public.about_page USING btree (updated_at);


--
-- Name: contact_page_breadcrumbs_doc_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_page_breadcrumbs_doc_idx ON public.contact_page_breadcrumbs USING btree (doc_id);


--
-- Name: contact_page_breadcrumbs_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_page_breadcrumbs_order_idx ON public.contact_page_breadcrumbs USING btree (_order);


--
-- Name: contact_page_breadcrumbs_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contact_page_breadcrumbs_parent_id_idx ON public.contact_page_breadcrumbs USING btree (_parent_id);


--
-- Name: dietary_options__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dietary_options__status_idx ON public.dietary_options USING btree (_status);


--
-- Name: dietary_options_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dietary_options_created_at_idx ON public.dietary_options USING btree (created_at);


--
-- Name: dietary_options_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX dietary_options_slug_idx ON public.dietary_options USING btree (slug);


--
-- Name: dietary_options_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dietary_options_status_idx ON public.dietary_options USING btree (status);


--
-- Name: dietary_options_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dietary_options_updated_at_idx ON public.dietary_options USING btree (updated_at);


--
-- Name: faqs__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faqs__status_idx ON public.faqs USING btree (_status);


--
-- Name: faqs_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faqs_category_idx ON public.faqs USING btree (category);


--
-- Name: faqs_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faqs_created_at_idx ON public.faqs USING btree (created_at);


--
-- Name: faqs_page_visibility_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faqs_page_visibility_idx ON public.faqs USING btree (page_visibility);


--
-- Name: faqs_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faqs_updated_at_idx ON public.faqs USING btree (updated_at);


--
-- Name: food_items__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items__status_idx ON public.food_items USING btree (_status);


--
-- Name: food_items_allergens_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_allergens_order_idx ON public.food_items_allergens USING btree (_order);


--
-- Name: food_items_allergens_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_allergens_parent_id_idx ON public.food_items_allergens USING btree (_parent_id);


--
-- Name: food_items_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_category_idx ON public.food_items USING btree (category);


--
-- Name: food_items_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_created_at_idx ON public.food_items USING btree (created_at);


--
-- Name: food_items_flavor_profile_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_flavor_profile_order_idx ON public.food_items_flavor_profile USING btree (_order);


--
-- Name: food_items_flavor_profile_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_flavor_profile_parent_id_idx ON public.food_items_flavor_profile USING btree (_parent_id);


--
-- Name: food_items_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_image_idx ON public.food_items USING btree (image_id);


--
-- Name: food_items_ingredients_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_ingredients_order_idx ON public.food_items_ingredients USING btree (_order);


--
-- Name: food_items_ingredients_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_ingredients_parent_id_idx ON public.food_items_ingredients USING btree (_parent_id);


--
-- Name: food_items_local_names_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_local_names_order_idx ON public.food_items_local_names USING btree (_order);


--
-- Name: food_items_local_names_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_local_names_parent_id_idx ON public.food_items_local_names USING btree (_parent_id);


--
-- Name: food_items_rels_dietary_options_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_rels_dietary_options_id_idx ON public.food_items_rels USING btree (dietary_options_id);


--
-- Name: food_items_rels_media_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_rels_media_id_idx ON public.food_items_rels USING btree (media_id);


--
-- Name: food_items_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_rels_order_idx ON public.food_items_rels USING btree ("order");


--
-- Name: food_items_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_rels_parent_idx ON public.food_items_rels USING btree (parent_id);


--
-- Name: food_items_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_rels_path_idx ON public.food_items_rels USING btree (path);


--
-- Name: food_items_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX food_items_slug_idx ON public.food_items USING btree (slug);


--
-- Name: food_items_status_featured_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_status_featured_idx ON public.food_items USING btree (status, featured);


--
-- Name: food_items_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_items_updated_at_idx ON public.food_items USING btree (updated_at);


--
-- Name: home_page_blocks_about_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_about_block_parent_idx ON public.home_page_blocks_about_block USING btree (_parent_id);


--
-- Name: home_page_blocks_cta_block_buttons_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_cta_block_buttons_parent_idx ON public.home_page_blocks_cta_block_buttons USING btree (_parent_id);


--
-- Name: home_page_blocks_cta_block_features_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_cta_block_features_parent_idx ON public.home_page_blocks_cta_block_features USING btree (_parent_id);


--
-- Name: home_page_blocks_cta_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_cta_block_parent_idx ON public.home_page_blocks_cta_block USING btree (_parent_id);


--
-- Name: home_page_blocks_hero_block_badges_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_hero_block_badges_parent_idx ON public.home_page_blocks_hero_block_badges USING btree (_parent_id);


--
-- Name: home_page_blocks_hero_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_hero_block_parent_idx ON public.home_page_blocks_hero_block USING btree (_parent_id);


--
-- Name: home_page_blocks_manifesto_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_manifesto_block_parent_idx ON public.home_page_blocks_manifesto_block USING btree (_parent_id);


--
-- Name: home_page_blocks_pillars_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_pillars_block_parent_idx ON public.home_page_blocks_pillars_block USING btree (_parent_id);


--
-- Name: home_page_blocks_pillars_block_pillars_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_pillars_block_pillars_parent_idx ON public.home_page_blocks_pillars_block_pillars USING btree (_parent_id);


--
-- Name: home_page_blocks_segments_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_segments_block_parent_idx ON public.home_page_blocks_segments_block USING btree (_parent_id);


--
-- Name: home_page_blocks_stats_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_stats_block_parent_idx ON public.home_page_blocks_stats_block USING btree (_parent_id);


--
-- Name: home_page_blocks_stats_block_stats_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_stats_block_stats_parent_idx ON public.home_page_blocks_stats_block_stats USING btree (_parent_id);


--
-- Name: home_page_blocks_vendors_block_links_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_vendors_block_links_parent_idx ON public.home_page_blocks_vendors_block_links USING btree (_parent_id);


--
-- Name: home_page_blocks_vendors_block_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX home_page_blocks_vendors_block_parent_idx ON public.home_page_blocks_vendors_block USING btree (_parent_id);


--
-- Name: legal_pages_status_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX legal_pages_status_slug_idx ON public.legal_pages USING btree (status, slug);


--
-- Name: locations_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locations_slug_idx ON public.locations USING btree (slug);


--
-- Name: locations_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locations_status_idx ON public.locations USING btree (status);


--
-- Name: media_coverage_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_coverage_category_idx ON public.media_coverage USING btree (category);


--
-- Name: media_coverage_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_coverage_created_at_idx ON public.media_coverage USING btree (created_at);


--
-- Name: media_coverage_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_coverage_status_idx ON public.media_coverage USING btree (status);


--
-- Name: media_coverage_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_coverage_updated_at_idx ON public.media_coverage USING btree (updated_at);


--
-- Name: media_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);


--
-- Name: media_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX media_filename_idx ON public.media USING btree (filename);


--
-- Name: media_sizes_large_sizes_large_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_large_sizes_large_filename_idx ON public.media USING btree (sizes_large_filename);


--
-- Name: media_sizes_medium_sizes_medium_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_medium_sizes_medium_filename_idx ON public.media USING btree (sizes_medium_filename);


--
-- Name: media_sizes_thumbnail_sizes_thumbnail_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_thumbnail_sizes_thumbnail_filename_idx ON public.media USING btree (sizes_thumbnail_filename);


--
-- Name: media_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_updated_at_idx ON public.media USING btree (updated_at);


--
-- Name: menus_items_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menus_items_parent_idx ON public.menus_items USING btree (_parent_id);


--
-- Name: menus_location_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX menus_location_idx ON public.menus USING btree (location);


--
-- Name: payload_kv_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX payload_kv_key_idx ON public.payload_kv USING btree (key);


--
-- Name: payload_locked_docs_form_submissions_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_form_submissions_id_idx ON public.payload_locked_documents_rels USING btree (form_submissions_id);


--
-- Name: payload_locked_docs_forms_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_forms_id_idx ON public.payload_locked_documents_rels USING btree (forms_id);


--
-- Name: payload_locked_docs_home_page_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_home_page_id_idx ON public.payload_locked_documents_rels USING btree (home_page_id);


--
-- Name: payload_locked_docs_legal_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_legal_pages_id_idx ON public.payload_locked_documents_rels USING btree (legal_pages_id);


--
-- Name: payload_locked_docs_locations_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_locations_id_idx ON public.payload_locked_documents_rels USING btree (locations_id);


--
-- Name: payload_locked_docs_menus_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_menus_id_idx ON public.payload_locked_documents_rels USING btree (menus_id);


--
-- Name: payload_locked_docs_specialty_experiences_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_specialty_experiences_id_idx ON public.payload_locked_documents_rels USING btree (specialty_experiences_id);


--
-- Name: payload_locked_docs_travel_types_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_docs_travel_types_id_idx ON public.payload_locked_documents_rels USING btree (travel_types_id);


--
-- Name: payload_locked_documents_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_created_at_idx ON public.payload_locked_documents USING btree (created_at);


--
-- Name: payload_locked_documents_global_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_global_slug_idx ON public.payload_locked_documents USING btree (global_slug);


--
-- Name: payload_locked_documents_rels_about_page_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_about_page_id_idx ON public.payload_locked_documents_rels USING btree (about_page_id);


--
-- Name: payload_locked_documents_rels_contact_page_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_contact_page_id_idx ON public.payload_locked_documents_rels USING btree (contact_page_id);


--
-- Name: payload_locked_documents_rels_dietary_landing_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_dietary_landing_pages_id_idx ON public.payload_locked_documents_rels USING btree (dietary_landing_pages_id);


--
-- Name: payload_locked_documents_rels_dietary_options_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_dietary_options_id_idx ON public.payload_locked_documents_rels USING btree (dietary_options_id);


--
-- Name: payload_locked_documents_rels_faqs_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_faqs_id_idx ON public.payload_locked_documents_rels USING btree (faqs_id);


--
-- Name: payload_locked_documents_rels_food_items_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_food_items_id_idx ON public.payload_locked_documents_rels USING btree (food_items_id);


--
-- Name: payload_locked_documents_rels_location_landing_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_location_landing_pages_id_idx ON public.payload_locked_documents_rels USING btree (location_landing_pages_id);


--
-- Name: payload_locked_documents_rels_media_coverage_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_media_coverage_id_idx ON public.payload_locked_documents_rels USING btree (media_coverage_id);


--
-- Name: payload_locked_documents_rels_media_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_media_id_idx ON public.payload_locked_documents_rels USING btree (media_id);


--
-- Name: payload_locked_documents_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_order_idx ON public.payload_locked_documents_rels USING btree ("order");


--
-- Name: payload_locked_documents_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_parent_idx ON public.payload_locked_documents_rels USING btree (parent_id);


--
-- Name: payload_locked_documents_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_path_idx ON public.payload_locked_documents_rels USING btree (path);


--
-- Name: payload_locked_documents_rels_redirects_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_redirects_id_idx ON public.payload_locked_documents_rels USING btree (redirects_id);


--
-- Name: payload_locked_documents_rels_search_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_search_id_idx ON public.payload_locked_documents_rels USING btree (search_id);


--
-- Name: payload_locked_documents_rels_site_settings_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_site_settings_id_idx ON public.payload_locked_documents_rels USING btree (site_settings_id);


--
-- Name: payload_locked_documents_rels_specialty_landing_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_specialty_landing_pages_id_idx ON public.payload_locked_documents_rels USING btree (specialty_landing_pages_id);


--
-- Name: payload_locked_documents_rels_stories_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_stories_id_idx ON public.payload_locked_documents_rels USING btree (stories_id);


--
-- Name: payload_locked_documents_rels_testimonials_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_testimonials_id_idx ON public.payload_locked_documents_rels USING btree (testimonials_id);


--
-- Name: payload_locked_documents_rels_thank_you_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_thank_you_pages_id_idx ON public.payload_locked_documents_rels USING btree (thank_you_pages_id);


--
-- Name: payload_locked_documents_rels_tours_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_tours_id_idx ON public.payload_locked_documents_rels USING btree (tours_id);


--
-- Name: payload_locked_documents_rels_translations_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_translations_id_idx ON public.payload_locked_documents_rels USING btree (translations_id);


--
-- Name: payload_locked_documents_rels_travel_type_landing_pages__idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_travel_type_landing_pages__idx ON public.payload_locked_documents_rels USING btree (travel_type_landing_pages_id);


--
-- Name: payload_locked_documents_rels_users_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_users_id_idx ON public.payload_locked_documents_rels USING btree (users_id);


--
-- Name: payload_locked_documents_rels_vendors_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_vendors_id_idx ON public.payload_locked_documents_rels USING btree (vendors_id);


--
-- Name: payload_locked_documents_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_updated_at_idx ON public.payload_locked_documents USING btree (updated_at);


--
-- Name: payload_migrations_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_migrations_created_at_idx ON public.payload_migrations USING btree (created_at);


--
-- Name: payload_migrations_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_migrations_updated_at_idx ON public.payload_migrations USING btree (updated_at);


--
-- Name: payload_preferences_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_created_at_idx ON public.payload_preferences USING btree (created_at);


--
-- Name: payload_preferences_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_key_idx ON public.payload_preferences USING btree (key);


--
-- Name: payload_preferences_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_order_idx ON public.payload_preferences_rels USING btree ("order");


--
-- Name: payload_preferences_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_parent_idx ON public.payload_preferences_rels USING btree (parent_id);


--
-- Name: payload_preferences_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_path_idx ON public.payload_preferences_rels USING btree (path);


--
-- Name: payload_preferences_rels_users_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_users_id_idx ON public.payload_preferences_rels USING btree (users_id);


--
-- Name: payload_preferences_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_updated_at_idx ON public.payload_preferences USING btree (updated_at);


--
-- Name: site_settings_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX site_settings_created_at_idx ON public.site_settings USING btree (created_at);


--
-- Name: site_settings_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX site_settings_updated_at_idx ON public.site_settings USING btree (updated_at);


--
-- Name: specialty_experiences_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX specialty_experiences_slug_idx ON public.specialty_experiences USING btree (slug);


--
-- Name: specialty_experiences_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX specialty_experiences_status_idx ON public.specialty_experiences USING btree (status);


--
-- Name: stories__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stories__status_idx ON public.stories USING btree (_status);


--
-- Name: stories_author_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stories_author_idx ON public.stories USING btree (author_id);


--
-- Name: stories_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stories_created_at_idx ON public.stories USING btree (created_at);


--
-- Name: stories_meta_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stories_meta_meta_image_idx ON public.stories USING btree (meta_image_id);


--
-- Name: stories_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX stories_slug_idx ON public.stories USING btree (slug);


--
-- Name: stories_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stories_status_idx ON public.stories USING btree (status);


--
-- Name: stories_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stories_updated_at_idx ON public.stories USING btree (updated_at);


--
-- Name: testimonials__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX testimonials__status_idx ON public.testimonials USING btree (_status);


--
-- Name: testimonials_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX testimonials_created_at_idx ON public.testimonials USING btree (created_at);


--
-- Name: testimonials_platform_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX testimonials_platform_idx ON public.testimonials USING btree (platform);


--
-- Name: testimonials_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX testimonials_updated_at_idx ON public.testimonials USING btree (updated_at);


--
-- Name: testimonials_visibility_featured_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX testimonials_visibility_featured_idx ON public.testimonials USING btree (visibility_featured) WHERE (visibility_featured = true);


--
-- Name: thank_you_pages_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thank_you_pages_created_at_idx ON public.thank_you_pages USING btree (created_at);


--
-- Name: thank_you_pages_cta_section_cta_buttons_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thank_you_pages_cta_section_cta_buttons_order_idx ON public.thank_you_pages_cta_section_cta_buttons USING btree (_order);


--
-- Name: thank_you_pages_cta_section_cta_buttons_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thank_you_pages_cta_section_cta_buttons_parent_id_idx ON public.thank_you_pages_cta_section_cta_buttons USING btree (_parent_id);


--
-- Name: thank_you_pages_next_steps_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thank_you_pages_next_steps_order_idx ON public.thank_you_pages_next_steps USING btree (_order);


--
-- Name: thank_you_pages_next_steps_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thank_you_pages_next_steps_parent_id_idx ON public.thank_you_pages_next_steps USING btree (_parent_id);


--
-- Name: thank_you_pages_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX thank_you_pages_slug_idx ON public.thank_you_pages USING btree (slug);


--
-- Name: thank_you_pages_type_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thank_you_pages_type_status_idx ON public.thank_you_pages USING btree (type, status);


--
-- Name: thank_you_pages_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thank_you_pages_updated_at_idx ON public.thank_you_pages USING btree (updated_at);


--
-- Name: tours__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours__status_idx ON public.tours USING btree (_status);


--
-- Name: tours_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_created_at_idx ON public.tours USING btree (created_at);


--
-- Name: tours_gallery_images_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_gallery_images_order_idx ON public.tours_gallery_images USING btree (_order);


--
-- Name: tours_gallery_images_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_gallery_images_parent_id_idx ON public.tours_gallery_images USING btree (_parent_id);


--
-- Name: tours_highlights_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_highlights_order_idx ON public.tours_highlights USING btree (_order);


--
-- Name: tours_highlights_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_highlights_parent_id_idx ON public.tours_highlights USING btree (_parent_id);


--
-- Name: tours_location_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_location_status_idx ON public.tours USING btree (location, status);


--
-- Name: tours_meta_meta_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_meta_meta_image_idx ON public.tours USING btree (meta_image_id);


--
-- Name: tours_popular_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_popular_idx ON public.tours USING btree (popular) WHERE (popular = true);


--
-- Name: tours_rels_dietary_options_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_dietary_options_id_idx ON public.tours_rels USING btree (dietary_options_id);


--
-- Name: tours_rels_food_items_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_food_items_id_idx ON public.tours_rels USING btree (food_items_id);


--
-- Name: tours_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_order_idx ON public.tours_rels USING btree ("order");


--
-- Name: tours_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_parent_idx ON public.tours_rels USING btree (parent_id);


--
-- Name: tours_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_path_idx ON public.tours_rels USING btree (path);


--
-- Name: tours_rels_specialty_experiences_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_specialty_experiences_id_idx ON public.tours_rels USING btree (specialty_experiences_id);


--
-- Name: tours_rels_specialty_landing_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_specialty_landing_pages_id_idx ON public.tours_rels USING btree (specialty_landing_pages_id);


--
-- Name: tours_rels_travel_type_landing_pages_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_travel_type_landing_pages_id_idx ON public.tours_rels USING btree (travel_type_landing_pages_id);


--
-- Name: tours_rels_travel_types_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_rels_travel_types_id_idx ON public.tours_rels USING btree (travel_types_id);


--
-- Name: tours_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tours_slug_idx ON public.tours USING btree (slug);


--
-- Name: tours_status_featured_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_status_featured_idx ON public.tours USING btree (status, featured);


--
-- Name: tours_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_updated_at_idx ON public.tours USING btree (updated_at);


--
-- Name: tours_whats_excluded_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_whats_excluded_order_idx ON public.tours_whats_excluded USING btree (_order);


--
-- Name: tours_whats_excluded_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_whats_excluded_parent_id_idx ON public.tours_whats_excluded USING btree (_parent_id);


--
-- Name: tours_whats_included_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_whats_included_order_idx ON public.tours_whats_included USING btree (_order);


--
-- Name: tours_whats_included_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX tours_whats_included_parent_id_idx ON public.tours_whats_included USING btree (_parent_id);


--
-- Name: travel_types_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX travel_types_slug_idx ON public.travel_types USING btree (slug);


--
-- Name: travel_types_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX travel_types_status_idx ON public.travel_types USING btree (status);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_updated_at_idx ON public.users USING btree (updated_at);


--
-- Name: vendors__status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors__status_idx ON public.vendors USING btree (_status);


--
-- Name: vendors_awards_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_awards_order_idx ON public.vendors_awards USING btree (_order);


--
-- Name: vendors_awards_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_awards_parent_id_idx ON public.vendors_awards USING btree (_parent_id);


--
-- Name: vendors_closed_on_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_closed_on_order_idx ON public.vendors_closed_on USING btree (_order);


--
-- Name: vendors_closed_on_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_closed_on_parent_id_idx ON public.vendors_closed_on USING btree (_parent_id);


--
-- Name: vendors_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_created_at_idx ON public.vendors USING btree (created_at);


--
-- Name: vendors_facilities_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_facilities_order_idx ON public.vendors_facilities USING btree (_order);


--
-- Name: vendors_facilities_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_facilities_parent_id_idx ON public.vendors_facilities USING btree (_parent_id);


--
-- Name: vendors_images_gallery_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_images_gallery_image_idx ON public.vendors_images_gallery USING btree (image_id);


--
-- Name: vendors_images_gallery_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_images_gallery_order_idx ON public.vendors_images_gallery USING btree (_order);


--
-- Name: vendors_images_gallery_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_images_gallery_parent_id_idx ON public.vendors_images_gallery USING btree (_parent_id);


--
-- Name: vendors_images_images_main_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_images_images_main_idx ON public.vendors USING btree (images_main_id);


--
-- Name: vendors_operating_hours_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_operating_hours_order_idx ON public.vendors_operating_hours USING btree (_order);


--
-- Name: vendors_operating_hours_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_operating_hours_parent_id_idx ON public.vendors_operating_hours USING btree (_parent_id);


--
-- Name: vendors_payment_methods_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_payment_methods_order_idx ON public.vendors_payment_methods USING btree (_order);


--
-- Name: vendors_payment_methods_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_payment_methods_parent_id_idx ON public.vendors_payment_methods USING btree (_parent_id);


--
-- Name: vendors_rels_dietary_options_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_rels_dietary_options_id_idx ON public.vendors_rels USING btree (dietary_options_id);


--
-- Name: vendors_rels_food_items_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_rels_food_items_id_idx ON public.vendors_rels USING btree (food_items_id);


--
-- Name: vendors_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_rels_order_idx ON public.vendors_rels USING btree ("order");


--
-- Name: vendors_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_rels_parent_idx ON public.vendors_rels USING btree (parent_id);


--
-- Name: vendors_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_rels_path_idx ON public.vendors_rels USING btree (path);


--
-- Name: vendors_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX vendors_slug_idx ON public.vendors USING btree (slug);


--
-- Name: vendors_status_featured_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_status_featured_idx ON public.vendors USING btree (status, featured);


--
-- Name: vendors_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_type_idx ON public.vendors USING btree (type);


--
-- Name: vendors_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vendors_updated_at_idx ON public.vendors USING btree (updated_at);


--
-- Name: _contact_page_v _contact_page_v_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._contact_page_v
    ADD CONSTRAINT _contact_page_v_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.contact_page(id) ON DELETE CASCADE;


--
-- Name: _corporate_groups_page_v _corporate_groups_page_v_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._corporate_groups_page_v
    ADD CONSTRAINT _corporate_groups_page_v_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.corporate_groups_page(id) ON DELETE CASCADE;


--
-- Name: _dietary_options_v _dietary_options_v_parent_id_dietary_options_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._dietary_options_v
    ADD CONSTRAINT _dietary_options_v_parent_id_dietary_options_id_fk FOREIGN KEY (parent_id) REFERENCES public.dietary_options(id) ON DELETE SET NULL;


--
-- Name: _directions_page_v _directions_page_v_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._directions_page_v
    ADD CONSTRAINT _directions_page_v_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.directions_page(id) ON DELETE CASCADE;


--
-- Name: _faqs_v _faqs_v_parent_id_faqs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._faqs_v
    ADD CONSTRAINT _faqs_v_parent_id_faqs_id_fk FOREIGN KEY (parent_id) REFERENCES public.faqs(id) ON DELETE SET NULL;


--
-- Name: _food_items_v _food_items_v_parent_id_food_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v
    ADD CONSTRAINT _food_items_v_parent_id_food_items_id_fk FOREIGN KEY (parent_id) REFERENCES public.food_items(id) ON DELETE SET NULL;


--
-- Name: _food_items_v_rels _food_items_v_rels_dietary_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_rels
    ADD CONSTRAINT _food_items_v_rels_dietary_options_fk FOREIGN KEY (dietary_options_id) REFERENCES public.dietary_options(id) ON DELETE CASCADE;


--
-- Name: _food_items_v_rels _food_items_v_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_rels
    ADD CONSTRAINT _food_items_v_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: _food_items_v_rels _food_items_v_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_rels
    ADD CONSTRAINT _food_items_v_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public._food_items_v(id) ON DELETE CASCADE;


--
-- Name: _food_items_v_version_allergens _food_items_v_version_allergens_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_allergens
    ADD CONSTRAINT _food_items_v_version_allergens_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._food_items_v(id) ON DELETE CASCADE;


--
-- Name: _food_items_v_version_flavor_profile _food_items_v_version_flavor_profile_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_flavor_profile
    ADD CONSTRAINT _food_items_v_version_flavor_profile_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._food_items_v(id) ON DELETE CASCADE;


--
-- Name: _food_items_v _food_items_v_version_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v
    ADD CONSTRAINT _food_items_v_version_image_id_media_id_fk FOREIGN KEY (version_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _food_items_v_version_ingredients _food_items_v_version_ingredients_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_ingredients
    ADD CONSTRAINT _food_items_v_version_ingredients_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._food_items_v(id) ON DELETE CASCADE;


--
-- Name: _food_items_v_version_local_names _food_items_v_version_local_names_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._food_items_v_version_local_names
    ADD CONSTRAINT _food_items_v_version_local_names_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._food_items_v(id) ON DELETE CASCADE;


--
-- Name: _home_page_v _home_page_v_parent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._home_page_v
    ADD CONSTRAINT _home_page_v_parent_fkey FOREIGN KEY (parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: _how_it_works_page_v _how_it_works_page_v_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._how_it_works_page_v
    ADD CONSTRAINT _how_it_works_page_v_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.how_it_works_page(id) ON DELETE CASCADE;


--
-- Name: _how_to_prepare_page_v _how_to_prepare_page_v_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._how_to_prepare_page_v
    ADD CONSTRAINT _how_to_prepare_page_v_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.how_to_prepare_page(id) ON DELETE CASCADE;


--
-- Name: _landing_pages_v _landing_pages_v_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._landing_pages_v
    ADD CONSTRAINT _landing_pages_v_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: _legal_pages_v _legal_pages_v_parent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._legal_pages_v
    ADD CONSTRAINT _legal_pages_v_parent_fkey FOREIGN KEY (parent_id) REFERENCES public.legal_pages(id) ON DELETE CASCADE;


--
-- Name: menus_items _menus_items_v__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus_items
    ADD CONSTRAINT _menus_items_v__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.menus(id) ON DELETE CASCADE;


--
-- Name: _stories_v _stories_v_parent_id_stories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._stories_v
    ADD CONSTRAINT _stories_v_parent_id_stories_id_fk FOREIGN KEY (parent_id) REFERENCES public.stories(id) ON DELETE SET NULL;


--
-- Name: _stories_v _stories_v_version_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._stories_v
    ADD CONSTRAINT _stories_v_version_author_id_users_id_fk FOREIGN KEY (version_author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: _stories_v _stories_v_version_featured_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._stories_v
    ADD CONSTRAINT _stories_v_version_featured_image_id_fkey FOREIGN KEY (version_featured_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _stories_v _stories_v_version_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._stories_v
    ADD CONSTRAINT _stories_v_version_meta_image_id_media_id_fk FOREIGN KEY (version_meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _testimonials_v _testimonials_v_parent_id_testimonials_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._testimonials_v
    ADD CONSTRAINT _testimonials_v_parent_id_testimonials_id_fk FOREIGN KEY (parent_id) REFERENCES public.testimonials(id) ON DELETE SET NULL;


--
-- Name: _tours_v _tours_v_parent_id_tours_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v
    ADD CONSTRAINT _tours_v_parent_id_tours_id_fk FOREIGN KEY (parent_id) REFERENCES public.tours(id) ON DELETE SET NULL;


--
-- Name: _tours_v_rels _tours_v_rels_dietary_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_rels
    ADD CONSTRAINT _tours_v_rels_dietary_options_fk FOREIGN KEY (dietary_options_id) REFERENCES public.dietary_options(id) ON DELETE CASCADE;


--
-- Name: _tours_v_rels _tours_v_rels_food_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_rels
    ADD CONSTRAINT _tours_v_rels_food_items_fk FOREIGN KEY (food_items_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: _tours_v_rels _tours_v_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_rels
    ADD CONSTRAINT _tours_v_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public._tours_v(id) ON DELETE CASCADE;


--
-- Name: _tours_v_version_gallery_images _tours_v_version_gallery_images_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_gallery_images
    ADD CONSTRAINT _tours_v_version_gallery_images_image_id_fkey FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _tours_v_version_gallery_images _tours_v_version_gallery_images_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_gallery_images
    ADD CONSTRAINT _tours_v_version_gallery_images_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._tours_v(id) ON DELETE CASCADE;


--
-- Name: _tours_v _tours_v_version_hero_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v
    ADD CONSTRAINT _tours_v_version_hero_image_id_fkey FOREIGN KEY (version_hero_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _tours_v_version_highlights _tours_v_version_highlights_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_highlights
    ADD CONSTRAINT _tours_v_version_highlights_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._tours_v(id) ON DELETE CASCADE;


--
-- Name: _tours_v _tours_v_version_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v
    ADD CONSTRAINT _tours_v_version_meta_image_id_media_id_fk FOREIGN KEY (version_meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _tours_v_version_whats_excluded _tours_v_version_whats_excluded_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_whats_excluded
    ADD CONSTRAINT _tours_v_version_whats_excluded_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._tours_v(id) ON DELETE CASCADE;


--
-- Name: _tours_v_version_whats_included _tours_v_version_whats_included_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._tours_v_version_whats_included
    ADD CONSTRAINT _tours_v_version_whats_included_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._tours_v(id) ON DELETE CASCADE;


--
-- Name: _track_record_page_v _track_record_page_v_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._track_record_page_v
    ADD CONSTRAINT _track_record_page_v_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.track_record_page(id) ON DELETE CASCADE;


--
-- Name: _vendors_v _vendors_v_parent_id_vendors_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v
    ADD CONSTRAINT _vendors_v_parent_id_vendors_id_fk FOREIGN KEY (parent_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: _vendors_v_rels _vendors_v_rels_dietary_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_rels
    ADD CONSTRAINT _vendors_v_rels_dietary_options_fk FOREIGN KEY (dietary_options_id) REFERENCES public.dietary_options(id) ON DELETE CASCADE;


--
-- Name: _vendors_v_rels _vendors_v_rels_food_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_rels
    ADD CONSTRAINT _vendors_v_rels_food_items_fk FOREIGN KEY (food_items_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: _vendors_v_rels _vendors_v_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_rels
    ADD CONSTRAINT _vendors_v_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public._vendors_v(id) ON DELETE CASCADE;


--
-- Name: _vendors_v_version_awards _vendors_v_version_awards_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_awards
    ADD CONSTRAINT _vendors_v_version_awards_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._vendors_v(id) ON DELETE CASCADE;


--
-- Name: _vendors_v_version_closed_on _vendors_v_version_closed_on_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_closed_on
    ADD CONSTRAINT _vendors_v_version_closed_on_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._vendors_v(id) ON DELETE CASCADE;


--
-- Name: _vendors_v_version_facilities _vendors_v_version_facilities_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_facilities
    ADD CONSTRAINT _vendors_v_version_facilities_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._vendors_v(id) ON DELETE CASCADE;


--
-- Name: _vendors_v_version_images_gallery _vendors_v_version_images_gallery_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_images_gallery
    ADD CONSTRAINT _vendors_v_version_images_gallery_image_id_media_id_fk FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _vendors_v_version_images_gallery _vendors_v_version_images_gallery_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_images_gallery
    ADD CONSTRAINT _vendors_v_version_images_gallery_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._vendors_v(id) ON DELETE CASCADE;


--
-- Name: _vendors_v _vendors_v_version_images_main_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v
    ADD CONSTRAINT _vendors_v_version_images_main_id_media_id_fk FOREIGN KEY (version_images_main_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: _vendors_v_version_operating_hours _vendors_v_version_operating_hours_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_operating_hours
    ADD CONSTRAINT _vendors_v_version_operating_hours_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._vendors_v(id) ON DELETE CASCADE;


--
-- Name: _vendors_v_version_payment_methods _vendors_v_version_payment_methods_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._vendors_v_version_payment_methods
    ADD CONSTRAINT _vendors_v_version_payment_methods_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public._vendors_v(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_founder_story_block about_page_blocks_founder_story_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_founder_story_block
    ADD CONSTRAINT about_page_blocks_founder_story_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_hero_block about_page_blocks_hero_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_hero_block
    ADD CONSTRAINT about_page_blocks_hero_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_philosophy_block about_page_blocks_philosophy_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_philosophy_block
    ADD CONSTRAINT about_page_blocks_philosophy_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_stats_block about_page_blocks_stats_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_stats_block
    ADD CONSTRAINT about_page_blocks_stats_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_stats_block_stats about_page_blocks_stats_block_stats__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_stats_block_stats
    ADD CONSTRAINT about_page_blocks_stats_block_stats__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page_blocks_stats_block(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_team_block about_page_blocks_team_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_team_block
    ADD CONSTRAINT about_page_blocks_team_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_team_block_members about_page_blocks_team_block_members__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_team_block_members
    ADD CONSTRAINT about_page_blocks_team_block_members__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page_blocks_team_block(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_timeline_block about_page_blocks_timeline_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_timeline_block
    ADD CONSTRAINT about_page_blocks_timeline_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: about_page_blocks_timeline_block_events about_page_blocks_timeline_block_events__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_blocks_timeline_block_events
    ADD CONSTRAINT about_page_blocks_timeline_block_events__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.about_page_blocks_timeline_block(id) ON DELETE CASCADE;


--
-- Name: about_page_breadcrumbs about_page_breadcrumbs_doc_id_about_page_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_breadcrumbs
    ADD CONSTRAINT about_page_breadcrumbs_doc_id_about_page_id_fk FOREIGN KEY (doc_id) REFERENCES public.about_page(id) ON DELETE SET NULL;


--
-- Name: about_page_breadcrumbs about_page_breadcrumbs_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page_breadcrumbs
    ADD CONSTRAINT about_page_breadcrumbs_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: about_page about_page_parent_id_about_page_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.about_page
    ADD CONSTRAINT about_page_parent_id_about_page_id_fk FOREIGN KEY (parent_id) REFERENCES public.about_page(id) ON DELETE SET NULL;


--
-- Name: corporate_groups_page_benefit_cards corporate_groups_page_benefit_cards__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corporate_groups_page_benefit_cards
    ADD CONSTRAINT corporate_groups_page_benefit_cards__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.corporate_groups_page(id) ON DELETE CASCADE;


--
-- Name: corporate_groups_page_how_steps corporate_groups_page_how_steps__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corporate_groups_page_how_steps
    ADD CONSTRAINT corporate_groups_page_how_steps__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.corporate_groups_page(id) ON DELETE CASCADE;


--
-- Name: corporate_groups_page_offer_perfect_for corporate_groups_page_offer_perfect_for__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corporate_groups_page_offer_perfect_for
    ADD CONSTRAINT corporate_groups_page_offer_perfect_for__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.corporate_groups_page(id) ON DELETE CASCADE;


--
-- Name: directions_page_general_tips directions_page_general_tips__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directions_page_general_tips
    ADD CONSTRAINT directions_page_general_tips__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.directions_page(id) ON DELETE CASCADE;


--
-- Name: directions_page_meeting_points directions_page_meeting_points__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.directions_page_meeting_points
    ADD CONSTRAINT directions_page_meeting_points__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.directions_page(id) ON DELETE CASCADE;


--
-- Name: food_items_allergens food_items_allergens_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_allergens
    ADD CONSTRAINT food_items_allergens_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: food_items_flavor_profile food_items_flavor_profile_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_flavor_profile
    ADD CONSTRAINT food_items_flavor_profile_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: food_items food_items_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items
    ADD CONSTRAINT food_items_image_id_media_id_fk FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: food_items_ingredients food_items_ingredients_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_ingredients
    ADD CONSTRAINT food_items_ingredients_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: food_items_local_names food_items_local_names_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_local_names
    ADD CONSTRAINT food_items_local_names_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: food_items_rels food_items_rels_dietary_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_rels
    ADD CONSTRAINT food_items_rels_dietary_options_fk FOREIGN KEY (dietary_options_id) REFERENCES public.dietary_options(id) ON DELETE CASCADE;


--
-- Name: food_items_rels food_items_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_rels
    ADD CONSTRAINT food_items_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: food_items_rels food_items_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_items_rels
    ADD CONSTRAINT food_items_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_about_block home_page_blocks_about_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_about_block
    ADD CONSTRAINT home_page_blocks_about_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_cta_block_buttons home_page_blocks_cta_block_buttons__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block_buttons
    ADD CONSTRAINT home_page_blocks_cta_block_buttons__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page_blocks_cta_block(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_cta_block_features home_page_blocks_cta_block_features__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block_features
    ADD CONSTRAINT home_page_blocks_cta_block_features__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page_blocks_cta_block(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_hero_block home_page_blocks_hero_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_hero_block
    ADD CONSTRAINT home_page_blocks_hero_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_hero_block_badges home_page_blocks_hero_block_badges__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_hero_block_badges
    ADD CONSTRAINT home_page_blocks_hero_block_badges__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page_blocks_hero_block(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_manifesto_block home_page_blocks_manifesto_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_manifesto_block
    ADD CONSTRAINT home_page_blocks_manifesto_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_pillars_block home_page_blocks_pillars_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_pillars_block
    ADD CONSTRAINT home_page_blocks_pillars_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_pillars_block_pillars home_page_blocks_pillars_block_pillars__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_pillars_block_pillars
    ADD CONSTRAINT home_page_blocks_pillars_block_pillars__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page_blocks_pillars_block(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_segments_block home_page_blocks_segments_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_segments_block
    ADD CONSTRAINT home_page_blocks_segments_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_stats_block home_page_blocks_stats_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_stats_block
    ADD CONSTRAINT home_page_blocks_stats_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_stats_block_stats home_page_blocks_stats_block_stats__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_stats_block_stats
    ADD CONSTRAINT home_page_blocks_stats_block_stats__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page_blocks_stats_block(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_vendors_block home_page_blocks_vendors_block__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_vendors_block
    ADD CONSTRAINT home_page_blocks_vendors_block__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_vendors_block_links home_page_blocks_vendors_block_links__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_vendors_block_links
    ADD CONSTRAINT home_page_blocks_vendors_block_links__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page_blocks_vendors_block(id) ON DELETE CASCADE;


--
-- Name: home_page_blocks_cta_block home_page_cta_section__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_page_blocks_cta_block
    ADD CONSTRAINT home_page_cta_section__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: how_it_works_page_formats how_it_works_page_formats__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_it_works_page_formats
    ADD CONSTRAINT how_it_works_page_formats__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.how_it_works_page(id) ON DELETE CASCADE;


--
-- Name: how_it_works_page_inclusions how_it_works_page_inclusions__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_it_works_page_inclusions
    ADD CONSTRAINT how_it_works_page_inclusions__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.how_it_works_page(id) ON DELETE CASCADE;


--
-- Name: how_it_works_page_steps how_it_works_page_steps__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_it_works_page_steps
    ADD CONSTRAINT how_it_works_page_steps__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.how_it_works_page(id) ON DELETE CASCADE;


--
-- Name: how_to_prepare_page_dietary_notes how_to_prepare_page_dietary_notes__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_dietary_notes
    ADD CONSTRAINT how_to_prepare_page_dietary_notes__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.how_to_prepare_page(id) ON DELETE CASCADE;


--
-- Name: how_to_prepare_page_what_to_bring how_to_prepare_page_what_to_bring__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_what_to_bring
    ADD CONSTRAINT how_to_prepare_page_what_to_bring__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.how_to_prepare_page(id) ON DELETE CASCADE;


--
-- Name: how_to_prepare_page_what_to_expect how_to_prepare_page_what_to_expect__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_what_to_expect
    ADD CONSTRAINT how_to_prepare_page_what_to_expect__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.how_to_prepare_page(id) ON DELETE CASCADE;


--
-- Name: how_to_prepare_page_what_to_wear how_to_prepare_page_what_to_wear__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.how_to_prepare_page_what_to_wear
    ADD CONSTRAINT how_to_prepare_page_what_to_wear__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.how_to_prepare_page(id) ON DELETE CASCADE;


--
-- Name: landing_pages_avoid_dishes landing_pages_avoid_dishes__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_avoid_dishes
    ADD CONSTRAINT landing_pages_avoid_dishes__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: landing_pages_challenges landing_pages_challenges__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_challenges
    ADD CONSTRAINT landing_pages_challenges__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: landing_pages_highlights landing_pages_highlights__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_highlights
    ADD CONSTRAINT landing_pages_highlights__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: landing_pages_safe_dishes landing_pages_safe_dishes__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_safe_dishes
    ADD CONSTRAINT landing_pages_safe_dishes__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: landing_pages_suitable_tours landing_pages_suitable_tours__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_suitable_tours
    ADD CONSTRAINT landing_pages_suitable_tours__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: landing_pages_tips landing_pages_tips__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_tips
    ADD CONSTRAINT landing_pages_tips__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: landing_pages_travel_tips landing_pages_travel_tips__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.landing_pages_travel_tips
    ADD CONSTRAINT landing_pages_travel_tips__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_docs_home_page_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_docs_home_page_fk FOREIGN KEY (home_page_id) REFERENCES public.home_page(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_docs_legal_pages_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_docs_legal_pages_fk FOREIGN KEY (legal_pages_id) REFERENCES public.legal_pages(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_docs_locations_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_docs_locations_fk FOREIGN KEY (locations_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_docs_menus_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_docs_menus_fk FOREIGN KEY (menus_id) REFERENCES public.menus(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_docs_specialty_experiences_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_docs_specialty_experiences_fk FOREIGN KEY (specialty_experiences_id) REFERENCES public.specialty_experiences(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_docs_travel_types_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_docs_travel_types_fk FOREIGN KEY (travel_types_id) REFERENCES public.travel_types(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_about_page_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_about_page_fk FOREIGN KEY (about_page_id) REFERENCES public.about_page(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_corporate_groups_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_corporate_groups_page_id_fkey FOREIGN KEY (corporate_groups_page_id) REFERENCES public.corporate_groups_page(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_dietary_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_dietary_options_fk FOREIGN KEY (dietary_options_id) REFERENCES public.dietary_options(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_directions_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_directions_page_id_fkey FOREIGN KEY (directions_page_id) REFERENCES public.directions_page(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_faqs_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_faqs_fk FOREIGN KEY (faqs_id) REFERENCES public.faqs(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_food_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_food_items_fk FOREIGN KEY (food_items_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_how_it_works_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_how_it_works_page_id_fkey FOREIGN KEY (how_it_works_page_id) REFERENCES public.how_it_works_page(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_how_to_prepare_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_how_to_prepare_page_id_fkey FOREIGN KEY (how_to_prepare_page_id) REFERENCES public.how_to_prepare_page(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_landing_pages_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_landing_pages_id_fkey FOREIGN KEY (landing_pages_id) REFERENCES public.landing_pages(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_media_coverage_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_media_coverage_fk FOREIGN KEY (media_coverage_id) REFERENCES public.media_coverage(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_locked_documents(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_site_settings_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_site_settings_fk FOREIGN KEY (site_settings_id) REFERENCES public.site_settings(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_stories_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_stories_fk FOREIGN KEY (stories_id) REFERENCES public.stories(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_testimonials_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_testimonials_fk FOREIGN KEY (testimonials_id) REFERENCES public.testimonials(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_thank_you_pages_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_thank_you_pages_fk FOREIGN KEY (thank_you_pages_id) REFERENCES public.thank_you_pages(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_tours_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_tours_fk FOREIGN KEY (tours_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_track_record_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_track_record_page_id_fkey FOREIGN KEY (track_record_page_id) REFERENCES public.track_record_page(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_vendors_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_vendors_fk FOREIGN KEY (vendors_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_preferences(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stories stories_author_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_author_id_users_id_fk FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stories stories_featured_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_featured_image_id_fkey FOREIGN KEY (featured_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: stories stories_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_meta_image_id_media_id_fk FOREIGN KEY (meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: thank_you_pages_cta_section_cta_buttons thank_you_pages_cta_section_cta_buttons_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thank_you_pages_cta_section_cta_buttons
    ADD CONSTRAINT thank_you_pages_cta_section_cta_buttons_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.thank_you_pages(id) ON DELETE CASCADE;


--
-- Name: thank_you_pages_next_steps thank_you_pages_next_steps_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thank_you_pages_next_steps
    ADD CONSTRAINT thank_you_pages_next_steps_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.thank_you_pages(id) ON DELETE CASCADE;


--
-- Name: tours_gallery_images tours_gallery_images_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_gallery_images
    ADD CONSTRAINT tours_gallery_images_image_id_fkey FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: tours_gallery_images tours_gallery_images_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_gallery_images
    ADD CONSTRAINT tours_gallery_images_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tours tours_hero_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_hero_image_id_fkey FOREIGN KEY (hero_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: tours_highlights tours_highlights_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_highlights
    ADD CONSTRAINT tours_highlights_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tours tours_meta_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours
    ADD CONSTRAINT tours_meta_image_id_media_id_fk FOREIGN KEY (meta_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: tours_rels tours_rels_dietary_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_rels
    ADD CONSTRAINT tours_rels_dietary_options_fk FOREIGN KEY (dietary_options_id) REFERENCES public.dietary_options(id) ON DELETE CASCADE;


--
-- Name: tours_rels tours_rels_food_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_rels
    ADD CONSTRAINT tours_rels_food_items_fk FOREIGN KEY (food_items_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: tours_rels tours_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_rels
    ADD CONSTRAINT tours_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tours_rels tours_rels_specialty_experiences_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_rels
    ADD CONSTRAINT tours_rels_specialty_experiences_fk FOREIGN KEY (specialty_experiences_id) REFERENCES public.specialty_experiences(id) ON DELETE CASCADE;


--
-- Name: tours_rels tours_rels_travel_types_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_rels
    ADD CONSTRAINT tours_rels_travel_types_fk FOREIGN KEY (travel_types_id) REFERENCES public.travel_types(id) ON DELETE CASCADE;


--
-- Name: tours_whats_excluded tours_whats_excluded_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_whats_excluded
    ADD CONSTRAINT tours_whats_excluded_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: tours_whats_included tours_whats_included_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tours_whats_included
    ADD CONSTRAINT tours_whats_included_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.tours(id) ON DELETE CASCADE;


--
-- Name: track_record_page_awards track_record_page_awards__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_awards
    ADD CONSTRAINT track_record_page_awards__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.track_record_page(id) ON DELETE CASCADE;


--
-- Name: track_record_page_case_studies track_record_page_case_studies__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_case_studies
    ADD CONSTRAINT track_record_page_case_studies__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.track_record_page(id) ON DELETE CASCADE;


--
-- Name: track_record_page_press track_record_page_press__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_press
    ADD CONSTRAINT track_record_page_press__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.track_record_page(id) ON DELETE CASCADE;


--
-- Name: track_record_page_segments track_record_page_segments__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_segments
    ADD CONSTRAINT track_record_page_segments__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.track_record_page(id) ON DELETE CASCADE;


--
-- Name: track_record_page_stats track_record_page_stats__parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.track_record_page_stats
    ADD CONSTRAINT track_record_page_stats__parent_id_fkey FOREIGN KEY (_parent_id) REFERENCES public.track_record_page(id) ON DELETE CASCADE;


--
-- Name: vendors_awards vendors_awards_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_awards
    ADD CONSTRAINT vendors_awards_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendors_closed_on vendors_closed_on_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_closed_on
    ADD CONSTRAINT vendors_closed_on_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendors_facilities vendors_facilities_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_facilities
    ADD CONSTRAINT vendors_facilities_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendors_images_gallery vendors_images_gallery_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_images_gallery
    ADD CONSTRAINT vendors_images_gallery_image_id_media_id_fk FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: vendors_images_gallery vendors_images_gallery_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_images_gallery
    ADD CONSTRAINT vendors_images_gallery_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_images_main_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_images_main_id_media_id_fk FOREIGN KEY (images_main_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: vendors_operating_hours vendors_operating_hours_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_operating_hours
    ADD CONSTRAINT vendors_operating_hours_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendors_payment_methods vendors_payment_methods_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_payment_methods
    ADD CONSTRAINT vendors_payment_methods_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendors_rels vendors_rels_dietary_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_rels
    ADD CONSTRAINT vendors_rels_dietary_options_fk FOREIGN KEY (dietary_options_id) REFERENCES public.dietary_options(id) ON DELETE CASCADE;


--
-- Name: vendors_rels vendors_rels_food_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_rels
    ADD CONSTRAINT vendors_rels_food_items_fk FOREIGN KEY (food_items_id) REFERENCES public.food_items(id) ON DELETE CASCADE;


--
-- Name: vendors_rels vendors_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors_rels
    ADD CONSTRAINT vendors_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict tfN9bsXahzmbh9PeiS3x1UsBY8l0BPNtvHEaJm3zusccEgFZhPYve2Y1v8pEbJX

